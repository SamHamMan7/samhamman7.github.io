﻿import {createBattleAssets} from './transport/battle-assets.js';
// Offline transport and entry points for the pinned official Showdown client.
import {parseLocalCommand} from './transport/commands.js';
const {App, MainMenuRoom, TeambuilderRoom, Storage, Dex, BattleLog, Popup} = window;
const state = {ready:false, busy:false, error:'', turn:0, ended:false, request:null};
let engine, policies={}, roomid, packedTeam='', generation=0, mode='play', difficulty='Very Strong';
let tokens={}, timers={}, battleCount=0;
// Champions VGC runs entirely in its own browser worker (simulator + Discharge search).
const CHAMPIONS_FORMAT='gen9championsvgc2026regmc';
let championsValidator=null;

const battleAssets=createBattleAssets({Dex,Storage});

function receive(data) { window.app.receive(data); }
function roomReceive(data) { if(roomid) receive(`>${roomid}\n${data}`); }
function fail(message) { state.error=message; state.busy=false; window.app.addPopupMessage(message); }
function fatal(message) {
  engine?.terminate(); for(const policy of Object.values(policies)) policy.terminate();
  for(const timer of Object.values(timers)) clearTimeout(timer);
  tokens={}; state.aborted=true; state.ready=false; state.busy=false;
  roomReceive('|request|null'); roomReceive('|allowleave|');
  if(roomid) receive(`>${roomid}\n|expire|Local battle stopped`);
  fail(message+' Return Home to start a new battle. Your saved teams are intact.');
}
function workers(format='') {
  generation++; engine?.terminate(); for(const policy of Object.values(policies)) policy.terminate();
  for(const timer of Object.values(timers)) clearTimeout(timer);
  timers={}; tokens={};
  const champions=format===CHAMPIONS_FORMAT;
  engine=new Worker(new URL(champions?'./champions.worker.js':'./engine.worker.js',location.href),{type:'module'});
  policies={};
  engine.onerror=e=>fatal(`Battle engine error: ${e.message}`);
  // Each watch-mode player has an isolated policy worker. No policy process
  // receives both private player views, including when history models are added.
  if(!champions) for(const side of mode==='watch'?['p1','p2']:['p2']) {
    const policy=policies[side]=new Worker(new URL('./ai.worker.js',location.href),{type:'module'});
    policy.onerror=e=>fatal(`AI error: ${e.message}`);
    policy.onmessage=({data})=>{
      clearTimeout(timers[data.side]);
      if(data.type==='decision') {
        engine.postMessage({type:'choose',side:data.side,token:data.token,choice:data.choice});
        state.lastDecisionMs=data.elapsedMs;
        state.neural=data.diagnostics?{backend:!!data.diagnostics.neuralBackend,fallback:data.diagnostics.neuralFallback||null,observationVersion:data.diagnostics.observationVersion||null}:null;
      } else fatal('AI evaluation failed: '+data.message);
    };
  }
  const workerGeneration=generation;
  let incoming=Promise.resolve();
  engine.onmessage=({data})=>{ incoming=incoming.then(async()=>{
    if(workerGeneration!==generation||state.aborted)return;
    if(data.type==='ready') state.ready=true;
    if(data.type==='validation') receive('|popup|'+(data.validation.errors.length ? data.validation.errors.join('\n') : 'Your team is valid for this format.'));
    if(data.type==='error') {
      if(!state.request&&!state.turn) state.ended=true;
      if(data.message.startsWith('[Invalid choice]')) roomReceive('|error|'+data.message);
      else fail(data.message);
    }
    if(data.type==='update') {
      // Team preview/reveal lines give us a head start on image decode without
      // exposing any hidden information to the AI or renderer.
      await battleAssets.prepare({lines:data.lines});
      if(workerGeneration!==generation||state.aborted)return;
      Object.assign(state,{turn:data.view.turn,ended:!!data.view.ended,request:data.view.request});
      if(data.lines.length) roomReceive(data.lines.join('\n'));
      if(data.view.ended) { state.busy=false; roomReceive('|allowleave|'); for(const timer of Object.values(timers)) clearTimeout(timer); }
    }
    if(data.type==='request') {
      tokens[data.side]=data.token;
      if(data.side==='p1') {
        state.request=data.view.request; state.busy=false;
        // Only the human player's private request is used for private prewarming.
        // Never inspect p2's private request here.
        await battleAssets.prepare({request:data.view.request});
        if(workerGeneration!==generation||state.aborted)return;
        // BattleStream has no server rqid: our one-use token supplies that boundary.
        // BattleRoom.add requires each request in a separate protocol message.
        if(mode==='play') roomReceive('|request|'+JSON.stringify({...data.view.request,rqid:data.token,noCancel:true}));
      }
      if(data.side==='p2'||mode==='watch') {
        if(data.view.request?.wait) return;
        policies[data.side].postMessage({...data,difficulty,seed:data.token*7919+generation+(data.side==='p1'?104729:0)});
        clearTimeout(timers[data.side]);
        timers[data.side]=setTimeout(()=>fatal('The local AI took more than 30 seconds.'),30000);
      }
    }
  }).catch(e=>fatal('Battle resource error: '+e.message)); };
}
function start(format, options={}) {
  if(!state.ready&&!state.aborted) return fail('The local battle engine is still loading.');
  if(roomid&&!state.ended&&!state.aborted) return fail('Finish or forfeit the current local battle first.');
  const menu=window.app.rooms[''];
  difficulty=menu.$('button[name=offlineDifficulty]').val()||difficulty||'Very Strong'; mode=options.mode||'play';
  battleAssets.reset();
  Object.assign(state,{ready:false,busy:true,error:'',turn:0,ended:false,aborted:false,request:null});
  if(format===CHAMPIONS_FORMAT&&mode==='watch') { state.busy=false; return fail('Champions VGC supports playing against the AI, not watch mode.'); }
  workers(format);
  roomid=`battle-${format}-${Date.now()}${++battleCount}`;
  const title=mode==='watch'?'AI 1 vs. AI 2':format===CHAMPIONS_FORMAT?'You vs. Discharge':'You vs. Offline AI';
  receive(`>${roomid}\n|init|battle\n|title|${title}`);
  roomReceive('|cantleave|');
  window.app.focusRoom(roomid);
  const teamPaste=mode==='watch'?'':Storage.exportTeam(Storage.unpackTeam(packedTeam));
  engine.postMessage({type:'start',options:{
    format,teamPaste,autoTeamP1:mode==='watch',playerNames:mode==='watch'?{p1:'AI 1',p2:'AI 2'}:{p1:'You',p2:'Offline AI'},
    ...(format===CHAMPIONS_FORMAT?{difficulty,informationMode:'bo3'}:{}),
    seed:Array.from(crypto.getRandomValues(new Uint16Array(4))),
  }});
}
function localSend(message) {
  for(const part of message.split('\n')) {
    const cmd=parseLocalCommand(part);
    if(cmd.type==='team') packedTeam=cmd.team;
    else if(cmd.type==='start') start(cmd.format);
    else if(cmd.type==='validate'&&cmd.format===CHAMPIONS_FORMAT) {
      if(!championsValidator){championsValidator=new Worker(new URL('./champions.worker.js',location.href),{type:'module'});championsValidator.onmessage=({data})=>{if(data.type==='validation')receive('|popup|'+(data.validation.errors.length?data.validation.errors.join('\n'):'Your team is valid for this format.'));};}
      championsValidator.postMessage({type:'validate',paste:Storage.exportTeam(Storage.unpackTeam(packedTeam)),format:cmd.format});
    }
    else if(cmd.type==='validate') engine.postMessage({type:'validate',paste:Storage.exportTeam(Storage.unpackTeam(packedTeam)),format:cmd.format});
    else if(cmd.type==='choice'&&cmd.room===roomid&&mode==='play') {
      if(cmd.rqid!==null&&cmd.rqid!==tokens.p1) continue;
      if(tokens.p1===undefined) continue;
      const token=tokens.p1; delete tokens.p1; state.busy=true;
      engine.postMessage({type:'choose',side:'p1',token,choice:cmd.choice});
    } else if(cmd.type==='forfeit'&&cmd.room===roomid) engine.postMessage({type:'forfeit'});
    else if(cmd.type==='rooms') receive('|queryresponse|rooms|'+JSON.stringify({official:[],chat:[],userCount:1,battleCount:state.ended?0:1}));
    else if(cmd.type==='unsupported') fail('This command needs the online Showdown service. Local battles and the teambuilder work offline.');
  }
}
Dex.resourcePrefix='/'; Dex.fxPrefix='/fx/';
// The pinned client builds move buttons from a stale request after its active
// Pokemon faints (double KOs, instant playback). Render those buttons without
// effectiveness tags instead of throwing and stopping the local battle.
if(window.BattleTooltips){const moveTypeText=window.BattleTooltips.prototype.getMoveTypeText;
window.BattleTooltips.prototype.getMoveTypeText=function(move,value,forMaxMove){if(value&&!value.pokemon){let type=move.type;try{type=this.getMoveType(move,value,forMaxMove)[0];}catch{}return [type,''];}return moveTypeText.call(this,move,value,forMaxMove);};}
// Browser edition: enforce bundled static graphics and silent play.
const nativePrefs=Dex.prefs.bind(Dex);
Dex.prefs=(key)=>['bwgfx','noanim','nogif'].includes(key)?true:nativePrefs(key);
Storage.prefs('mute',true);
if(window.BattleSound){window.BattleSound.setMute(true);window.BattleSound.getSound=()=>undefined;}

const getSpriteData=Dex.getSpriteData.bind(Dex);
Dex.getSpriteData=function(...args) {
  const data=getSpriteData(...args), fallback=window.OfflineResourceFallbacks||{};
  if(Object.hasOwn(fallback,data.url)) Object.assign(data,{url:fallback[data.url],w:96,h:96,pixelated:true});
  const cry='/'+data.cryurl?.replace(/^\//,'');
  if(Object.hasOwn(fallback,cry)) data.cryurl=fallback[cry];
  data.cryurl='';
  return data;
};
const getTypeIcon=Dex.getTypeIcon.bind(Dex);
Dex.getTypeIcon=(...args)=>getTypeIcon(...args).replace(/%3f%3f%3f\.png/ig,'unknown.png');
Storage.loadRemoteTeams=after=>after?.();
TeambuilderRoom.prototype.tryLoadFormatResource=function() {};
App.prototype.initializeCCPAIntercept=function() {};
App.prototype.connect=function() {
  this.socket={readyState:1,send:localSend,close(){}}; this.isDisconnected=false;
  queueMicrotask(()=>{
    this.trigger('init:socketopened');
    this.user.loaded=true;
    this.user.set({name:'You',userid:'you',named:true,avatar:'1'});
    this.receive('|formats|,1|Offline Practice|[Gen 9 Champions] VGC 2026 Reg M-C,e|[Gen 9] OU,e|[Gen 9] Random Battle,f|[Gen 9] Random Doubles Battle,f');
    for(const message of this.sendQueue||[]) localSend(message);
    this.sendQueue=[]; this.resize();
  });
};
const OfflineDifficultyPopup=Popup.extend({
  type:'semimodal',
  events:{'click button[name=selectDifficulty]':'selectDifficulty'},
  initialize(data) {
    this.sourceEl=data.sourceEl;
    const current=data.current||'Very Strong';
    const options=['Medium','Strong','Very Strong'].map(value=>
      `<li><button name="selectDifficulty" value="${value}" class="option${value===current?' cur':''}">${value}</button></li>`
    ).join('');
    this.$el.html(`<ul class="popupmenu">${options}</ul>`);
  },
  selectDifficulty(event) {
    const value=event.currentTarget.value;
    difficulty=value;
    this.sourceEl.val(value).html(BattleLog.escapeHTML(value));
    this.close();
  },
});
MainMenuRoom.prototype.events={...MainMenuRoom.prototype.events,'click button.offline-difficulty':'selectOfflineDifficulty'};
MainMenuRoom.prototype.selectOfflineDifficulty=function(event) {
  event.preventDefault();
  const source=window.jQuery(event.currentTarget);
  window.app.addPopup(OfflineDifficultyPopup,{sourceEl:source,current:source.val()});
};
function offlineMenu(menu) {
  menu.$('button[name=search]').html('<strong>Offline Battle</strong><br /><small>Play against local AI</small>');
  menu.$('input[name=private]').closest('p').remove();
  menu.$('button[value=ladder],button[value="/smogtours"],button[value=battles],button[name=finduser],button[value="/friends"]').closest('p').remove();
  menu.$('.rightmenu,.activitymenu').empty();
  // The AI's competitive opponent pool is intentionally private to the engine.
  // Do not expose those teams in Storage, Teambuilder, or a main-menu selector.
  menu.$('select[name=offlineOpponent]').closest('p').remove();
  if(!menu.$('button.offline-difficulty').length) {
    menu.$('button[name=search]').closest('p').before(
      `<p><label class="label">AI level:</label><button class="select offline-difficulty" name="offlineDifficulty" value="${BattleLog.escapeHTML(difficulty)}">${BattleLog.escapeHTML(difficulty)}</button></p>`
    );
    menu.$('button[name=search]').closest('p').after('<p><button class="button" name="offlineWatch">Watch AI Battle</button></p>');
  }
}
const menuInitialize=MainMenuRoom.prototype.initialize;
MainMenuRoom.prototype.initialize=function() {
  menuInitialize.apply(this,arguments); offlineMenu(this);
  window.app.user.on('saveteams',()=>offlineMenu(this));
};
const updateSearch=MainMenuRoom.prototype.updateSearch;
MainMenuRoom.prototype.updateSearch=function() { updateSearch.apply(this,arguments); offlineMenu(this); };
const updateFormats=MainMenuRoom.prototype.updateFormats;
MainMenuRoom.prototype.updateFormats=function() { updateFormats.apply(this,arguments); offlineMenu(this); };
function selectedBattle(menu,watch=false) {
  const format=menu.$('button[name=format]').val(), index=menu.$('button[name=team]').val();
  if(!watch&&!window.BattleFormats[format]?.team&&(index===''||!Storage.teams[index])) return fail('Please select a team in the Showdown team selector.');
  packedTeam=watch?'':(Storage.teams[index]?.team||'');

  start(format,{mode:watch?'watch':'play'});
}
MainMenuRoom.prototype.search=function() { selectedBattle(this); };
MainMenuRoom.prototype.offlineWatch=function() { selectedBattle(this,true); };

// Keep user teams and AI opponent teams in separate stores. The AI pool now
// exists only inside the engine worker/session bundle, never the client/Storage.
Storage.whenTeamsLoaded(()=>{
  if(!localStorage.getItem('offline-showdown-native-migration')) {
    let previous=[];
    try { previous=JSON.parse(localStorage.getItem('offline-showdown-teams-v1')||'[]'); } catch {}
    for(const team of previous) {
      if(!team.paste) continue;
      const packed=Storage.packTeam(Storage.importTeam(team.paste));
      if(!Storage.teams.some(t=>t.team===packed)) Storage.teams.push({name:team.name||'Imported team',format:'gen9ou',folder:'',team:packed,capacity:6});
    }
    Storage.saveTeams(); localStorage.setItem('offline-showdown-native-migration','1');
  }
  if(!localStorage.getItem('offline-showdown-private-ai-pool-v2')) {
    // A saved team may have been edited without being renamed. Never delete it
    // by a bundled sample's name. New AI teams remain private to the engine;
    // existing user storage is preserved, including previously saved samples.
    localStorage.setItem('offline-showdown-private-ai-pool-v2','1');
  }
});
window.app=new App(); workers();

if('serviceWorker' in navigator&&!location.hostname.endsWith('androidplatform.net')) navigator.serviceWorker.register('/sw.js').catch(e=>{state.cacheError=e.message;});
Object.defineProperty(window,'offlinePractice',{value:{
  snapshot:()=>JSON.parse(JSON.stringify({...state,roomid,mode,client:'smogon/pokemon-showdown-client'})),
  warmAssets:()=>battleAssets.snapshot(),
}});

