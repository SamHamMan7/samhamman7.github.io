import corpus from '../data/champions-competitive-teams.json' with {type:'json'};
import {hypothesizePosition,opponentBuilds} from './champions-damage.mjs';
import {toID} from './champions-public.mjs';
import {seededChampionsRandom} from './champions-search.mjs';
export function createBeliefWorlds(publicPosition,dex,{mode='bo3'}={}){
  const worlds=[];
  const speciesKey=name=>{const s=dex.species.get(name);return toID(s.isMega?s.baseSpecies:s.name||name);};
  if(mode==='bo1')for(const entry of corpus.entries){
    if(!publicPosition.teams[1].every(m=>entry.team.some(s=>speciesKey(s.species)===speciesKey(m.species))))continue;
    const unseen=publicPosition.teams[1].filter(m=>!m.revealed).length,needed=Math.max(0,publicPosition.teams[0].length-publicPosition.teams[1].filter(m=>m.revealed).length);
    const choose=(n,k)=>{let x=1;for(let i=1;i<=k;i++)x=x*(n-i+1)/i;return Math.round(x);},subsets=unseen>needed?choose(unseen,needed):1;
    for(let subset=0;subset<subsets;subset++){
    const q=hypothesizePosition(publicPosition,subset);let valid=true;
    for(const m of q.teams[1]){
      const set=entry.team.find(s=>speciesKey(s.species)===speciesKey(m.species));
      if(m.moves.some(id=>!set.moves.map(toID).includes(id))||m.knowledge?.item&&m.item&&toID(m.item)!==toID(set.item)||m.knowledge?.ability&&toID(m.ability)!==toID(set.ability)){valid=false;break;}
      const original=publicPosition.teams[1].find(x=>x.species===m.species);
      m.build={nature:set.nature,points:{...set.evs}};m.nature=set.nature;
      m.stats=Object.fromEntries(['hp','atk','def','spa','spd','spe'].map(k=>[k,dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},dex.species.get(m.species).baseStats,{nature:set.nature,evs:set.evs,level:50},k)]));
      m.moves=[...set.moves].map(toID);m.item=original?.knowledge?.item?original.item:set.item;m.ability=original?.knowledge?.ability?original.ability:set.ability;
    }
    if(valid)worlds.push({id:`corpus-${entry.id}-bring-${subset}`,position:q,weight:1,source:'public-corpus-prior'});
    }
  }
  const corpusCount=worlds.length;if(corpusCount)worlds.forEach(w=>w.weight=.9/corpusCount);
  const count=Math.max(6,...publicPosition.teams[1].map(m=>opponentBuilds(m).length));
  for(let i=0;i<count;i++){
    const q=hypothesizePosition(publicPosition,i);
    for(const m of q.teams[1])if(Object.values(m.build.points).every(n=>n===0)&&m.nature==='Serious'){
      // Showdown's missing-investment guard rejects Serious + all-zero points.
      // A neutral zero-investment hypothesis must be explicit; a publicly
      // fixed Serious Nature instead needs at least one legal stat point.
      if(!m.knowledge?.nature){m.nature=m.build.nature='Hardy';}
      else {m.build.points.hp=1;m.stats.hp=dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},dex.species.get(m.species).baseStats,{nature:m.nature,evs:m.build.points,level:50},'hp');}
    }
    for(const m of q.teams[1])if(!m.moves.length){
      // Public species/corpus prior only. A hypothetical move is labeled as
      // an assumption, never as a revealed move or a hidden simulator read.
      const set=corpus.entries.flatMap(e=>e.team).find(s=>speciesKey(s.species)===speciesKey(m.species));
      m.moves=set?set.moves.map(toID):['protect'];
    }
    // Coordinate hypothetical held items across the whole roster. Item Clause
    // applies to starting builds, and unknown Assault Vest + Status proposals
    // should not masquerade as complete competitive sets. Publicly changed
    // items are retained, since Trick can create duplicates during a battle.
    const used=new Set(q.teams[1].filter(m=>m.knowledge?.item&&m.item).map(m=>toID(m.item)));
    for(const m of q.teams[1])if(!m.knowledge?.item){if(toID(m.item)==='assaultvest'&&m.moves.some(id=>dex.moves.get(id).category==='Status')||m.item&&used.has(toID(m.item)))m.item='';if(m.item)used.add(toID(m.item));}
    worlds.push({id:`archetype-${i}`,position:q,weight:(corpusCount?.1:1)/count,source:'public-archetype'});
  }
  const sum=worlds.reduce((s,w)=>s+w.weight,0);worlds.forEach(w=>w.weight/=sum);
  return {schema:'champions-public-beliefs-v1',mode,worlds,evidence:[],revision:0};
}
export function deterministicBeliefWorlds(beliefs,count){
  // Identical physical hypotheses share probability mass, not repeated seats.
  // Preserve hypothetical brought benches as part of the physical signature.
  const unique=new Map();for(const w of beliefs.worlds){const key=JSON.stringify(w.position.teams.map(t=>t.map(m=>[m.species,m.hp,m.stats,m.nature,m.item,m.ability,m.moves,m.build])));if(unique.has(key))unique.get(key).weight+=w.weight;else unique.set(key,{...w});}
  const all=[...unique.values()],out=[];
  for(let i=0;i<Math.min(count,all.length);i++){let mass=(i+.5)/Math.min(count,all.length),pick=all.at(-1);for(const w of all){mass-=w.weight;if(mass<=0){pick=w;break;}}if(!out.includes(pick))out.push(pick);}
  for(const w of all)if(out.length<Math.min(count,all.length)&&!out.includes(w))out.push(w);
  const mass=out.reduce((s,w)=>s+w.weight,0);return out.map(w=>({...w,weight:w.weight/mass}));
}
export function updateBeliefs(beliefs,evidence,dex){
  // Evidence contains only observations/likelihoods supplied by a public
  // observer. No actual simulator set, Nature or stat array is accepted.
  if(!['move','item','ability','speed','damage'].includes(evidence.kind))throw Error('Unsupported public belief evidence');
  const next=structuredClone(beliefs);next.evidence.push(Object.fromEntries(['kind','species','value','otherSpecies','faster','comparable','likelihoods'].filter(k=>evidence[k]!==undefined).map(k=>[k,structuredClone(evidence[k])])));next.revision++;
  for(const w of next.worlds){
    const a=w.position.teams[1].find(m=>toID(m.species)===toID(evidence.species));let likelihood=1;
    if(a&&['move','item','ability'].includes(evidence.kind)){
      const compatible=evidence.kind==='move'?a.moves.includes(toID(evidence.value)):toID(a[evidence.kind])===toID(evidence.value);likelihood=compatible?1:.01;
    }
    if(a&&evidence.kind==='speed'&&evidence.comparable===true&&!evidence.likelihoods){const other=[...w.position.teams[0],...w.position.teams[1]].find(m=>toID(m.species)===toID(evidence.otherSpecies));if(other)likelihood=(evidence.faster?a.stats.spe>=other.stats.spe:a.stats.spe<=other.stats.spe)?1:.05;}
    if(evidence.kind==='damage'||evidence.kind==='speed'&&evidence.comparable===true&&evidence.likelihoods){
      // An oracle-derived likelihood table can account for public roll ranges,
      // screens/items/stages. Unknown or ambiguous attribution is left neutral.
      const probability=evidence.likelihoods?.[w.id];if(probability!==undefined){if(!Number.isFinite(probability)||probability<0||probability>1)throw Error('Invalid public damage likelihood');likelihood=Math.max(.001,probability);}
    }
    w.weight*=likelihood;
  }
  const total=next.worlds.reduce((s,w)=>s+w.weight,0);next.worlds.forEach(w=>w.weight/=total);return next;
}
export function sampleBeliefWorlds(beliefs,count,seed){
  const random=seededChampionsRandom(seed),out=[];
  for(let n=0;n<count;n++){let x=random(),chosen=beliefs.worlds.at(-1);for(const w of beliefs.worlds){x-=w.weight;if(x<=0){chosen=w;break;}}out.push(chosen);}
  return out;
}
