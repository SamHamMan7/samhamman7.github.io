// Experimental V3 contract. Actions address public roster tokens explicitly.
// No selected-move ID embedding: mechanics and actor/recipient context carry
// the action meaning. Shared slot processing permits consistent ally swaps.
import {encodeSearchState,SEARCH_FEATURES,featureHash} from './champions-search-features.mjs';
import {megaForm} from './champions-public.mjs';
export const ACTOR_FEATURES=Object.freeze({schema:'champions-actor-features-v3',tokens:12,hashSize:1024,monCat:6,monNum:48,field:16,actionLinks:3,actionNum:64,pairNum:8});
export const ACTOR_INPUTS=['token_ids','token_num','field','action_links','action_num','pair_num'];
const stats=['hp','atk','def','spa','spd','spe'];
const types=['Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy'];
const targets=['normal','self','adjacentAlly','adjacentAllyOrSelf','adjacentFoe','any','allAdjacent','allAdjacentFoes','all','allySide','foeSide'];
const id=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
const token=(p,side,index)=>index>=0&&p.teams[side][index]?side*6+index:12;
const rangeCache=new WeakMap();
function publicRanges(dex,m,own){
  if(own)return stats.map(k=>[m.stats[k]||0,m.stats[k]||0]);
  let cache=rangeCache.get(dex);if(!cache)rangeCache.set(dex,cache=new Map());
  const nature=m.knowledge?.nature?m.nature:'',key=id(m.species)+'/'+id(nature);
  if(!cache.has(key)){
    const natures=nature?[nature]:dex.natures.all().map(n=>n.name),base=dex.species.get(m.species).baseStats;
    const stat=(n,k,points)=>dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},base,{nature:n,level:50,evs:{[k]:points}},k);
    cache.set(key,stats.map(k=>[Math.min(...natures.map(n=>stat(n,k,0))),Math.max(...natures.map(n=>stat(n,k,32)))]));
  }
  return cache.get(key);
}
export function encodeActorState(p,dex){
  const state=encodeSearchState(p,SEARCH_FEATURES);
  state.field[1]=Number(!!p.field.trickroom);
  for(let side=0;side<2;side++)for(let i=0;i<6;i++){
    const m=p.teams[side][i],n=state.token_num[side*6+i];
    if(!m){n.push(...Array(16).fill(0));continue;}
    for(const [index,key] of [[4,'nature'],[5,'item'],[6,'ability'],[30,'sheet']])n[index]=Number(index!==30&&side===0||!!m.knowledge?.[key]);
    const ranges=publicRanges(dex,m,side===0);
    // A public estimate/range replaces synthetic opponent stats, independent
    // of any chosen belief-world build or inaccessible true investment.
    for(let k=0;k<6;k++)n[7+k]=(ranges[k][0]+ranges[k][1])/600;
    n.push(...ranges.flat().map(x=>x/300),...['protect','substitute','imprison','unburden'].map(x=>Number(m.volatiles?.includes(x))));
  }
  return state;
}
export function canonicalActorIdentity(p,j,side=0){
  return JSON.stringify([...j.actions].sort((a,b)=>a.slot-b.slot).map(a=>({slot:a.slot,actor:p.active[side][a.slot],type:a.type,move:a.type==='move'?id(a.move?.id||a.move?.move):'',target:a.target||0,destination:a.type==='switch'?a.choice-1:null,mega:!!a.mega})));
}
export function encodeActorActions(p,joints,side,dex){
  const action_links=[],action_num=[],pair_num=[];
  for(const j of joints){
    const actions=[0,1].map(slot=>j.actions.find(a=>a.slot===slot)||{slot,type:'pass'}),moves=actions.map(a=>a.type==='move'?dex.moves.get(a.move.id||a.move.move):null),links=[],nums=[];
    for(let slot=0;slot<2;slot++){
      const a=actions[slot],m=moves[slot],actor=token(p,side,p.active[side][slot]);
      let target=12;
      if(a.target>0)target=token(p,1-side,p.active[1-side][a.target-1]);
      else if(a.target<0)target=token(p,side,p.active[side][-a.target-1]);
      else if(m?.target==='self')target=actor;
      links.push([actor,target,a.type==='switch'?token(p,side,a.choice-1):12]);
      const mid=m?.id||'',flags=m?.flags||{},mon=p.teams[side][p.active[side][slot]];
      const form=a.mega&&mon&&(side===0||mon.knowledge?.item)?megaForm(dex,mon):null,before=form?dex.species.get(mon.species):null,after=form?dex.species.get(form):null,ability=id(after?.abilities['0']);
      nums.push([Number(a.type==='move'),Number(a.type==='switch'),Number(a.type==='pass'),Number(!!a.mega),(m?.basePower||0)/200,(typeof m?.accuracy==='number'?m.accuracy:100)/100,(m?.priority||0)/8,Number(m?.category==='Physical'),Number(m?.category==='Special'),Number(m?.category==='Status'),...types.map(t=>Number(m?.type===t)),...targets.map(t=>Number(m?.target===t)),Number(!!m?.stallingMove),Number(['followme','ragepowder'].includes(mid)),Number(mid==='helpinghand'),Number(mid==='tailwind'),Number(mid==='trickroom'),Number(mid==='fakeout'),Number(!!m?.heal||!!m?.drain),Number(!!m?.boosts),Number(!!m?.self?.boosts),Number(!!m?.status),Number(!!m?.volatileStatus),Number(!!m?.selfSwitch),Number(!!flags.contact),Number(!!flags.sound),...stats.map(k=>after?(after.baseStats[k]-before.baseStats[k])/100:0),Number(!!after?.types.includes(m?.type)),Number(ability==='drought'),Number(ability==='drizzle'),Number(['pixilate','aerilate','refrigerate'].includes(ability)),Number(['toughclaws','adaptability'].includes(ability))]);
    }
    const protect=m=>!!m?.stallingMove,redirect=m=>['followme','ragepowder'].includes(m?.id),attack=m=>m&&m.category!=='Status',spread=m=>['allAdjacent','allAdjacentFoes'].includes(m?.target);
    action_links.push(links);action_num.push(nums);
    pair_num.push([side,Number(actions[0].target>0&&actions[0].target===actions[1].target),Number(moves.some(spread)),Number(moves.some(m=>m?.target==='allAdjacent')),Number(moves.every(protect)),Number(redirect(moves[0])&&attack(moves[1])||redirect(moves[1])&&attack(moves[0])),Number(actions[0].type==='switch'&&protect(moves[1])||actions[1].type==='switch'&&protect(moves[0])),Number(actions.some(a=>a.target<0))]);
  }
  return {action_links,action_num,pair_num,identities:joints.map(j=>canonicalActorIdentity(p,j,side))};
}
