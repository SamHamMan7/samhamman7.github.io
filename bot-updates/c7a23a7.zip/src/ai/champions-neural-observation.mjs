// Separate Champions contract. No imports from singles observations/models.
import {toID} from './champions-public.mjs';
export const SCHEMA='champions-neural-observation-v1';
export const FORMAT='gen9championsvgc2026regmc';
export const CAT=['kind','side','slot','identity','species','status','item','ability','move1','move2','move3','move4','volatile1','volatile2','volatile3','volatile4','actor','target','effect','result'];
export const NUM=['hp','activeA','activeB','benchAvailable','movesComplete','megaCapable','megaEvolved','sideMegaUsed','acted','turnsSinceSwitch','protectStreak','atk','def','spa','spd','spe','accuracy','evasion','turn','trickroom','tailwindOwn','tailwindOpp','forceA','forceB',...['reflect','lightscreen','auroraveil','safeguard','spikes','stealthrock','toxicspikes','stickyweb'].flatMap(s=>[s+'Own',s+'Opp'])];
export const TOKENS=29,BUCKETS=4096;
const identity=s=>String(s||'').replace(/^(p[12])[ab]:/,'$1:');
const getHP=s=>{if(/fnt/.test(s))return 0;const m=String(s).match(/^(\d+)\/(\d+)/);return m&&+m[2]>0?+m[1]/+m[2]:null;};
export function hashCategory(field,value){if(value==null)return 0;let h=2166136261;for(const c of `${field}:${String(value)||'<none>'}`)h=Math.imul(h^c.charCodeAt(0),16777619);return 1+((h>>>0)%(BUCKETS-1));}
export function makeContract(dex) {
  return {schema:SCHEMA,format:FORMAT,tokens:TOKENS,hashBuckets:BUCKETS,categorical:CAT,numeric:NUM,history:16,
    moves:['<unknown>',...dex.moves.all().filter(m=>m.exists).map(m=>m.id).sort()],
    species:['<unknown>',...dex.species.all().filter(s=>s.exists).map(s=>s.id).sort()],
    types:['move','switch','pass'],targets:['automatic','own-a','own-b','foe-a','foe-b'],mega:['none','slot-a','slot-b'],retroKnown:false};
}

export function encodeChampionsObservation(observation,side,{dex,request=null,phase='turn'}={}) {
  if(observation.schema!=='champions-public-spectator-v1'||observation.format!==FORMAT||!['p1','p2'].includes(side))throw Error('Champions neural observation contract mismatch');
  if(request&&request.side?.id!==side)throw Error('Champions neural firewall: opposing request');
  const foe=side==='p1'?'p2':'p1',order=[side,foe];
  const cats=Array.from({length:TOKENS},()=>Array(CAT.length).fill(0)),nums=Array.from({length:TOKENS},()=>Array(NUM.length).fill(0)),known=nums.map(r=>r.map(()=>false)),mask=Array(TOKENS).fill(false);
  const c=(t,k,v)=>{cats[t][CAT.indexOf(k)]=hashCategory(k,v);};
  const n=(t,k,v)=>{if(v==null)return;const j=NUM.indexOf(k);if(j<0||!Number.isFinite(Number(v)))throw Error('Invalid neural numeric feature');nums[t][j]=Number(v);known[t][j]=true;};
  const history=observation.publicHistory||[],bindings=new Map(),teams=[];
  // Explicit identity-bound disclosures override the older summary tracker's
  // generic [of] handling. In particular Trace's [of] is NOT Trace's holder.
  const disclosures=new Map();
  const disclose=(who,key,value)=>{if(!/^p[12][ab]?: /.test(who||''))return;const id=identity(who),r=disclosures.get(id)||{};r[key]=value;disclosures.set(id,r);};
  for(const e of history){const a=e.args||[];
    if(e.type==='-ability')disclose(a[0],'ability',a[1]);
    if(e.type==='-item'||e.type==='-enditem')disclose(a[0],'item',e.type==='-enditem'?'':a[1]);
    if(e.type==='-mega'){disclose(a[0],'item',a[2]??null);disclose(a[0],'ability',null);}
    if(e.type!=='-ability'){const from=a.find(s=>/^\[from\] (item|ability): /.test(s));if(from){const m=from.match(/^\[from\] (item|ability): (.*)$/);disclose(a.find(s=>s.startsWith('[of] '))?.slice(5)||a[0],m[1],m[2]);}}
  }
  for(const [teamIndex,s] of order.entries()) {
    const publicSide=observation.publicTeams[s],entries=publicSide.roster.map(m=>({
      ...Object.fromEntries(['ident','species','status','boosts','volatiles','acted','lastMove','switchTurn','protectStreak','revealed','hp','movesComplete','item','ability','ots'].filter(k=>m[k]!==undefined).map(k=>[k,m[k]])),
      movesRevealed:[...(m.movesRevealed||[])]}));
    const active=(publicSide.active||[-1,-1]).map(i=>entries[i]||null);
    // Preview species are public but unobserved entries are NOT known brought/bench.
    for(const species of publicSide.previewSpecies||[])if(!entries.some(m=>toID(dex.species.get(m.species).baseSpecies||m.species)===toID(dex.species.get(species).baseSpecies||species)))entries.push({species});
    if(teamIndex===0&&request)for(const [i,m] of (request.side.pokemon||[]).entries()) {
      let entry=entries.find(p=>identity(p.ident)===identity(m.ident));
      const species=m.details?.split(',')[0];
      if(!entry){const matches=entries.filter(p=>!p.ident&&toID(p.species)===toID(species));entry=matches.length===1?matches[0]:null;}
      if(!entry){entry={};entries.push(entry);}Object.assign(entry,{ident:identity(m.ident),species,hp:getHP(m.condition||''),status:m.condition?.split(' ')[1]||'',movesRevealed:m.moves||[],movesComplete:true,item:m.item??null,ability:m.ability??m.baseAbility??null,privateOwn:true,brought:true});
      if(m.active&&i<2)active[i]=entry;
      if(i<2&&request.active?.[i])entry.canMega=!!request.active[i].canMegaEvo;
    }
    // At most 6 named entities; fail rather than silently alias duplicate identities.
    if(entries.length>6)throw Error('Ambiguous/oversized neural roster');
    teams.push({entries,active});
    for(const [i,m] of entries.entries()) {
      const t=teamIndex*6+i;mask[t]=true;
      if(m.ident)bindings.set(identity(m.ident),`${teamIndex}:${i}`);
      const slot=active.indexOf(m),observed=!!m.revealed,slotKnown=observed||!!m.privateOwn;
      c(t,'kind','pokemon');c(t,'side',teamIndex);c(t,'identity',i);c(t,'slot',slot>=0?slot:slotKnown?'bench':null);c(t,'species',toID(m.species));
      c(t,'status',m.status??null);
      for(const k of ['item','ability']){const d=disclosures.get(identity(m.ident));c(t,k,m.privateOwn?m[k]:d&&Object.hasOwn(d,k)?d[k]:(m.ots?m[k]:null));}
      for(let j=0;j<4;j++){c(t,'move'+(j+1),(m.movesRevealed||[]).map(toID).sort()[j]??(m.movesComplete?'':null));c(t,'volatile'+(j+1),m.volatiles?[...m.volatiles].sort()[j]??'':null);}
      c(t,'effect',m.lastMove??null);
      n(t,'hp',m.hp);n(t,'activeA',slotKnown?slot===0:null);n(t,'activeB',slotKnown?slot===1:null);
      n(t,'benchAvailable',m.privateOwn||observed?slot<0&&m.hp>0:null);
      n(t,'movesComplete',m.movesComplete??null);n(t,'megaCapable',m.canMega??null);
      n(t,'megaEvolved',m.species?!!dex.species.get(m.species).isMega:null);n(t,'sideMegaUsed',publicSide.megaUsed??null);
      n(t,'acted',m.acted??null);n(t,'turnsSinceSwitch',m.switchTurn!=null?Math.min(10,observation.turn-m.switchTurn)/10:null);n(t,'protectStreak',m.protectStreak!=null?Math.min(5,m.protectStreak)/5:null);
      for(const boost of ['atk','def','spa','spd','spe','accuracy','evasion'])n(t,boost,m.boosts?(m.boosts[boost]||0)/6:null);
    }
  }
  const f=12;mask[f]=true;c(f,'kind','field');c(f,'effect',observation.field?.weather??null);c(f,'result',observation.field?.terrain??null);c(f,'slot',phase);
  n(f,'turn',Math.min(observation.turn||0,100)/100);n(f,'trickroom',observation.field?.trickroom??null);
  for(const [i,s] of order.entries())for(const condition of ['tailwind','reflect','lightscreen','auroraveil','safeguard','spikes','stealthrock','toxicspikes','stickyweb'])n(f,condition+(i?'Opp':'Own'),observation.publicTeams[s].conditions?.includes(condition)??null);
  // Public replacement labels do not establish an exact force-switch request.
  if(request){n(f,'forceA',!!request.forceSwitch?.[0]);n(f,'forceB',!!request.forceSwitch?.[1]);}
  const events=history.filter(e=>['move','switch','drag','replace','cant','faint','-mega','-fail','-immune','-activate','-damage','-heal','-start','-end','-sidestart','-sideend','-fieldstart','-fieldend','-weather'].includes(e.type)).slice(-16);
  events.forEach((e,j)=>{const t=13+j,a=e.args||[];mask[t]=true;c(t,'kind',e.type);c(t,'actor',bindings.get(identity(a[0]))??null);c(t,'target',e.type==='move'?bindings.get(identity(a[2]))??null:null);
    c(t,'effect',e.type==='move'?toID(a[1]):['switch','drag','replace'].includes(e.type)?toID(a[1]?.split(',')[0]):toID(a[1]||a[0]));
    c(t,'result',e.type==='cant'?toID(a[1]):e.type);n(t,'turn',j/16);
    if(['-damage','-heal'].includes(e.type))n(t,'hp',getHP(a[1]||''));
  });
  return {schema:SCHEMA,categorical:cats,categoricalKnown:cats.map(r=>r.map(v=>v!==0)),numeric:nums,known,tokenMask:mask};
}

export function encodeLabels(row,contract) {
  const label={type:[-1,-1],move:[-1,-1],switch:[-1,-1],target:[-1,-1],mega:-1,value:row.masks.knownOutcome?row.outcome:null};
  for(let k=0;k<2;k++) {
    const a=row.labels.actions?.[k];
    if(row.masks[`knownActionSlot${k+1}`]&&a){label.type[k]=contract.types.indexOf(a.type);
      const key=a.type==='move'?'move':'switch',vocab=a.type==='move'?contract.moves:contract.species;
      if(a.type!=='pass'){const index=vocab.indexOf(toID(a.move||a.destination?.species));if(index>0)label[key][k]=index;}
    }
    if(row.masks[`knownTargetSlot${k+1}`]&&a?.type==='move'&&a.target)label.target[k]=a.target.mode==='automatic'?0:(a.target.side===row.side?1:3)+a.target.slot;
    if(row.masks[`knownMegaSlot${k+1}`]&&row.labels.mega?.[k]===true){if(label.mega!==-1)throw Error('Two observed Mega activations');label.mega=k+1;}
  }
  return label;
}
