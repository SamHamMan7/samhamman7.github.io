// Separate experimental contract; existing models/adapters are not modified.
import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import * as ort from 'onnxruntime-node';
import {neuralFeeds} from './champions-neural.mjs';
import {SCHEMA,FORMAT,TOKENS,CAT,NUM,encodeChampionsObservation} from './champions-neural-observation.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
import {calibrateCandidateFamilies} from './champions-policy-calibration.mjs';
import {toID} from './champions-public.mjs';
import {matchupSnapshot,legalMatchupCandidates,matchupID,MATCHUP_SCHEMA,MATCHUP_FEATURES,assertMatchupLayout} from './champions-matchup-candidates.mjs';
import {matchupImplementationHash} from './champions-matchup-version.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
const logSoftmax=a=>{const m=Math.max(...a),z=m+Math.log(a.reduce((s,x)=>s+Math.exp(x-m),0));return a.map(x=>x-z);};
export function matchupFeeds(encoded,candidates){const count=candidates.mask[0].length;return {...neuralFeeds(encoded),candidate_features:new ort.Tensor('float32',Float32Array.from(candidates.features.flat(2)),[1,2,count,MATCHUP_FEATURES.length]),candidate_mask:new ort.Tensor('bool',Uint8Array.from(candidates.mask.flat(),Number),[1,2,count])};}
export function rankMatchupActions(legal,output,contract,request,candidates){
 const types=logSoftmax(Array.from(output.types)),mega=logSoftmax(Array.from(output.mega)),count=candidates.mask[0].length;
 const scores=[0,1].map(k=>candidates.mask[k].some(Boolean)?logSoftmax(Array.from(output.candidate_scores).slice(k*count,(k+1)*count).map((v,i)=>candidates.mask[k][i]?v:-Infinity)):Array(count).fill(-Infinity));
 const sw=[0,1].map(k=>logSoftmax(Array.from(output.switches).slice(k*contract.species.length,(k+1)*contract.species.length)));
 const ranked=legal.map(j=>{
  const t=j.actions.map(a=>contract.types.indexOf(a.type)),components={type:types[t[0]*3+t[1]],move:[0,0],switch:[0,0],target:0,mega:0};let activation=0;
  for(const [k,a]of j.actions.entries()){
   if(a.type==='move'){const i=candidates.ids[k].indexOf(matchupID(a.move.id||a.move.move,a.target||0));if(i<0||!candidates.mask[k][i])throw Error('Legal move+target absent from public candidate features');components.move[k]=scores[k][i];if(a.mega)activation=k+1;}
   if(a.type==='switch'){const id=toID(request.side.pokemon[a.choice-1].details.split(',')[0]),i=contract.species.indexOf(id);if(i<1)throw Error('Switch outside matchup vocabulary');components.switch[k]=sw[k][i];}
  }
  components.mega=mega[activation];const score=Object.values(components).flat().reduce((s,x)=>s+x,0);if(!Number.isFinite(score))throw Error('Nonfinite matchup policy');return {...j,score,components};
 });return calibrateCandidateFamilies(ranked);
}
export async function loadChampionsMatchup(directory){
 const manifest=JSON.parse(await fs.readFile(path.join(directory,'manifest.json'))),bytes=await fs.readFile(path.join(directory,'model.onnx')),contractBytes=await fs.readFile(path.join(directory,'contract.json')),contract=JSON.parse(contractBytes);
 if(manifest.schema!=='champions-neural-model-v3-matchup'||manifest.observationInput!=='public-snapshot-only-v1'||manifest.observationSchema!==SCHEMA||contract.schema!==SCHEMA||manifest.format!==FORMAT||contract.format!==FORMAT||manifest.candidateSchema!==MATCHUP_SCHEMA||manifest.contractSha256!==sha(contractBytes)||manifest.modelSha256!==sha(bytes))throw Error('Matchup model/contract/fingerprint mismatch');
 assertMatchupLayout(contract);if(contract.tokens!==TOKENS||JSON.stringify(contract.categorical)!==JSON.stringify(CAT)||JSON.stringify(contract.numeric)!==JSON.stringify(NUM))throw Error('Matchup state layout mismatch');
 if(manifest.matchupSourceSha256!==await matchupImplementationHash())throw Error('Matchup feature source fingerprint mismatch');
 const session=await ort.InferenceSession.create(bytes,{executionProviders:['cpu'],intraOpNumThreads:1,interOpNumThreads:1});
 async function rank(tracker,request){
  if(request.side?.id!==tracker.state.side)throw Error('Matchup firewall: opposing request');
  const idle=(request.active||[]).flatMap((a,k)=>a?.moves?.length===1&&a.moves[0].id==='recharge'?[k]:[]);
  if(idle.length){const surrogate={...request,active:request.active.map((a,k)=>idle.includes(k)?null:a)},original=enumerateChampionsActions(request),result=await rank(tracker,surrogate),identity=j=>JSON.stringify(j.actions.filter(a=>!idle.includes(a.slot)).map(a=>[a.slot,a.type,a.choice,a.target,!!a.mega])),members=new Map(original.map(j=>[identity(j),j]));return {...result,ranked:result.ranked.map(j=>{const member=members.get(identity(j));if(!member)throw Error('Recharge has no matching legal command');return {...j,...member};})};}
  const legal=enumerateChampionsActions(request);if(request.teamPreview||!legal.length)throw Error('No matchup turn candidates');
  const snapshot=matchupSnapshot(tracker),encoded=encodeChampionsObservation(snapshot,tracker.state.side,{dex:tracker.state.dex,phase:request.forceSwitch?'replacement':'turn'}),candidates=legalMatchupCandidates(snapshot,tracker.state.side,legal,tracker.state.dex),result=await session.run(matchupFeeds(encoded,candidates)),output=Object.fromEntries(Object.entries(result).map(([k,t])=>[k,t.data]));
  return {ranked:rankMatchupActions(legal,output,contract,request,candidates),encoded,candidates,value:NaN};
 }
 return {manifest,contract,session,rank};
}
