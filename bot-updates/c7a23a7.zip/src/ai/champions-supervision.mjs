// Offline supervision and arena phase helpers; app difficulty dispatch is unchanged.
import {createHash} from 'node:crypto';
import {signalPublicPosition} from './champions-signal-teacher.mjs';
import {createBeliefWorlds,updateBeliefs} from './champions-belief-worlds.mjs';
import {createChampionsDamageDecision,createPublicDamageBattle} from './champions-damage.mjs';
import {createSearchOracle} from './champions-search-oracle.mjs';
import {teacherActionIdentity,teacherOpponentPool,teacherBoardValue} from './champions-search-teacher.mjs';
import {scoreChampionsCandidates,shortlistChampionsCandidates} from './champions-search.mjs';
import {solveMatrixGame} from './champions-matrix-solver.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';

export const SUPERVISION_CONFIG=Object.freeze({schema:'champions-stable-supervision-v2',ordinary:{worlds:2,seeds:[17,101]},important:{worlds:4,seeds:[17,101]},ambiguous:{worlds:4,seeds:[17,101,409,1237]},depth:1,risk:.3,solverIterations:3000,tolerance:.005});
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const sorted=x=>Array.isArray(x)?x.map(sorted):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sorted(x[k])])):x;
export function supervisionPublicPosition(position){
 const p=signalPublicPosition(position);
 p.publicEvidence=(position.publicEvidence||[]).map(e=>Object.fromEntries(['kind','species','value','otherSpecies','faster','comparable','likelihoods'].filter(k=>e[k]!==undefined).map(k=>[k,structuredClone(e[k])])));
 // This context is supplied exclusively by the own split-stream recovery/collector.
 p.publicContext=structuredClone(position.publicContext||{});return p;
}
export function canonicalSupervisionKey(position,rows,columns,{mode='bo3',replacement=false,config=SUPERVISION_CONFIG}={}){
 const p=supervisionPublicPosition(position);
 // Names and absolute p1/p2 labels have no mechanical meaning; roster indices do.
 for(const [side,t]of p.teams.entries())for(const [i,m]of t.entries())m.ident=`public-${side}-${i}`;
 for(const t of p.teams)for(const m of t){m.moves=[...m.moves].sort();m.volatiles=[...(m.volatiles||[])].sort();}
 p.conditions=p.conditions.map(xs=>[...xs].sort());
 return hash(sorted({p,rows:rows.map(teacherActionIdentity).sort(),columns:columns.map(teacherActionIdentity).sort(),mode,replacement,config}));
}
export function supervisionWorlds(position,dex,mode,count){
 const p=supervisionPublicPosition(position);let beliefs=createBeliefWorlds(p,dex,{mode});
 for(const e of p.publicEvidence)beliefs=updateBeliefs(beliefs,e,dex);
 const unique=new Map();for(const w of beliefs.worlds){
  const key=hash([w.position.teams.map(t=>t.map(m=>[m.species,m.hp,m.stats,m.nature,m.item,m.ability,m.moves,m.build]))]);
  if(unique.has(key))unique.get(key).weight+=w.weight;else unique.set(key,{...w});
 }
 const all=[...unique.values()],n=Math.min(count,all.length);
 // Deterministic weight quantiles, without replacement. Preserve distinct public
 // brought-team hypotheses; unlike the old seeded sampling this cannot duplicate worlds.
 const chosen=[];for(let i=0;i<n;i++){let mass=(i+.5)/n,pick=all.at(-1);for(const w of all){mass-=w.weight;if(mass<=0){pick=w;break;}}if(!chosen.includes(pick))chosen.push(pick);}
 for(const w of [...all].sort((a,b)=>b.weight-a.weight||a.id.localeCompare(b.id)))if(chosen.length<n&&!chosen.includes(w))chosen.push(w);
 return chosen;
}
const canonical=xs=>[...new Map(xs.map(j=>[teacherActionIdentity(j),j])).values()].sort((a,b)=>teacherActionIdentity(a).localeCompare(teacherActionIdentity(b)));
const pass={command:'pass, pass',actions:[{slot:0,type:'pass'},{slot:1,type:'pass'}]};
export function replacementActions(position,side){
 const b=createPublicDamageBattle(position);try{
  const s=b.sides[side];if(!s.active.some(m=>m&&!m.hp))return [pass];
  for(const m of s.active)if(m&&!m.hp)m.switchFlag=true;
  b.makeRequest('switch');const request=s.activeRequest;if(!request||request.wait)return [pass];
  return canonical(enumerateChampionsActions(request).map(j=>({...j,actions:j.actions.map(a=>a.type==='switch'?{...a,choice:s.pokemon[a.choice-1].m.publicIndex+1}:a)})));
 }finally{b.destroy();}
}
const effectData=s=>Object.fromEntries(Object.entries(s||{}).flatMap(([k,v])=>['string','number','boolean'].includes(typeof v)||v===null?[[k,v]]:k==='source'&&v?.m?.publicIndex!==undefined?[['publicSource',[v.side.n,v.m.publicIndex]]]:[]));
export function applyPublicReplacement(position,own,foe=pass,seed=17){
 const b=createPublicDamageBattle(position);try{
  const before=b.turn;b.resetRNG([17+seed,29,43+seed,71]);
  for(const [side,j]of [own,foe].entries())for(const a of j.actions){
   if(a.type==='move')throw Error('An attack cannot occur during forced replacement');
   if(a.type==='switch'){
    const incoming=b.sides[side].pokemon.find(m=>m.m.publicIndex===a.choice-1);
    if(!incoming?.hp||incoming.isActive)throw Error('Illegal public replacement');
    b.actions.switchIn(incoming,a.slot);
   }
  }
  b.queue.sort();while(b.queue.peek()){const a=b.queue.shift();if(a.choice!=='runSwitch')throw Error('Unexpected replacement queue action');b.actions.runSwitch(a.pokemon);}
  b.faintMessages();b.checkWin();if(b.turn!==before)throw Error('Replacement advanced the turn');
  const next=structuredClone(position);
  for(const [side,s]of b.sides.entries()){
   next.active[side]=s.active.map(m=>m?.m.publicIndex??-1);next.conditions[side]=Object.keys(s.sideConditions);
   for(const m of s.pokemon){const x=next.teams[side][m.m.publicIndex];Object.assign(x,{species:m.species.name,types:[...m.species.types],hp:m.hp/m.maxhp,stats:{hp:m.maxhp,...m.storedStats},boosts:{...m.boosts},status:m.status,item:m.getItem().name,ability:m.getAbility().name,volatiles:Object.keys(m.volatiles),movePP:Object.fromEntries(m.moveSlots.map(slot=>[slot.id,slot.pp])),timesAttacked:m.timesAttacked,acted:m.activeMoveActions>0});if(m.isActive)x.revealed=true;}
  }
  next.field={weather:b.field.weather,terrain:b.field.terrain,trickroom:!!b.field.getPseudoWeather('trickroom')};
  next.forecast={ended:b.ended,winner:b.winner,totalFainted:b.sides.map(s=>s.totalFainted),pokemon:b.sides.map(s=>{const xs=[];for(const m of s.pokemon)xs[m.m.publicIndex]={status:effectData(m.statusState),ability:effectData(m.abilityState),item:effectData(m.itemState),timesAttacked:m.timesAttacked,movePP:Object.fromEntries(m.moveSlots.map(slot=>[slot.id,slot.pp])),volatiles:Object.fromEntries(Object.entries(m.volatiles).map(([id,state])=>[id,effectData(state)]))};return xs;}),conditions:b.sides.map(s=>Object.fromEntries(Object.entries(s.sideConditions).map(([id,state])=>[id,effectData(state)]))),weather:effectData(b.field.weatherState),terrain:effectData(b.field.terrainState),pseudoWeather:Object.fromEntries(Object.entries(b.field.pseudoWeather).map(([id,state])=>[id,effectData(state)]))};
  return {position:next,ended:b.ended,winner:b.winner};
 }finally{b.destroy();}
}
export function supervisionCandidates(position,legal,dex,{mode='bo3',replacement=false,cap=8}={}){
 const started=performance.now(),world=supervisionWorlds(position,dex,mode,1)[0],oracle=createSearchOracle(world.position,dex,{nodes:1e6,timeMs:1e12});
 try{
  const own=canonical(legal),foe=replacement?replacementActions(world.position,1):oracle.legalActions(world.position,1);
  const pick=(xs,side)=>canonical(shortlistChampionsCandidates(scoreChampionsCandidates(dex,world.position,canonical(xs),side),cap,dex));
  return {rows:replacement?own:pick(own,0),columns:replacement?canonical(foe):pick(foe,1),discoveryMs:performance.now()-started};
 }finally{oracle.dispose();}
}
export function supervisionProfile(position,{replacement=false}={}){
 const active=position.active.flatMap((xs,s)=>xs.map(i=>position.teams[s][i]).filter(m=>m&&m.hp>0));
 if(!replacement&&(position.field.trickroom||position.teams[0].filter(m=>m.hp>0).length<=2&&active.some(m=>m.hp<.25)))return 'ambiguous';
 const important=replacement||position.teams[0].filter(m=>m.hp>0).length<=2||active.some(m=>m.hp<.45)||!!position.field.trickroom;
 return important?'important':'ordinary';
}
export function evaluateSupervision(position,inputRows,inputColumns,dex,{mode='bo3',replacement=false,profile=null,config=SUPERVISION_CONFIG}={}){
 const started=performance.now(),p=supervisionPublicPosition(position),rows=canonical(inputRows),columns=canonical(inputColumns),tier=profile||supervisionProfile(p,{replacement}),settings=config[tier],worlds=supervisionWorlds(p,dex,mode,settings.worlds),oracle=createSearchOracle(p,dex,{nodes:1e6,timeMs:1e12}),decision=createChampionsDamageDecision(p),coverageCache=new Map(),valueCache=new Map();
 let replacementMs=0,continuationCalls=0,valueCacheHits=0;
 const value=result=>{if(result.ended)return result.winner==='Public own'?1:result.winner==='Public opponent'?-1:0;const key=hash(result.position);if(valueCache.has(key)){valueCacheHits++;return valueCache.get(key);}const v=teacherBoardValue(dex,result.position,coverageCache);valueCache.set(key,v);return v;};
 try{
  const legalFor=w=>new Map((replacement?replacementActions(w.position,1):oracle.legalActions(w.position,1)).map(j=>[teacherActionIdentity(j),j])),legal=worlds.map(legalFor);let coverageWorlds=0;
  for(const b of columns)if(legal.every(xs=>!xs.has(teacherActionIdentity(b)))){
   const candidate=supervisionWorlds(p,dex,mode,1e6).find(w=>legalFor(w).has(teacherActionIdentity(b)));
   if(candidate){worlds.push(candidate);legal.push(legalFor(candidate));coverageWorlds++;}
  }
  const unavailable=columns.map(b=>legal.filter(xs=>!xs.has(teacherActionIdentity(b))).length);
  if(unavailable.some(n=>n===worlds.length))throw Error('Candidate unavailable in every public world');
  const matrix=rows.map(a=>columns.map(b=>{
   const buildMeans=[];
   for(const [wi,w]of worlds.entries()){
    const response=legal[wi].get(teacherActionIdentity(b));if(!response)continue;
    let sampleValues=[];
    if(replacement){
     const t=performance.now(),entry=applyPublicReplacement(w.position,a,response);replacementMs+=performance.now()-t;
     if(entry.ended)sampleValues=[value(entry)];else{
      // All replacement roots have the same continuation horizon. Entry is
      // resolved first; then BOTH sides choose a new joint action. No free attack.
      const r=entry.position,continuationOwn=canonical(shortlistChampionsCandidates(scoreChampionsCandidates(dex,r,oracle.legalActions(r,0),0),2,dex)),continuationFoe=canonical(shortlistChampionsCandidates(scoreChampionsCandidates(dex,r,oracle.legalActions(r,1),1),2,dex));
      for(const seed of settings.seeds){const m=continuationOwn.map(x=>continuationFoe.map(y=>{continuationCalls++;return value(decision.exchange(r,x,y,{seed,nativeChance:true}));}));sampleValues.push(m.length&&m[0].length?solveMatrixGame(m,{iterations:1000,tolerance:.005}).value:value(entry));}
     }
    }else for(const seed of settings.seeds)sampleValues.push(value(decision.exchange(w.position,a,response,{seed,nativeChance:true})));
    buildMeans.push({mean:sampleValues.reduce((s,x)=>s+x,0)/sampleValues.length,weight:w.weight});
   }
   const mass=buildMeans.reduce((s,x)=>s+x.weight,0),mean=buildMeans.reduce((s,x)=>s+x.mean*x.weight,0)/mass;
   return (1-config.risk)*mean+config.risk*Math.min(...buildMeans.map(x=>x.mean));
  }));
  const solved=solveMatrixGame(matrix,{iterations:config.solverIterations,tolerance:config.tolerance}),policy=[...solved.rowStrategy,...solved.columnStrategy],actionValues=matrix.map(row=>row.reduce((s,x,j)=>s+x*solved.columnStrategy[j],0));
  return {rows,columns,matrix,policy,actionValues,value:solved.value,diagnostics:{...decision.metrics,ms:performance.now()-started,tier,worlds:worlds.map(w=>({id:w.id,weight:w.weight})),seeds:settings.seeds,unavailable,coverageWorlds,residual:solved.residual,valueCacheHits,replacementMs,continuationCalls,depth:replacement?'entry plus uniform 2x2 next-exchange':'uniform one exchange',scope:'Native common seeded chance samples; deterministic bounded public hypotheses; risk across build means; mixed equilibrium; heuristic exchange value, not eventual win probability'}};
 }finally{oracle.dispose();decision.dispose();}
}
export function createSupervisionCache(){const values=new Map();return {metrics:{hits:0,misses:0},evaluate(p,rows,columns,dex,options={}){const key=canonicalSupervisionKey(p,rows,columns,options);if(values.has(key)){this.metrics.hits++;return {key,...values.get(key)};}this.metrics.misses++;const result=evaluateSupervision(p,rows,columns,dex,options);values.set(key,result);return {key,...result};}};}
