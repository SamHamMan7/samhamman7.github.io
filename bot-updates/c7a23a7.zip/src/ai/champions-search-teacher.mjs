// Experimental teacher. The browser loadChampionsStrong and foundation matrix
// remain separate baselines. All positions originate from the own public stream.
import {publicDamagePosition} from './champions-damage.mjs';
import {createBeliefWorlds,sampleBeliefWorlds,deterministicBeliefWorlds,updateBeliefs} from './champions-belief-worlds.mjs';
import {createSearchOracle,SearchBudgetExceeded,selectiveChance} from './champions-search-oracle.mjs';
import {solveMatrixGame,doubleOracle,sampleStrategy} from './champions-matrix-solver.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
import {chooseChampionsPreview} from './champions-preview.mjs';
import {difficultyProfile} from './search-difficulty.mjs';
import {scoreChampionsCandidates,shortlistChampionsCandidates,seededChampionsRandom,simulateSearchPly,estimateChampionsDamage,chooseChampionsSearch,SEARCH_SETTINGS} from './champions-search.mjs';
export const teacherActionIdentity=j=>JSON.stringify(j.actions.map(a=>[a.slot,a.type,a.move?.id,a.target||0,a.type==='switch'?a.choice||0:0,!!a.mega]));
const key=teacherActionIdentity;
export function coverTeacherResponses(selected,legal,{cap=48,anchors=6}={}){
  // Preserve legal Mega/no-Mega and double-target alternatives for discovered
  // move pairs. A plausible Mega response must not hide its non-Mega counter.
  const byKey=new Map(legal.map(j=>[key(j),j])),out=[],seen=new Set();
  const add=j=>{if(j&&!seen.has(key(j))&&out.length<cap){seen.add(key(j));out.push(j);}};
  const variants=base=>{
    const pair=legal.filter(j=>j.actions.every((a,i)=>{const b=base.actions[i];return a.type===b.type&&(a.type==='move'?a.move.id===b.move.id:a.type==='switch'?a.choice===b.choice:true);}));
    // First close the evolution toggle at unchanged targets, then both explicit
    // double attacks, then remaining legal target combinations. Never fabricate
    // commands or infer an opponent's actual submission.
    for(const j of pair.filter(j=>j.actions.every((a,i)=>a.target===base.actions[i].target)))add(j);
    for(const target of [1,2])for(const j of pair.filter(j=>j.actions.every(a=>a.type==='move'&&a.target===target)))add(j);
  };
  selected.forEach(add);for(const base of selected.slice(0,anchors))variants(base);
  for(const j of out)if(!byKey.has(key(j)))throw Error('Response is not a member of the public legal pool');
  return out;
}
export function teacherOpponentPool(byWorld){
  // Synthetic move indices vary across public build hypotheses. Deduplicate
  // by move identity, and give colliding command labels distinct identities
  // for the solver/model maps. These labels are never submitted to a battle;
  // sandbox exchanges use actions, and own commands remain request members.
  const pool=[...new Map(byWorld.flat().map(j=>[key(j),j])).values()],labels=new Map();
  for(const j of pool)labels.set(j.command,(labels.get(j.command)||0)+1);
  return pool.map(j=>labels.get(j.command)>1?{...j,command:`${j.command} [public hypothesis ${key(j)}]`}:j);
}
export function teacherBoardValue(dex,p,coverageCache=null){
  // Every living mon in a world is a brought hypothesis, including unseen bench.
  // Material is symmetric; surviving unique coverage receives a modest premium.
  const faints=p.forecast?.totalFainted??p.teams.map((team,s)=>team.filter(m=>m.hp<=0&&(s===0||m.revealed)).length);
  const signatures=new Map(),signature=m=>{if(!signatures.has(m))signatures.set(m,JSON.stringify([m.types,m.stats,m.boosts,m.hp,m.status,m.item,m.ability,m.moves,m.movePP,m.timesAttacked,faints]));return signatures.get(m);};
  const coverage=(s,m,target)=>{
    if(!coverageCache)return Math.max(0,...m.moves.filter(id=>m.movePP?.[id]!==0).map(id=>estimateChampionsDamage(dex,p,s,m,target,dex.moves.get(id)).fraction));
    const k=JSON.stringify([signature(m),signature(target),p.field.weather,p.field.terrain,p.conditions[1-s]]);
    if(coverageCache.has(k))return coverageCache.get(k);
    const hit=Math.max(0,...m.moves.filter(id=>m.movePP?.[id]!==0).map(id=>estimateChampionsDamage(dex,p,s,m,target,dex.moves.get(id)).fraction));coverageCache.set(k,hit);return hit;
  };
  const sideValue=s=>{
    const own=p.teams[s].filter(m=>m.hp>0),foe=p.teams[1-s].filter(m=>m.hp>0);let value=own.reduce((v,m)=>v+65+35*m.hp,0);
    for(const target of foe){const hits=own.map(m=>coverage(s,m,target)*m.hp),total=hits.reduce((v,x)=>v+x,0);if(total)value+=25*Math.min(1,Math.max(...hits))*Math.max(...hits)/total;}
    for(const m of own){value+=2*((m.boosts.atk||0)+(m.boosts.spa||0)+(m.boosts.def||0)+(m.boosts.spd||0));if(['slp','frz'].includes(m.status))value-=10;}
    for(const index of p.active[s]){const m=p.teams[s][index];if(!m||m.hp<=0)continue;for(const j of p.active[1-s]){const f=p.teams[1-s][j];if(!f||f.hp<=0)continue;const speed=(x,side)=>{const n=x.boosts.spe||0;return x.stats.spe*(n>=0?(2+n)/2:2/(2-n))*(p.conditions[side].includes('tailwind')?2:1)*(x.status==='par'?.5:1);};const delta=(speed(m,s)-speed(f,1-s))*(p.field.trickroom?-1:1);value+=delta>0?3:delta<0?-3:0;}}
    return value;
  };return Math.tanh((sideValue(0)-sideValue(1))/180);
}
export function teacherOutcomeValue(dex,result){return result.ended?(result.winner==='Public own'?1:result.winner==='Public opponent'?-1:0):teacherBoardValue(dex,result.position);}
function discover(dex,p,ranked,side,foe,limit,{pilot=true,coverageCache=null}={}){
  const families=j=>new Set(j.actions.flatMap(a=>a.type==='switch'?[`switch-${a.slot}`]:a.type==='move'?[...(dex.moves.get(a.move.id).stallingMove?[`protect-${a.slot}`]:dex.moves.get(a.move.id).category==='Status'?[`support-${a.slot}`]:[]),...(a.target>0&&j.actions.filter(b=>b.type==='move'&&b.target===a.target).length===2?['double']:[])]:[]));
  const diverse=(ranked,cap)=>{const out=ranked.slice(0,Math.max(1,cap-4)),covered=new Set(out.flatMap(j=>[...families(j)]));while(out.length<cap){const candidates=ranked.filter(j=>!out.includes(j));candidates.sort((a,b)=>[...families(b)].filter(f=>!covered.has(f)).length-[...families(a)].filter(f=>!covered.has(f)).length);const pick=candidates[0];if(!pick)break;out.push(pick);families(pick).forEach(f=>covered.add(f));}return out;};
  const wide=diverse(ranked,Math.min(18,Math.max(limit,12)));
  if(pilot){for(const a of wide){const values=foe.slice(0,6).map(b=>{const next=side===0?simulateSearchPly(dex,p,a,b,.925,1).position:simulateSearchPly(dex,p,b,a,.925,0).position;return teacherBoardValue(dex,next,coverageCache)*(side===0?1:-1);});a.discoveryScore=.6*values.reduce((s,v)=>s+v,0)/Math.max(1,values.length)+.4*Math.min(...values);}
    wide.sort((a,b)=>b.discoveryScore-a.discoveryScore||a.command.localeCompare(b.command));}
  // Joint set coverage can retain both slot families in one command, rather
  // than spending the whole small pool on separate Protect examples.
  return diverse(wide,limit);
}
export async function chooseChampionsTeacher(tracker,request,{mode='bo3',strength='casual',profile=null,seed=1,model=null,priorModel=null,evidence=[],trace=false,ablation='full'}={}){
  if(request.side?.id!==tracker.state.side)throw Error('Teacher firewall: own request required');const started=performance.now(),random=seededChampionsRandom(seed),settings=profile||difficultyProfile(`champions-${mode}`,strength),legal=enumerateChampionsActions(request);
  if(!legal.length)throw Error('No legal teacher action');if(request.teamPreview)return {chosen:chooseChampionsPreview(request,tracker.state.dex,{random}),source:'teacher-preview',diagnostics:{totalMs:performance.now()-started}};
  const dex=tracker.state.dex,p=publicDamagePosition(tracker.state,request),beliefStart=performance.now();let beliefs=createBeliefWorlds(p,dex,{mode});for(const e of evidence)beliefs=updateBeliefs(beliefs,e,dex);const worlds=settings.deterministicWorlds?deterministicBeliefWorlds(beliefs,settings.worlds):sampleBeliefWorlds(beliefs,settings.worlds,seed),beliefMs=performance.now()-beliefStart;
  const coverageCache=new Map(),valueFunction=ablation==='old-value'?null:r=>r.ended?teacherOutcomeValue(dex,r):teacherBoardValue(dex,r.position,coverageCache),oracle=createSearchOracle(p,dex,{...settings,minimumNodes:Math.min(settings.nodes,9*worlds.length),valueFunction,repairEffectTargets:true}),cells=new Map(),expansions=[];
  let neuralMs=0,discoveryMs=0,matrixMs=0,solverMs=0,deeperMs=0,deepened=0,neuralError=null;
  try{
    const t=performance.now(),foes=worlds.map(w=>oracle.legalActions(w.position,1)),foeUnion=teacherOpponentPool(foes),q=worlds[0].position,cheapOwn=scoreChampionsCandidates(dex,q,legal,0),cheapFoe=scoreChampionsCandidates(dex,q,foeUnion,1),cap=Math.max(6,settings.candidates),rows=discover(dex,q,cheapOwn,0,cheapFoe,cap,{pilot:ablation!=='no-discovery',coverageCache});let columns=discover(dex,q,cheapFoe,1,cheapOwn,cap,{pilot:ablation!=='no-discovery',coverageCache});if(settings.responseCoverage)columns=coverTeacherResponses(columns,foeUnion,{cap:settings.responseCap||48});discoveryMs=performance.now()-t;
    let prior=[];if(priorModel){const t=performance.now();try{prior=(await priorModel.rank(tracker,request)).ranked;for(const a of prior.slice(0,2)){const member=legal.find(j=>j.command===a.command);if(member&&!rows.some(j=>j.command===member.command))rows.unshift(member);}}catch(e){neuralError=e.message;}neuralMs+=performance.now()-t;}
    if(ablation!=='no-discovery'){
      const t=performance.now(),guide=chooseChampionsSearch(legal,tracker.state,dex,{...SEARCH_SETTINGS,depth:2,enemyStatProfile:'offense',request,prior,random:seededChampionsRandom(seed^0x17ab)});
      // The strong inexpensive hybrid discovers lines; only authoritative
      // exchange payoffs and the mixed matrix policy decide their probability.
      for(const a of guide.top.slice(0,2).reverse()){const member=legal.find(j=>j.command===a.command),existing=rows.findIndex(j=>j.command===a.command);if(existing>=0)rows.splice(existing,1);if(member)rows.unshift(member);}discoveryMs+=performance.now()-t;
    }
    if(model){const t=performance.now(),pred=await model.predict(p,rows,columns);neuralMs+=performance.now()-t;rows.sort((a,b)=>pred.own.get(b.command)-pred.own.get(a.command));columns.sort((a,b)=>pred.foe.get(b.command)-pred.foe.get(a.command));}
    const depthEnabled=ablation!=='no-depth'&&!settings.uniformHorizon&&!request.forceSwitch,rootLimit=depthEnabled?Math.max(9*worlds.length,Math.floor(settings.nodes*.65)):settings.nodes;
    const foeMembers=foes.map(xs=>new Map(xs.map(j=>[key(j),j]))),fallbackFoes=new Map();
    const chanceSeeds=settings.chanceSeeds||[seed];
    const payoff=(a,b)=>{const k=JSON.stringify([key(a),key(b)]);if(cells.has(k))return cells.get(k).value;if(oracle.metrics.nodes+worlds.length*chanceSeeds.length>rootLimit)throw new SearchBudgetExceeded();const t=performance.now();try{const groups=worlds.map((w,i)=>{let member=foeMembers[i].get(key(b));if(!member){if(!fallbackFoes.has(i))fallbackFoes.set(i,scoreChampionsCandidates(dex,w.position,foes[i],1)[0]);member=fallbackFoes.get(i);}const samples=chanceSeeds.map(sample=>selectiveChance(oracle,p,a,member,w,{seed:(sample+i*193)%65500,maxCalls:1}));return {samples,mean:samples.reduce((s,c)=>s+c.value,0)/samples.length,weight:settings.deterministicWorlds?w.weight:1/worlds.length};}),samples=groups.flatMap(g=>g.samples),mean=groups.reduce((s,g)=>s+g.weight*g.mean,0),risk=settings.buildRisk||0,value=(1-risk)*mean+risk*Math.min(...groups.map(g=>g.mean));cells.set(k,{value,samples});return value;}finally{matrixMs+=performance.now()-t;}};
    let game=doubleOracle(rows,columns,payoff,{initial:Math.min(3,rows.length,columns.length),maxIterations:Math.max(3,settings.oracleIterations),solverIterations:Math.max(400,settings.solverIterations),responseBatch:ablation==='full-scan'||settings.fullResponseScan?Infinity:2,onIteration:e=>expansions.push(e),onSolve:ms=>solverMs+=ms});
    if(depthEnabled){const t=performance.now(),entries=game.rows.flatMap((a,i)=>game.columns.map((b,j)=>({a,b,i,j,weight:game.rowStrategy[i]*game.columnStrategy[j]}))).sort((a,b)=>b.weight-a.weight);
      for(const entry of entries.slice(0,Math.max(2,settings.deepenCells))){const cell=cells.get(JSON.stringify([key(entry.a),key(entry.b)])),leaves=cell.samples.flatMap(c=>c.leaves.map(l=>({...l,probability:l.probability/cell.samples.length}))),required=4*leaves.filter(l=>!l.result.ended).length;if(!oracle.canAfford(required))break;
        let continuation=0,complete=true;try{for(const leaf of leaves){const next=leaf.result;if(next.ended){continuation+=leaf.probability*next.value;continue;}const r=next.position,own=shortlistChampionsCandidates(scoreChampionsCandidates(dex,r,oracle.legalActions(r,0),0),2,dex),foe=shortlistChampionsCandidates(scoreChampionsCandidates(dex,r,oracle.legalActions(r,1),1),2,dex);if(!own.length||!foe.length){continuation+=leaf.probability*next.value;continue;}const w={id:'public-continuation',source:'public-forecast',position:r},m=own.map(a=>foe.map(b=>oracle.evaluateJointOutcome(r,a,b,w,{seed}).value)),s=performance.now(),solved=solveMatrixGame(m,{iterations:Math.max(400,settings.solverIterations)});solverMs+=performance.now()-s;continuation+=leaf.probability*solved.value;}}catch(e){if(e.name!=='SearchBudgetExceeded')throw e;complete=false;}
        if(!complete)break;game.matrix[entry.i][entry.j]=.25*game.matrix[entry.i][entry.j]+.75*continuation;deepened++;expansions.push({deepen:`${entry.a.command} vs ${entry.b.command}`,reason:'reserved budget for likely joint exchange; probability-weighted public-world continuations'});
      }const s=performance.now();game={...game,...solveMatrixGame(game.matrix,{iterations:Math.max(400,settings.solverIterations)}),externalResidual:null};solverMs+=performance.now()-s;deeperMs=performance.now()-t;
    }
    const chosen=game.rows[sampleStrategy(game.rowStrategy,random)];if(!legal.some(j=>j.command===chosen.command))throw Error('Nonmember teacher action');
    const policy=game.rows.map((a,i)=>({command:a.command,probability:game.rowStrategy[i]})),opponentPolicy=game.columns.map((b,j)=>({command:b.command,probability:game.columnStrategy[j]})),diagnostics={...oracle.diagnostics(),beliefMs,discoveryMs,neuralMs,matrixMs,solverMs,deeperMs,deepened,totalMs:performance.now()-started,matrixDimensions:[game.rows.length,game.columns.length],residual:game.residual,externalResidual:game.externalResidual,budgetStopped:game.budgetStopped,solverIterations:game.iterations,neuralError,teacherVersion:'selective-v2',chanceSeeds:settings.chanceSeeds||'decision-seed',responsePool:columns.length,responseCoverage:!!settings.responseCoverage,uniformHorizon:!depthEnabled,ablation,mode};
    return {chosen,source:'selective-teacher',policy,opponentPolicy,opponentActions:game.columns,value:game.value,diagnostics,...(trace?{trace:{publicOnly:true,policy,opponentPolicy,payoff:game.matrix,value:game.value,calibration:'heuristic continuation value; not validated eventual win probability',candidatePools:{own:rows.map(j=>j.command),foe:columns.map(j=>j.command)},expansions,beliefs:worlds.map(w=>({id:w.id,source:w.source})),...diagnostics}}:{})};
  }finally{oracle.dispose();}
}
