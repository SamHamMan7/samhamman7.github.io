// Isolated V2 adapter. Exact own-request legal commands remain authoritative.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import * as ort from 'onnxruntime-node';
import {neuralFeeds,neuralSnapshot} from './champions-neural.mjs';
import {encodeChampionsObservation,SCHEMA,FORMAT,TOKENS,CAT,NUM} from './champions-neural-observation.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
import {legalCandidates,CANDIDATE_SCHEMA,CANDIDATE_FEATURES} from './champions-candidates.mjs';
import {toID} from './champions-public.mjs';
import {calibrateCandidateFamilies} from './champions-policy-calibration.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
const logSoftmax=a=>{const m=Math.max(...a),z=m+Math.log(a.reduce((s,v)=>s+Math.exp(v-m),0));return a.map(v=>v-z);};
export function candidateFeeds(encoded,candidates){
  const count=candidates.mask[0].length;
  return {...neuralFeeds(encoded),candidate_features:new ort.Tensor('float32',Float32Array.from(candidates.features.flat(2)),[1,2,count,CANDIDATE_FEATURES.length]),candidate_mask:new ort.Tensor('bool',Uint8Array.from(candidates.mask.flat(),Number),[1,2,count])};
}
export function rankCandidateActions(legal,output,contract,request,candidates,{familyNormalization=false}={}){
  const type=logSoftmax(Array.from(output.types)),targets=logSoftmax(Array.from(output.targets)),mega=logSoftmax(Array.from(output.mega)),count=candidates.mask[0].length;
  const move=[0,1].map(k=>candidates.mask[k].some(Boolean)?logSoftmax(Array.from(output.candidate_scores).slice(k*count,(k+1)*count).map((v,i)=>candidates.mask[k][i]?v:-Infinity)):Array(count).fill(-Infinity));
  const sw=[0,1].map(k=>logSoftmax(Array.from(output.switches).slice(k*contract.species.length,(k+1)*contract.species.length)));
  const ranked=legal.map(j=>{
    const types=j.actions.map(a=>contract.types.indexOf(a.type)),chosenTargets=[null,null],components={type:type[types[0]*3+types[1]],move:[0,0],switch:[0,0],target:0,mega:0};let megaChoice=0;
    for(const [k,a] of j.actions.entries()){
      if(a.type==='move'){
        const index=candidates.ids[k].indexOf(toID(a.move.id||a.move.move));if(index<0||!candidates.mask[k][index])throw Error('Legal move missing candidate feature');
        components.move[k]=move[k][index];chosenTargets[k]=a.target<0?-a.target:a.target>0?a.target+2:0;if(a.mega)megaChoice=k+1;
      }else if(a.type==='switch'){
        const id=toID(request.side.pokemon[a.choice-1].details.split(',')[0]),index=contract.species.indexOf(id);if(index<1)throw Error('Switch outside V2 vocabulary');components.switch[k]=sw[k][index];
      }
    }
    const compatible=[];for(let a=0;a<5;a++)for(let b=0;b<5;b++)if((chosenTargets[0]===null||chosenTargets[0]===a)&&(chosenTargets[1]===null||chosenTargets[1]===b))compatible.push(targets[a*5+b]);
    const m=Math.max(...compatible);components.target=m+Math.log(compatible.reduce((s,v)=>s+Math.exp(v-m),0))-Math.log(compatible.length);
    components.mega=mega[megaChoice];const score=Object.values(components).flat().reduce((s,v)=>s+v,0);
    if(!Number.isFinite(score))throw Error('Non-finite V2 candidate score');return {...j,score,components};
  }).sort((a,b)=>b.score-a.score);
  if(familyNormalization)return calibrateCandidateFamilies(ranked);
  const probabilities=logSoftmax(ranked.map(j=>j.score));return ranked.map((j,i)=>({...j,probability:Math.exp(probabilities[i])}));
}
export async function loadChampionsCandidate(directory){
  const manifest=JSON.parse(await fs.readFile(path.join(directory,'manifest.json'),'utf8')),contractBytes=await fs.readFile(path.join(directory,'contract.json')),modelBytes=await fs.readFile(path.join(directory,'model.onnx')),contract=JSON.parse(contractBytes);
  if(manifest.schema!=='champions-neural-model-v2-candidate'||manifest.observationSchema!==SCHEMA||manifest.format!==FORMAT||contract.schema!==SCHEMA||contract.format!==FORMAT||manifest.candidateSchema!==CANDIDATE_SCHEMA||contract.candidateSchema!==CANDIDATE_SCHEMA||manifest.contractSha256!==sha(contractBytes)||manifest.modelSha256!==sha(modelBytes))throw Error('V2 model/contract/fingerprint mismatch');
  if(contract.tokens!==TOKENS||JSON.stringify(contract.categorical)!==JSON.stringify(CAT)||JSON.stringify(contract.numeric)!==JSON.stringify(NUM)||JSON.stringify(contract.candidateFeatures)!==JSON.stringify(CANDIDATE_FEATURES))throw Error('V2 feature layout mismatch');
  if(manifest.policyCalibration!==undefined&&manifest.policyCalibration!=='legal-joint-family-v1')throw Error('Unknown V2 policy calibration');
  const session=await ort.InferenceSession.create(modelBytes,{executionProviders:['cpu'],intraOpNumThreads:1,interOpNumThreads:1});
  async function rank(tracker,request){
    if(request.side?.id!==tracker.state.side)throw Error('V2 neural firewall: opposing request');
    // Recharge is the simulator's forced idle request, with no Dex move entry.
    // The existing V2 head scores that slot as pass; retain the exact requested
    // command when returning joint actions. Ordinary request scores are intact.
    const idleSlots=(request.active||[]).flatMap((a,i)=>a?.moves?.length===1&&a.moves[0].id==='recharge'?[i]:[]);
    if(idleSlots.length){
      const surrogate={...request,active:request.active.map((a,i)=>idleSlots.includes(i)?null:a)},original=enumerateChampionsActions(request),scores=await rank(tracker,surrogate);
      const identity=j=>JSON.stringify(j.actions.filter(a=>!idleSlots.includes(a.slot)).map(a=>[a.slot,a.type,a.choice,a.target,!!a.mega])),members=new Map(original.map(j=>[identity(j),j]));
      return {...scores,ranked:scores.ranked.map(j=>{const member=members.get(identity(j));if(!member)throw Error('Recharge request has no matching legal joint action');return {...j,...member};}),virtualRequest:'public forced Recharge scored as idle'};
    }
    const legal=enumerateChampionsActions(request);if(request.teamPreview||!legal.length)throw Error('No V2 turn candidates');
    const encoded=encodeChampionsObservation(neuralSnapshot(tracker),tracker.state.side,{dex:tracker.state.dex,request,phase:request.forceSwitch?'replacement':'turn'}),candidates=legalCandidates(legal,tracker.state.dex);
    const tensors=await session.run(candidateFeeds(encoded,candidates)),output=Object.fromEntries(Object.entries(tensors).map(([k,v])=>[k,v.data]));
    return {ranked:rankCandidateActions(legal,output,contract,request,candidates,{familyNormalization:manifest.policyCalibration==='legal-joint-family-v1'}),value:Number(output.value[0]),encoded,candidates};
  }
  return {manifest,contract,session,rank};
}
