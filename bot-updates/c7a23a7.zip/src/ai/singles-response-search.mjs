import {Dex} from '@pkmn/sim';
import {clamp} from './damage.js';
import {opponentHypotheses} from './priors.js';
import {chooseAction as stable} from './singles-stable.js';
import {createResourceContext, DIFFICULTIES, legalActions, responseOptions, pairOutcome, resourceContinuation, teraOpportunityCost} from './index.js';
import {solveMatrixGame, sampleStrategy} from './champions-matrix-solver.mjs';

const living = m => !m.fainted && !String(m.condition || '').includes('fnt') && (m.hpFraction ?? 1) > 0;
const responseKey = r => r.kind === 'switch' ? `switch:${r.mon.ident || r.mon.species}` : `move:${Dex.moves.get(r.move).id}`;
const weighted = (values, probabilities) => values.reduce((s, v, i) => s + v * probabilities[i], 0);
function random(seed) {let x = seed >>> 0; return () => {x += 0x6d2b79f5; let t = Math.imul(x ^ x >>> 15, x | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296;};}

export function publicMaterialEdge(ctx) {
  const own = ctx.roster.reduce((s, m) => s + (living(m) ? m.hpFraction : 0), 0);
  const known = ctx.view.opponent.revealed || [], size = ctx.roster.length;
  const foe = known.reduce((s, m) => s + (living(m) ? m.hpFraction ?? 1 : 0), 0) + Math.max(0, size - known.length);
  return (own - foe) / Math.max(1, size) * 100;
}

/** One common response game, not a different clairvoyant opponent per action.
 * The adversarial part can depart from the public response prior. Its weight
 * rises when ahead and falls when behind; it never rewards prediction itself. */
export function solveResponseGame(matrix, prior, {risk = .34, iterations = 1200, mixWindow = 3} = {}) {
  if (!Number.isFinite(risk) || risk < 0 || risk > 1 || !Number.isInteger(iterations) || iterations < 1 || !Number.isFinite(mixWindow) || mixWindow < 0) throw Error('Invalid response game settings');
  if (prior.length !== matrix[0]?.length || prior.some(p => !Number.isFinite(p) || p < 0) || !(prior.reduce((a, b) => a + b, 0) > 0)) throw Error('Invalid response prior');
  const sum = prior.reduce((a, b) => a + b, 0), probabilities = prior.map(p => p / sum);
  const expected = matrix.map(row => weighted(row, probabilities));
  const game = matrix.map((row, i) => row.map(v => (1 - risk) * expected[i] + risk * v));
  const solution = solveMatrixGame(game, {iterations, tolerance: .03});
  const effectiveOpponent = probabilities.map((p, j) => (1 - risk) * p + risk * solution.columnStrategy[j]);
  const values = matrix.map(row => weighted(row, effectiveOpponent)), best = Math.max(...values);
  let policy = solution.rowStrategy.map((p, i) => values[i] >= best - mixWindow && p > 1 / (iterations * Math.max(2, matrix.length)) ? p : 0);
  if (!policy.some(Boolean)) policy[values.indexOf(best)] = 1;
  const mass = policy.reduce((a, b) => a + b, 0); policy = policy.map(p => p / mass);
  return {...solution, policy, values, effectiveOpponent, prior: probabilities, risk};
}

/** Experimental Gen 9 singles planner. Never called by the deployed chooser.
 * The only input is a player view; it has no engine, opponent request or choice. */
export function chooseSimultaneousResourceAction(view, {difficulty = 'Strong', seed = 1, depth = null, budget = null, hypothesisFactory = null, requiredChoice = null} = {}) {
  if (view.format !== 'gen9randombattle' || view.request?.teamPreview || view.request?.forceSwitch?.some(Boolean) || view.request?.wait || view.request?.active?.length !== 1) return stable(view, {difficulty, seed});
  const started = performance.now(), profile = DIFFICULTIES[difficulty] || DIFFICULTIES.Strong;
  try {
    const actions = legalActions(view), ctx = createResourceContext(view, profile);
    if (!ctx.own || !ctx.opponent || !actions.length) return stable(view, {difficulty, seed});
    if (actions.some(a => !['move', 'switch'].includes(a.kind))) return stable(view, {difficulty, seed});
    const hypotheses = hypothesisFactory ? hypothesisFactory(ctx.opponent, profile.hypotheses) : opponentHypotheses(ctx.opponent, view.format, profile.hypotheses);
    const mass = hypotheses.reduce((s, h) => s + h.weight, 0);
    // Include the complete bounded public move pool, not just replies that hit
    // the CURRENT type hard. A column is the same opponent action for all rows.
    const options = hypotheses.map(h => responseOptions(h, ctx.own, {...ctx, profile: {...profile, responses: 12}}));
    const columns = [...new Map(options.flat().map(r => [responseKey(r), r])).values()].slice(0, 15);
    const prior = columns.map(c => hypotheses.reduce((s, h, k) => s + h.weight / mass * (options[k].find(r => responseKey(r) === responseKey(c))?.weight || 0), 0));
    // A column is a restricted contingent response: if that move is unavailable
    // in a world (e.g. Scarf lock / AV), use THAT world's best legal reply.
    // Never evaluate an illegal response as though it were selectable there.
    const responseFor = (response, world) => options[world].find(r => responseKey(r) === responseKey(response)) || options[world][0];
    const outcomes = actions.map(action => columns.map(response => hypotheses.map((h, k) => ({outcome: pairOutcome(ctx.own, h, action, responseFor(response, k), ctx), weight: h.weight / mass}))));
    let matrix = actions.map((action, i) => columns.map((_, j) => outcomes[i][j].reduce((s, e) => s + e.outcome.score * e.weight, 0) - teraOpportunityCost(ctx, action)));
    const edge = publicMaterialEdge(ctx), risk = clamp(profile.downside + edge / 240, .12, .65);
    const solve = values => solveResponseGame(values, prior, {risk, mixWindow: profile.mixWindow / 2});
    const root = solve(matrix);
    let rows = actions.map((_, i) => i), complete = false, attempted = false;
    ctx.searchBudget = budget ?? Math.ceil((profile.maxCalculations + 1800) * (hypothesisFactory ? Math.min(2, Math.sqrt(hypotheses.length)) : 1));
    ctx.deferredTeraEvaluations = 0;
    if ((depth ?? profile.depth) > 1) {
      attempted = true;
      const ranked = rows.toSorted((a, b) => root.values[b] - root.values[a]);
      const strongestTera = ranked.find(i => actions[i].tera), strongestPlain = ranked.find(i => actions[i].kind === 'move' && !actions[i].tera), strongestSwitch = ranked.find(i => actions[i].kind === 'switch');
      const required = rows.find(i => actions[i].choice === requiredChoice);
      const counterpart = required === undefined ? undefined : rows.find(i => actions[i].choice === requiredChoice.replace(' terastallize', ''));
      const initial = required === undefined ? [ranked[0], strongestPlain, strongestSwitch, strongestTera] : [required, counterpart, strongestSwitch, ranked[0], strongestPlain, strongestTera];
      const beam = [...new Set([...initial, ...ranked].filter(i => i !== undefined))].slice(0, profile.searchWidth);
      const next = []; complete = true;
      for (const i of beam) {
        const row = [];
        for (let j = 0; j < columns.length; j++) {
          let value = 0;
          for (const entry of outcomes[i][j]) {
            const result = resourceContinuation(entry.outcome, actions[i], ctx);
            if (!result.complete) {complete = false; break;}
            value += result.value * entry.weight;
          }
          if (!complete) break;
          row.push(matrix[i][j] + value);
        }
        if (!complete) break;
        next.push(row);
      }
      // All-or-nothing: a partial row/depth never creates invented zero values
      // for the later candidates. The fully evaluated one-ply game is retained.
      if (complete) {matrix = next; rows = beam;}
    }
    const solution = complete ? solve(matrix) : root;
    const index = sampleStrategy(solution.policy, random(seed ^ Math.imul((view.turn || 0) + 1, 0x9e3779b1))), chosen = actions[rows[index]];
    return {choice: chosen.choice, reason: 'Public simultaneous response game with one-use Tera and complete-depth resource accounting.',
      scores: rows.map((r, i) => ({choice: actions[r].choice, score: solution.values[i], probability: solution.policy[i], teraCost: teraOpportunityCost(ctx, actions[r]),
        ...(requiredChoice ? {ownKO: outcomes[r].reduce((s, list, j) => s + solution.effectiveOpponent[j] * list.reduce((n, e) => n + Number(e.outcome.own.hpFraction <= 0) * e.weight, 0), 0)} : {})})),
      diagnostics: {policy: 'randbats-simultaneous-resource-v1', difficulty, materialEdge: edge, risk, rows: rows.length, columns: columns.length,
        responsePrior: solution.prior, opponentPolicy: solution.effectiveOpponent, opponentActions: columns.map(responseKey),
        hypotheses: hypotheses.length, calculations: ctx.calculations, calcFailures: ctx.failures, budget: ctx.searchBudget,
        attemptedLookahead: attempted, completeLookahead: complete, deferredTeraEvaluations: ctx.deferredTeraEvaluations,
        solverResidual: solution.residual, solverIterations: solution.iterations, ms: performance.now() - started,
        ...(hypothesisFactory ? {policy: 'randbats-public-set-response-v1',
          publicSetWorlds: hypotheses.map(h => ({assumedItem: h.item || '', assumedAbility: h.ability || '', weight: h.weight, movePool: h.assumedMovePool, source: h.priorSource, fallback: h.priorFallback})),
          conditionalResponseMap: columns.map(c => hypotheses.map((_, k) => responseKey(responseFor(c, k))))} : {})}};
  } catch (error) {
    const result = stable(view, {difficulty, seed});
    return {...result, diagnostics: {...result.diagnostics, searchError: error.message}};
  }
}
