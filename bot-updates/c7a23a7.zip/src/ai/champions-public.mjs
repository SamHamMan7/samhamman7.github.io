// Own player stream only. Never accept a Battle, opposing request, or choices.
import {observePublicEffects,publicEffectsSnapshot} from './champions-public-effects.mjs';
export const toID=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
const identity=x=>String(x||'').replace(/^(p[12])[ab]:/,'$1:');
const hp=s=>{const m=String(s||'').match(/^(\d+)\/(\d+)/);return /fnt/.test(s)?0:m?+m[1]/+m[2]:1;};
export function createChampionsPublic(side,dex,Teams) {
  return {side,dex,Teams,turn:0,active:{p1:[null,null],p2:[null,null]},roster:{p1:[],p2:[]},
    sideConditions:{p1:new Set(),p2:new Set()},megaUsed:{p1:false,p2:false},field:{trickroom:false,weather:'',terrain:''}};
}
export function observeChampionsPublic(s,chunk) {
  const lines=chunk.split('\n');
  for(const line of lines) {
    if(line.startsWith('|split|'))throw Error('Champions firewall: unsplit channel');
    if(line.startsWith('|request|')){const r=JSON.parse(line.slice(9));if(r&&r.side?.id!==s.side)throw Error('Champions firewall: opposing request');}
  }
  for(const line of lines) {
    const [,kind,...a]=line.split('|');
    if(kind==='request'||!kind)continue;
    observePublicEffects(s,kind,a);
    if(kind==='turn'){s.turn=+a[0];continue;}
    if(kind==='poke'&&s.roster[a[0]]){
      const species=a[1].split(',')[0];
      if(!s.roster[a[0]].some(m=>toID(m.species)===toID(species)))s.roster[a[0]].push({species,hp:1,moves:[],boosts:{},revealed:false});
      continue;
    }
    if(kind==='showteam') {
      const side=a.shift();if(!s.roster[side])continue;
      const bound=new Set();
      for(const set of s.Teams.unpack(a.join('|'))||[]) {
        let m=s.roster[side].find(x=>!bound.has(x)&&toID(x.species)===toID(set.species));
        if(!m){m={species:set.species,hp:1,boosts:{},moves:[],revealed:false};s.roster[side].push(m);}
        bound.add(m);
        // OTS nature is public in Champions. Stat points/IVs are NOT copied.
        Object.assign(m,{item:set.item,ability:set.ability,nature:set.nature,moves:set.moves.map(toID),sheet:true});
        m.sheetFacts={species:set.species,item:set.item,ability:set.ability,nature:set.nature,moves:set.moves.map(toID)};
      }
      continue;
    }
    const match=a[0]?.match(/^(p[12])([ab]):/),side=match?.[1],slot=match?.[2]==='b'?1:0;
    let mon=side?s.active[side][slot]:null;
    if(['switch','drag','replace'].includes(kind)&&side) {
      const species=a[1].split(',')[0];
      let next=s.roster[side].find(x=>x.ident===identity(a[0]))||s.roster[side].find(x=>!x.ident&&toID(x.species)===toID(species));
      if(!next){next={species,hp:1,moves:[],boosts:{}};s.roster[side].push(next);}
      if(kind!=='replace'){if(mon){mon.boosts={};mon.volatiles=[];mon.choiceLock='';delete mon.perishTurns;}Object.assign(next,{boosts:{},volatiles:[],acted:false,switchTurn:s.turn,lastMove:'',protectStreak:0,choiceLock:''});delete next.perishTurns;}
      else if(mon)Object.assign(next,{boosts:{...mon.boosts},volatiles:[...(mon.volatiles||[])],acted:mon.acted,lastMove:mon.lastMove,lastMoveTurn:mon.lastMoveTurn,protectStreak:mon.protectStreak,choiceLock:mon.choiceLock,perishTurns:mon.perishTurns});
      Object.assign(next,{ident:identity(a[0]),species,hp:hp(a[2]),status:a[2]?.split(' ')[1]||'',revealed:true});s.active[side][slot]=next;continue;
    }
    if(['detailschange','-formechange'].includes(kind)&&mon){mon.species=a[1].split(',')[0];continue;}
    if(kind==='-mega'&&side){
      s.megaUsed[side]=true;
      // Mega form and its sole ability are public, even without an -ability line.
      if(mon){const form=s.dex.species.get(mon.species);if(form.isMega)mon.ability=form.abilities['0'];}
      continue;
    }
    if(mon) {
      if(['-damage','-heal','-sethp'].includes(kind)){mon.hp=hp(a[1]);mon.status=a[1]?.split(' ')[1]||'';}
      if(kind==='faint')mon.hp=0;
      if(kind==='move') {const move=toID(a[1]);mon.protectStreak=s.dex.moves.get(move).stallingMove?(mon.lastMoveTurn===s.turn-1?(mon.protectStreak||0)+1:1):0;mon.lastMove=move;mon.lastMoveTurn=s.turn;mon.acted=true;if(!mon.moves.includes(move))mon.moves.push(move);if(/^choice(band|scarf|specs)$/.test(toID(mon.item))&&!a.slice(3).some(x=>x.startsWith('[from]')))mon.choiceLock=move;}
      if(kind==='cant')mon.acted=true;
      if(kind==='-fail'&&mon.lastMoveTurn===s.turn&&s.dex.moves.get(mon.lastMove).stallingMove)mon.protectStreak=0;
      if(kind==='-status')mon.status=a[1];if(kind==='-curestatus')mon.status='';
      if(kind==='-boost'||kind==='-unboost')mon.boosts[a[1]]=Math.max(-6,Math.min(6,(mon.boosts[a[1]]||0)+(+a[2])*(kind==='-boost'?1:-1)));
      if(kind==='-setboost')mon.boosts[a[1]]=+a[2];if(kind==='-clearboost')mon.boosts={};
      if(kind==='-item'||kind==='-enditem'){
        mon.item=kind==='-item'?a[1]:'';mon.choiceLock='';
        if(kind==='-enditem'&&toID(mon.ability)==='unburden'&&a[1]){mon.volatiles||=[];if(!mon.volatiles.includes('unburden'))mon.volatiles.push('unburden');}
      }
      if(kind==='-ability'){mon.ability=a[1];if(toID(mon.ability)!=='unburden')mon.volatiles=(mon.volatiles||[]).filter(id=>id!=='unburden');}
      if(kind==='-start'){mon.volatiles||=[];const effect=toID(a[1].replace(/^move: /,''));if(/^perish[0-3]$/.test(effect)){mon.volatiles=mon.volatiles.filter(id=>!/^perish[0-3]$/.test(id));mon.perishTurns=a.includes('[silent]')?4:Number(effect.at(-1));}if(!mon.volatiles.includes(effect))mon.volatiles.push(effect);}
      if(kind==='-end')mon.volatiles=(mon.volatiles||[]).filter(x=>x!==toID(a[1].replace(/^move: /,'')));
    }
    if(kind==='-sidestart')s.sideConditions[a[0].slice(0,2)]?.add(toID(a[1].replace(/^move: /,'')));
    if(kind==='-sideend')s.sideConditions[a[0].slice(0,2)]?.delete(toID(a[1].replace(/^move: /,'')));
    if(kind==='-weather')s.field.weather=toID(a[0]);
    if(['-fieldstart','-fieldend'].includes(kind)){const effect=toID(a[0].replace(/^move: /,'')),on=kind==='-fieldstart';if(effect==='trickroom')s.field.trickroom=on;else if(effect.endsWith('terrain'))s.field.terrain=on?effect:'';}
  }
}
export function megaForm(dex,mon) {
  const stone=dex.items.get(mon.item||'').megaStone;
  return typeof stone==='string'?stone:stone?.[dex.species.get(mon.species).baseSpecies]||null;
}
export function combatant(dex,publicMon={},own=null) {
  const species=own?.details?.split(',')[0]||publicMon.species;
  const data=dex.species.get(species||'');
  const stats={},nature=publicMon.nature||'Serious';
  for(const key of ['hp','atk','def','spa','spd','spe']) {
    // Public-stat estimate: neutral 11/66 points per stat, not hidden allocation.
    stats[key]=dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},data.baseStats||{hp:80,atk:80,def:80,spa:80,spd:80,spe:80},
      {nature,level:50,evs:Object.fromEntries(['hp','atk','def','spa','spd','spe'].map(k=>[k,11]))},key);
  }
  if(own){Object.assign(stats,own.stats||{});const max=String(own.condition).match(/^\d+\/(\d+)/);if(max)stats.hp=+max[1];}
  return {species:data.name||species,types:[...data.types||[]],stats,hp:own?hp(own.condition):publicMon.hp??1,
    item:own?.item??publicMon.item??'',ability:own?.ability||own?.baseAbility||publicMon.ability||'',nature,
    boosts:{...publicMon.boosts},status:own?.condition?.split(' ')[1]||publicMon.status||'',
    moves:[...(own?.moves||publicMon.moves||[])].map(toID),acted:!!publicMon.acted,lastMove:publicMon.lastMove||'',
    lastMoveTurn:publicMon.lastMoveTurn,protectStreak:publicMon.protectStreak||0,volatiles:[...publicMon.volatiles||[]],choiceLock:publicMon.choiceLock||'',...(publicMon.perishTurns!==undefined?{perishTurns:publicMon.perishTurns}:{}),revealed:!!publicMon.revealed,ident:identity(own?.ident||publicMon.ident)};
}
export function championsPosition(s,request) {
  if(request.side?.id!==s.side)throw Error('Champions firewall: own request required');
  const foe=s.side==='p1'?'p2':'p1';
  const own=(request.side.pokemon||[]).map(m=>combatant(s.dex,s.roster[s.side].find(p=>p.ident===identity(m.ident))||{},m));
  const opp=s.roster[foe].map(m=>combatant(s.dex,m));
  const active=[[0,1].map(i=>request.side.pokemon[i]?.active?i:-1),s.active[foe].map(m=>m?s.roster[foe].indexOf(m):-1)];
  for(const team of [own,opp])for(const m of team){
    const source=s.roster[team===own?s.side:foe].find(x=>x.ident===m.ident);
    if(source&&s.turn>(source.switchTurn??s.turn)+1)m.acted=true;
    if(m.lastMoveTurn!==s.turn-1)m.protectStreak=0;
  }
  const effects=publicEffectsSnapshot(s);
  return {turn:s.turn,teams:[own,opp],active,field:{...s.field},conditions:[[...s.sideConditions[s.side]],[...s.sideConditions[foe]]],megaUsed:[s.megaUsed[s.side],s.megaUsed[foe]],...(effects?{publicEffects:effects}:{})};
}
