// Versioned public-only features. Opposing synthetic stats/builds are deliberately
// excluded even when a caller supplies a belief world rather than the root.
export const SEARCH_FEATURES=Object.freeze({schema:'champions-search-features-v1',tokens:12,hashSize:1024,monCat:6,monNum:32,field:16,actionCat:4,actionNum:24});
export const SEARCH_FEATURES_V2=Object.freeze({...SEARCH_FEATURES,schema:'champions-search-features-v2',monCat:10});
const id=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
export function featureHash(x){if(!x)return 0;let h=2166136261;for(const c of id(x))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return 1+h%1023;}
const stats=['hp','atk','def','spa','spd','spe'],boosts=['atk','def','spa','spd','spe','accuracy','evasion'],statuses=['brn','par','slp','psn','tox','frz'];
export function encodeSearchState(p,features=SEARCH_FEATURES){
  const token_ids=[],token_num=[];
  for(let side=0;side<2;side++)for(let i=0;i<6;i++){
    const m=p.teams[side][i];if(!m){token_ids.push(Array(features.monCat).fill(0));token_num.push(Array(32).fill(0));continue;}
    const own=side===0,k=m.knowledge||{};
    token_ids.push([m.species,own||k.item?m.item:'',own||k.ability?m.ability:'',own||k.nature?m.nature:'',...(m.types||[])].slice(0,6).map(featureHash));while(token_ids.at(-1).length<6)token_ids.at(-1).push(0);
    if(features.monCat===10){const moves=own||k.sheet?m.moves:[];token_ids.at(-1).push(...Array.from({length:4},(_,i)=>featureHash(moves[i])));}
    token_num.push([m.hp,Number(p.active[side].includes(i)),Number(own),Number(m.revealed),Number(own||k.nature),Number(own||k.item),Number(own||k.ability),...stats.map(s=>own?(m.stats[s]||0)/300:0),...boosts.map(s=>(m.boosts?.[s]||0)/6),...statuses.map(s=>Number(m.status===s)),Number(m.acted),Number(p.megaUsed[side]),m.moves.length/4,Number(m.revealed||own),Number(k.sheet),Number(m.hp>0)]);
  }
  return {token_ids,token_num,field:[Math.min(p.turn,100)/100,Number(p.field.trickroom),...['sunnyday','raindance','sandstorm','snow','desolateland','primordialsea'].map(x=>Number(p.field.weather===x)),...['electricterrain','grassyterrain','mistyterrain','psychicterrain'].map(x=>Number(p.field.terrain===x)),...p.conditions.map(xs=>Number(xs.includes('tailwind'))),...p.conditions.map(xs=>Number(xs.includes('reflect')||xs.includes('lightscreen')))]};
}
export function encodeSearchActions(p,actions,side=0,dex=null){
  return {action_ids:actions.map(j=>[0,1].map(slot=>j.actions.find(a=>a.slot===slot)).flatMap(a=>[featureHash(a?.move?.id||a?.move?.move),featureHash(a?.type==='switch'?p.teams[side][a.choice-1]?.species:'')])),
    action_num:actions.map(j=>{const a=[0,1].map(slot=>j.actions.find(a=>a.slot===slot)),move=x=>dex&&x?.type==='move'?dex.moves.get(x.move.id||x.move.move):x?.move;return [...a.flatMap(x=>{const m=move(x);return [Number(x?.type==='move'),Number(x?.type==='switch'),Number(x?.type==='pass'),(x?.target||0)/2,Number(!!x?.mega),(m?.basePower||0)/200,(typeof m?.accuracy==='number'?m.accuracy:100)/100,(m?.priority||0)/8,Number(m?.category==='Physical'),Number(m?.category==='Special')];}),side,Number(a[0]?.target>0&&a[0]?.target===a[1]?.target),Number(a.some(x=>['allAdjacent','allAdjacentFoes'].includes(move(x)?.target))),Number(a.some(x=>move(x)?.category==='Status'))];})};
}

