// Analysis-only rendering. A trace labels assumed builds rather than presenting
// them as the opponent's hidden actual set. No visible browser UI integration.
export function renderChampionsTrace(trace){
  if(!trace?.publicOnly)throw Error('Require public analysis trace');
  const lines=[`Public ${trace.mode.toUpperCase()} search: heuristic value ${trace.value.toFixed(3)} (${trace.calibration})`];
  for(const a of trace.policy)lines.push(`${a.command}: equilibrium probability ${a.probability.toFixed(3)}`);
  lines.push(`Opponent responses: ${trace.opponentPolicy.map(a=>`${a.command} @ ${a.probability.toFixed(3)}`).join('; ')}`);
  for(const d of trace.damageRanges)lines.push(`${d.move} into ${d.target}: ${d.min}–${d.max}; KO probability ${d.koProbabilityRange.map(x=>x.toFixed(3)).join('–')} across sampled assumptions`);
  lines.push(`Matrix ${trace.matrixDimensions.join('x')}; residual ${trace.residual.toFixed(4)}; nodes ${trace.nodes}; ${trace.totalMs.toFixed(1)} ms`);
  for(const e of trace.expansions)if(e.deepen)lines.push(`Deepened ${e.deepen}: ${e.reason}`);
  return lines.join('\n');
}
