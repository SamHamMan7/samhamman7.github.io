// Public-information Champions agent. The neural prior is optional and is
// evaluated as an ablation; the selected search backbone needs no model.
import {enumerateChampionsActions} from './champions-actions.mjs';
import {chooseChampionsSearch,SEARCH_SETTINGS} from './champions-search.mjs';
import {chooseChampionsPreview} from './champions-preview.mjs';
export const STRONG_SETTINGS=Object.freeze({...SEARCH_SETTINGS,depth:2,enemyStatProfile:'offense',ownCap:6,responseCap:8,deepCandidates:2,secondOwnCap:2,secondResponseCap:2,neuralCandidates:1,buildRisk:.2});
export const STRONG_PROPOSAL_SETTINGS=Object.freeze({...SEARCH_SETTINGS,depth:2,enemyStatProfile:'offense'});
export async function loadChampionsStrong(directory='artifacts/champions/neural-v2-candidate-723'){
  const {loadChampionsCandidate}=await import('./champions-neural-candidate.mjs');
  const model=await loadChampionsCandidate(directory);
  return {model,settings:STRONG_SETTINGS,choose:(tracker,request,options={})=>chooseChampionsStrong(tracker,request,{...options,model,settings:STRONG_SETTINGS})};
}
export async function chooseChampionsStrong(tracker,request,{random=Math.random,model=null,settings=STRONG_SETTINGS}={}){
  if(request.side?.id!==tracker.state.side)throw Error('Champions strong firewall: own request required');
  const legal=enumerateChampionsActions(request);if(!legal.length)throw Error('Champions strong requires a legal request');
  if(request.teamPreview)return {chosen:chooseChampionsPreview(request,tracker.state.dex,{random}),source:'heuristic-preview',diagnostics:{neuralMs:0,searchMs:0,valueUsed:false}};
  settings={...STRONG_SETTINGS,...settings};
  let prior=[],neuralMs=0,neuralError=null;
  if(model){const start=performance.now();try{prior=(await model.rank(tracker,request)).ranked;if(!Array.isArray(prior))throw Error('Invalid neural prior');}catch(error){prior=[];neuralError=error.message;}neuralMs=performance.now()-start;}
  const {createChampionsExactEvaluator}=await import('./champions-exact-evaluator.mjs');
  const searchStart=performance.now();
  // Preserve the proven broad tactical search's joint plans before spending
  // engine simulations on finalists. Exact exchange scores decide the winner.
  const proposal=chooseChampionsSearch(legal,tracker.state,tracker.state.dex,{request,random:()=>0,prior,...STRONG_PROPOSAL_SETTINGS});
  const members=new Map(legal.map(j=>[j.command,j])),candidates=proposal.top.slice(0,settings.ownCap).map(j=>members.get(j.command));
  for(const j of prior.slice(0,settings.neuralCandidates)){const member=members.get(j.command);if(member&&!candidates.includes(member))candidates.push(member);}
  const evaluator=createChampionsExactEvaluator(tracker.state,request,tracker.state.dex,settings);
  let result,damageDiagnostics;
  try{result=chooseChampionsSearch(candidates,tracker.state,tracker.state.dex,{request,random,prior,...settings,ownCap:candidates.length,evaluator});damageDiagnostics=evaluator.diagnostics();}
  finally{evaluator.decision.dispose();}
  if(!legal.some(j=>j.command===result.chosen.command))throw Error('Champions strong produced a nonmember legal command');
  return {...result,source:neuralError?'tactical-fallback':model?'hybrid':'search',diagnostics:{...result.diagnostics,legal:legal.length,proposalMs:proposal.diagnostics.ms,proposalCandidates:proposal.diagnostics.ownCandidates,...damageDiagnostics,searchMs:performance.now()-searchStart,neuralMs,neuralError,valueUsed:false}};
}
