import {toID} from './champions-public.mjs';
// Only publicly disclosed persistent facts. Battle HP/boosts/effects reset.
export function seriesFacts(state){
  return {schema:'champions-public-series-v1',games:1,teams:Object.fromEntries(['p1','p2'].map(side=>[side,state.roster[side].map(m=>({species:state.dex.species.get(m.species).baseSpecies||m.species,moves:[...m.moves],
    ...(m.sheet?{nature:(m.sheetFacts||m).nature,item:(m.sheetFacts||m).item,ability:(m.sheetFacts||m).ability,sheet:true}:{}),
    ...(!m.sheet&&m.item?{item:m.item}:{}),...(!m.sheet&&m.ability?{ability:m.ability}:{})}))]))};
}
export function mergeSeriesFacts(before,next){
  if(!before)return structuredClone(next);
  const out=structuredClone(next);out.games=before.games+1;
  for(const side of ['p1','p2'])for(const old of before.teams[side]){
    const mon=out.teams[side].find(m=>toID(m.species)===toID(old.species));
    if(mon)mon.moves=[...new Set([...old.moves,...mon.moves])];
  }
  return out;
}
export function applySeriesFacts(state,facts){
  if(!facts||facts.schema!=='champions-public-series-v1')return;
  for(const side of ['p1','p2'])for(const known of facts.teams[side]){
    let mon=state.roster[side].find(m=>toID(m.species)===toID(known.species));
    if(!mon){mon={species:known.species,hp:1,moves:[],boosts:{},revealed:false};state.roster[side].push(mon);}
    // Never Object.assign untrusted records: explicitly copy allowed facts.
    mon.moves=[...new Set([...mon.moves,...known.moves])];
    for(const key of ['nature','item','ability'])if(known[key]!==undefined)mon[key]=known[key];
    if(known.sheet)mon.sheet=true;
  }
}
