// Experimental runner refinement from disclosed effects/moves only. This does
// not alter the browser policy or consult opposing requests/simulator objects.
import {toID} from './champions-public.mjs';
export function publicLegalRequest(state,request){
  if(request.side?.id!==state.side)throw Error('Legality firewall: own request required');
  if(!request.active)return request;const foe=state.side==='p1'?'p2':'p1',blocked=new Set();
  for(const m of state.active[foe])if(m&&m.hp>0&&m.volatiles?.includes('imprison'))for(const move of m.moves)blocked.add(toID(move));
  if(!blocked.size)return request;return {...request,active:request.active.map(a=>a?{...a,moves:a.moves.map(m=>blocked.has(toID(m.id||m.move))?{...m,disabled:true}:m)}:a)};
}
