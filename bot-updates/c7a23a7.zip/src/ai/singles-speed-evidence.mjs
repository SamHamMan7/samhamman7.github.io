import {Dex} from '@pkmn/sim';
import {effectiveSpeed, toID} from './damage.js';

const evs = {hp: 84, atk: 84, def: 84, spa: 84, spd: 84, spe: 84};
const ALLOWED = new Set(['move', 'damage', 'heal', 'boost', 'unboost', 'crit', 'miss', 'fail', 'cant', 'faint']);
const slowItems = new Set(['ironball', 'machobrace', 'powerweight', 'powerbracer', 'powerbelt', 'powerlens', 'powerband', 'poweranklet']);
const speed = (m, field, reverse) => effectiveSpeed(m, field, reverse) * (slowItems.has(toID(m.item)) ? .5 : 1);

/** Conservative evidence, NOT an item revelation. Only a complete previous
 * public turn, with the SAME two visits and unambiguous normal-priority moves,
 * can support a Scarf hypothesis. No private opposing stats/set is inspected. */
export function publicScarfEvidence(view, own, opponent) {
  if (view.format !== 'gen9randombattle' || view.field?.trickRoom || Object.hasOwn(opponent, 'item')) return null;
  if (['stall', 'slowstart'].includes(toID(own.ability)) || ['laggingtail', 'fullincense'].includes(toID(own.item))) return null;
  const activeOwn = view.own?.active?.[0], activeFoe = view.opponent?.active?.[0], turn = view.turn - 1;
  if (own.transformed || opponent.transformed || activeOwn?.transformed || activeFoe?.transformed) return null;
  if (!(activeOwn?.publicRef > 0 && activeFoe?.publicRef > 0)) return null;
  const events = (view.semanticHistory || []).filter(e => e.turn === turn);
  if (!events.length || events[0].ordinal !== 1 || events.some(e => !ALLOWED.has(e.kind))) return null;
  const moves = events.filter(e => e.kind === 'move');
  if (moves.length !== 2 || moves[0].actor?.side !== 'opponent' || moves[1].actor?.side !== 'own') return null;
  const matches = (e, side, m) => e.actor.side === side && e.actor.ref === m.publicRef && e.actor.species === toID(m.species);
  if (!matches(moves[0], 'opponent', activeFoe) || !matches(moves[1], 'own', activeOwn)) return null;
  if (moves.some(e => {const m = Dex.moves.get(e.move); return !m.exists || m.priority !== 0 || m.category === 'Status';})) return null;
  const abilities = opponent.ability ? [opponent.ability] : Object.values(Dex.species.get(opponent.species).abilities);
  // These can make order independent of raw Speed. Unknown activation state is
  // deliberately not guessed, and never turned into a false Scarf assertion.
  if (abilities.some(a => ['quickdraw', 'galewings', 'triage', 'unburden'].includes(toID(a)))) return null;
  const before = (mon, side) => {
    const boosts = {...mon.boosts};
    for (const e of events) if (['boost', 'unboost'].includes(e.kind) && e.actor?.side === side && e.effect === 'spe') {
      if (e.actor.ref !== (side === 'own' ? activeOwn : activeFoe).publicRef) return null;
      boosts.spe = (boosts.spe || 0) - e.amount;
      if (boosts.spe < -6 || boosts.spe > 6) return null;
    }
    return boosts;
  };
  const ownBoosts = before(own, 'own'), foeBoosts = before(opponent, 'opponent');
  if (!ownBoosts || !foeBoosts) return null;
  const ownSpeed = speed({...own, boosts: ownBoosts}, view.field, false);
  // Whitelist the opponent's PUBLIC fields. Never accept exactStats, private
  // EVs/IVs, a generated set, or an unrevealed Tera type from a caller.
  const foe = {species: opponent.species, level: opponent.level || 100, boosts: foeBoosts, status: opponent.status,
    evs, nature: 'Serious', hpFraction: opponent.hpFraction, boostedStat: opponent.boostedStat,
    terastallized: opponent.terastallized, ...(opponent.terastallized ? {teraType: opponent.teraType} : {})};
  const maximum = Math.max(...abilities.map(ability => speed({...foe, ability, item: ''}, view.field, true)));
  const scarfMaximum = Math.max(...abilities.map(ability => speed({...foe, ability, item: 'Choice Scarf'}, view.field, true)));
  // Avoid converting a possible integer-rounding tie into item evidence.
  if (!(ownSpeed > maximum + 2 && scarfMaximum >= ownSpeed)) return null;
  return {kind: 'scarf-compatible-public-order', turn, ownRef: activeOwn.publicRef, opponentRef: activeFoe.publicRef,
    ownSpeed, unscarfMaximum: maximum, scarfMaximum,
    source: 'complete public turn; listed species/normal RandBats spread assumptions; reversed Speed stages; Scarf is compatible, not revealed (Illusion/other unmodeled causes remain possible)'};
}
