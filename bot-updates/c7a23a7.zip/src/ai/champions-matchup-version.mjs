// Hash every runtime feature dependency so an experimental checkpoint cannot
// silently run under different public feature semantics after a source edit.
import fs from 'node:fs/promises';import {createHash} from 'node:crypto';
export const MATCHUP_SOURCE_FILES=['src/ai/champions-matchup-version.mjs','src/ai/champions-matchup-candidates.mjs','src/ai/champions-neural-matchup.mjs','src/ai/champions-candidates.mjs','src/ai/champions-neural-observation.mjs','src/ai/champions-neural.mjs','src/ai/champions-public.mjs','src/ai/champions-public-effects.mjs','src/ai/champions-damage.mjs','src/ai/champions-search.mjs','src/ai/champions-actions.mjs','src/ai/champions-policy-calibration.mjs'];
export async function matchupImplementationHash(){const sources=await Promise.all(MATCHUP_SOURCE_FILES.map(async f=>[f,createHash('sha256').update(await fs.readFile(new URL('../../'+f,import.meta.url))).digest('hex')]));return createHash('sha256').update(JSON.stringify(sources)).digest('hex');}
