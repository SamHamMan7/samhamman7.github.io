import {seededChampionsRandom} from './champions-search.mjs';
const scale=400/Math.log(10),sigmoid=x=>1/(1+Math.exp(-Math.max(-30,Math.min(30,x))));
// Relative Bradley-Terry maximum likelihood with a weak ridge for separated
// smoke outcomes. Bootstrap resamples whole paired-matchup clusters.
export function fitRelativeStrength(matches,{iterations=3000,ridge=.05}={}){
  if(!matches.length)throw Error('Calibration needs matches');const ids=[...new Set(matches.flatMap(m=>[m.a,m.b]))].sort(),scores=Object.fromEntries(ids.map(x=>[x,0]));
  for(const m of matches)if(!Number.isFinite(m.score)||m.score<0||m.score>1||m.a===m.b)throw Error('Invalid calibration match');
  for(let step=0;step<iterations;step++){
    const g=Object.fromEntries(ids.map(x=>[x,-ridge*scores[x]]));
    for(const m of matches){const error=m.score-sigmoid(scores[m.a]-scores[m.b]);g[m.a]+=error;g[m.b]-=error;}
    const rate=.6/Math.max(1,matches.length/ids.length),mean=ids.reduce((s,id)=>s+scores[id]+rate*g[id],0)/ids.length;
    let delta=0;for(const id of ids){const next=scores[id]+rate*g[id]-mean;delta=Math.max(delta,Math.abs(next-scores[id]));scores[id]=next;}if(delta<1e-8)break;
  }
  return {ratings:Object.fromEntries(ids.map(id=>[id,scores[id]*scale])),predict:(a,b)=>sigmoid(scores[a]-scores[b]),regularization:ridge};
}
export function calibrateProfiles(format,matches,{samples=200,seed=7139,order=['casual','medium','high','maximum']}={}){
  if(!['champions-bo1','champions-bo3','gen9ou','gen9randombattle'].includes(format))throw Error('Unsupported calibration format');
  const fit=fitRelativeStrength(matches),groups=new Map();for(const m of matches){const k=m.cluster||m.pair;if(k===undefined)throw Error('Paired calibration requires cluster ID');if(!groups.has(k))groups.set(k,[]);groups.get(k).push(m);}
  const clusters=[...groups.values()],rng=seededChampionsRandom(seed),draws=Object.fromEntries(Object.keys(fit.ratings).map(k=>[k,[]]));
  for(let b=0;b<samples;b++){const selected=Array.from({length:clusters.length},()=>clusters[Math.floor(rng()*clusters.length)]).flat(),ratings=fitRelativeStrength(selected,{iterations:1000}).ratings;for(const id of Object.keys(draws))if(ratings[id]!==undefined)draws[id].push(ratings[id]);}
  const profiles=Object.entries(fit.ratings).map(([id,relativeRating])=>{const x=draws[id].sort((a,b)=>a-b);return {id,relativeRating,relativeInterval:{low:x[Math.floor(x.length*.025)]??null,high:x[Math.min(x.length-1,Math.floor(x.length*.975))]??null},absoluteElo:null,absoluteAnchorValidated:false,status:'uncalibrated'};});
  const monotonic=order.slice(1).every((id,i)=>fit.ratings[id]===undefined||fit.ratings[order[i]]===undefined||fit.ratings[id]>=fit.ratings[order[i]]);
  return {schema:'offline-strength-calibration-v1',format,profiles,matches:matches.length,independentClusters:clusters.length,bootstrapSamples:samples,seed,monotonic,absoluteAnchor:null,status:'uncalibrated',scope:'Relative offline pool only; no ladder anchor; intervals clustered by paired matchup; small runs are diagnostic'};
}
export function resolveEstimatedElo(format,elo,calibration){
  if(calibration?.format!==format||!calibration.absoluteAnchor?.validated)throw Error('Absolute Elo is uncalibrated for this format');
  const rows=calibration.profiles.filter(p=>p.absoluteAnchorValidated&&Number.isFinite(p.absoluteElo));if(!rows.length)throw Error('No defensibly anchored profile');
  return rows.reduce((best,p)=>Math.abs(p.absoluteElo-elo)<Math.abs(best.absoluteElo-elo)?p:best);
}
