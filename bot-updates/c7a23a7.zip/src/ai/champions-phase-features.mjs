// Same V4 graph and tensor sizes. Own evidence slots carry a known locked action
// only during an interrupted turn; ordinary inputs and old checkpoints are unchanged.
import {encodeSignalState} from './champions-signal-features.mjs';
const types=['Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy'];
export function encodePhaseSignalState(p,dex){
 const state=encodeSignalState(p,dex);
 for(const action of p.publicContext?.pivot?.ownPending||[]){
  const index=p.active[0][action.slot];if(index<0||index>=6)continue;
  const move=dex.moves.get(action.move.id),category=['Physical','Special','Status'].indexOf(move.category);
  state.evidence[index]=[((move.basePower||0)+300*Math.max(0,category))/800,Math.max(0,types.indexOf(move.type))/18,(move.priority||0)/8,(action.target||0)/5+(action.mega?2:0)];
 }
 return state;
}
