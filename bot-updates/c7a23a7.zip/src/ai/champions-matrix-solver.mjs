const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const normal=a=>{const s=a.reduce((x,y)=>x+y,0);return s?a.map(x=>x/s):a.map(()=>1/a.length);};
export function matrixResidual(matrix,row,column){
  const rows=matrix.map(r=>dot(r,column)),columns=column.map((_,j)=>dot(row,matrix.map(r=>r[j])));
  const upper=Math.max(...rows),lower=Math.min(...columns);return {upper,lower,residual:upper-lower,value:dot(row,rows)};
}
export function solveMatrixGame(matrix,{iterations=1000,tolerance=.01}={}){
  if(!matrix.length||!matrix[0].length||matrix.some(r=>r.length!==matrix[0].length||r.some(x=>!Number.isFinite(x))))throw Error('Invalid finite rectangular matrix');
  const n=matrix.length,m=matrix[0].length,rr=Array(n).fill(0),cr=Array(m).fill(0),ra=Array(n).fill(0),ca=Array(m).fill(0);
  let result,used=0;
  for(let t=1;t<=iterations;t++){
    const row=normal(rr.map(x=>Math.max(0,x))),column=normal(cr.map(x=>Math.max(0,x))),values=matrix.map(r=>dot(r,column)),v=dot(row,values);
    for(let i=0;i<n;i++){rr[i]+=values[i]-v;ra[i]+=row[i];}
    for(let j=0;j<m;j++){cr[j]+=v-dot(row,matrix.map(r=>r[j]));ca[j]+=column[j];}
    used=t;if(t%25===0||t===iterations){const rowStrategy=normal(ra),columnStrategy=normal(ca);result={rowStrategy,columnStrategy,...matrixResidual(matrix,rowStrategy,columnStrategy)};if(result.residual<=tolerance)break;}
  }
  return {...result,iterations:used};
}
export function sampleStrategy(strategy,random){let x=random();for(let i=0;i<strategy.length;i++){x-=strategy[i];if(x<=0)return i;}return strategy.length-1;}
export function doubleOracle(rowPool,columnPool,payoff,{initial=2,maxIterations=4,tolerance=.02,solverIterations=500,responseBatch=Infinity,onIteration=()=>{},onSolve=()=>{}}={}){
  const rows=rowPool.slice(0,initial),columns=columnPool.slice(0,initial),cache=new Map();
  const cell=(a,b)=>{const key=JSON.stringify([a.command,b.command]);if(!cache.has(key))cache.set(key,payoff(a,b));return cache.get(key);};
  const solve=matrix=>{const t=performance.now();try{return solveMatrixGame(matrix,{iterations:solverIterations,tolerance});}finally{onSolve(performance.now()-t);}};
  let solution,externalResidual=null,used=0,budgetStopped=false;
  for(let t=0;t<maxIterations;t++){
    const matrix=rows.map(a=>columns.map(b=>cell(a,b)));solution=solve(matrix);used=t+1;
    let rb={value:-Infinity},cb={value:Infinity};
    try{
    const batch=(pool,inside)=>{const outside=pool.filter(a=>!inside.includes(a));if(!Number.isFinite(responseBatch))return pool;const offset=outside.length?(t*responseBatch)%outside.length:0;return [...inside,...Array.from({length:Math.min(responseBatch,outside.length)},(_,i)=>outside[(offset+i)%outside.length])];};
    const rowScan=batch(rowPool,rows),columnScan=batch(columnPool,columns),complete=rowScan.length===rowPool.length&&columnScan.length===columnPool.length;
    for(const a of rowScan){const value=dot(columns.map(b=>cell(a,b)),solution.columnStrategy);if(value>rb.value)rb={action:a,value};}
    for(const b of columnScan){const value=dot(rows.map(a=>cell(a,b)),solution.rowStrategy);if(value<cb.value)cb={action:b,value};}
    externalResidual=complete?rb.value-cb.value:null;onIteration({iteration:t+1,rows:rows.length,columns:columns.length,externalResidual,scannedResidual:rb.value-cb.value,responseScope:complete?'full candidate pool':'bounded response batch',scanned:[rowScan.length,columnScan.length]});
    if(complete&&externalResidual<=tolerance)break;
    const addRow=!rows.includes(rb.action),addColumn=!columns.includes(cb.action);
    if(!addRow&&!addColumn){if(complete)break;continue;}
    // Evaluate expansion transactionally; a budget stop must never leave an
    // incomplete matrix or fill an unevaluated cell with an invented payoff.
    if(addRow)for(const b of columns)cell(rb.action,b);
    if(addColumn)for(const a of rows)cell(a,cb.action);
    if(addRow&&addColumn)cell(rb.action,cb.action);
    if(addRow)rows.push(rb.action);if(addColumn)columns.push(cb.action);
    }catch(error){if(error.name!=='SearchBudgetExceeded')throw error;externalResidual=null;budgetStopped=true;break;}
  }
  const matrix=rows.map(a=>columns.map(b=>cell(a,b)));solution=solve(matrix);
  return {...solution,rows,columns,matrix,oracleIterations:used,externalResidual,budgetStopped,evaluatedCells:cache.size};
}
