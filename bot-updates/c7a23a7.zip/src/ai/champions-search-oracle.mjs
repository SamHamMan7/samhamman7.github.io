import {createChampionsDamageDecision,createPublicDamageBattle} from './champions-damage.mjs';
import {boardValue} from './champions-search.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
const freeze=x=>{if(x&&typeof x==='object'&&!Object.isFrozen(x)){Object.freeze(x);for(const v of Object.values(x))freeze(v);}return x;};
export class SearchBudgetExceeded extends Error {constructor(){super('Search node/time budget exhausted');this.name='SearchBudgetExceeded';}}
export function prepareSearchSandbox(b){
  // References belong exclusively to this detached public sandbox. The engine
  // normally installs these targets when initializing Pokemon effect states;
  // the serialized public forecast intentionally does not retain live objects.
  for(const s of b.sides)for(const m of s.pokemon){m.itemState.target=m;m.abilityState.target=m;m.statusState.target=m;for(const v of Object.values(m.volatiles))v.target=m;}return b;
}
export function createSearchOracle(publicPosition,dex,{nodes=128,timeMs=500,minimumNodes=0,valueFunction=null,repairEffectTargets=false}={}){
  const start=performance.now(),decision=createChampionsDamageDecision(publicPosition,{prepareBattle:repairEffectTargets?prepareSearchSandbox:null}),outcomes=new Map(),legality=new Map(),speeds=new Map();
  const metrics={nodes:0,outcomeCacheHits:0,legalityCacheHits:0,speedCacheHits:0,oracleMs:0};
  const signature=p=>JSON.stringify(p);
  function evaluateJointOutcome(publicState,ourJointAction,opponentJointAction,beliefWorld,{seed=0,prefix=[]}={}){
    if(!beliefWorld||!['public-corpus-prior','public-archetype','public-forecast'].includes(beliefWorld.source))throw Error('A public belief world is required');
    const p=beliefWorld.position,key=JSON.stringify([publicState.turn,p,ourJointAction.actions,opponentJointAction.actions,seed,prefix]);
    if(outcomes.has(key)){metrics.outcomeCacheHits++;return outcomes.get(key);}
    if(metrics.nodes>=nodes||metrics.nodes>=minimumNodes&&performance.now()-start>=timeMs)throw new SearchBudgetExceeded();
    const t=performance.now();metrics.nodes++;
    try{
      const result=decision.exchange(p,ourJointAction,opponentJointAction,{seed:seed%65500,nativeChance:true,chancePrefix:prefix});
      const terminal=result.ended&&(result.winner==='Public opponent'||result.position.teams[1].filter(m=>m.revealed).length>=p.teams[0].length);
      const value=valueFunction?valueFunction(result):terminal?(result.winner==='Public own'?1:result.winner==='Public opponent'?-1:0):Math.tanh((boardValue(dex,result.position,0)-boardValue(dex,result.position,1))/180);
      const out=freeze({...result,value,world:beliefWorld.id,probabilityScope:'native seeded sample; explicitly branched events carry exact engine conditional probabilities'});outcomes.set(key,out);return out;
    }finally{metrics.oracleMs+=performance.now()-t;}
  }
  function legalActions(p,side){
    const key=JSON.stringify([signature(p),side]);if(legality.has(key)){metrics.legalityCacheHits++;return legality.get(key);}
    const b=createPublicDamageBattle(p);
    if(repairEffectTargets)prepareSearchSandbox(b);
    try{
      if(b.ended)return [];
      b.makeRequest('move');const s=b.sides[side],request=s.activeRequest;
      const actions=enumerateChampionsActions(request).map(j=>({...j,actions:j.actions.map(a=>a.type==='switch'?{...a,choice:s.pokemon[a.choice-1].m.publicIndex+1}:a)}));
      legality.set(key,actions);return actions;
    }finally{b.destroy();}
  }
  function speedRelationships(p){
    const key=signature(p);if(speeds.has(key)){metrics.speedCacheHits++;return speeds.get(key);}
    const b=createPublicDamageBattle(p);if(repairEffectTargets)prepareSearchSandbox(b);try{const value=freeze(b.sides.map(s=>s.active.map(m=>m?{index:m.m.publicIndex,speed:m.speed,priorityScope:'move priority is resolved by engine exchange',trickRoom:p.field.trickroom}:null)));speeds.set(key,value);return value;}finally{b.destroy();}
  }
  return {evaluateJointOutcome,legalActions,speedRelationships,decision,metrics,canAfford:n=>metrics.nodes+n<=nodes&&(metrics.nodes+n<=minimumNodes||performance.now()-start<timeMs),
    diagnostics:()=>({...metrics,...decision.metrics,totalOracleElapsedMs:performance.now()-start}),dispose(){decision.dispose();outcomes.clear();legality.clear();speeds.clear();}};
}
export function selectiveChance(oracle,publicState,our,foe,world,{seed=0,maxCalls=1,threshold=.06}={}){
  const initial=oracle.evaluateJointOutcome(publicState,our,foe,world,{seed}),leaves=[{probability:1,result:initial,prefix:[]}];let calls=1;
  if(maxCalls>1)for(let index=0;index<initial.chanceEvents.length;index++){
    const event=initial.chanceEvents[index],options=event.outcomes;
    if(options.length+calls>maxCalls||!oracle.canAfford(options.length))continue;
    const prior=initial.chanceEvents.slice(0,index).map(e=>({kind:e.kind,value:e.value}));
    const results=options.map(o=>({probability:o.probability,prefix:[...prior,{kind:event.kind,value:o.value}],result:oracle.evaluateJointOutcome(publicState,our,foe,world,{seed,prefix:[...prior,{kind:event.kind,value:o.value}]})}));calls+=options.length;
    if(Math.max(...results.map(r=>r.result.value))-Math.min(...results.map(r=>r.result.value))<threshold)continue;
    leaves.splice(0,leaves.length,...results);break;
  }
  const mass=leaves.reduce((s,l)=>s+l.probability,0);if(Math.abs(mass-1)>1e-9)throw Error('Chance probability mass lost');
  return {leaves,value:leaves.reduce((s,l)=>s+l.probability*l.result.value,0),probabilityMass:mass,calls,sampledRemainder:true};
}
