﻿const TARGETS = [0, -1, -2, 1, 2];

function legalTargets(move, slot) {
  switch (move.target) {
    case 'normal':
    case 'any':
      return [1, 2, -(2 - slot)];

    case 'adjacentFoe':
      return [1, 2];

    case 'adjacentAlly':
      return [-(2 - slot)];

    case 'adjacentAllyOrSelf':
      return [-1, -2];

    default:
      return [0];
  }
}

function living(mon) {
  return mon &&
    !mon.fainted &&
    !/\bfnt\b/.test(mon.condition || '');
}

function serialize(x) {
  if (x.type === 'pass') return 'pass';

  if (x.type === 'switch') {
    return `switch ${x.choice}`;
  }

  return `move ${x.choice}` +
    (x.target ? ` ${x.target}` : '') +
    (x.mega ? ' mega' : '');
}

export function enumerateChampionsActions(request) {
  if (request.teamPreview) {
    const roster = request.side?.pokemon || [];
    const pick =
      request.maxChosenTeamSize ??
      request.maxTeamSize ??
      4;

    const out = [];

    function rec(prefix, available) {
      if (prefix.length === pick) {
        out.push({
          phase: 'preview',
          order: prefix,
          command: `team ${prefix.join('')}`,
        });
        return;
      }

      for (const n of available) {
        rec(
          [...prefix, n],
          available.filter(x => x !== n)
        );
      }
    }

    rec([], roster.map((_, i) => i + 1));
    return out;
  }

  if (request.wait) return [];

  const roster = request.side?.pokemon || [];

  const bench = roster
    .map((m, i) =>
      !m.active && living(m) ? i + 1 : 0
    )
    .filter(Boolean);

  const force = Array.isArray(request.forceSwitch)
    ? request.forceSwitch
    : null;

  const forcedCount = force
    ? force.filter(Boolean).length
    : 0;

  const requiredSwitches = force
    ? Math.min(forcedCount, bench.length)
    : null;

  const perSlot = [0, 1].map(slot => {
    const req = request.active?.[slot];
    const actions = [];

    /*
     * Forced-replacement phase:
     *
     * A slot that does not need replacing must pass.
     *
     * If more slots fainted than there are surviving bench
     * Pokémon, a forced slot is also allowed to pass. The
     * joint-action check below ensures exactly the available
     * number of replacements are actually sent.
     */
    if (force) {
      if (!force[slot]) {
        return [{slot, type: 'pass'}];
      }

      for (const n of bench) {
        actions.push({
          slot,
          type: 'switch',
          choice: n,
        });
      }

      if (forcedCount > bench.length) {
        actions.push({
          slot,
          type: 'pass',
        });
      }

      return actions;
    }

    const slotMon = roster[slot];

    // Showdown auto-passes an empty, fainted, or Commanding active slot.
    // We must represent that explicitly as pass instead of sending a move.
    if (
      !req ||
      !slotMon ||
      !slotMon.active ||
      !living(slotMon) ||
      slotMon.commanding
    ) {
      return [{slot, type: 'pass'}];
    }

    if (!req.trapped) {
      for (const n of bench) {
        actions.push({
          slot,
          type: 'switch',
          choice: n,
        });
      }
    }

    for (const [i, move] of (req.moves || []).entries()) {
      if (move.disabled || move.pp === 0) continue;

      for (const target of legalTargets(move, slot)) {
        actions.push({
          slot,
          type: 'move',
          choice: i + 1,
          target,
          mega: false,
          move,
        });

        if (req.canMegaEvo) {
          actions.push({
            slot,
            type: 'move',
            choice: i + 1,
            target,
            mega: true,
            move,
          });
        }
      }
    }

    return actions;
  });

  const joint = [];

  for (const a of perSlot[0]) {
    for (const b of perSlot[1]) {
      const actions = [a, b];

      const switches = actions.filter(
        x => x.type === 'switch'
      );

      // Cannot send both active slots into the same party member.
      if (
        new Set(switches.map(x => x.choice)).size !==
        switches.length
      ) {
        continue;
      }

      // During forced replacement, send exactly as many
      // replacements as the remaining roster permits.
      if (
        requiredSwitches !== null &&
        switches.length !== requiredSwitches
      ) {
        continue;
      }

      // Only one Mega activation in a joint turn.
      if (
        actions.filter(x => x.mega).length > 1
      ) {
        continue;
      }

      joint.push({
        actions,
        command:
          `${serialize(a)}, ${serialize(b)}`,
      });
    }
  }

  return joint;
}

