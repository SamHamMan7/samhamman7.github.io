import {Dex} from '@pkmn/sim';
import {clamp, toID, hazardCost} from './damage.js';
import {possibleMoves, opponentHypotheses} from './priors.js';

// A bounded public matchup portfolio, not an extra simulator or an opponent set
// oracle. Keep permanent Tera typing and the OPTION to Tera a different check
// separate. Only already revealed opponents are considered.
const alive = m => m && !m.fainted && !String(m.condition || '').includes('fnt') && m.hpFraction > 0;
const key = m => m.ident || m.species;
const attack = move => move.exists && move.category !== 'Status';
const boost = n => n >= 0 ? (2 + n) / 2 : 2 / (2 - n);

export function createTeamSafety(ctx, moveFirst) {
  const {roster, own, view, field} = ctx;
  const available = !!ctx.request.active?.[0]?.canTerastallize;
  const publicFoes = [...(view.opponent?.revealed || [])];
  if (!publicFoes.some(m => key(m) === key(ctx.opponent))) publicFoes.unshift(ctx.opponent);
  const foes = publicFoes.filter(alive).sort((a, b) => {
    if (key(a) === key(ctx.opponent)) return -1;
    if (key(b) === key(ctx.opponent)) return 1;
    const power = m => {const s = Dex.species.get(m.species).baseStats; return Math.max(s.atk, s.spa) + s.spe;};
    return power(b) - power(a) || key(a).localeCompare(key(b));
  }).slice(0, 3);
  const start = ctx.calculations;
  const cards = [];
  for (const publicFoe of foes) {
    const active = key(publicFoe) === key(ctx.opponent);
    const initial = opponentHypotheses({...publicFoe, ...(active ? {} : {boosts: {}, lastMove: null, volatiles: []})}, view.format, 1)[0];
    if (!initial) continue;
    const foe = {...initial, boosts: {}};
    const moves = possibleMoves(foe, 9, view.format).map(m => Dex.moves.get(m)).filter(attack);
    if (!moves.length) continue;
    const profiles = roster.map(mon => {
      if (!alive(mon)) return null;
      const ownMoves = (mon.moves || []).map(m => Dex.moves.get(m)).filter(attack);
      const profile = transformed => {
        const incoming = moves.map(move => ({move, damage: ctx.damage(foe, transformed, move.name, true)}));
        const outgoing = ownMoves.map(move => ({move, damage: ctx.damage(transformed, foe, move.name)}));
        return {mon: transformed, incoming, outgoing, order: new Map()};
      };
      const normal = profile(mon);
      const tera = available && mon.teraType && !mon.terastallized
        ? profile({...mon, terastallized: mon.teraType}) : null;
      return {normal, tera};
    });
    cards.push({foe, initial, active, profiles});
  }
  const calculations = ctx.calculations - start;

  function answer(profile, hp, target, entering, current = profile?.mon) {
    if (!profile || hp <= 0) return 0;
    const {mon, incoming, outgoing} = profile;
    const hazards = entering ? hazardCost(mon, field.sideConditions) : 0;
    if (hp <= hazards) return 0;
    let best = 0;
    for (const ours of outgoing) {
      const attackStat = ours.move.category === 'Physical' ? 'atk' : 'spa';
      const defenseStat = ours.move.overrideDefensiveStat || (ours.move.category === 'Physical' ? 'def' : 'spd');
      let damage = ours.damage.mean;
      if (toID(target.ability) !== 'unaware') damage *= boost(current.boosts?.[attackStat] || 0) / boost(mon.boosts?.[attackStat] || 0);
      if (toID(mon.ability) !== 'unaware') damage /= boost(target.boosts?.[defenseStat] || 0);
      if (damage <= 0) continue;
      let quality = 1;
      for (const theirs of incoming) {
        let incomingDamage = theirs.damage.mean;
        // Full-HP shields cannot be retained after this piece takes damage.
        if (mon.hpFraction >= 1 && hp < 1 && ['multiscale', 'shadowshield'].includes(toID(mon.ability))) incomingDamage *= 2;
        const stat = theirs.move.category === 'Physical' ? 'atk' : 'spa';
        if (toID(mon.ability) !== 'unaware') incomingDamage *= boost(target.boosts?.[stat] || 0);
        const defense = theirs.move.overrideDefensiveStat || (theirs.move.category === 'Physical' ? 'def' : 'spd');
        if (toID(target.ability) !== 'unaware') incomingDamage *= boost(mon.boosts?.[defense] || 0) / boost(current.boosts?.[defense] || 0);
        const turns = Math.min(8, Math.ceil((target.hpFraction - 1e-9) / damage));
        const priority = m => m.priority + (m.id === 'grassyglide' && toID(field.terrain) === 'grassyterrain' ? 1 : 0);
        const orderKey = [priority(ours.move), priority(theirs.move), current.boosts?.spe || 0, target.boosts?.spe || 0, current.status, target.status].join(':');
        if (!profile.order.has(orderKey)) profile.order.set(orderKey, moveFirst({...mon, boosts: current.boosts}, target, ours.move.name, theirs.move.name, field));
        const first = profile.order.get(orderKey);
        const hits = Math.max(0, turns - first);
        const margin = count => incomingDamage ? clamp((hp - hazards - incomingDamage * count) / Math.max(.15, incomingDamage) + .5) : 1;
        // A hard switch must absorb an entry hit. A fragile revenge killer is
        // still an answer, but weaker insurance than a safe switch-in.
        const survives = entering ? Math.max(margin(hits + 1), .65 * margin(hits)) : margin(hits);
        quality = Math.min(quality, survives * ours.damage.accuracy);
      }
      if (ours.move.selfdestruct) quality *= .5;
      best = Math.max(best, quality);
    }
    return best;
  }

  function value(card, state, canTera) {
    let normal = 0, withTera = 0;
    for (let i = 0; i < roster.length; i++) {
      const profiles = card.profiles[i];
      if (!profiles) continue;
      const changed = state && key(state.own) === key(roster[i]);
      const hp = changed ? state.own.hpFraction : roster[i].hpFraction;
      const isTera = changed ? state.own.terastallized : roster[i].terastallized;
      const profile = isTera && profiles.tera ? profiles.tera : profiles.normal;
      const foe = state && key(state.opponent) === key(card.foe) ? state.opponent : state && card.active ? card.foe : card.initial;
      const entering = state ? key(state.own) !== key(roster[i]) : key(own) !== key(roster[i]);
      const current = changed ? state.own : roster[i];
      const q = answer(profile, hp, foe, entering, current);
      normal = Math.max(normal, q);
      withTera = Math.max(withTera, q, canTera && profiles.tera ? answer(profiles.tera, hp, foe, entering, current) : 0);
    }
    return {normal, option: withTera - normal};
  }

  function adjustment(outcome, action) {
    let before = 0, after = 0, beforeOption = 0, afterOption = 0;
    const details = [];
    for (const card of cards) {
      // A defeated threat no longer needs checking. Do not charge for trading
      // away a check once its last relevant target has already been removed.
      if (key(outcome.opponent) === key(card.foe) && outcome.opponent.hpFraction <= 0) continue;
      const a = value(card, null, available), b = value(card, outcome, available && !action.tera);
      const weight = .5 + .5 * (key(outcome.opponent) === key(card.foe) ? outcome.opponent.hpFraction : card.foe.hpFraction);
      before += weight * a.normal; after += weight * b.normal;
      // Tera is one resource: do not sum independent uses on different Pokemon.
      beforeOption = Math.max(beforeOption, weight * a.option);
      afterOption = Math.max(afterOption, weight * b.option);
      details.push({species: card.foe.species, before: a, after: b});
    }
    const loss = Math.max(0, before + beforeOption - after - afterOption);
    return {score: -50 * loss, loss, details};
  }
  return {adjustment, calculations, threats: cards.map(c => c.foe.species)};
}
