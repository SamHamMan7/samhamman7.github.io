import {Dex} from '@pkmn/sim';
import {TeamGenerators} from '@pkmn/randoms';
import {toID} from './damage.js';
import {opponentHypotheses} from './priors.js';

const cache = new Map();
function samplesFor(species) {
  const id = toID(species);
  if (cache.has(id)) return cache.get(id);
  let hash = 2166136261;
  for (const c of id) hash = Math.imul(hash ^ c.charCodeAt(0), 16777619) >>> 0;
  // Independent PUBLIC prior seed, never the live simulator's RNG or AI seed.
  const g = TeamGenerators.getTeamGenerator('gen9randombattle', [hash & 65535, hash >>> 16, 19073, 731]);
  const sets = Array.from({length: 96}, () => g.randomSet(Dex.species.get(species), {}));
  if (cache.size >= 64) cache.delete(cache.keys().next().value);
  cache.set(id, sets); return sets;
}

/** Public generated SET PRIORS, never the actual opposing generated set.
 * Sampled item/ability/stat assumptions are separate from public revelations.
 * Moves remain a conditioned pool within each marginal world, not a claim that
 * a real Pokemon has more than four moves. Unknown opponent Tera is NOT read. */
export function randbatsSetBeliefs(mon, count = 4) {
  if (!Number.isInteger(count) || count < 1 || count > 4) throw Error('Set beliefs require 1..4 worlds');
  const observed = [...(mon.movesSeen || [])], ids = observed.map(toID);
  const publicState = {};
  for (const k of ['ident', 'publicRef', 'species', 'level', 'hpFraction', 'status', 'boosts', 'volatiles', 'lastMove', 'boostedStat', 'fainted', 'alliesFainted', 'transformed', 'publicMechanics', 'v3']) if (mon[k] !== undefined) publicState[k] = mon[k];
  publicState.movesSeen = observed;
  if (mon.terastallized) {publicState.terastallized = mon.terastallized; publicState.teraType = mon.teraType;}
  const knownItem = Object.hasOwn(mon, 'item'), knownAbility = !!mon.ability;
  if (knownItem) publicState.item = mon.item;
  if (knownAbility) publicState.ability = mon.ability;
  const fallback = reason => opponentHypotheses(publicState, 'gen9randombattle', count).map(h => ({...h, priorFallback: reason}));
  if (mon.transformed) return fallback('transformed public state');
  let sets;
  try {sets = samplesFor(mon.species).filter(s => ids.every(id => s.moves.map(toID).includes(id)));}
  catch {return fallback('no public randomSet prior for this form');}
  if (!sets.length) return fallback('no compatible sample; retain public move-family prior');
  const groups = new Map();
  for (const s of sets) {
    const item = knownItem ? mon.item : s.item, ability = knownAbility ? mon.ability : s.ability;
    const key = JSON.stringify([toID(item), toID(ability), s.nature || 'Serious', s.evs, s.ivs]);
    if (!groups.has(key)) groups.set(key, {key, item, ability, nature: s.nature || 'Serious', evs: s.evs, ivs: s.ivs, weight: 0, moves: new Set()});
    const group = groups.get(key); group.weight++; for (const m of s.moves) group.moves.add(Dex.moves.get(m).name);
  }
  const ranked = [...groups.values()].sort((a, b) => b.weight - a.weight || a.key.localeCompare(b.key)), selected = [], distinct = new Set();
  for (const group of ranked) {
    const key = toID(group.item) + ':' + toID(group.ability);
    if (!distinct.has(key) && selected.length < count) {selected.push(group); distinct.add(key);}
  }
  for (const group of ranked) if (selected.length < count && !selected.includes(group)) selected.push(group);
  const total = selected.reduce((s, g) => s + g.weight, 0);
  return selected.map(g => ({...publicState, nature: g.nature, evs: {...g.evs}, ivs: {...g.ivs}, item: g.item, ability: g.ability,
    weight: g.weight / total, inferred: true, assumedMovePool: [...g.moves], compatiblePublicSamples: sets.length,
    priorSource: 'public @pkmn/randoms randomSet samples, neutral team context; inferred marginal world, not a revelation'}));
}
