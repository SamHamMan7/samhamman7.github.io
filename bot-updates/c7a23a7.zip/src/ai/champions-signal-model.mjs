// Node-only diagnostic loader. Browser dispatch deliberately remains unchanged.
import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import {createRequire} from 'node:module';import * as ort from 'onnxruntime-node';
import {SIGNAL_FEATURES,encodeSignalState,encodeSignalActions} from './champions-signal-features.mjs';
import {encodePhaseSignalState} from './champions-phase-features.mjs';
const dex=createRequire(import.meta.url)('../../.tools/pokemon-showdown-current/dist/sim/index.js').Dex.mod('champions');
export async function loadChampionsSignalModel(directory){
 const manifest=JSON.parse(await fs.readFile(path.join(directory,'manifest.json'))),bytes=await fs.readFile(path.join(directory,'model.onnx'));
 if(manifest.architecture!=='v4'||manifest.parameters!==91106||manifest.valueUsed!==false||manifest.modelSha256!==createHash('sha256').update(bytes).digest('hex'))throw Error('Experimental signal model contract/hash mismatch');
 const stateEncoder=['B','C'].includes(manifest.config?.cohort)?encodePhaseSignalState:encodeSignalState;
 const session=await ort.InferenceSession.create(bytes,{executionProviders:['cpu'],intraOpNumThreads:1,interOpNumThreads:1});
 if(session.inputNames.length!==9)throw Error('Signal model input contract');
 return {manifest,features:SIGNAL_FEATURES,session,async predict(p,own,foe){
  const start=performance.now(),s=stateEncoder(p,dex),a=encodeSignalActions(p,own,0,dex),b=encodeSignalActions(p,foe,1,dex),count=own.length+foe.length;
  if(!own.length||!foe.length)throw Error('Signal model requires both public candidate pools');
  const float=(data,dims)=>new ort.Tensor('float32',Float32Array.from(data),dims),feeds={token_ids:new ort.Tensor('int64',BigInt64Array.from(s.token_ids.flat(),BigInt),[1,12,6]),token_num:float(s.token_num.flat(),[1,12,48]),field:float(s.field,[1,16]),action_links:new ort.Tensor('int64',BigInt64Array.from([...a.action_links,...b.action_links].flat(2),BigInt),[1,count,2,3]),action_num:float([...a.action_num,...b.action_num].flat(2),[1,count,2,64]),pair_num:float([...a.pair_num,...b.pair_num].flat(),[1,count,8]),known_moves:float(s.known_moves.flat(2),[1,12,4,64]),known_mask:float(s.known_mask.flat(),[1,12,4]),evidence:float(s.evidence.flat(),[1,12,4])};
  const out=await session.run(feeds);if(!Array.from(out.logits.data).every(Number.isFinite)||!Number.isFinite(Number(out.value.data[0])))throw Error('Nonfinite signal output');
  return {own:new Map(own.map((j,i)=>[j.command,out.logits.data[i]])),foe:new Map(foe.map((j,i)=>[j.command,out.logits.data[own.length+i]])),logits:Array.from(out.logits.data),valueUsed:false,ms:performance.now()-start};
 }};
}
