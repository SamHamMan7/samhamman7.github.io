import {publicDamagePosition} from './champions-damage.mjs';
import {createBeliefWorlds,sampleBeliefWorlds,updateBeliefs} from './champions-belief-worlds.mjs';
import {createSearchOracle,selectiveChance,SearchBudgetExceeded} from './champions-search-oracle.mjs';
import {doubleOracle,solveMatrixGame,sampleStrategy} from './champions-matrix-solver.mjs';
import {scoreChampionsCandidates,shortlistChampionsCandidates,seededChampionsRandom} from './champions-search.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
import {chooseChampionsPreview} from './champions-preview.mjs';
import {difficultyProfile} from './search-difficulty.mjs';
const actionKey=j=>JSON.stringify(j.actions.map(a=>[a.slot,a.type,a.move?.id,a.target||0,a.choice||0,!!a.mega]));
export async function chooseChampionsMatrix(tracker,request,{mode='bo3',strength='medium',seed=1,profile=null,model=null,priorModel=null,evidence=[],trace=false}={}){
  if(request.side?.id!==tracker.state.side)throw Error('Matrix firewall: own request required');
  const random=seededChampionsRandom(seed),settings=profile||difficultyProfile(`champions-${mode}`,strength),started=performance.now();
  const legal=enumerateChampionsActions(request);if(!legal.length)throw Error('No legal matrix action');
  if(request.teamPreview)return {chosen:chooseChampionsPreview(request,tracker.state.dex,{random}),source:'matrix-preview',diagnostics:{totalMs:performance.now()-started}};
  const dex=tracker.state.dex,p=publicDamagePosition(tracker.state,request);let beliefs=createBeliefWorlds(p,dex,{mode});for(const e of evidence)beliefs=updateBeliefs(beliefs,e,dex);
  // Finish a minimum restricted game even on a cold engine/model. Every later
  // expansion is transactional and can stop at the advertised time budget.
  const worlds=sampleBeliefWorlds(beliefs,settings.worlds,seed),minimumNodes=Math.min(settings.nodes,4*settings.worlds),oracle=createSearchOracle(p,dex,{...settings,minimumNodes}),cells=new Map(),expansions=[];
  let neuralMs=0,matrixMs=0,solverMs=0,deeperMs=0,neuralError=null;
  try{
    const positions=worlds.map(w=>w.position),ownRank=scoreChampionsCandidates(dex,positions[0],legal,0);
    const rowPool=shortlistChampionsCandidates(ownRank,settings.candidates,dex),foeByWorld=worlds.map(w=>oracle.legalActions(w.position,1));
    const foeMembers=new Map(foeByWorld.flat().map(j=>[actionKey(j),j])),foeRank=scoreChampionsCandidates(dex,positions[0],[...foeMembers.values()],1),columnPool=shortlistChampionsCandidates(foeRank,settings.candidates,dex);
    if(!columnPool.length)throw Error('No plausible legal opponent action');
    if(priorModel){const t=performance.now();try{const prior=(await priorModel.rank(tracker,request)).ranked;for(const a of prior.slice(0,2)){const member=legal.find(j=>j.command===a.command);if(member&&!rowPool.some(j=>j.command===member.command))rowPool.unshift(member);}}catch(error){neuralError=error.message;}neuralMs+=performance.now()-t;}
    if(model){const t=performance.now();const output=await model.predict(p,rowPool,columnPool);neuralMs+=performance.now()-t;rowPool.sort((a,b)=>output.own.get(b.command)-output.own.get(a.command));columnPool.sort((a,b)=>output.foe.get(b.command)-output.foe.get(a.command));}
    const payoff=(our,foe)=>{
      const key=JSON.stringify([actionKey(our),actionKey(foe)]);if(cells.has(key))return cells.get(key).value;
      if(!oracle.canAfford(worlds.length))throw new SearchBudgetExceeded();
      const t=performance.now(),samples=[];try{
      for(let i=0;i<worlds.length;i++){
        const w=worlds[i],member=foeByWorld[i].find(j=>actionKey(j)===actionKey(foe))||scoreChampionsCandidates(dex,w.position,foeByWorld[i],1)[0];
        const chance=selectiveChance(oracle,p,our,member,w,{seed:(seed+i*193)%65500,maxCalls:cells.size<4?1:settings.chanceCalls});samples.push(chance);
      }
      const value=samples.reduce((s,c)=>s+c.value,0)/samples.length;cells.set(key,{value,samples});return value;
      }finally{matrixMs+=performance.now()-t;}
    };
    let game=doubleOracle(rowPool,columnPool,payoff,{initial:Math.min(2,settings.initial,rowPool.length,columnPool.length),maxIterations:settings.oracleIterations,solverIterations:settings.solverIterations,onIteration:x=>expansions.push(x),onSolve:ms=>solverMs+=ms});
    if(settings.depth>1&&!request.forceSwitch){
      const t=performance.now(),important=game.rows.flatMap((a,i)=>game.columns.map((b,j)=>({a,b,i,j,weight:game.rowStrategy[i]*game.columnStrategy[j]}))).sort((a,b)=>b.weight-a.weight).slice(0,settings.deepenCells);
      for(const entry of important){if(!oracle.canAfford(4))break;
        const cell=cells.get(JSON.stringify([actionKey(entry.a),actionKey(entry.b)])),next=cell.samples[0].leaves[0].result;if(next.ended)continue;
        const q=next.position,w={id:'forecast',position:q,source:'public-forecast'},own=shortlistChampionsCandidates(scoreChampionsCandidates(dex,q,oracle.legalActions(q,0),0),2,dex),foe=shortlistChampionsCandidates(scoreChampionsCandidates(dex,q,oracle.legalActions(q,1),1),2,dex);
        if(!own.length||!foe.length)continue;
        try{const matrix=own.map(a=>foe.map(b=>oracle.evaluateJointOutcome(q,a,b,w,{seed}).value)),continuation=solveMatrixGame(matrix,{iterations:settings.solverIterations});game.matrix[entry.i][entry.j]=.4*game.matrix[entry.i][entry.j]+.6*continuation.value;expansions.push({deepen:`${entry.a.command} vs ${entry.b.command}`,reason:'high equilibrium probability; engine continuation'});}
        catch(error){if(error.name!=='SearchBudgetExceeded')throw error;break;}
      }
      game={...game,...solveMatrixGame(game.matrix,{iterations:settings.solverIterations}),externalResidual:null};deeperMs=performance.now()-t;
    }
    const chosen=game.rows[sampleStrategy(game.rowStrategy,random)];if(!legal.some(j=>j.command===chosen.command))throw Error('Nonmember matrix command');
    const damageRanges=[];let traceDamageMs=0;
    if(trace){const t=performance.now();for(const row of game.rows.slice(0,2))for(const a of row.actions)if(a.type==='move'&&a.target>0){const index=p.active[1][a.target-1];if(index<0)continue;const ranges=worlds.map(w=>oracle.decision.calculate(w.position,{side:0,index:p.active[0][a.slot]},{side:1,index},a.move.id||a.move.move));damageRanges.push({command:row.command,move:a.move.id||a.move.move,target:p.teams[1][index].species,min:Math.min(...ranges.map(d=>d.min)),max:Math.max(...ranges.map(d=>d.max)),koProbabilityRange:[Math.min(...ranges.map(d=>d.koProbability)),Math.max(...ranges.map(d=>d.koProbability))],guaranteedAcrossSampledWorlds:ranges.every(d=>d.guaranteedKO),scope:'single hit across sampled public hypotheses; not all legal builds'});}traceDamageMs=performance.now()-t;}
    const diagnostics={...oracle.diagnostics(),neuralMs,matrixMs,solverMs,deeperMs,traceDamageMs,totalMs:performance.now()-started,matrixDimensions:[game.rows.length,game.columns.length],solverIterations:game.iterations,oracleIterations:game.oracleIterations,residual:game.residual,externalResidual:game.externalResidual,budgetStopped:game.budgetStopped,neuralError,beliefWorlds:worlds.length,mode,strength,status:'experimental; deployed hybrid unchanged'};
    const policy=game.rows.map((j,i)=>({command:j.command,probability:game.rowStrategy[i]})),opponentPolicy=game.columns.map((j,i)=>({command:j.command,probability:game.columnStrategy[i]}));
    return {chosen,source:model?'matrix-neural':'matrix',policy,opponentPolicy,opponentActions:game.columns,value:game.value,diagnostics,
      ...(trace?{trace:{publicOnly:true,value:game.value,heuristicWinValue:(game.value+1)/2,calibration:'uncalibrated board-value transform; not a validated win probability',policy,opponentPolicy,payoff:game.matrix,damageRanges,beliefs:worlds.map(w=>({id:w.id,source:w.source,weight:w.weight,assumptions:w.position.teams[1].map(m=>({species:m.species,nature:m.nature,points:m.build.points,item:m.item,ability:m.ability,moves:m.moves}))})),expansions,...diagnostics}}:{})};
  }finally{oracle.dispose();}
}
