import {enumerateChampionsActions} from './champions-actions.mjs';
import {championsPosition,megaForm,toID} from './champions-public.mjs';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const alive=m=>m&&m.hp>0;
const mon=(p,s,k)=>p.teams[s][p.active[s][k]];
const boost=n=>n>=0?(2+n)/2:2/(2-n);
const stat=(m,k)=>m.stats[k]*boost(m.boosts[k]||0);
const protect=m=>m.stallingMove&&m.id!=='endure';
export function seededChampionsRandom(seed){let n=seed>>>0;return ()=>{n+=0x6d2b79f5;let t=Math.imul(n^n>>>15,1|n);t^=t+Math.imul(t^t>>>7,61|t);return ((t^t>>>14)>>>0)/4294967296;};}
function speed(p,s,m){return stat(m,'spe')*(p.conditions[s].includes('tailwind')?2:1)*(m.status==='par'?.5:1)*(toID(m.item)==='choicescarf'?1.5:1);}
function evolve(dex,m) {
  const form=megaForm(dex,m);if(!form)return;
  const before=dex.species.get(m.species),after=dex.species.get(form),nature=dex.natures.get(m.nature);
  for(const k in m.stats)m.stats[k]+=((after.baseStats[k]||0)-(before.baseStats[k]||0))*(nature.plus===k?1.1:nature.minus===k?.9:1);
  m.species=after.name;m.types=[...after.types];m.ability=after.abilities['0'];
}
function grounded(m){return !m.types.includes('Flying')&&toID(m.ability)!=='levitate';}
function priority(dex,p,s,m,move){return (move.priority||0)+(toID(m.ability)==='prankster'&&move.category==='Status'?1:0)+(move.id==='grassyglide'&&p.field.terrain==='grassyterrain'&&grounded(m)?1:0);}
export function estimateChampionsDamage(dex,p,s,a,t,move,{spread=false,roll=.925}={}) {
  if(!alive(a)||!alive(t)||move.category==='Status')return {fraction:0,ko:0};
  let type=move.type,power=move.basePower||0,modifier=1;
  const ability=toID(a.ability),defAbility=toID(t.ability),item=toID(a.item);
  if(type==='Normal'&&['aerilate','pixilate','refrigerate'].includes(ability)){type={aerilate:'Flying',pixilate:'Fairy',refrigerate:'Ice'}[ability];modifier*=1.2;}
  if(!dex.getImmunity(type,t.types)||type==='Ground'&&defAbility==='levitate'||type==='Fire'&&defAbility==='flashfire'||type==='Water'&&['waterabsorb','stormdrain','dryskin'].includes(defAbility)||type==='Electric'&&['lightningrod','voltabsorb','motordrive'].includes(defAbility))return {fraction:0,ko:0};
  if(move.id==='fakeout'&&a.acted)return {fraction:0,ko:0};
  if(move.id==='bodypress')power=80;
  if(move.id==='electroball')power=80;if(move.id==='gyroball')power=Math.min(150,25*stat(t,'spe')/Math.max(1,stat(a,'spe'))+1);
  if(move.id==='eruption'||move.id==='waterspout')power=150*a.hp;
  if(!power)power=move.damage||move.damageCallback?60:0;
  const physical=move.category==='Physical',offense=move.id==='bodypress'?stat(a,'def'):stat(a,physical?'atk':'spa'),defense=stat(t,physical?'def':'spd');
  let effectiveness=2**dex.getEffectiveness(type,t.types);
  let damage=((22*power*offense/Math.max(1,defense))/50+2)*effectiveness;
  if(a.types.includes(type))damage*=ability==='adaptability'?2:1.5;
  if(physical&&a.status==='brn'&&ability!=='guts')modifier*=.5;
  if(physical&&['hugepower','purepower'].includes(ability))modifier*=2;
  if(physical&&ability==='guts'&&a.status)modifier*=1.5;
  if(power<=60&&ability==='technician')modifier*=1.5;
  if(item==='lifeorb')modifier*=1.3;
  if(item==='choiceband'&&physical||item==='choicespecs'&&!physical)modifier*=1.5;
  if(item==='miracleseed'&&type==='Grass')modifier*=1.2;
  if(spread)modifier*=.75;
  if(!p.teams[s].includes(t)&&(p.conditions[1-s].includes(physical?'reflect':'lightscreen')||p.conditions[1-s].includes('auroraveil')))modifier*=2/3;
  if(p.field.weather.includes('sun')){if(type==='Fire')modifier*=1.5;if(type==='Water')modifier*=.5;}
  if(p.field.weather.includes('rain')){if(type==='Water')modifier*=1.5;if(type==='Fire')modifier*=.5;}
  if(p.field.terrain==='grassyterrain'&&type==='Grass'&&grounded(a))modifier*=1.3;
  if(p.field.terrain==='electricterrain'&&type==='Electric'&&grounded(a))modifier*=1.3;
  if(p.field.terrain==='grassyterrain'&&['earthquake','bulldoze'].includes(move.id)&&grounded(t))modifier*=.5;
  if(ability==='toughclaws'&&move.flags?.contact)modifier*=1.3;
  if(defAbility==='multiscale'&&t.hp===1)modifier*=.5;
  if(toID(t.item)==='assaultvest'&&!physical)modifier/=1.5;
  const accuracy=ability==='noguard'||defAbility==='noguard'||move.accuracy===true?1:typeof move.accuracy==='number'?move.accuracy/100:1;
  const fraction=damage*modifier*roll/Math.max(1,t.stats.hp);
  const ko=clamp((damage*modifier/t.stats.hp-t.hp)/Math.max(.001,damage*modifier/t.stats.hp*.15)+1/16)*accuracy;
  return {fraction:fraction*accuracy,ko};
}
function targets(p,s,a,move) {
  if(a.target)return [{s:a.target>0?1-s:s,k:Math.abs(a.target)-1}];
  if(move.target==='self'||move.target==='allySide')return [{s,k:a.slot}];
  const foes=[0,1].filter(k=>alive(mon(p,1-s,k))).map(k=>({s:1-s,k}));
  // Representative random target, never mistake Struggle for a spread attack.
  if(move.target==='randomNormal')return foes.slice(0,1);
  if(move.target==='allAdjacent')return [...foes,...[0,1].filter(k=>k!==a.slot&&alive(mon(p,s,k))).map(k=>({s,k}))];
  if(move.target==='all')return [...foes,...[0,1].filter(k=>alive(mon(p,s,k))).map(k=>({s,k}))];
  return foes;
}
function speedValue(p,s) {
  let result=0;
  for(let k=0;k<2;k++)for(let j=0;j<2;j++){const a=mon(p,s,k),b=mon(p,1-s,j);if(alive(a)&&alive(b)){const delta=(speed(p,s,a)-speed(p,1-s,b))*(p.field.trickroom?-1:1);result+=delta===0?0:delta>0?3:-3;}}
  return result;
}
function bestHit(dex,p,s,a,t) {return Math.max(0,...a.moves.map(id=>estimateChampionsDamage(dex,p,s,a,t,dex.moves.get(id)).fraction));}
function boardValue(dex,p,s) {
  // Unknown brought bench choices are never counted as known material.
  let value=0;
  for(const m of p.teams[s])if(alive(m)&&(s===0||m.revealed))value+=65+35*m.hp;
  if(s===1)value+=Math.max(0,p.teams[0].length-p.teams[1].filter(m=>m.revealed).length)*100;
  value+=speedValue(p,s);
  for(let k=0;k<2;k++){
    const a=mon(p,s,k);if(!alive(a))continue;
    const threat=Math.max(0,...[0,1].map(j=>alive(mon(p,1-s,j))?bestHit(dex,p,s,a,mon(p,1-s,j)):0));
    value+=12*Math.min(1,threat)*a.hp;
    value+=2*((a.boosts.atk||0)+(a.boosts.spa||0)+(a.boosts.def||0)+(a.boosts.spd||0));
    if(p.conditions[s].includes('tailwind'))value+=Math.max(0,speedValue(p,s))*0.6;
  }
  return value;
}
function updateBoost(m,changes,scale=1) {for(const [k,n] of Object.entries(changes||{}))m.boosts[k]=clamp((m.boosts[k]||0)+n*scale,-6,6);}
export function simulateChampionsPly(dex,position,own,opponent,roll=.925) {
  const p=structuredClone(position),choices=[own,opponent],blocked=[[],[]],flinch=[[],[]],help=[[],[]],redirect=[null,null],events=[];
  for(let s=0;s<2;s++)for(const a of choices[s].actions) {
    if(a.type==='switch') {
      const out=mon(p,s,a.slot);if(out)out.boosts={};
      p.active[s][a.slot]=a.choice-1;const incoming=mon(p,s,a.slot);incoming.boosts={};incoming.acted=false;incoming.revealed=true;
      if(toID(incoming.ability)==='intimidate')for(let k=0;k<2;k++){const foe=mon(p,1-s,k);if(alive(foe)&&!['innerfocus','clearbody','fullmetalbody'].includes(toID(foe.ability)))updateBoost(foe,{atk:-1});}
      if(p.conditions[s].includes('stealthrock'))incoming.hp=Math.max(0,incoming.hp-.125*2**dex.getEffectiveness('Rock',incoming.types));
    }
    if(a.type==='move')events.push({s,a});
  }
  for(const {s,a} of events)if(a.mega&&!p.megaUsed[s]){evolve(dex,mon(p,s,a.slot));p.megaUsed[s]=true;}
  while(events.length) {
    events.sort((x,y)=>{
      const a=mon(p,x.s,x.a.slot),b=mon(p,y.s,y.a.slot);if(!a||!b)return a?-1:1;
      return priority(dex,p,y.s,b,dex.moves.get(y.a.move.id))-priority(dex,p,x.s,a,dex.moves.get(x.a.move.id))||
        (speed(p,y.s,b)-speed(p,x.s,a))*(p.field.trickroom?-1:1)|| (roll<.925?x.s-y.s:y.s-x.s);
    });
    const {s,a}=events.shift(),actor=mon(p,s,a.slot),move=dex.moves.get(a.move.id);
    if(!alive(actor)||flinch[s][a.slot]||['slp','frz'].includes(actor.status))continue;
    if(protect(move)){blocked[s][a.slot]=1/3**Math.min(6,actor.protectStreak);continue;}
    if(move.id==='tailwind'){if(!p.conditions[s].includes('tailwind'))p.conditions[s].push('tailwind');continue;}
    if(move.id==='trickroom'){p.field.trickroom=!p.field.trickroom;continue;}
    if(['followme','ragepowder'].includes(move.id)){redirect[s]=a.slot;continue;}
    if(move.id==='helpinghand'){const k=a.target<0?-a.target-1:1-a.slot;help[s][k]=1.5;continue;}
    if(move.id==='fakeout'&&actor.acted)continue;
    let ts=targets(p,s,a,move);
    if(a.target>0&&redirect[1-s]!==null&&alive(mon(p,1-s,redirect[1-s])))ts=[{s:1-s,k:redirect[1-s]}];
    const spread=ts.filter(t=>alive(mon(p,t.s,t.k))).length>1&&['allAdjacent','allAdjacentFoes'].includes(move.target);
    let hit=false;
    for(const t of ts) {
      let target=mon(p,t.s,t.k);
      if(!alive(target)&&t.s!==s&&a.target>0){t.k=1-t.k;target=mon(p,t.s,t.k);}
      if(!alive(target))continue;
      if(t.s!==s&&priority(dex,p,s,actor,move)>0&&(p.field.terrain==='psychicterrain'&&grounded(target)||['dazzling','queenlymajesty','armortail'].includes(toID(target.ability))))continue;
      const protection=move.flags?.protect?blocked[t.s][t.k]||0:0;
      if(move.category==='Status') {
        if(protection>=1||t.s!==s&&toID(target.ability)==='goodasgold')continue;
        if(move.boosts)updateBoost(target,move.boosts,toID(target.ability)==='contrary'?-1:1);
        if(move.heal)target.hp=Math.min(1,target.hp+move.heal[0]/move.heal[1]);
        if(move.status)target.status=move.status;
        continue;
      }
      const d=estimateChampionsDamage(dex,p,s,actor,target,move,{spread,roll});
      let damage=d.fraction*(help[s][a.slot]||1)*(1-protection);
      if(target.volatiles?.includes('substitute')){damage=Math.max(0,damage-.25);target.volatiles=target.volatiles.filter(x=>x!=='substitute');}
      if(target.hp===1&&['focussash'].includes(toID(target.item))&&damage>=1){damage=.99;target.item='';}
      const dealt=Math.min(target.hp,damage);target.hp=Math.max(0,target.hp-damage);
      if(dealt>0)hit=true;
      if(move.id==='fakeout'&&dealt>0&&!['innerfocus','shielddust'].includes(toID(target.ability))&&toID(target.item)!=='covertcloak')flinch[t.s][t.k]=true;
      if(dealt>0&&move.recoil)actor.hp=Math.max(0,actor.hp-dealt*target.stats.hp/actor.stats.hp*move.recoil[0]/move.recoil[1]);
      if(dealt>0&&move.drain)actor.hp=Math.min(1,actor.hp+dealt*target.stats.hp/actor.stats.hp*move.drain[0]/move.drain[1]);
      if(dealt>0&&toID(target.item)==='sitrusberry'&&target.hp>0&&target.hp<=.5){target.hp=Math.min(1,target.hp+.25);target.item='';}
      for(const secondary of move.secondaries||[move.secondary].filter(Boolean))if(dealt>0&&secondary.boosts)updateBoost(target,secondary.boosts,(secondary.chance||100)/100);
    }
    if(hit&&move.self?.boosts)updateBoost(actor,move.self.boosts,toID(actor.ability)==='contrary'?-1:1);
    actor.acted=true;
  }
  return {score:boardValue(dex,p,0)-boardValue(dex,p,1),position:p};
}
function responseRequest(dex,p) {
  const allBroughtKnown=p.teams[1].filter(m=>m.revealed).length>=p.teams[0].length;
  const order=[...p.active[1],...p.teams[1].map((_,i)=>i).filter(i=>!p.active[1].includes(i)&&(!allBroughtKnown||p.teams[1][i].revealed))];
  const roster=order.map((index,slot)=>{
    const m=p.teams[1][index];return {active:slot<2,condition:alive(m)?'100/100':'0 fnt',index};
  });
  return {order,request:{side:{pokemon:roster},active:[0,1].map(k=>{
    const m=mon(p,1,k);if(!alive(m))return null;
    let moves=m.moves;
    // Without OTS, only revealed moves may be used; no hidden move-set lookup.
    if(!moves.length)return null;
    if(/^choice(band|scarf|specs)$/.test(toID(m.item))&&m.acted&&m.lastMove)moves=moves.filter(x=>x===m.lastMove);
    return {canMegaEvo:!p.megaUsed[1]&&!!megaForm(dex,m),moves:moves.slice(0,4).map(id=>{const d=dex.moves.get(id);return {id,move:d.name,target:d.target,pp:1,disabled:m.volatiles.includes('taunt')&&d.category==='Status'};})};
  })}};
}
const idle={actions:[{slot:0,type:'pass'},{slot:1,type:'pass'}],command:'pass, pass'};
function cheapScores(dex,p,legal,s) {
  const cache=new Map();
  return legal.map(joint=>{
    let score=0;
    for(const action of joint.actions) {
      const key=JSON.stringify(action);if(cache.has(key)){score+=cache.get(key);continue;}
      let value=0;const actor=mon(p,s,action.slot);
      if(action.type==='switch') {
        const candidate=p.teams[s][action.choice-1];
        value=alive(candidate)?8*candidate.hp-10: -100;
        for(let k=0;k<2;k++){const foe=mon(p,1-s,k);if(alive(foe)&&alive(candidate))value+=8*bestHit(dex,p,s,candidate,foe)-12*bestHit(dex,p,1-s,foe,candidate);}
      } else if(action.type==='move'&&alive(actor)) {
        const a=structuredClone(actor);if(action.mega)evolve(dex,a);
        const move=dex.moves.get(action.move.id);
        if(move.category!=='Status')for(const t of targets(p,s,action,move)) {
          const target=mon(p,t.s,t.k);if(!alive(target))continue;
          const d=estimateChampionsDamage(dex,p,s,a,target,move,{spread:['allAdjacent','allAdjacentFoes'].includes(move.target)});
          value+=(t.s===s?-1.5:1)*(60*Math.min(d.fraction,target.hp)+35*d.ko);
          if(move.id==='fakeout'&&!a.acted&&d.fraction>0)value+=22;
          if(move.secondary?.boosts?.spe<0||move.secondary?.boosts?.spa<0)value+=5;
        }
        else if(protect(move))value=Math.max(0,...[0,1].map(k=>alive(mon(p,1-s,k))?bestHit(dex,p,1-s,mon(p,1-s,k),actor)*28:0))*(actor.protectStreak?1/3:1);
        else if(move.id==='tailwind'||move.id==='trickroom'){
          const next=structuredClone(p);if(move.id==='tailwind'&&!next.conditions[s].includes('tailwind'))next.conditions[s].push('tailwind');if(move.id==='trickroom')next.field.trickroom=!next.field.trickroom;
          value=(speedValue(next,s)-speedValue(p,s))*1.8;
        } else if(move.heal)value=40*Math.min(1-actor.hp,move.heal[0]/move.heal[1]);
        else if(move.boosts)value=8*Object.values(move.boosts).reduce((a,b)=>a+b,0);
        else if(['helpinghand','followme','ragepowder'].includes(move.id))value=16;
      }
      cache.set(key,value);score+=value;
    }
    return {...joint,cheapScore:score};
  }).sort((a,b)=>b.cheapScore-a.cheapScore||a.command.localeCompare(b.command));
}
function shortlist(ranked,limit,dex) {
  const out=ranked.slice(0,Math.max(1,limit-4));
  // Preserve a few plausible defensive/support response families before pruning.
  for(const family of ['protect','switch','speed','support','mega']) {
    const pick=ranked.find(j=>!out.includes(j)&&j.cheapScore>=ranked[0].cheapScore-70&&j.actions.some(a=>family==='switch'?a.type==='switch':family==='mega'?a.mega:a.type==='move'&&(family==='protect'?protect(dex.moves.get(a.move.id)):family==='speed'?['tailwind','trickroom','icywind','electroweb'].includes(a.move.id):!!dex.moves.get(a.move.id).boosts||['fakeout','helpinghand','followme','ragepowder'].includes(a.move.id))));
    if(pick&&out.length<limit)out.push(pick);
  }
  for(const x of ranked)if(out.length<limit&&!out.includes(x))out.push(x);
  return out;
}
export function chooseChampionsLookahead(legal,state,dex,{request,random=Math.random,ownCap=12,responseCap=10,window=2.5,temperature=.65}={}) {
  const started=performance.now(),p=championsPosition(state,request);
  ownCap=clamp(Math.floor(ownCap),1,16);responseCap=clamp(Math.floor(responseCap),1,12);
  const own=shortlist(cheapScores(dex,p,legal,0),ownCap,dex);
  const modeled=responseRequest(dex,p);
  let responses=enumerateChampionsActions(modeled.request).map(j=>({...j,actions:j.actions.map(a=>a.type==='switch'?{...a,choice:modeled.order[a.choice-1]+1}:a)}));
  responses=shortlist(cheapScores(dex,p,responses,1),responseCap,dex);
  if(request.forceSwitch||!responses.length)responses=[{...idle,cheapScore:0}];
  const best=responses[0].cheapScore,weights=responses.map(r=>.15+Math.exp((r.cheapScore-best)/30)),total=weights.reduce((a,b)=>a+b,0);
  const material=p.teams[0].reduce((n,m)=>n+m.hp,0)-p.teams[1].filter(m=>m.revealed).reduce((n,m)=>n+m.hp,0)-Math.max(0,p.teams[0].length-p.teams[1].filter(m=>m.revealed).length);
  const downside=material>1?.35:material< -1?.12:.25;
  const ranked=own.map(j=>{
    const values=responses.map(r=>[.85,.925,1].reduce((sum,roll)=>sum+simulateChampionsPly(dex,p,j,r,roll).score,0)/3);
    const mean=values.reduce((sum,v,i)=>sum+v*weights[i],0)/total,worst=Math.min(...values);
    return {...j,score:(1-downside)*mean+downside*worst,mean,worst};
  }).sort((a,b)=>b.score-a.score||a.command.localeCompare(b.command));
  const near=ranked.filter(j=>j.score>=ranked[0].score-clamp(window,0,4));
  const ws=near.map(j=>Math.exp((j.score-ranked[0].score)/Math.max(.01,Math.min(1,temperature))));
  let pick=random()*ws.reduce((a,b)=>a+b,0),chosen=near[0];for(let i=0;i<near.length;i++){pick-=ws[i];if(pick<=0){chosen=near[i];break;}}
  return {chosen,top:ranked.slice(0,10),diagnostics:{legal:legal.length,ownCandidates:own.length,responses:responses.length,plies:own.length*responses.length*3,nearBest:near.length,ms:performance.now()-started,
    responseCommands:responses.map(r=>r.command)}};
}
