// Public protocol timers/layers only. No Battle, RNG or opposing request input.
const id=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
const effect=x=>id(String(x||'').replace(/^move: /,''));
const screen=new Set(['reflect','lightscreen','auroraveil']);
const weatherRock={raindance:'damprock',sunnyday:'heatrock',sandstorm:'smoothrock',hail:'icyrock',snowscape:'icyrock'};
const interval=(base,source,item,extra=3)=>source&&source.item!==undefined?{min:base+(id(source.item)===item?extra:0),max:base+(id(source.item)===item?extra:0)}:{min:base,max:base+extra};
function publicSource(s,ident){
 const match=String(ident||'').match(/^(p[12])([ab]):/);if(!match)return null;
 const canonical=ident.replace(/^(p[12])[ab]:/,'$1:');
 return s.roster[match[1]].find(m=>m.ident===canonical)||null;
}
export function observePublicEffects(s,kind,args){
 const e=s.publicEffects??={conditions:{p1:{},p2:{}},field:{},lastMove:null};
 if(kind==='move'){e.lastMove={ident:args[0],move:effect(args[1]),turn:s.turn};return;}
 if(kind==='upkeep'){
  // Expiration messages precede upkeep. Continued public presence rules out a
  // zero-duration endpoint (native duration=0 would otherwise mean no expiry).
  for(const group of [e.conditions.p1,e.conditions.p2,e.field])for(const value of Object.values(group))if(value.remaining){value.remaining.min=Math.max(1,value.remaining.min-1);value.remaining.max=Math.max(1,value.remaining.max-1);}
  return;
 }
 if(!['-sidestart','-sideend','-weather','-fieldstart','-fieldend'].includes(kind))return;
 const from=args.find(x=>x.startsWith('[of] '))?.slice(5),last=e.lastMove?.turn===s.turn?e.lastMove:null;
 const source=publicSource(s,from||last?.ident),name=effect(args[1]),condition=s.dex.conditions.get(name);
 if(kind==='-sidestart'){
  const side=args[0].slice(0,2);if(!e.conditions[side])return;
  if(['spikes','toxicspikes'].includes(name)){const max=name==='spikes'?3:2;e.conditions[side][name]={layers:Math.min(max,(e.conditions[side][name]?.layers||0)+1)};return;}
  if(!condition.duration)return;
  const base=condition.duration+(args.includes('[persistent]')?2:0);
  e.conditions[side][name]={remaining:screen.has(name)?interval(base,source,'lightclay'):{min:base,max:base}};
 }
 if(kind==='-sideend')delete e.conditions[args[0].slice(0,2)]?.[name];
 if(kind==='-weather'&&!args.includes('[upkeep]')){
  const weather=effect(args[0]),duration=s.dex.conditions.get(weather).duration;
  if(weather==='none'||!duration){delete e.field.weather;return;}
  e.field.weather={remaining:interval(duration,source,weatherRock[weather]||'')};
 }
 if(kind==='-fieldstart'||kind==='-fieldend'){
  const field=effect(args[0]),key=field==='trickroom'?'trickroom':field.endsWith('terrain')?'terrain':null;if(!key)return;
  if(kind==='-fieldend'){delete e.field[key];return;}
  const base=(s.dex.conditions.get(field).duration||5)+(args.includes('[persistent]')?2:0);
  e.field[key]={remaining:key==='terrain'?interval(base,source,'terrainextender'):{min:base,max:base}};
 }
}
export function publicEffectsSnapshot(s){
 const e=s.publicEffects;if(!e)return undefined;
 const sides=[s.side,s.side==='p1'?'p2':'p1'];
 return sanitizePublicEffects({conditions:sides.map(side=>e.conditions[side]),field:e.field},sides.map(side=>[...s.sideConditions[side]]));
}
export function sanitizePublicEffects(e,conditions){
 const clean=value=>{
  const out={};if(Number.isInteger(value?.layers)&&value.layers>=1&&value.layers<=3)out.layers=value.layers;
  const min=value?.remaining?.min,max=value?.remaining?.max;if(Number.isInteger(min)&&Number.isInteger(max)&&min>=0&&max>=min&&max<=12)out.remaining={min,max};
  return out;
 };
 return {conditions:conditions.map((names,s)=>Object.fromEntries(names.filter(k=>e.conditions?.[s]?.[k]).map(k=>[k,clean(e.conditions[s][k])]))),field:Object.fromEntries(['weather','terrain','trickroom'].filter(k=>e.field?.[k]).map(k=>[k,clean(e.field[k])]))};
}
