// Node-side only: the same pinned local engine used by the Champions server.
// No live Battle is accepted. Every Pokemon below is created from an allowlist
// of the player's request and disclosures on that player's stream.
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {championsPosition,toID} from './champions-public.mjs';
const {Battle,Dex}=createRequire(import.meta.url)(fileURLToPath(new URL('../../.tools/pokemon-showdown-current/dist/sim/index.js',import.meta.url)));
export const CHAMPIONS_DAMAGE_ENGINE='local-showdown-champions';
const dex=Dex.mod('champions'),keys=['hp','atk','def','spa','spd','spe'];
const alive=m=>m&&m.hp>0;
const stat=(species,nature,points,k)=>dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},dex.species.get(species).baseStats,{nature,level:50,evs:points},k);
const statsFor=(species,nature,points)=>Object.fromEntries(keys.map(k=>[k,stat(species,nature,points,k)]));

export function publicDamagePosition(state,request){
  const p=championsPosition(state,request),foe=state.side==='p1'?'p2':'p1';
  for(let side=0;side<2;side++)for(const [i,m] of p.teams[side].entries()){
    const disclosed=side===0?state.roster[state.side].find(x=>x.ident===m.ident):state.roster[foe][i];
    // In particular, ignore opposing stats, evs, ivs and any private set object.
    m.knowledge={own:side===0,nature:!!disclosed?.nature,item:side===0||disclosed?.item!==undefined,ability:side===0||!!disclosed?.ability,sheet:!!disclosed?.sheet};
    if(side===0){const slot=p.active[0].indexOf(i),moves=slot>=0?request.active?.[slot]?.moves:[];m.movePP=Object.fromEntries((moves||[]).filter(x=>Number.isInteger(x.pp)).map(x=>[toID(x.id||x.move),x.pp]));}
    m.volatiles=m.volatiles.map(id=>{
      if(!id.startsWith('ability'))return id;
      const ability=dex.abilities.get(id.slice(7));if(!ability.exists)return id;
      m.ability=ability.name;m.knowledge.ability=true;return ability.id;
    });
  }
  return p;
}

function offensiveStat(m){
  const power=c=>m.moves.map(id=>dex.moves.get(id)).filter(x=>x.category===c).reduce((v,x)=>v+(x.basePower||40),0);
  return power('Physical')>power('Special')?'atk':'spa';
}
// Coherent, legal allocations (0..32 per stat, at most 66 in total). These are
// hypotheses, never estimates obtained from the real opponent's simulator set.
export function opponentBuilds(m){
  const attack=offensiveStat(m),known=m.knowledge||{},species=dex.species.get(m.species);
  const profiles=[['fast',{hp:2,[attack]:32,spe:32},attack==='atk'?'Jolly':'Timid'],
    ['physical-bulk',{hp:32,def:32,[attack]:2},attack==='atk'?'Impish':'Bold'],
    ['special-bulk',{hp:32,spd:32,[attack]:2},attack==='atk'?'Careful':'Calm'],
    ['power',{hp:2,[attack]:32,spe:32},attack==='atk'?'Adamant':'Modest'],
    ['uninvested',{},'Serious'],
    ['mixed-bulk',{hp:32,def:16,spd:16,[attack]:2},attack==='atk'?'Careful':'Bold']];
  const abilities=known.ability?[m.ability]:[...new Set(Object.values(species.abilities))];
  const items=known.item?[m.item]:['','Life Orb','Sitrus Berry','Focus Sash','Assault Vest'];
  return profiles.map(([id,allocation,n])=>{
    const points=Object.fromEntries(keys.map(k=>[k,allocation[k]||0])),nature=known.nature?m.nature:n;
    return {id,points,nature,stats:statsFor(m.species,nature,points),ability:abilities[0]||'',item:items[0]||''};
  }).concat(abilities.slice(1).map((ability,i)=>({...makeBuild(m,profiles[0],known),id:`ability-${i+1}`,ability,item:items[0]})),
    items.slice(1).map((item,i)=>({...makeBuild(m,profiles[i%4],known),id:`item-${toID(item)}`,ability:abilities[i%abilities.length]||'',item})));
}
function makeBuild(m,[id,allocation,n],known){
  const points=Object.fromEntries(keys.map(k=>[k,allocation[k]||0])),nature=known.nature?m.nature:n;
  return {id,points,nature,stats:statsFor(m.species,nature,points)};
}
export function damageBeliefs(p){
  return p.teams[1].map(m=>{
    const builds=opponentBuilds(m),natures=m.knowledge?.nature?[m.nature]:dex.natures.all().map(n=>n.name);
    const range=Object.fromEntries(keys.map(k=>[k,{min:Math.min(...natures.map(n=>stat(m.species,n,{[k]:0},k))),max:Math.max(...natures.map(n=>stat(m.species,n,{[k]:32},k)))}]));
    return {species:m.species,natureKnown:!!m.knowledge?.nature,itemKnown:!!m.knowledge?.item,abilityKnown:!!m.knowledge?.ability,statPointsKnown:false,
      builds:builds.map(b=>({id:b.id,nature:b.nature,points:b.points,ability:b.ability,item:b.item})),statRange:range,
      scope:'bounded public hypotheses; not all possible builds/items or unrevealed moves'};
  });
}
function ownBuild(m){
  // Exact own request stats are authoritative. Recover a compatible synthetic
  // nature/allocation for engine forme changes, without accessing any live set.
  const candidates=m.knowledge?.nature?[dex.natures.get(m.nature)]:dex.natures.all();
  for(const nature of candidates){
    const points={};let valid=true;
    for(const k of keys){
      const options=Array.from({length:33},(_,i)=>i).filter(i=>stat(m.species,nature.name,{[k]:i},k)===m.stats[k]);
      if(!options.length){valid=false;break;}points[k]=options[0];
    }
    if(valid&&Object.values(points).reduce((a,b)=>a+b,0)<=66)return {nature:nature.name,points};
  }
  // Synthetic test requests can have arbitrary exact stats. They remain exact
  // before a forme change, while the inferred Mega build is explicitly unknown.
  return {nature:m.nature,points:Object.fromEntries(keys.map(k=>[k,11]))};
}
export function hypothesizePosition(p,index=0){
  const q=structuredClone(p);
  for(const m of q.teams[0])m.build=ownBuild(m);
  for(const m of q.teams[1]){const builds=opponentBuilds(m),b=builds[index%builds.length];Object.assign(m,{stats:b.stats,nature:b.nature,ability:b.ability,item:b.item,build:{nature:b.nature,points:b.points}});}
  // An OTS roster is six, but only four were brought. Pick a public hypothesis
  // for the unseen slots, never the actual opposing preview choice. Once four
  // are revealed, exclude every other sheet entry from simulated endgames.
  const unseen=q.teams[1].map((m,i)=>({m,i})).filter(({m})=>!m.revealed),known=q.teams[1].filter(m=>m.revealed).length;
  const needed=Math.max(0,q.teams[0].length-known);
  if(unseen.length>needed){
    const subsets=[];function subsetsOf(start,chosen){if(chosen.length===needed){subsets.push(chosen);return;}for(let i=start;i<unseen.length;i++)subsetsOf(i+1,[...chosen,unseen[i].i]);}subsetsOf(0,[]);
    const brought=new Set(subsets[index%subsets.length]);for(const {m,i} of unseen)if(!brought.has(i))m.hp=0;
  }
  q.hypothesis=index;return q;
}
const effectState=(b,id,source,extra={})=>b.initEffectState({id,source,sourceSlot:source?.getSlot(),duration:dex.conditions.get(id).duration,...extra});
const forecastState=state=>Object.fromEntries(Object.entries(state||{}).flatMap(([k,v])=>{
  if(['string','number','boolean'].includes(typeof v)||v===null)return [[k,v]];
  if(k==='source'&&v?.m?.publicIndex!==undefined)return [['publicSource',[v.side.n,v.m.publicIndex]]];
  return [];
}));
function restoreForecast(b,id,state,source){
  const {publicSource,...data}=state||{};
  if(publicSource)source=b.sides[publicSource[0]].pokemon.find(m=>m.m.publicIndex===publicSource[1]);
  return effectState(b,id,source,data);
}
export function createPublicDamageBattle(p){
  // Unknown extension items remain explicit public ranges. Public worlds take
  // alternating range endpoints; no private item/duration is consulted.
  const remaining=value=>value?.remaining?(p.hypothesis%2?value.remaining.max:value.remaining.min):undefined;
  const timed=value=>remaining(value)===undefined?{}:{duration:remaining(value)};
  const teams=p.teams.map(team=>team.map((m,i)=>({name:`Public${i}`,species:m.species,ability:m.ability,item:m.item,nature:m.build?.nature||m.nature,
    evs:{...(m.build?.points||Object.fromEntries(keys.map(k=>[k,11])))},moves:m.moves.length?[...m.moves]:['splash'],gender:'M',level:50})));
  // deserialized avoids starting abilities/terrain a second time. Only effects
  // already disclosed in p are installed; real switches trigger entry effects.
  const b=new Battle({formatid:'gen9championsvgc2026regmc',deserialized:true,seed:[17,29,43,71],p1:{name:'Public own',team:teams[0]},p2:{name:'Public opponent',team:teams[1]}});
  b.started=true;b.turn=Math.max(1,p.turn);b.midTurn=false;b.requestState='';
  for(let s=0;s<2;s++){
    const side=b.sides[s];side.foe=b.sides[1-s];side.pokemonLeft=p.teams[s].filter(alive).length;
    side.totalFainted=p.forecast?.totalFainted?.[s]??p.teams[s].filter(m=>!alive(m)&&(s===0||m.revealed)).length;
    side.pokemon.forEach((m,i)=>{m.m.publicIndex=i;});
    side.active=p.active[s].map(i=>side.pokemon[i]||null);
    side.pokemon=[...side.active.filter(Boolean),...side.pokemon.filter(m=>!side.active.includes(m))];
    side.pokemon.forEach((m,i)=>{
      const x=p.teams[s][m.m.publicIndex];m.isActive=side.active.includes(m);m.position=i;
      m.baseStoredStats={...x.stats};m.storedStats=Object.fromEntries(keys.filter(k=>k!=='hp').map(k=>[k,x.stats[k]]));m.maxhp=m.baseMaxhp=x.stats.hp;
      m.hp=alive(x)?Math.max(1,Math.round(x.hp*m.maxhp)):0;m.fainted=!m.hp;m.activeTurns=x.acted?2:1;m.newlySwitched=!x.acted;
      // Fake Out/First Impression read this counter, not activeTurns. runMove
      // increments it before onTry; the existing public visit flag supplies
      // the only distinction needed at the next decision: 0 versus >=1.
      m.activeMoveActions=x.acted?1:0;
      m.boosts={...m.boosts,...x.boosts};m.status=x.status||'';m.statusState=effectState(b,m.status,m);
      if(m.status==='slp'){
        // Optional arena-only public-duration hypothesis. No live statusState
        // or hidden sleep RNG is accepted; callers derive this from public cant
        // attempts. Old callers retain their existing two-tick forecast.
        const ticks=p.publicSleepTimes?.[s]?.[m.m.publicIndex]??2;
        if(!Number.isInteger(ticks)||ticks<1||ticks>4)throw Error('Invalid public sleep-duration hypothesis');
        m.statusState.time=ticks;
      }
      if(m.status==='tox')m.statusState.stage=0;
      m.lastMove=x.lastMove?dex.getActiveMove(x.lastMove):null;
      for(const slot of m.moveSlots)if(x.movePP?.[slot.id]!==undefined)slot.pp=Math.max(0,Math.min(slot.maxpp,x.movePP[slot.id]));
      m.abilityState.started=true;m.itemState.started=true;
      if(p.megaUsed[s])m.canMegaEvo=null;
      for(const id of x.volatiles||[]){if(/^perish[0-3]$/.test(id)){m.volatiles.perishsong=effectState(b,'perishsong',m,{duration:x.perishTurns??Number(id.at(-1))});continue;}m.volatiles[id]=effectState(b,id,m);if(id==='substitute')m.volatiles[id].hp=Math.floor(m.maxhp/4);}
      if(x.choiceLock&&dex.items.get(m.item).isChoice&&m.hasMove(x.choiceLock))m.volatiles.choicelock=effectState(b,'choicelock',m,{move:x.choiceLock});
      if(x.protectStreak)m.volatiles.stall=effectState(b,'stall',m,{counter:3**Math.min(6,x.protectStreak)});
    });
    const source=side.active.find(Boolean)||side.pokemon[0];
    for(const id of p.conditions[s]){const state=p.publicEffects?.conditions[s]?.[id];side.sideConditions[id]=effectState(b,id,source,{...timed(state),...(['spikes','toxicspikes'].includes(id)?{layers:state?.layers||1}:{})});}
  }
  const source=b.p1.active.find(Boolean)||b.p2.active.find(Boolean);
  if(p.field.weather&&p.field.weather!=='none'){b.field.weather=p.field.weather;b.field.weatherState=effectState(b,p.field.weather,source,timed(p.publicEffects?.field.weather));}
  if(p.field.terrain){b.field.terrain=p.field.terrain;b.field.terrainState=effectState(b,p.field.terrain,source,timed(p.publicEffects?.field.terrain));}
  if(p.field.trickroom)b.field.pseudoWeather.trickroom=effectState(b,'trickroom',source,timed(p.publicEffects?.field.trickroom));
  if(p.forecast){
    for(const side of b.sides)for(const m of side.pokemon){
      const f=p.forecast.pokemon[side.n]?.[m.m.publicIndex];if(!f)continue;
      m.statusState=restoreForecast(b,m.status,f.status,m);m.abilityState=restoreForecast(b,m.ability,f.ability,m);m.itemState=restoreForecast(b,m.item,f.item,m);
      m.volatiles=Object.fromEntries(Object.entries(f.volatiles).map(([id,state])=>[id,restoreForecast(b,id,state,m)]));
      if(f.timesAttacked!==undefined)m.timesAttacked=f.timesAttacked;
      if(f.movePP)for(const slot of m.moveSlots)if(f.movePP[slot.id]!==undefined)slot.pp=f.movePP[slot.id];
    }
    b.sides.forEach((side,s)=>{side.sideConditions=Object.fromEntries(Object.entries(p.forecast.conditions[s]).map(([id,state])=>[id,restoreForecast(b,id,state,side.active.find(Boolean))]));});
    b.field.weatherState=restoreForecast(b,p.field.weather,p.forecast.weather,source);b.field.terrainState=restoreForecast(b,p.field.terrain,p.forecast.terrain,source);
    b.field.pseudoWeather=Object.fromEntries(Object.entries(p.forecast.pseudoWeather).map(([id,state])=>[id,restoreForecast(b,id,state,source)]));
  }
  // Forecast serialization omits live references. Restore each Pokemon effect
  // owner's target independently of its source (which may be another Pokemon).
  // Native item callbacks such as White Herb's onAnySwitchIn require this same
  // owner reference installed by the simulator's Pokemon constructor.
  for(const side of b.sides)for(const m of side.pokemon){
    for(const state of [m.statusState,m.abilityState,m.itemState,...Object.values(m.volatiles)])state.target=m;
  }
  // Rebuilding a deserialized board bypasses Battle.endTurn's request refresh.
  // Restore its native legality hooks WITHOUT advancing/residuals or reading a
  // live request. Otherwise Choice lock/Taunt/Imprison and Shadow Tag are inert
  // in forecasts even though all requisite effects are publicly disclosed.
  for(const m of b.getAllActive())if(m.hp){
    b.runEvent('DisableMove',m);
    for(const slot of m.moveSlots){const move=dex.getActiveMove(slot.id);b.singleEvent('DisableMove',move,null,m);if(move.flags.cantusetwice&&m.lastMove?.id===slot.id)m.disableMove(slot.id);}
    b.runEvent('TrapPokemon',m);
  }
  b.updateSpeed();
  // A continuation can already be terminal. Its native winner (including the
  // simultaneous-KO rule) must survive serialization; running another turn
  // would ask two empty sides for choices and discard that outcome.
  if(p.forecast?.ended)b.win(b.sides.find(side=>side.name===p.forecast.winner)||null);
  else b.checkWin();
  return b;
}

function prepareHit(b,source,target,id,{spread=false,critical=false,protect=false,helpingHand=false}={}){
  let move=dex.getActiveMove(id);move.willCrit=critical;move.spreadHit=spread;move.hit=1;
  if(protect)target.volatiles.protect=effectState(b,'protect',target);
  if(helpingHand)source.volatiles.helpinghand=effectState(b,'helpinghand',source);
  b.setActiveMove(move,source,target);
  b.singleEvent('ModifyType',move,null,source,target,move,move);
  b.singleEvent('ModifyMove',move,null,source,target,move,move);
  move=b.runEvent('ModifyType',source,target,move,move);
  move=b.runEvent('ModifyMove',source,target,move,move);
  b.setActiveMove(move,source,target);
  return move;
}
export function createChampionsDamageDecision(position,{cache=true,prepareBattle=null}={}){
  // Position must come from publicDamagePosition; no live simulator parameter.
  const damageCache=new Map(),exchangeCache=new Map();
  const metrics={engine:CHAMPIONS_DAMAGE_ENGINE,damageCalculations:0,damageMs:0,damageCacheHits:0,exchangeSimulations:0,exchangeMs:0,exchangeCacheHits:0};
  function instrument(b){
    if(prepareBattle)prepareBattle(b);
    const original=b.actions.getDamage.bind(b.actions);
    b.actions.getDamage=(source,target,move,...args)=>{
      const t=performance.now();try{
        metrics.damageCalculations++;const damage=original(source,target,move,...args);
        return damage;
      }finally{metrics.damageMs+=performance.now()-t;}
    };
    return b;
  }
  function calculate(p,attacker,defender,id,options={}){
    const key=JSON.stringify([p,attacker,defender,id,options]);if(cache&&damageCache.has(key)){metrics.damageCacheHits++;return damageCache.get(key);}
    const samples=[];let accuracy=1,critChance=0;
    for(const critical of [false,true])for(let roll=85;roll<=100;roll++){
      const b=instrument(createPublicDamageBattle(p));
      try{
        const a=b.sides[attacker.side].pokemon.find(m=>m.m.publicIndex===attacker.index),t=b.sides[defender.side].pokemon.find(m=>m.m.publicIndex===defender.index),beforeHP=t.hp;
        const move=prepareHit(b,a,t,id,{...options,critical});
        if(!critical){const ratio=b.clampIntRange(b.runEvent('ModifyCritRatio',a,t,move,move.critRatio||0),0,4);critChance=move.willCrit===true?1:1/([Infinity,24,8,2,1][ratio]);}
        // WillCrit is forced only to enumerate the two engine branches; the
        // probability comes from the move/ability/item's normal crit mechanics.
        const original=dex.moves.get(id);if(original.willCrit===true)critChance=1;if(original.willCrit===false)critChance=0;
        b.publicDamageRoll=roll;b.randomizer=base=>b.trunc(b.trunc(base*roll)/100);
        let hit=true;
        const preparable=b.singleEvent('Try',move,null,a,t,move)&&b.singleEvent('PrepareHit',move,{},t,a,move)&&b.runEvent('PrepareHit',a,t,move);
        if(!preparable)hit=false;
        if(hit)for(const step of ['hitStepInvulnerabilityEvent','hitStepTryHitEvent','hitStepTypeImmunity','hitStepTryImmunity']){if(!b.actions[step]([t],a,move)?.[0]){hit=false;break;}}
        if(hit){const randomChance=b.randomChance;b.randomChance=(n,d)=>{accuracy=Math.max(0,Math.min(1,n/d));return true;};try{hit=!!b.actions.hitStepAccuracy([t],a,move)[0];}finally{b.randomChance=randomChance;}}
        if(hit)b.actions.hitStepBreakProtect([t],a,move);
        let damage=0;
        const getDamage=b.actions.getDamage.bind(b.actions);
        b.actions.getDamage=(source,target,...args)=>{const value=getDamage(source,target,...args);if(source===a&&target===t)damage+=Number(value)||0;return value;};
        // Includes PrimaryHit/Substitute and actual Damage/AfterHit hooks,
        // rather than inferring HP loss from the damage formula alone.
        if(hit&&move.category!=='Status')b.actions.spreadMoveHit([t],a,move,move,false,false);
        samples.push({damage,applied:beforeHP-t.hp,critical,roll,ko:t.hp===0&&beforeHP>0});
      }finally{b.destroy();}
    }
    const normal=samples.filter(s=>!s.critical),crit=samples.filter(s=>s.critical),weight=s=>((s.critical?critChance:1-critChance)/16),expected=samples.reduce((v,s)=>v+s.damage*weight(s),0)*accuracy;
    const hp=Math.max(1,Math.round(p.teams[defender.side][defender.index].hp*p.teams[defender.side][defender.index].stats.hp));
    const probability=v=>Math.max(0,Math.min(1,v));
    const koProbability=probability(samples.reduce((v,s)=>v+(s.ko?weight(s):0),0)*accuracy);
    const possible=samples.filter(s=>weight(s)>0);
    const baseRolls=critChance===1?crit:normal;
    const result={engine:CHAMPIONS_DAMAGE_ENGINE,min:Math.min(...baseRolls.map(s=>s.damage)),max:Math.max(...baseRolls.map(s=>s.damage)),possibleMin:Math.min(...possible.map(s=>s.damage)),possibleMax:Math.max(...possible.map(s=>s.damage)),criticalMin:Math.min(...crit.map(s=>s.damage)),criticalMax:Math.max(...crit.map(s=>s.damage)),expected,accuracy,critChance,koProbability,
      guaranteedKO:accuracy===1&&samples.filter(s=>weight(s)>0).every(s=>s.ko),remainingHP:Math.max(0,Math.round((hp-samples.reduce((v,s)=>v+s.applied*weight(s),0)*accuracy)*1e9)/1e9),
      twoHitKOProbability:probability(samples.reduce((v,a)=>v+samples.reduce((n,c)=>n+(a.damage+c.damage>=hp?weight(a)*weight(c):0),0),0)*accuracy**2),
      twoHitScope:'two independent formula hits before recovery, item consumption or state changes; use exchange() for those effects',
      distributionScope:'one damage hit; multi-hit and smart-target moves are resolved by exchange()',rolls:normal.map(s=>s.damage),criticalRolls:crit.map(s=>s.damage)};
    if(cache)damageCache.set(key,result);return result;
  }
  function exchange(p,own,opponent,{roll=93,tie=0,seed=0,nativeChance=false,chancePrefix=[]}={}){
    const key=JSON.stringify([p,own.actions,opponent.actions,roll,tie,seed,nativeChance,chancePrefix]);if(cache&&exchangeCache.has(key)){metrics.exchangeCacheHits++;return exchangeCache.get(key);}
    const started=performance.now(),b=instrument(createPublicDamageBattle(p));
    try{
      // Fixed roll samples retain the engine's integer arithmetic. All other
      // mechanics run through its actual queue, actions and residual events.
      b.publicDamageRoll=roll;b.randomizer=base=>b.trunc(b.trunc(base*roll)/100);
      b.resetRNG([17+seed,29+tie,43+seed,71+tie]);
      const chanceEvents=[];
      if(nativeChance){
        // Trace/branch the actual local engine distribution. Consume every
        // native RNG call first, including forced counterfactual branches.
        const record=(kind,value,outcomes)=>{
          const index=chanceEvents.length,forced=chancePrefix[index];
          if(forced&&forced.kind!==kind)throw Error('Divergent chance prefix');
          const outcome=forced?forced.value:value;
          if(!outcomes.some(o=>JSON.stringify(o.value)===JSON.stringify(outcome)))throw Error('Invalid chance outcome');
          chanceEvents.push({kind,value:outcome,outcomes});return outcome;
        };
        const normalChance=b.randomChance.bind(b);
        b.randomChance=(n,d)=>{const v=normalChance(n,d);return n>0&&n<d?record('boolean',v,[{value:true,probability:n/d},{value:false,probability:1-n/d}]):v;};
        b.randomizer=base=>{
          const value=100-b.random(16),selected=record('damage-roll',value,Array.from({length:16},(_,i)=>({value:85+i,probability:1/16})));
          return b.trunc(b.trunc(base*selected)/100);
        };
        const shuffle=b.prng.shuffle.bind(b.prng);
        b.prng.shuffle=(list,start=0,end=list.length)=>{
          const before=list.slice(start,end);shuffle(list,start,end);
          if(before.length<2||before.length>4||!before.every(x=>x.choice==='move'))return;
          const permutations=[];function permute(left,chosen){if(!left.length){permutations.push(chosen);return;}for(const i of left)permute(left.filter(j=>j!==i),[...chosen,i]);}permute(before.map((_,i)=>i),[]);
          const selected=record('speed-order',list.slice(start,end).map(x=>before.indexOf(x)),permutations.map(value=>({value,probability:1/permutations.length})));
          for(let i=0;i<selected.length;i++)list[start+i]=before[selected[i]];
        };
      }
      const normalSort=b.speedSort.bind(b);
      if(!nativeChance)b.speedSort=(list,compare=b.comparePriority)=>normalSort(list,(a,c)=>compare(a,c)||((a.pokemon?.side.n??tie)===(c.pokemon?.side.n??tie)?0:a.pokemon?.side.n===tie?-1:1));
      if(!b.ended){
      b.updateSpeed();
      for(const [s,joint] of [own,opponent].entries())for(const action of joint.actions){
        const pokemon=b.sides[s].active[action.slot];if(!pokemon)continue;
        if(action.type==='move')b.queue.addChoice({choice:'move',pokemon,moveid:action.move.id,targetLoc:action.target||0,mega:!!action.mega});
        if(action.type==='switch')b.queue.addChoice({choice:'switch',pokemon,target:b.sides[s].pokemon.find(m=>m.m.publicIndex===action.choice-1)});
      }
      b.queue.sort();b.turnLoop();
      // Resolve mid-turn pivots/forced replacements from this synthetic public
      // roster. Unrevealed OTS members remain hypothetical, as in existing search.
      for(let guard=0;b.requestState==='switch'&&!b.ended&&guard<8;guard++){
        let count=0;
        for(const side of b.sides){const chosen=new Set();for(const pokemon of side.active)if(pokemon?.switchFlag){
          const incoming=side.pokemon.find(m=>m.hp&&!m.isActive&&!chosen.has(m));if(incoming){chosen.add(incoming);b.queue.insertChoice({choice:'instaswitch',pokemon,target:incoming});count++;}else pokemon.switchFlag=false;
        }}
        if(!count)break;b.turnLoop();
      }
      }
      const next=structuredClone(p);next.turn=b.turn;
      for(let s=0;s<2;s++){
        const side=b.sides[s];next.active[s]=side.active.map(m=>m?.m.publicIndex??-1);
        next.conditions[s]=Object.keys(side.sideConditions);
        for(const m of side.pokemon){
          // Simulator objects are only from our own public sandbox. Never return
          // them or accept objects from the live battle through this interface.
          const x=next.teams[s][m.m.publicIndex];Object.assign(x,{species:m.species.name,types:[...m.species.types],stats:{hp:m.maxhp,...m.storedStats},hp:m.hp/m.maxhp,
            item:m.getItem().name,ability:m.getAbility().name,boosts:{...m.boosts},status:m.status,volatiles:Object.keys(m.volatiles),acted:m.activeMoveActions>0,
            movePP:Object.fromEntries(m.moveSlots.map(slot=>[slot.id,slot.pp])),timesAttacked:m.timesAttacked,lastMove:m.lastMove?.id||'',protectStreak:m.volatiles.stall?Math.round(Math.log(m.volatiles.stall.counter)/Math.log(3)):0});
          if(m.species.isMega)next.megaUsed[s]=true;
          if(m.isActive)x.revealed=true;
        }
      }
      next.field={weather:b.field.weather,terrain:b.field.terrain,trickroom:!!b.field.getPseudoWeather('trickroom')};
      // Preserve predicted counters/durations into the second ply. These are
      // generated by this public sandbox, never copied from the live engine.
      next.forecast={ended:b.ended,winner:b.winner,totalFainted:b.sides.map(s=>s.totalFainted),pokemon:b.sides.map(side=>{
        const team=[];for(const m of side.pokemon)team[m.m.publicIndex]={status:forecastState(m.statusState),ability:forecastState(m.abilityState),item:forecastState(m.itemState),timesAttacked:m.timesAttacked,movePP:Object.fromEntries(m.moveSlots.map(slot=>[slot.id,slot.pp])),
          volatiles:Object.fromEntries(Object.entries(m.volatiles).map(([id,state])=>[id,forecastState(state)]))};return team;
      }),conditions:b.sides.map(side=>Object.fromEntries(Object.entries(side.sideConditions).map(([id,state])=>[id,forecastState(state)]))),
        weather:forecastState(b.field.weatherState),terrain:forecastState(b.field.terrainState),pseudoWeather:Object.fromEntries(Object.entries(b.field.pseudoWeather).map(([id,state])=>[id,forecastState(state)]))};
      const result={position:next,ended:b.ended,winner:b.winner,...(nativeChance?{chanceEvents}: {})};if(cache)exchangeCache.set(key,result);return result;
    }finally{metrics.exchangeSimulations++;metrics.exchangeMs+=performance.now()-started;b.destroy();}
  }
  function calculatePublic(attacker,defender,id,options={}){
    const count=Math.max(1,...damageBeliefs(position).map(m=>m.builds.length));
    const builds=Array.from({length:count},(_,i)=>calculate(hypothesizePosition(position,i),attacker,defender,id,options));
    const koRange={min:Math.min(...builds.map(b=>b.koProbability)),max:Math.max(...builds.map(b=>b.koProbability))};
    // A guarantee must also clear conservative independent stat bounds. The
    // simultaneous extremes need not describe a real legal set; they prevent
    // a gap between sampled archetypes from being mislabeled as a certain KO.
    const bounds=damageBeliefs(position),checks=[];
    for(let i=0;i<count;i++)for(const speedEnd of ['min','max']){
      const q=hypothesizePosition(position,i);
      if(attacker.side===1){const m=q.teams[1][attacker.index];for(const k of keys)m.stats[k]=bounds[attacker.index].statRange[k].min;}
      if(defender.side===1){const m=q.teams[1][defender.index],range=bounds[defender.index].statRange;for(const k of keys)m.stats[k]=range[k][['atk','spa'].includes(k)?'min':k==='spe'?speedEnd:'max'];}
      checks.push(calculate(q,attacker,defender,id,options));
    }
    return {engine:CHAMPIONS_DAMAGE_ENGINE,min:Math.min(...builds.map(b=>b.min)),max:Math.max(...builds.map(b=>b.max)),
      expectedRange:{min:Math.min(...builds.map(b=>b.expected)),max:Math.max(...builds.map(b=>b.expected))},koProbabilityRange:koRange,
      guaranteedAcrossBuilds:builds.every(b=>b.guaranteedKO),guaranteedKO:builds.every(b=>b.guaranteedKO)&&checks.every(b=>b.guaranteedKO),uncertainKO:(koRange.min<1||checks.some(b=>!b.guaranteedKO))&&koRange.max>0,
      twoHitKOProbabilityRange:{min:Math.min(...builds.map(b=>b.twoHitKOProbability)),max:Math.max(...builds.map(b=>b.twoHitKOProbability))},
      remainingHPRange:{min:Math.min(...builds.map(b=>b.remainingHP)),max:Math.max(...builds.map(b=>b.remainingHP))},builds,
      scope:'robust across the listed public hypotheses; not a guarantee over every conceivable unrevealed build'};
  }
  return {position,calculate,calculatePublic,exchange,metrics,beliefs:damageBeliefs(position),dispose(){damageCache.clear();exchangeCache.clear();}};
}
