// Node-side policy selection for the Champions browser transport only.
import {loadChampionsStrong} from './champions-strong.mjs';

export function createChampionsBrowserDispatcher({loadStrong=loadChampionsStrong}={}) {
  let strong;
  return async difficulty => {
    if (difficulty !== 'Neural Preview') {
      return {implementation:'champions-lookahead',agent:null};
    }
    // Share one ONNX instance across decisions and battles. A failed load is
    // surfaced to the browser; a later battle may retry after files are fixed.
    strong ??= loadStrong();
    try {
      return {implementation:'champions-strong-hybrid',agent:await strong};
    } catch (error) {
      strong=null;
      throw new Error(`Champions hybrid could not load: ${error.message}`);
    }
  };
}

export const loadChampionsBrowserAI=createChampionsBrowserDispatcher();
