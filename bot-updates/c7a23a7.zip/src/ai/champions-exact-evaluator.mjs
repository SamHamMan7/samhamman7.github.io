import {publicDamagePosition,createChampionsDamageDecision,hypothesizePosition} from './champions-damage.mjs';
import {boardValue} from './champions-search.mjs';

// The action shortlist can remain cheap; every scored exchange (including the
// second ply) executes the authoritative local engine on public build beliefs.
export function createChampionsExactEvaluator(state,request,dex,{buildRisk=.2}={}){
  const position=publicDamagePosition(state,request),decision=createChampionsDamageDecision(position);
  const variants=Array.from({length:Math.max(1,...decision.beliefs.map(m=>m.builds.length))},(_,i)=>hypothesizePosition(position,i));
  const cache=new Map();
  function simulate(p,own,foe,roll=.925,tie=1){
    const key=JSON.stringify([p,own.actions,foe.actions,roll,tie]);if(cache.has(key))return cache.get(key);
    const positions=(p.hypothesis===undefined?variants:[p]).filter(q=>foe.actions.every(a=>a.type!=='switch'||q.teams[1][a.choice-1]?.hp>0));
    if(!positions.length)throw Error('No public brought-team hypothesis supports this response');
    const results=positions.map(q=>{
      const result=decision.exchange(q,own,foe,{roll:Math.round(roll*100),tie,seed:roll<.9?0:roll<1?1:2});
      const next=result.position;
      const knownBrought=next.teams[1].filter(m=>m.revealed).length>=next.teams[0].length;
      const terminal=result.ended&&(result.winner==='Public opponent'||knownBrought);
      const score=boardValue(dex,next,0)-boardValue(dex,next,1)+(terminal?(result.winner==='Public own'?10000:result.winner==='Public opponent'?-10000:0):0);
      return {...result,score};
    });
    const weights=positions.map(q=>[.45,.12,.12,.15,.06,.1][q.hypothesis%6]),total=weights.reduce((a,b)=>a+b,0);
    const worst=results.reduce((a,b)=>a.score<b.score?a:b),mean=results.reduce((sum,r,i)=>sum+r.score*weights[i],0)/total;
    // Continue a likely public build; the worst build already contributes to
    // the first-ply score. Carrying only that build would make every future
    // position assume the pessimistic spread with certainty.
    const likely=weights.indexOf(Math.max(...weights));
    const result={score:(1-buildRisk)*mean+buildRisk*worst.score,position:results[likely].position,mean,worst:worst.score};
    cache.set(key,result);return result;
  }
  return {position,simulate,decision,diagnostics:()=>({...decision.metrics,beliefs:decision.beliefs,buildHypotheses:variants.length,
    exchangeProbabilityScope:'bounded build hypotheses, endpoint/midpoint rolls and both speed ties; other random events use fixed independent seeds'})};
}
