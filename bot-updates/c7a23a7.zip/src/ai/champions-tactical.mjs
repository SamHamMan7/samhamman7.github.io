﻿const PROTECT = new Set([
  'protect','detect','spikyshield','kingsshield',
  'banefulbunker','silktrap','burningbulwark'
]);

const STATUS_VALUE = new Map([
  ['tailwind', 36],
  ['trickroom', 25],
  ['followme', 25],
  ['ragepowder', 25],
  ['helpinghand', 18],
  ['swordsdance', 18],
  ['nastyplot', 18],
  ['calmmind', 17],
  ['dragondance', 20],
  ['quiverdance', 22],
  ['recover', 15],
  ['roost', 15],
  ['slackoff', 15],
]);

export function createChampionsState() {
  return {
    turn: 0,
    active: {
      p1: [null, null],
      p2: [null, null],
    },
    lastMove: {
      p1: ['', ''],
      p2: ['', ''],
    },
    sideConditions: {
      p1: new Set(),
      p2: new Set(),
    },
  };
}

function slotFromIdent(ident) {
  const m = ident.match(/^(p[12])([ab]):/);
  if (!m) return null;
  return {
    side: m[1],
    slot: m[2] === 'a' ? 0 : 1,
  };
}

function speciesFromDetails(details) {
  return (details || '').split(',')[0].trim();
}

export function observeChampionsChunk(state, chunk) {
  for (const line of chunk.split('\n')) {
    let m;

    if ((m = line.match(/^\|turn\|(\d+)$/))) {
      state.turn = Number(m[1]);
      continue;
    }

    if (line.startsWith('|switch|') || line.startsWith('|drag|')) {
      const parts = line.split('|');
      const where = slotFromIdent(parts[2] || '');
      if (!where) continue;

      state.active[where.side][where.slot] = {
        species: speciesFromDetails(parts[3]),
        switchTurn: state.turn,
      };
      state.lastMove[where.side][where.slot] = '';
      continue;
    }

    if (line.startsWith('|faint|')) {
      const where = slotFromIdent(line.split('|')[2] || '');
      if (where) state.active[where.side][where.slot] = null;
      continue;
    }

    if (line.startsWith('|move|')) {
      const parts = line.split('|');
      const where = slotFromIdent(parts[2] || '');
      if (where) state.lastMove[where.side][where.slot] =
        (parts[3] || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      continue;
    }

    if (line.startsWith('|-sidestart|')) {
      const parts = line.split('|');
      const side = (parts[2] || '').slice(0, 2);
      if (state.sideConditions[side]) {
        state.sideConditions[side].add(
          (parts[3] || '').toLowerCase().replace(/^move:\s*/, '')
        );
      }
      continue;
    }

    if (line.startsWith('|-sideend|')) {
      const parts = line.split('|');
      const side = (parts[2] || '').slice(0, 2);
      if (state.sideConditions[side]) {
        state.sideConditions[side].delete(
          (parts[3] || '').toLowerCase().replace(/^move:\s*/, '')
        );
      }
    }
  }
}

function typeMultiplier(dex, moveType, speciesName) {
  if (!speciesName) return 1;

  const species = dex.species.get(speciesName);
  if (!species?.exists) return 1;

  let mult = 1;

  for (const type of species.types || []) {
    const data = dex.types.get(type);
    const taken = data.damageTaken?.[moveType];

    if (taken === 1) mult *= 2;
    else if (taken === 2) mult *= 0.5;
    else if (taken === 3) return 0;
  }

  return mult;
}

function hasSTAB(dex, speciesName, moveType) {
  if (!speciesName) return false;
  const species = dex.species.get(speciesName);
  return species?.types?.includes(moveType);
}

function firstTurnOut(state, side, slot) {
  const mon = state.active[side]?.[slot];
  if (!mon) return false;
  return state.turn === mon.switchTurn + 1;
}

function moveScore(action, state, dex) {
  const move = dex.moves.get(action.move?.id || '');
  if (!move?.exists) return 0;

  const own = state.active.p1[action.slot]?.species;

  if (move.category === 'Status') {
    let score = STATUS_VALUE.get(move.id) ?? 5;

    if (PROTECT.has(move.id)) {
      score = state.lastMove.p1[action.slot] === move.id ? 2 : 16;
    }

    if (
      move.id === 'tailwind' &&
      state.sideConditions.p1.has('tailwind')
    ) score = -15;

    return score + (action.mega ? 7 : 0);
  }

  // Damaging your own ally is legal, but generally awful.
  if (action.target < 0) return -120 + (action.mega ? 2 : 0);

  let bp = move.basePower || 60;
  let accuracy = move.accuracy === true ? 1 :
    typeof move.accuracy === 'number' ? move.accuracy / 100 : 1;

  let multiplier = 1;

  if (action.target > 0) {
    const foe = state.active.p2[action.target - 1]?.species;
    multiplier = typeMultiplier(dex, move.type, foe);
  } else if (
    ['allAdjacentFoes', 'allAdjacent', 'randomNormal'].includes(move.target)
  ) {
    const foes = state.active.p2
      .filter(Boolean)
      .map(x => typeMultiplier(dex, move.type, x.species));

    if (foes.length) multiplier =
      foes.reduce((a, b) => a + b, 0) / foes.length;

    if (move.target === 'allAdjacent') bp *= 0.8;
  }

  const stab = hasSTAB(dex, own, move.type) ? 1.5 : 1;

  let score = bp * accuracy * stab * multiplier / 10;

  score += (move.priority || 0) * 2;

  if (move.id === 'fakeout') {
    score += firstTurnOut(state, 'p1', action.slot) ? 30 : -35;
  }

  if (['icywind','electroweb'].includes(move.id)) score += 17;
  if (move.id === 'snarl') score += 8;
  if (move.id === 'makeitrain') score += 6;

  if (multiplier === 0) score -= 40;

  if (action.mega) score += 10;

  return score;
}

function actionScore(action, state, dex) {
  if (action.type === 'pass') return -20;
  if (action.type === 'switch') return -3;
  return moveScore(action, state, dex);
}

export function scoreChampionsJoint(joint, state, dex) {
  let score = joint.actions.reduce(
    (sum, action) => sum + actionScore(action, state, dex),
    0
  );

  const protects = joint.actions.filter(
    a => a.type === 'move' && PROTECT.has(a.move?.id)
  ).length;

  if (protects === 2) score -= 8;

  const switches = joint.actions.filter(a => a.type === 'switch').length;
  if (switches === 2) score -= 5;

  return score;
}

export function chooseChampionsJoint(
  legal,
  state,
  dex,
  {temperature = 5, window = 14, random = Math.random} = {}
) {
  const ranked = legal
    .map(x => ({
      ...x,
      score: scoreChampionsJoint(x, state, dex),
    }))
    .sort((a, b) => b.score - a.score);

  const best = ranked[0]?.score ?? 0;

  const candidates = ranked
    .filter((x, i) => i < 20 && x.score >= best - window);

  const weights = candidates.map(
    x => Math.exp((x.score - best) / temperature)
  );

  const total = weights.reduce((a, b) => a + b, 0);
  let roll = random() * total;

  let chosen = candidates[0];

  for (let i = 0; i < candidates.length; i++) {
    roll -= weights[i];
    if (roll <= 0) {
      chosen = candidates[i];
      break;
    }
  }

  return {
    chosen,
    top: ranked.slice(0, 10),
  };
}
