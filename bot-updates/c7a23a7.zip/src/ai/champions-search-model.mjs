import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import * as ort from 'onnxruntime-node';
import {SEARCH_FEATURES,SEARCH_FEATURES_V2,encodeSearchState,encodeSearchActions} from './champions-search-features.mjs';
import {ACTOR_FEATURES,encodeActorState,encodeActorActions} from './champions-actor-features.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
export async function loadChampionsSearchModel(directory){
  const manifest=JSON.parse(await fs.readFile(path.join(directory,'manifest.json'))),bytes=await fs.readFile(path.join(directory,'model.onnx'));
  const actor=manifest.schema==='champions-actor-model-v3';
  if((actor?JSON.stringify(manifest.features)!==JSON.stringify(ACTOR_FEATURES):manifest.schema!=='champions-search-model-v1'||![SEARCH_FEATURES,SEARCH_FEATURES_V2].some(f=>JSON.stringify(manifest.features)===JSON.stringify(f)))||manifest.modelSha256!==sha(bytes)||manifest.parameters>3000000)throw Error('Search model contract/hash mismatch');
  const session=await ort.InferenceSession.create(bytes,{executionProviders:['cpu'],intraOpNumThreads:1,interOpNumThreads:1});
  const dex=actor||manifest.features.monCat===10?createRequire(import.meta.url)(fileURLToPath(new URL('../../.tools/pokemon-showdown-current/dist/sim/index.js',import.meta.url))).Dex.mod('champions'):null;
  return {manifest,session,async predict(p,own,foe){
    const state=actor?encodeActorState(p,dex):encodeSearchState(p,manifest.features),a=actor?encodeActorActions(p,own,0,dex):encodeSearchActions(p,own,0,dex),b=actor?encodeActorActions(p,foe,1,dex):encodeSearchActions(p,foe,1,dex),count=own.length+foe.length;
    if(!count)throw Error('No model candidates');
    const feeds={token_ids:new ort.Tensor('int64',BigInt64Array.from(state.token_ids.flat(),BigInt),[1,12,manifest.features.monCat]),token_num:new ort.Tensor('float32',Float32Array.from(state.token_num.flat()),[1,12,manifest.features.monNum]),field:new ort.Tensor('float32',Float32Array.from(state.field),[1,16]),...(actor?{action_links:new ort.Tensor('int64',BigInt64Array.from([...a.action_links,...b.action_links].flat(2),BigInt),[1,count,2,3]),action_num:new ort.Tensor('float32',Float32Array.from([...a.action_num,...b.action_num].flat(2)),[1,count,2,ACTOR_FEATURES.actionNum]),pair_num:new ort.Tensor('float32',Float32Array.from([...a.pair_num,...b.pair_num].flat()),[1,count,ACTOR_FEATURES.pairNum])}:{action_ids:new ort.Tensor('int64',BigInt64Array.from([...a.action_ids,...b.action_ids].flat(),BigInt),[1,count,4]),action_num:new ort.Tensor('float32',Float32Array.from([...a.action_num,...b.action_num].flat()),[1,count,24])})};
    const out=await session.run(feeds);if(actor&&(!Array.from(out.logits.data).every(Number.isFinite)||!Number.isFinite(Number(out.value.data[0]))))throw Error('Nonfinite actor model output');return {own:new Map(own.map((j,i)=>[j.command,out.logits.data[i]])),foe:new Map(foe.map((j,i)=>[j.command,out.logits.data[own.length+i]])),value:Number(out.value.data[0]),valueUsed:false};
  }};
}
