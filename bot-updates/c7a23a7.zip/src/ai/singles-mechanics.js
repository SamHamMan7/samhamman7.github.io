import {Dex} from '@pkmn/sim';
import {clamp, toID, hazardCost} from './damage.js';

function helmetDamage(attacker, defender, moveName, hitChance, field) {
  if (!moveName || hitChance <= 0 || toID(defender.item) !== 'rockyhelmet' || toID(defender.ability) === 'klutz' || field?.magicRoom) return 0;
  const move = Dex.moves.get(moveName), item = toID(attacker.item);
  if (!move.flags.contact || toID(attacker.ability) === 'magicguard' || toID(attacker.ability) === 'longreach' ||
    item === 'protectivepads' || item === 'punchingglove' && move.flags.punch) return 0;
  const volatiles = defender.volatiles;
  if (Array.isArray(volatiles) && volatiles.some(v => toID(typeof v === 'string' ? v : v?.id) === 'substitute') || volatiles?.substitute) return 0;
  const maxHP = attacker.exactStats?.hp;
  const fraction = maxHP > 0 ? Math.floor(maxHP / 6) / maxHP : 1 / 6;
  const accuracy = move.accuracy === true ? 1 : Number(move.accuracy || 100) / 100;
  // One activation is a conservative lower bound for multihit contact moves.
  return fraction * clamp(hitChance) * accuracy;
}

/** Public contact/residual facts only; no engine object or opposing request. */
export function resolvePublicResiduals({own, opponent, ownHP, opponentHP, ownMove, opponentMove,
  ownHitChance, opponentHitChance, ownResidual, opponentResidual, field}) {
  const ownContact = helmetDamage(own, opponent, ownMove, ownHitChance, field);
  const opponentContact = helmetDamage(opponent, own, opponentMove, opponentHitChance, field);
  const beforeOwn = Math.max(0, ownHP), beforeOpponent = Math.max(0, opponentHP);
  let score = -Math.min(beforeOwn, ownContact) * 100 + Math.min(beforeOpponent, opponentContact) * 100;
  if (beforeOwn > 0 && ownContact >= beforeOwn) score -= 60 + own.hpFraction * 18;
  if (beforeOpponent > 0 && opponentContact >= beforeOpponent) score += 50 + opponent.hpFraction * 12;
  const remainingOwn = ownHP - ownContact, remainingOpponent = opponentHP - opponentContact;
  // End-of-turn recovery happens only to a living Pokemon. Never resurrect a
  // KO, including one caused by contact/recoil before its healing item triggers.
  return {ownHP: remainingOwn > 0 ? clamp(remainingOwn + ownResidual) : 0,
    opponentHP: remainingOpponent > 0 ? clamp(remainingOpponent + opponentResidual) : 0,
    score, ownContact, opponentContact};
}

/** The next decision after our faint: free replacement, then one normal turn.
 * All teammates are own private knowledge; the opposing state is a public
 * hypothesis. A doomed Pokemon never receives Regenerator or another action. */
export function replacementAfterKO(outcome, action, ctx, {pair, responses, moves, limit}) {
  const deadIndex = action.kind === 'switch' ? action.slot - 1 : ctx.roster.indexOf(ctx.own);
  const key = JSON.stringify([deadIndex, outcome.opponent, !!action.tera, !!ctx.request.active?.[0]?.canTerastallize]);
  ctx.replacementCache ??= new Map();
  if (ctx.replacementCache.has(key)) return ctx.replacementCache.get(key);
  const alive = m => !m.fainted && !String(m.condition || '').includes('fnt') && m.hpFraction > 0;
  const roster = ctx.roster.map((m, i) => {
    if (i === deadIndex) return {...m, active: false, hpFraction: 0, fainted: true, condition: '0 fnt'};
    if (m.active) return {...m, active: false, boosts: {}, volatiles: [], lastMove: null,
      hpFraction: clamp(m.hpFraction + (toID(m.ability) === 'regenerator' ? 1 / 3 : 0)),
      status: toID(m.ability) === 'naturalcure' ? '' : m.status};
    return m;
  });
  let best = -Infinity;
  const available = !action.tera && ctx.request.active?.[0]?.canTerastallize;
  const reserve = (5 + Math.max(0, roster.filter(alive).length - 1) * 2.2) * ctx.profile.teraReserve;
  for (const original of roster.filter(alive)) {
    const hazards = hazardCost(original, ctx.field.sideConditions), hpFraction = original.hpFraction - hazards;
    if (hpFraction <= 0) continue;
    const incoming = {...original, hpFraction, active: true, boosts: {}, volatiles: [], lastMove: null,
      alliesFainted: roster.filter(m => !alive(m)).length};
    const next = {...ctx, own: incoming, opponent: outcome.opponent, roster};
    const choices = moves(incoming, {kind: 'switch'});
    if (available && incoming.teraType && !incoming.terastallized) choices.push(...choices.map(a => ({...a, tera: incoming.teraType})));
    const replies = responses(outcome.opponent, incoming, next).slice(0, 3);
    for (const choice of choices) {
      let value = 0, weight = 0;
      for (const reply of replies) {
        if (ctx.calculations > limit) return {value: 0, complete: false};
        value += pair(incoming, outcome.opponent, choice, reply, next).score * reply.weight;
        weight += reply.weight;
      }
      // No attack is granted during the forced switch. Both sides act once in
      // the following turn. Entry hazards and a deferred Tera are paid once.
      best = Math.max(best, value / (weight || 1) - hazards * 100 - (choice.tera ? reserve / .52 : 0));
    }
  }
  const result = {value: Number.isFinite(best) ? best : -100, complete: true};
  ctx.replacementCache.set(key, result);
  return result;
}
