import {Dex} from '@pkmn/sim';
import {calculate, Pokemon, Move, Field} from '@smogon/calc';

export const toID = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
export const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, value));

export function conditionInfo(condition = '100/100') {
  const [health, status = ''] = condition.split(' ');
  const [hp, maxHP] = health.split('/').map(Number);
  return {hp: Number.isFinite(hp) ? hp : 100, maxHP: maxHP || 100,
    hpFraction: status === 'fnt' ? 0 : clamp((Number.isFinite(hp) ? hp : 100) / (maxHP || 100)),
    status: status === 'fnt' ? '' : status, fainted: status === 'fnt' || hp === 0};
}

export function fromRequest(mon, publicMon = {}) {
  const ownSet = mon.ownSet || mon.set || {};
  const details = mon.details || '';
  const health = conditionInfo(mon.condition);
  return {
    ...ownSet, ...mon, ...publicMon, ...health,
    species: (publicMon.transformed&&publicMon.species) || details.split(',')[0] || ownSet.species || publicMon.species || mon.species,
    level: ownSet.level || Number(details.match(/, L(\d+)/)?.[1]) || mon.level || 100,
    ability: publicMon.ability || mon.ability || ownSet.ability || mon.baseAbility || '',
    item: mon.item ?? ownSet.item ?? '', nature: ownSet.nature || mon.nature,
    evs: ownSet.evs || mon.evs, ivs: ownSet.ivs || mon.ivs,
    moves: mon.moves || ownSet.moves || [], movesSeen: mon.moves || ownSet.moves || [],
    boosts: publicMon.boosts || {}, exactStats: {...mon.stats, hp: health.maxHP},
    teraType: ownSet.teraType || mon.teraType || publicMon.teraType,
    terastallized: publicMon.terastallized || mon.terastallized,
  };
}

// calculate() clones Pokemon before calculating. Preserve known own raw stats in that clone.
function preserveStats(pokemon, stats) {
  if (!stats) return pokemon;
  Object.assign(pokemon.rawStats, stats);
  Object.assign(pokemon.stats, stats);
  const originalClone = pokemon.clone.bind(pokemon);
  pokemon.clone = () => preserveStats(originalClone(), stats);
  return pokemon;
}

export function calcPokemon(mon) {
  const species = Dex.species.get(mon.species);
  const name = species.exists ? species.name : 'Pikachu';
  const teraType = mon.terastallized ? (typeof mon.terastallized === 'string' ? mon.terastallized : mon.teraType) : undefined;
  const pokemon = preserveStats(new Pokemon(9, name, {
    // Showdown may publish a cosmetic/battle forme before calc's species table.
    // Public Dex metadata supplies its real stats/types instead of a guessed species.
    overrides: {baseStats: {...species.baseStats}, types: [...species.types], weightkg: species.weightkg},
    level: mon.level || 100, item: Dex.items.get(mon.item || '').name || '',
    // Empty string makes calc choose the default ability; 'None' deliberately means unrevealed.
    ability: mon.ability ? Dex.abilities.get(mon.ability).name : 'None',
    nature: mon.nature || 'Serious', evs: mon.evs || {}, ivs: mon.ivs || {},
    boosts: mon.boosts || {}, status: mon.status || '', teraType,
    toxicCounter: mon.toxicCounter || 0,
    alliesFainted: mon.alliesFainted || 0, boostedStat: mon.boostedStat, abilityOn: !!mon.boostedStat,
  }), mon.exactStats);
  pokemon.originalCurHP = Math.max(1, Math.round(pokemon.rawStats.hp * clamp(mon.hpFraction ?? 1)));
  return pokemon;
}

function fieldSide(conditions) {
  const names = Array.isArray(conditions) ? conditions.map(c => toID(typeof c === 'string' ? c : c.id || c.name)) : Object.keys(conditions || {}).map(toID);
  return {isReflect: names.includes('reflect'), isLightScreen: names.includes('lightscreen'),
    isAuroraVeil: names.includes('auroraveil'), isTailwind: names.includes('tailwind'),
    isSR: names.includes('stealthrock'), isStickyWeb: names.includes('stickyweb')};
}

export function calcField(field = {}, reverse = false) {
  const weather = {sunnyday: 'Sun', raindance: 'Rain', sandstorm: 'Sand', hail: 'Hail', snowscape: 'Snow', desolateland: 'Harsh Sunshine', primordialsea: 'Heavy Rain'}[toID(field.weather)];
  const terrain = {electricterrain: 'Electric', grassyterrain: 'Grassy', psychicterrain: 'Psychic', mistyterrain: 'Misty'}[toID(field.terrain)];
  return new Field({weather, terrain, gameType: field.gameType || 'Singles',
    attackerSide: fieldSide(reverse ? field.opponentSideConditions : field.sideConditions),
    defenderSide: fieldSide(reverse ? field.sideConditions : field.opponentSideConditions)});
}

export function effectiveSpeed(mon, field = {}, reverse = false) {
  const p = calcPokemon(mon);
  const boost = mon.boosts?.spe || 0;
  let speed = p.rawStats.spe * (boost >= 0 ? (2 + boost) / 2 : 2 / (2 - boost));
  const ability = toID(mon.ability), weather = toID(field.weather), item = toID(mon.item);
  if (mon.status === 'par' && ability !== 'quickfeet') speed *= 0.5;
  if (ability === 'quickfeet' && mon.status) speed *= 1.5;
  if (item === 'choicescarf') speed *= 1.5;
  if (mon.boostedStat==='spe' && ['protosynthesis','quarkdrive'].includes(ability)) speed *= 1.5;
  if ((ability === 'swiftswim' && ['rain', 'raindance'].includes(weather)) ||
      (ability === 'chlorophyll' && ['sun', 'sunnyday'].includes(weather)) ||
      (ability === 'sandrush' && weather === 'sandstorm') ||
      (ability === 'slushrush' && ['hail', 'snowscape'].includes(weather)) ||
      (ability === 'surgesurfer' && toID(field.terrain) === 'electricterrain')) speed *= 2;
  if (fieldSide(reverse ? field.opponentSideConditions : field.sideConditions).isTailwind) speed *= 2;
  return speed;
}

function averageDamage(damage) {
  if (typeof damage === 'number') return [damage];
  if (!Array.isArray(damage)) return [0];
  if (Array.isArray(damage[0])) {
    // Multi-hit damage arrays contain a roll distribution per hit.
    return damage[0].map((_, i) => damage.reduce((sum, hit) => sum + (hit[i % hit.length] || 0), 0));
  }
  return damage;
}

/** Actual Smogon generation-nine damage formulas; only hidden inputs are approximations. */
export function damageEstimate(attacker, defender, moveName, field = {}, reverse = false) {
  const data = Dex.moves.get(moveName);
  if (!data.exists || data.category === 'Status') return {mean: 0, min: 0, max: 0, ko: 0, accuracy: 1};
  const a = calcPokemon(attacker), d = calcPokemon(defender);
  const move = new Move(9, data.name);
  const result = calculate(9, a, d, move, calcField(field, reverse));
  const rolls = averageDamage(result.damage);
  const accuracy = data.accuracy === true ? 1 : clamp((data.accuracy || 100) / 100);
  const hp = Math.max(1, d.rawStats.hp * (defender.hpFraction ?? 1));
  const average = rolls.reduce((total, damage) => total + damage, 0) / (rolls.length || 1);
  return {mean: average / d.rawStats.hp * accuracy, min: Math.min(...rolls) / d.rawStats.hp,
    max: Math.max(...rolls) / d.rawStats.hp, ko: rolls.filter(damage => damage >= hp).length / (rolls.length || 1) * accuracy,
    accuracy};
}

export function typeEffectiveness(moveType, mon) {
  const species = Dex.species.get(mon.species);
  const types = mon.terastallized && mon.teraType !== 'Stellar' ? [mon.teraType || mon.terastallized] : mon.types || species.types || [];
  if (!Dex.getImmunity(moveType, types)) return 0;
  return 2 ** Dex.getEffectiveness(moveType, types);
}

export function hazardCost(mon, conditions = []) {
  if (toID(mon.item) === 'heavydutyboots' || toID(mon.ability) === 'magicguard') return 0;
  const list = Array.isArray(conditions) ? conditions.map(c => toID(typeof c === 'string' ? c : c.id || c.name)) : Object.keys(conditions).map(toID);
  const grounded = typeEffectiveness('Ground', mon) > 0 && toID(mon.ability) !== 'levitate' && toID(mon.item) !== 'airballoon';
  return (list.includes('stealthrock') ? 0.125 * typeEffectiveness('Rock', mon) : 0) +
    (grounded && list.includes('spikes') ? [0,.125,1/6,.25][Math.min(3,list.filter(x=>x==='spikes').length)] : 0) +
    (grounded && list.includes('toxicspikes') && !mon.status && !Dex.species.get(mon.species).types.some(t => ['Poison', 'Steel'].includes(t)) ? 0.06 : 0);
}
