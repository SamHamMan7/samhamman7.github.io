import {enumerateChampionsActions} from './champions-actions.mjs';
import {championsPosition,megaForm,toID} from './champions-public.mjs';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const alive=m=>m&&m.hp>0;
const mon=(p,s,k)=>p.teams[s][p.active[s][k]];
const boost=n=>n>=0?(2+n)/2:2/(2-n);
const stat=(m,k)=>m.stats[k]*boost(m.boosts[k]||0);
const protect=m=>m.stallingMove&&m.id!=='endure';
export function seededChampionsRandom(seed){let n=seed>>>0;return ()=>{n+=0x6d2b79f5;let t=Math.imul(n^n>>>15,1|n);t^=t+Math.imul(t^t>>>7,61|t);return ((t^t>>>14)>>>0)/4294967296;};}
function speed(p,s,m){return stat(m,'spe')*(p.conditions[s].includes('tailwind')?2:1)*(m.status==='par'?.5:1)*(toID(m.item)==='choicescarf'?1.5:1);}
function evolve(dex,m) {
  const form=megaForm(dex,m);if(!form)return;
  const before=dex.species.get(m.species),after=dex.species.get(form),nature=dex.natures.get(m.nature);
  for(const k in m.stats)m.stats[k]+=((after.baseStats[k]||0)-(before.baseStats[k]||0))*(nature.plus===k?1.1:nature.minus===k?.9:1);
  m.species=after.name;m.types=[...after.types];m.ability=after.abilities['0'];
}
function grounded(m){return !m.types.includes('Flying')&&toID(m.ability)!=='levitate';}
function priority(dex,p,s,m,move){return (move.priority||0)+(toID(m.ability)==='prankster'&&move.category==='Status'?1:0)+(move.id==='grassyglide'&&p.field.terrain==='grassyterrain'&&grounded(m)?1:0);}
export function estimateChampionsDamage(dex,p,s,a,t,move,{spread=false,roll=.925}={}) {
  if(!alive(a)||!alive(t)||move.category==='Status')return {fraction:0,ko:0};
  let type=move.type,power=move.basePower||0,modifier=1;
  if(['ragefist','lastrespects'].includes(move.id)&&typeof move.basePowerCallback==='function'){
    // These two pinned callbacks are pure reads of these public/synthetic
    // counters. Do not approximate a boosted Last Respects as a 50-power move
    // and prune it before the native exchange evaluator can examine it.
    const totalFainted=p.forecast?.totalFainted?.[s]??p.teams[s].filter(m=>m.hp<=0&&(s===0||m.revealed)).length;
    power=move.basePowerCallback.call({dex},{timesAttacked:a.timesAttacked||0,side:{totalFainted}},null,move);
  }
  const ability=toID(a.ability),defAbility=toID(t.ability),item=toID(a.item);
  if(type==='Normal'&&['aerilate','pixilate','refrigerate'].includes(ability)){type={aerilate:'Flying',pixilate:'Fairy',refrigerate:'Ice'}[ability];modifier*=1.2;}
  if(!dex.getImmunity(type,t.types)||type==='Ground'&&defAbility==='levitate'||type==='Fire'&&defAbility==='flashfire'||type==='Water'&&['waterabsorb','stormdrain','dryskin'].includes(defAbility)||type==='Electric'&&['lightningrod','voltabsorb','motordrive'].includes(defAbility))return {fraction:0,ko:0};
  if(move.id==='fakeout'&&a.acted)return {fraction:0,ko:0};
  if(move.id==='bodypress')power=80;
  if(move.id==='electroball')power=80;if(move.id==='gyroball')power=Math.min(150,25*stat(t,'spe')/Math.max(1,stat(a,'spe'))+1);
  if(move.id==='eruption'||move.id==='waterspout')power=150*a.hp;
  if(!power)power=move.damage||move.damageCallback?60:0;
  const physical=move.category==='Physical',offense=move.id==='bodypress'?stat(a,'def'):stat(a,physical?'atk':'spa'),defense=stat(t,physical?'def':'spd');
  let effectiveness=2**dex.getEffectiveness(type,t.types);
  let damage=((22*power*offense/Math.max(1,defense))/50+2)*effectiveness;
  if(a.types.includes(type))damage*=ability==='adaptability'?2:1.5;
  if(physical&&a.status==='brn'&&ability!=='guts')modifier*=.5;
  if(physical&&['hugepower','purepower'].includes(ability))modifier*=2;
  if(physical&&ability==='guts'&&a.status)modifier*=1.5;
  if(power<=60&&ability==='technician')modifier*=1.5;
  if(item==='lifeorb')modifier*=1.3;
  if(item==='choiceband'&&physical||item==='choicespecs'&&!physical)modifier*=1.5;
  if(item==='miracleseed'&&type==='Grass')modifier*=1.2;
  if(spread)modifier*=.75;
  if(!p.teams[s].includes(t)&&(p.conditions[1-s].includes(physical?'reflect':'lightscreen')||p.conditions[1-s].includes('auroraveil')))modifier*=2/3;
  if(p.field.weather.includes('sun')){if(type==='Fire')modifier*=1.5;if(type==='Water')modifier*=.5;}
  if(p.field.weather.includes('rain')){if(type==='Water')modifier*=1.5;if(type==='Fire')modifier*=.5;}
  if(p.field.terrain==='grassyterrain'&&type==='Grass'&&grounded(a))modifier*=1.3;
  if(p.field.terrain==='electricterrain'&&type==='Electric'&&grounded(a))modifier*=1.3;
  if(p.field.terrain==='grassyterrain'&&['earthquake','bulldoze'].includes(move.id)&&grounded(t))modifier*=.5;
  if(ability==='toughclaws'&&move.flags?.contact)modifier*=1.3;
  if(defAbility==='multiscale'&&t.hp===1)modifier*=.5;
  if(toID(t.item)==='assaultvest'&&!physical)modifier/=1.5;
  const accuracy=ability==='noguard'||defAbility==='noguard'||move.accuracy===true?1:typeof move.accuracy==='number'?move.accuracy/100:1;
  const fraction=damage*modifier*roll/Math.max(1,t.stats.hp);
  const ko=clamp((damage*modifier/t.stats.hp-t.hp)/Math.max(.001,damage*modifier/t.stats.hp*.15)+1/16)*accuracy;
  return {fraction:fraction*accuracy,ko};
}
function targets(p,s,a,move) {
  if(a.target)return [{s:a.target>0?1-s:s,k:Math.abs(a.target)-1}];
  if(move.target==='self'||move.target==='allySide')return [{s,k:a.slot}];
  const foes=[0,1].filter(k=>alive(mon(p,1-s,k))).map(k=>({s:1-s,k}));
  // Representative random target, never mistake Struggle for a spread attack.
  if(move.target==='randomNormal')return foes.slice(0,1);
  if(move.target==='allAdjacent')return [...foes,...[0,1].filter(k=>k!==a.slot&&alive(mon(p,s,k))).map(k=>({s,k}))];
  if(move.target==='all')return [...foes,...[0,1].filter(k=>alive(mon(p,s,k))).map(k=>({s,k}))];
  return foes;
}
function speedValue(p,s) {
  let result=0;
  for(let k=0;k<2;k++)for(let j=0;j<2;j++){const a=mon(p,s,k),b=mon(p,1-s,j);if(alive(a)&&alive(b)){const delta=(speed(p,s,a)-speed(p,1-s,b))*(p.field.trickroom?-1:1);result+=delta===0?0:delta>0?3:-3;}}
  return result;
}
function bestHit(dex,p,s,a,t) {return Math.max(0,...a.moves.filter(id=>a.movePP?.[id]!==0).map(id=>estimateChampionsDamage(dex,p,s,a,t,dex.moves.get(id)).fraction));}
export function boardValue(dex,p,s) {
  // Unknown brought bench choices are never counted as known material.
  let value=0;
  for(const m of p.teams[s])if(alive(m)&&(s===0||m.revealed))value+=65+35*m.hp;
  if(s===1)value+=Math.max(0,p.teams[0].length-p.teams[1].filter(m=>m.revealed).length)*100;
  value+=speedValue(p,s);
  for(let k=0;k<2;k++){
    const a=mon(p,s,k);if(!alive(a))continue;
    const threat=Math.max(0,...[0,1].map(j=>alive(mon(p,1-s,j))?bestHit(dex,p,s,a,mon(p,1-s,j)):0));
    value+=12*Math.min(1,threat)*a.hp;
    value+=2*((a.boosts.atk||0)+(a.boosts.spa||0)+(a.boosts.def||0)+(a.boosts.spd||0));
    if(p.conditions[s].includes('tailwind'))value+=Math.max(0,speedValue(p,s))*0.6;
  }
  return value;
}
function updateBoost(m,changes,scale=1) {for(const [k,n] of Object.entries(changes||{}))m.boosts[k]=clamp((m.boosts[k]||0)+n*scale,-6,6);}
function entryEffects(dex,p,s,m){
  if(toID(m.ability)==='grassysurge')p.field.terrain='grassyterrain';
  if(toID(m.ability)==='intimidate')for(let k=0;k<2;k++){
    const foe=mon(p,1-s,k),ability=toID(foe?.ability);if(!alive(foe)||['innerfocus','clearbody','fullmetalbody'].includes(ability))continue;
    updateBoost(foe,{atk:-1},ability==='contrary'?-1:1);if(ability==='defiant')updateBoost(foe,{atk:2});if(ability==='competitive')updateBoost(foe,{spa:2});
  }
}
function replacementCandidates(p,s){
  const allKnown=p.teams[1].filter(m=>m.revealed).length>=p.teams[0].length;
  return p.teams[s].map((m,i)=>({m,i})).filter(({m,i})=>alive(m)&&!p.active[s].includes(i)&&(s===0||!allKnown||m.revealed));
}
function replacementChoice(dex,p,s){
  return replacementCandidates(p,s).map(({m,i})=>({i,score:8*m.hp+[0,1].reduce((v,k)=>{const foe=mon(p,1-s,k);return v+(alive(foe)?12*bestHit(dex,p,s,m,foe)-15*bestHit(dex,p,1-s,foe,m):0);},0)})).sort((a,b)=>b.score-a.score||a.i-b.i)[0]?.i;
}
function bringIn(dex,p,s,k,i){
  const outgoing=mon(p,s,k);if(outgoing){outgoing.boosts={};outgoing.protectStreak=0;outgoing.volatiles=[];}
  p.active[s][k]=i;const m=mon(p,s,k);m.boosts={};m.acted=false;m.switchTurn=p.turn;m.lastMove='';m.protectStreak=0;m.revealed=true;entryEffects(dex,p,s,m);
}
function fillFainted(dex,p){
  // Public future hypotheses only; no opponent request or actual brought bench
  // is available. Unknown OTS bench members are hypotheses, not known choices.
  for(let s=0;s<2;s++)for(let k=0;k<2;k++)if(!alive(mon(p,s,k))){const i=replacementChoice(dex,p,s);if(i!==undefined)bringIn(dex,p,s,k,i);}
}
export function simulateSearchPly(dex,position,own,opponent,roll=.925,tieSide=roll<.925?0:1) {
  const p=structuredClone(position),choices=[own,opponent],blocked=[[],[]],flinch=[[],[]],help=[[],[]],redirect=[null,null],events=[];
  for(let s=0;s<2;s++)for(const a of choices[s].actions) {
    if(a.type==='switch') {
      const out=mon(p,s,a.slot);if(out)out.boosts={};
      p.active[s][a.slot]=a.choice-1;const incoming=mon(p,s,a.slot);incoming.boosts={};incoming.acted=false;incoming.switchTurn=p.turn;incoming.revealed=true;
      entryEffects(dex,p,s,incoming);
      if(p.conditions[s].includes('stealthrock'))incoming.hp=Math.max(0,incoming.hp-.125*2**dex.getEffectiveness('Rock',incoming.types));
    }
    if(a.type==='move')events.push({s,a});
  }
  for(const {s,a} of events)if(a.mega&&!p.megaUsed[s]){evolve(dex,mon(p,s,a.slot));p.megaUsed[s]=true;}
  while(events.length) {
    events.sort((x,y)=>{
      const a=mon(p,x.s,x.a.slot),b=mon(p,y.s,y.a.slot);if(!a||!b)return a?-1:1;
      return priority(dex,p,y.s,b,dex.moves.get(y.a.move.id))-priority(dex,p,x.s,a,dex.moves.get(x.a.move.id))||
        (speed(p,y.s,b)-speed(p,x.s,a))*(p.field.trickroom?-1:1)|| (tieSide===0?x.s-y.s:y.s-x.s);
    });
    const {s,a}=events.shift(),actor=mon(p,s,a.slot),move=dex.moves.get(a.move.id);
    if(!alive(actor)||flinch[s][a.slot]||['slp','frz'].includes(actor.status))continue;
    const previousStreak=actor.protectStreak;
    actor.lastMove=move.id;actor.lastMoveTurn=p.turn;actor.protectStreak=protect(move)?previousStreak+1:0;
    if(protect(move)){blocked[s][a.slot]=1/3**Math.min(6,previousStreak);actor.acted=true;continue;}
    if(move.id==='tailwind'){if(!p.conditions[s].includes('tailwind'))p.conditions[s].push('tailwind');continue;}
    if(move.id==='trickroom'){p.field.trickroom=!p.field.trickroom;continue;}
    if(['followme','ragepowder'].includes(move.id)){redirect[s]=a.slot;continue;}
    if(move.id==='helpinghand'){const k=a.target<0?-a.target-1:1-a.slot;help[s][k]=1.5;continue;}
    if(move.id==='fakeout'&&actor.acted)continue;
    let ts=targets(p,s,a,move);
    if(a.target>0&&redirect[1-s]!==null&&alive(mon(p,1-s,redirect[1-s])))ts=[{s:1-s,k:redirect[1-s]}];
    // Public ability redirection applies even when a different foe was targeted.
    // It is separate from target immunity and is essential to response search.
    if(a.target&&move.target!=='self'&&['Electric','Water'].includes(move.type)&&!['moldbreaker','teravolt','turboblaze'].includes(toID(actor.ability))){
      const redirectAbility=move.type==='Electric'?'lightningrod':'stormdrain',holders=[];
      for(let side=0;side<2;side++)for(let k=0;k<2;k++){const candidate=mon(p,side,k);if(alive(candidate)&&candidate!==actor&&toID(candidate.ability)===redirectAbility)holders.push({s:side,k,candidate});}
      holders.sort((a,b)=>speed(p,b.s,b.candidate)-speed(p,a.s,a.candidate));if(holders.length)ts=[{s:holders[0].s,k:holders[0].k}];
    }
    const spread=ts.filter(t=>alive(mon(p,t.s,t.k))).length>1&&['allAdjacent','allAdjacentFoes'].includes(move.target);
    let hit=false;
    for(const t of ts) {
      let target=mon(p,t.s,t.k);
      if(!alive(target)&&t.s!==s&&a.target>0){t.k=1-t.k;target=mon(p,t.s,t.k);}
      if(!alive(target))continue;
      if(t.s!==s&&priority(dex,p,s,actor,move)>0&&(p.field.terrain==='psychicterrain'&&grounded(target)||['dazzling','queenlymajesty','armortail'].includes(toID(target.ability))))continue;
      const protection=move.flags?.protect?blocked[t.s][t.k]||0:0;
      if(move.category==='Status') {
        if(protection>=1||t.s!==s&&toID(target.ability)==='goodasgold')continue;
        if(move.boosts)updateBoost(target,move.boosts,toID(target.ability)==='contrary'?-1:1);
        if(move.heal)target.hp=Math.min(1,target.hp+move.heal[0]/move.heal[1]);
        if(move.status)target.status=move.status;
        continue;
      }
      const d=estimateChampionsDamage(dex,p,s,actor,target,move,{spread,roll});
      if(move.type==='Electric'&&toID(target.ability)==='lightningrod'||move.type==='Water'&&toID(target.ability)==='stormdrain'){updateBoost(target,{spa:1});continue;}
      let damage=d.fraction*(help[s][a.slot]||1)*(1-protection);
      if(target.volatiles?.includes('substitute')){damage=Math.max(0,damage-.25);target.volatiles=target.volatiles.filter(x=>x!=='substitute');}
      if(target.hp===1&&['focussash'].includes(toID(target.item))&&damage>=1){damage=.99;target.item='';}
      const dealt=Math.min(target.hp,damage);target.hp=Math.max(0,target.hp-damage);
      if(dealt>0)hit=true;
      if(move.id==='fakeout'&&dealt>0&&!['innerfocus','shielddust'].includes(toID(target.ability))&&toID(target.item)!=='covertcloak')flinch[t.s][t.k]=true;
      if(dealt>0&&move.recoil)actor.hp=Math.max(0,actor.hp-dealt*target.stats.hp/actor.stats.hp*move.recoil[0]/move.recoil[1]);
      if(dealt>0&&move.drain)actor.hp=Math.min(1,actor.hp+dealt*target.stats.hp/actor.stats.hp*move.drain[0]/move.drain[1]);
      if(dealt>0&&toID(target.item)==='sitrusberry'&&target.hp>0&&target.hp<=.5){target.hp=Math.min(1,target.hp+.25);target.item='';}
      for(const secondary of move.secondaries||[move.secondary].filter(Boolean))if(dealt>0&&secondary.boosts&&!['clearbody','whitesmoke','fullmetalbody'].includes(toID(target.ability)))updateBoost(target,secondary.boosts,(secondary.chance||100)/100*(toID(target.ability)==='contrary'?-1:1));
    }
    if(hit&&move.self?.boosts)updateBoost(actor,move.self.boosts,toID(actor.ability)==='contrary'?-1:1);
    if(hit&&toID(actor.item)==='lifeorb'&&toID(actor.ability)!=='magicguard')actor.hp=Math.max(0,actor.hp-.1);
    actor.acted=true;
    if(hit&&move.selfSwitch&&alive(actor)){const i=replacementChoice(dex,p,s);if(i!==undefined)bringIn(dex,p,s,a.slot,i);}
  }
  for(let s=0;s<2;s++)for(let k=0;k<2;k++){
    const m=mon(p,s,k);if(!alive(m))continue;if(m.switchTurn!==p.turn)m.acted=true;
    if(toID(m.item)==='leftovers')m.hp=Math.min(1,m.hp+1/16);
    if(p.field.terrain==='grassyterrain'&&grounded(m))m.hp=Math.min(1,m.hp+1/16);
    if(m.status==='brn')m.hp=Math.max(0,m.hp-1/16);if(m.status==='psn')m.hp=Math.max(0,m.hp-1/8);
  }
  p.turn++;
  return {score:boardValue(dex,p,0)-boardValue(dex,p,1),position:p};
}
function responseRequest(dex,p) {
  const allBroughtKnown=p.teams[1].filter(m=>m.revealed).length>=p.teams[0].length;
  const order=[...p.active[1],...p.teams[1].map((_,i)=>i).filter(i=>!p.active[1].includes(i)&&(!allBroughtKnown||p.teams[1][i].revealed))];
  const roster=order.map((index,slot)=>{
    const m=p.teams[1][index];return {active:slot<2,condition:alive(m)?'100/100':'0 fnt',index};
  });
  return {order,request:{side:{pokemon:roster},active:[0,1].map(k=>{
    const m=mon(p,1,k);if(!alive(m))return null;
    let moves=m.moves;
    // Without OTS, only revealed moves may be used; no hidden move-set lookup.
    if(!moves.length)return null;
    if(/^choice(band|scarf|specs)$/.test(toID(m.item))&&m.acted&&m.lastMove)moves=moves.filter(x=>x===m.lastMove);
    return {canMegaEvo:!p.megaUsed[1]&&!!megaForm(dex,m),moves:moves.slice(0,4).map(id=>{const d=dex.moves.get(id);return {id,move:d.name,target:d.target,pp:1,disabled:m.volatiles.includes('taunt')&&d.category==='Status'};})};
  })}};
}
const idle={actions:[{slot:0,type:'pass'},{slot:1,type:'pass'}],command:'pass, pass'};
function cheapScores(dex,p,legal,s) {
  const cache=new Map();
  return legal.map(joint=>{
    let score=0;
    for(const action of joint.actions) {
      const key=JSON.stringify(action);if(cache.has(key)){score+=cache.get(key);continue;}
      let value=0;const actor=mon(p,s,action.slot);
      if(action.type==='switch') {
        const candidate=p.teams[s][action.choice-1];
        value=alive(candidate)?8*candidate.hp-10: -100;
        for(let k=0;k<2;k++){const foe=mon(p,1-s,k);if(alive(foe)&&alive(candidate))value+=8*bestHit(dex,p,s,candidate,foe)-12*bestHit(dex,p,1-s,foe,candidate);}
      } else if(action.type==='move'&&alive(actor)) {
        const a=structuredClone(actor);if(action.mega)evolve(dex,a);
        const move=dex.moves.get(action.move.id);
        if(move.category!=='Status')for(const t of targets(p,s,action,move)) {
          const target=mon(p,t.s,t.k);if(!alive(target))continue;
          const d=estimateChampionsDamage(dex,p,s,a,target,move,{spread:['allAdjacent','allAdjacentFoes'].includes(move.target)});
          value+=(t.s===s?-1.5:1)*(60*Math.min(d.fraction,target.hp)+35*d.ko);
          if(move.id==='fakeout'&&!a.acted&&d.fraction>0)value+=22;
          if(move.secondary?.boosts?.spe<0||move.secondary?.boosts?.spa<0)value+=5;
        }
        else if(protect(move))value=Math.max(0,...[0,1].map(k=>alive(mon(p,1-s,k))?bestHit(dex,p,1-s,mon(p,1-s,k),actor)*28:0))*(actor.protectStreak?1/3:1);
        else if(move.id==='tailwind'||move.id==='trickroom'){
          const next=structuredClone(p);if(move.id==='tailwind'&&!next.conditions[s].includes('tailwind'))next.conditions[s].push('tailwind');if(move.id==='trickroom')next.field.trickroom=!next.field.trickroom;
          value=(speedValue(next,s)-speedValue(p,s))*1.8;
        } else if(move.heal)value=40*Math.min(1-actor.hp,move.heal[0]/move.heal[1]);
        else if(move.boosts)value=8*Object.values(move.boosts).reduce((a,b)=>a+b,0);
        else if(['helpinghand','followme','ragepowder'].includes(move.id))value=16;
      }
      cache.set(key,value);score+=value;
    }
    return {...joint,cheapScore:score};
  }).sort((a,b)=>b.cheapScore-a.cheapScore||a.command.localeCompare(b.command));
}
function shortlist(ranked,limit,dex) {
  const out=ranked.slice(0,Math.max(1,limit-4));
  // Preserve a few plausible defensive/support response families before pruning.
  for(const family of ['protect','switch','speed','support','mega']) {
    const pick=ranked.find(j=>!out.includes(j)&&j.cheapScore>=ranked[0].cheapScore-70&&j.actions.some(a=>family==='switch'?a.type==='switch':family==='mega'?a.mega:a.type==='move'&&(family==='protect'?protect(dex.moves.get(a.move.id)):family==='speed'?['tailwind','trickroom','icywind','electroweb'].includes(a.move.id):!!dex.moves.get(a.move.id).boosts||['fakeout','helpinghand','followme','ragepowder'].includes(a.move.id))));
    if(pick&&out.length<limit)out.push(pick);
  }
  for(const x of ranked)if(out.length<limit&&!out.includes(x))out.push(x);
  return out;
}
export const SEARCH_SETTINGS=Object.freeze({ownCap:24,responseCap:16,depth:1,secondOwnCap:6,secondResponseCap:5,deepCandidates:6,risk:.4,discount:.7,window:0,temperature:.4,neuralCandidates:4,neuralWeight:0,enemySpeedPoints:null,tieSamples:2,enemyStatProfile:'balanced'});
export {modeledActions as modeledChampionsActions,cheapScores as scoreChampionsCandidates,shortlist as shortlistChampionsCandidates};
function modeledActions(dex,p,side){
  const q=side===1?p:{...p,teams:[p.teams[1],p.teams[0]],active:[p.active[1],p.active[0]],conditions:[p.conditions[1],p.conditions[0]],megaUsed:[p.megaUsed[1],p.megaUsed[0]]};
  const modeled=responseRequest(dex,q);
  return enumerateChampionsActions(modeled.request).map(j=>({...j,actions:j.actions.map(a=>a.type==='switch'?{...a,choice:modeled.order[a.choice-1]+1}:a)}));
}
export function chooseChampionsSearch(legal,state,dex,{request,random=Math.random,prior=[],evaluator=null,...settings}={}) {
  const options={...SEARCH_SETTINGS,...settings}, {ownCap,responseCap,window,temperature}=options;
  const started=performance.now(),p=evaluator?.position||championsPosition(state,request);
  const simulate=evaluator?.simulate||((p,a,b,roll,tie)=>simulateSearchPly(dex,p,a,b,roll,tie));
  if(![1,2].includes(options.tieSamples)||!['balanced','offense'].includes(options.enemyStatProfile))throw Error('Invalid search hypothesis');
  if(!evaluator&&options.enemyStatProfile==='offense')for(const m of p.teams[1]){
    const damaging=m.moves.map(id=>dex.moves.get(id)).filter(m=>m.category!=='Status');if(!damaging.length)continue;
    const power=category=>damaging.filter(m=>m.category===category).reduce((s,m)=>s+(m.basePower||40),0),offense=power('Physical')>power('Special')?'atk':'spa';
    // A coherent 66-point offensive archetype derived from public moves, not
    // copied hidden allocations. Other plausible builds remain unknown.
    const evs={hp:2,atk:0,def:0,spa:0,spd:0,spe:32};evs[offense]=32;
    for(const k of Object.keys(m.stats))m.stats[k]=dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},dex.species.get(m.species).baseStats,{nature:m.nature,level:50,evs},k);
  }
  // Opposing allocations are private. This is an explicit public-stat
  // hypothesis, not a reconstruction of an opponent request or team object.
  if(!evaluator&&options.enemySpeedPoints!==null){
    if(!Number.isInteger(options.enemySpeedPoints)||options.enemySpeedPoints<0||options.enemySpeedPoints>32)throw Error('Invalid public speed hypothesis');
    for(const m of p.teams[1])m.stats.spe=dex.data.Scripts.statModify.call({dex,trunc:Math.trunc,ruleTable:new Set()},dex.species.get(m.species).baseStats,{nature:m.nature,level:50,evs:{spe:options.enemySpeedPoints}},'spe');
  }
  const own=shortlist(cheapScores(dex,p,legal,0),clamp(Math.floor(ownCap),1,64),dex);
  // A prior can add legal candidates but cannot remove tactical coverage or
  // determine the winner. Invalid/nonmember neural commands are discarded.
  const commands=new Set(own.map(j=>j.command)),members=new Map(legal.map(j=>[j.command,j]));
  for(const j of prior.slice(0,options.neuralCandidates)){const member=members.get(j.command);if(member&&!commands.has(j.command)){own.push(member);commands.add(j.command);}}
  const modeled=responseRequest(dex,p);
  let responses=enumerateChampionsActions(modeled.request).map(j=>({...j,actions:j.actions.map(a=>a.type==='switch'?{...a,choice:modeled.order[a.choice-1]+1}:a)}));
  responses=shortlist(cheapScores(dex,p,responses,1),clamp(Math.floor(responseCap),1,48),dex);
  if(request.forceSwitch||!responses.length)responses=[{...idle,cheapScore:0}];
  const best=responses[0].cheapScore,weights=responses.map(r=>.15+Math.exp((r.cheapScore-best)/30)),total=weights.reduce((a,b)=>a+b,0);
  const downside=options.risk;
  let plies=0;
  const ranked=own.map(j=>{
    const values=responses.map(r=>[.85,.925,1].reduce((sum,roll)=>sum+Array.from({length:options.tieSamples},(_,tie)=>{plies++;return simulate(p,j,r,roll,options.tieSamples===1?(roll<.925?0:1):tie).score;}).reduce((a,b)=>a+b,0)/options.tieSamples,0)/3);
    const mean=values.reduce((sum,v,i)=>sum+v*weights[i],0)/total,worst=Math.min(...values);
    return {...j,score:(1-downside)*mean+downside*worst,mean,worst};
  }).sort((a,b)=>b.score-a.score||a.command.localeCompare(b.command));
  if(options.depth>1&&!request.forceSwitch){
    for(const j of ranked.slice(0,options.deepCandidates)){
      const successors=responses.map((r,i)=>({r,i,next:simulate(p,j,r,.925,1)})).sort((a,b)=>a.next.score-b.next.score).slice(0,options.secondResponseCap);
      const values=[];
      for(const {next} of successors){
        // The engine evaluator already resolves replacements and their entry
        // effects. Only the handwritten evaluator needs this approximation.
        if(!evaluator)fillFainted(dex,next.position);
        const nextOwn=shortlist(cheapScores(dex,next.position,modeledActions(dex,next.position,0),0),options.secondOwnCap,dex),nextFoe=shortlist(cheapScores(dex,next.position,modeledActions(dex,next.position,1),1),options.secondResponseCap,dex);
        let best=-Infinity;
        for(const a of nextOwn){const scores=(nextFoe.length?nextFoe:[idle]).map(b=>Array.from({length:options.tieSamples},(_,tie)=>{plies++;return simulate(next.position,a,b,.925,options.tieSamples===1?1:tie).score;}).reduce((a,b)=>a+b,0)/options.tieSamples);best=Math.max(best,(1-downside)*scores.reduce((a,b)=>a+b,0)/scores.length+downside*Math.min(...scores));}
        values.push(Number.isFinite(best)?best:next.score);
      }
      if(values.length)j.score=(1-options.discount)*j.score+options.discount*((1-downside)*values.reduce((a,b)=>a+b,0)/values.length+downside*Math.min(...values));
    }
    // Candidates without a second-ply score are not comparable with deep ones.
    ranked.splice(options.deepCandidates);ranked.sort((a,b)=>b.score-a.score||a.command.localeCompare(b.command));
  }
  const near=ranked.filter(j=>j.score>=ranked[0].score-clamp(window,0,4));
  const ws=near.map(j=>Math.exp((j.score-ranked[0].score)/Math.max(.01,Math.min(1,temperature))));
  let pick=random()*ws.reduce((a,b)=>a+b,0),chosen=near[0];for(let i=0;i<near.length;i++){pick-=ws[i];if(pick<=0){chosen=near[i];break;}}
  return {chosen,top:ranked.slice(0,10),diagnostics:{legal:legal.length,ownCandidates:own.length,responses:responses.length,plies,nearBest:near.length,ms:performance.now()-started,settings:options,
    responseCommands:responses.map(r=>r.command)}};
}
