import {createBeliefWorlds} from './champions-belief-worlds.mjs';
import {createPublicDamageBattle,createChampionsDamageDecision} from './champions-damage.mjs';
import {toID} from './champions-public.mjs';
// Conservative observation attribution: complex turns remain neutral. The
// caller supplies a public root and its own split stream, never a live Battle.
export function publicTurnEvidence(previous,chunk,dex,{side='p1',mode='bo1'}={}){
  if(!previous||!chunk)return [];
  const lines=chunk.split('\n'),forbidden=/^\|(?:switch|drag|replace|cant|-boost|-unboost|-setboost|-status|-curestatus|-weather|-fieldstart|-fieldend|-sidestart|-sideend|-item|-enditem|-ability|-start|-end|-mega|detailschange|-formechange|-heal|-activate|-crit|swap)\|/;
  if(lines.some(l=>l.startsWith('|split|')))throw Error('Evidence firewall: unsplit stream');
  if(lines.some(l=>{if(!l.startsWith('|request|'))return false;const r=JSON.parse(l.slice(9));return r?.side&&r.side.id!==side;}))throw Error('Evidence firewall: opposing request');
  if(lines.some(l=>forbidden.test(l)))return [];
  const p=structuredClone(previous),locate=ident=>{const match=ident?.match(/^(p[12])([ab]):/);if(!match)return null;const s=match[1]===side?0:1,index=p.active[s][match[2]==='a'?0:1];return index>=0?{side:s,index,mon:p.teams[s][index]}:null;},moves=[];
  let current;
  for(const line of lines){const [,kind,...a]=line.split('|');if(kind==='move'){current={attacker:locate(a[0]),target:locate(a[2]),move:dex.moves.get(a[1]),damages:[],called:a.some(x=>x.startsWith('[from]'))};moves.push(current);}else if(kind==='-damage'&&current){current.damages.push({target:locate(a[0]),condition:a[1],attributable:!a.slice(2).some(x=>x.startsWith('[from]'))});}}
  const evidence=[];
  for(const m of moves)if(m.attacker?.side===1&&!m.called){if(!m.attacker.mon.moves.includes(m.move.id))m.attacker.mon.moves.push(m.move.id);evidence.push({kind:'move',species:m.attacker.mon.species,value:m.move.id});}
  const beliefs=createBeliefWorlds(p,dex,{mode});
  const priorityUncertain=m=>{const mon=m.attacker?.mon;if(!mon)return true;const abilities=mon.knowledge?.ability?[mon.ability]:Object.values(dex.species.get(mon.species).abilities);return abilities.some(id=>{const a=dex.abilities.get(id);return a.onModifyPriority||a.onFractionalPriority;});};
  const comparable=moves.length===4&&moves.every(m=>m.attacker&&!m.called&&m.move.category!=='Status'&&m.move.priority===0&&!priorityUncertain(m))&&new Set(moves.map(m=>m.attacker.mon.ident)).size===4&&p.teams.flat().every(m=>!m.status&&!(m.volatiles||[]).length)&&!p.field.trickroom;
  if(comparable)for(let i=0;i<moves.length;i++)for(let j=i+1;j<moves.length;j++){
    const a=moves[i].attacker,b=moves[j].attacker;if(a.side===b.side)continue;const foe=a.side===1?a:b,other=a.side===0?a:b,likelihoods={};
    for(const w of beliefs.worlds){const battle=createPublicDamageBattle(w.position);try{const speed=x=>battle.sides[x.side].pokemon.find(m=>m.m.publicIndex===x.index).speed,fa=speed(foe),own=speed(other);likelihoods[w.id]=fa===own?.5:(a.side===1?fa>own:fa<own)?1:0;}finally{battle.destroy();}}
    evidence.push({kind:'speed',species:foe.mon.species,otherSpecies:other.mon.species,faster:a.side===1,comparable:true,likelihoods});
  }
  const decision=createChampionsDamageDecision(p);try{
    for(const m of moves){if(m.called||!m.attacker||!m.target||m.move.category==='Status'||m.move.target!=='normal'||m.move.multihit||m.damages.length!==1||!m.damages[0].attributable)continue;
      const damage=m.damages[0];if(!damage.target||damage.target.side===m.attacker.side||damage.target.index!==m.target.index)continue;
      if(moves.flatMap(x=>x.damages).filter(d=>d.target?.side===m.target.side&&d.target?.index===m.target.index).length!==1)continue;
      const match=damage.condition.match(/^(\d+)\/(\d+)/);if(!match)continue;const after=+match[1]/+match[2],observed=m.target.mon.hp-after;if(observed<=0)continue;
      const likelihoods={};for(const w of beliefs.worlds){const hp=w.position.teams[m.target.side][m.target.index].stats.hp,d=decision.calculate(w.position,m.attacker,m.target,m.move.id),tolerance=m.target.side===0?.5/hp:.011;
        const fits=roll=>Math.abs(Math.min(roll/hp,m.target.mon.hp)-observed)<=tolerance;
        likelihoods[w.id]=d.accuracy*((1-d.critChance)*d.rolls.filter(fits).length+d.critChance*d.criticalRolls.filter(fits).length)/16;
      }
      evidence.push({kind:'damage',species:(m.attacker.side===1?m.attacker:m.target).mon.species,likelihoods});
    }
  }finally{decision.dispose();}
  return evidence;
}
export function createPublicEvidenceLedger(side,dex,mode='bo1'){
  let previous=null,lines=[];const evidence=[];
  return {observe(chunk){lines.push(chunk);},advance(publicPosition){const newEvidence=publicTurnEvidence(previous,lines.join('\n'),dex,{side,mode});evidence.push(...newEvidence);previous=structuredClone(publicPosition);lines=[];return [...evidence];},get evidence(){return structuredClone(evidence);},restore(publicEvidence){for(const e of publicEvidence||[])if(['move','item','ability','speed','damage'].includes(e.kind))evidence.push(structuredClone(e));}};
}
