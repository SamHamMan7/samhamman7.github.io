// Public Dex metadata and decision-boundary public move sets only. Candidate
// identity is a lookup key, never a scorer input. No future-label completion.
import {toID} from './champions-public.mjs';
export const CANDIDATE_SCHEMA='champions-move-candidates-v2';
export const MOVE_TYPES=['Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy','???'];
export const MOVE_CATEGORIES=['Physical','Special','Status'];
export const MOVE_TARGETS=['normal','any','adjacentFoe','adjacentAlly','adjacentAllyOrSelf','self','allAdjacent','allAdjacentFoes','all','allySide','foeSide','allyTeam','randomNormal','scripted'];
export const MOVE_FLAGS=['contact','protect','sound','bullet','pulse','punch','bite','slicing','wind','dance','powder','bypasssub','snatch','charge','recharge'];
const STATS=['atk','def','spa','spd','spe','accuracy','evasion'];
export const CANDIDATE_FEATURES=[...MOVE_TYPES.map(x=>'type:'+x),...MOVE_CATEGORIES.map(x=>'category:'+x),...MOVE_TARGETS.map(x=>'target:'+x),...MOVE_FLAGS.map(x=>'flag:'+x),
  'basePower','dynamicPower','accuracy','alwaysHits','priority','spread','stalling','damage','drain','recoil','healing','selfSwitch','forceSwitch','statusEffect','flinchChance','secondaryChance','sideCondition','fieldCondition',
  ...STATS.map(x=>'boost:'+x),...STATS.map(x=>'selfBoost:'+x)];
export function candidateFeatures(move){
  if(!move?.exists)throw Error('Unknown candidate move metadata');
  const secondary=move.secondary??move.secondaries?.[0],secondaryChance=(secondary?.chance??0)/100;
  const signedBoost=stat=>(move.boosts?.[stat]??(secondary?.boosts?.[stat]??0)*secondaryChance)/6;
  const out=[...MOVE_TYPES.map(x=>+(move.type===x)),...MOVE_CATEGORIES.map(x=>+(move.category===x)),...MOVE_TARGETS.map(x=>+(move.target===x)),...MOVE_FLAGS.map(x=>+!!move.flags?.[x]),
    Math.min(250,move.basePower||0)/250,+!!(move.basePowerCallback||move.damageCallback||move.damage),move.accuracy===true?1:Math.max(0,Math.min(100,move.accuracy||0))/100,+(move.accuracy===true),Math.max(-7,Math.min(7,move.priority||0))/7,
    +['allAdjacent','allAdjacentFoes','all'].includes(move.target),+!!move.stallingMove,+(move.category!=='Status'),move.drain?move.drain[0]/move.drain[1]:0,move.recoil?move.recoil[0]/move.recoil[1]:0,move.heal?move.heal[0]/move.heal[1]:0,+!!move.selfSwitch,+!!move.forceSwitch,
    +!!(move.status||secondary?.status),secondary?.volatileStatus==='flinch'?secondaryChance:0,secondaryChance,+!!move.sideCondition,+!!(move.weather||move.terrain||move.pseudoWeather),...STATS.map(signedBoost),...STATS.map(x=>(move.self?.boosts?.[x]||0)/6)];
  if(out.length!==CANDIDATE_FEATURES.length||!out.every(Number.isFinite))throw Error('Invalid candidate features');return out;
}
export function encodeCandidateSets(ids,dex){
  const unique=ids.map(slot=>[...new Set(slot.map(toID))].filter(id=>dex.moves.get(id).exists).sort());
  const count=Math.max(1,...unique.map(s=>s.length));
  return {ids:unique,features:unique.map(s=>Array.from({length:count},(_,i)=>i<s.length?candidateFeatures(dex.moves.get(s[i])):Array(CANDIDATE_FEATURES.length).fill(0))),mask:unique.map(s=>Array.from({length:count},(_,i)=>i<s.length))};
}
export function replayCandidates(observation,side,dex){
  // Read only the frozen observation. Current labels/resolutionObservation,
  // subsequent rows, winner and private requests are not inputs to this API.
  const team=observation.publicTeams[side];
  return encodeCandidateSets([0,1].map(k=>team.roster[team.active?.[k]]?.movesRevealed||[]),dex);
}
export function legalCandidates(legal,dex){
  return encodeCandidateSets([0,1].map(k=>legal.flatMap(j=>j.actions[k]?.type==='move'?[j.actions[k].move.id||j.actions[k].move.move]:[])),dex);
}
