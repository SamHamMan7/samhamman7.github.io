// Node-only experimental adapter. Candidate commands come exclusively from the
// own request; neither an opposing request nor a Battle object is an input.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import * as ort from 'onnxruntime-node';
import {createChampionsPublic,observeChampionsPublic,toID} from './champions-public.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
import {chooseChampionsLookahead} from './champions-lookahead.mjs';
import {chooseChampionsPreview} from './champions-preview.mjs';
import {encodeChampionsObservation,SCHEMA,FORMAT,TOKENS,CAT,NUM} from './champions-neural-observation.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
export function createNeuralTracker(side,dex,Teams){return {state:createChampionsPublic(side,dex,Teams),history:[],preview:{p1:[],p2:[]}};}
export function observeNeuralTracker(tracker,chunk){
  for(const line of chunk.split('\n')){
    const [,kind,...args]=line.split('|');if(!kind)continue;
    if(kind==='request'){const r=JSON.parse(args.join('|'));if(r?.side?.id!==tracker.state.side)throw Error('Champions neural firewall: opposing request');continue;}
    if(kind==='split')throw Error('Champions neural firewall: split channel');
    if(kind==='poke'&&tracker.preview[args[0]])tracker.preview[args[0]].push(args[1].split(',')[0]);
    const match=args[0]?.match(/^(p[12])([ab]):/),m=match&&tracker.state.active[match[1]][match[2]==='a'?0:1],previousMoves=m?[...m.moves]:[];
    observeChampionsPublic(tracker.state,line);
    if(kind==='swap'&&match&&/^[01]$/.test(args[1])){const active=tracker.state.active[match[1]],i=match[2]==='a'?0:1,j=Number(args[1]);[active[i],active[j]]=[active[j],active[i]];}
    if(['turn','switch','drag','replace','move','cant','faint','detailschange','upkeep','swap'].includes(kind)||kind.startsWith('-')&&!['-message','-hint','-anim','-center'].includes(kind))tracker.history.push({type:kind,args});
    // Called moves are not evidence that this Pokemon knows the resulting move.
    if(kind==='move'&&m&&args.slice(3).some(a=>a.startsWith('[from]')))m.moves=previousMoves;
  }
}
export function neuralSnapshot(tracker){
  const s=tracker.state,publicTeams={};
  for(const side of ['p1','p2'])publicTeams[side]={previewSpecies:tracker.preview[side],roster:s.roster[side].map(m=>({
    ident:m.ident,species:m.species,status:m.status,boosts:m.boosts,volatiles:m.volatiles,acted:m.acted,lastMove:m.lastMove,
    switchTurn:m.switchTurn,protectStreak:m.protectStreak,revealed:!!m.revealed,hp:m.revealed?m.hp:null,
    movesRevealed:m.moves||[],movesComplete:!!m.sheet,item:m.item??null,ability:m.ability??null,ots:!!m.sheet})),
    active:s.active[side].map(m=>m?s.roster[side].indexOf(m):-1),conditions:[...s.sideConditions[side]],megaUsed:s.megaUsed[side]};
  return {schema:'champions-public-spectator-v1',format:FORMAT,turn:s.turn,publicTeams,field:{...s.field},publicHistory:structuredClone(tracker.history)};
}
function logSoftmax(a){const m=Math.max(...a),z=m+Math.log(a.reduce((s,v)=>s+Math.exp(v-m),0));return a.map(v=>v-z);}
function marginal(logs,size,a,b){const values=[];for(let i=0;i<size;i++)for(let j=0;j<size;j++)if((a==null||a===i)&&(b==null||b===j))values.push(logs[i*size+j]);const m=Math.max(...values);return m+Math.log(values.reduce((s,v)=>s+Math.exp(v-m),0));}
export function rankSemanticActions(legal,output,contract,request,{targetScoring='mean',moveOnly=false}={}){
  if(!['mean','mass','none'].includes(targetScoring))throw Error('Unknown target scoring');
  const type=logSoftmax(Array.from(output.types)),target=logSoftmax(Array.from(output.targets)),mega=logSoftmax(Array.from(output.mega));
  const move=[0,1].map(k=>logSoftmax(Array.from(output.moves).slice(k*contract.moves.length,(k+1)*contract.moves.length)));
  const sw=[0,1].map(k=>logSoftmax(Array.from(output.switches).slice(k*contract.species.length,(k+1)*contract.species.length)));
  const ranked=legal.map(joint=>{
    const types=joint.actions.map(a=>contract.types.indexOf(a.type));
    const components={type:type[types[0]*3+types[1]],move:[0,0],switch:[0,0],target:0,mega:0};
    const targets=[null,null];let megaChoice=0;
    for(const [k,a] of joint.actions.entries()){
      if(a.type==='move'){const id=toID(a.move.id||a.move.move),index=contract.moves.indexOf(id);if(index<1)throw Error('Move outside model vocabulary');components.move[k]=move[k][index];targets[k]=a.target<0?-a.target:a.target>0?a.target+2:0;if(a.mega)megaChoice=k+1;}
      if(a.type==='switch'){const id=toID(request.side.pokemon[a.choice-1].details.split(',')[0]),index=contract.species.indexOf(id);if(index<1)throw Error('Switch outside model vocabulary');components.switch[k]=sw[k][index];}
    }
    const compatibleTargetEncodings=5**targets.filter(t=>t===null).length;
    const targetLogMass=marginal(target,5,...targets);
    // Unused switch/pass targets have no selected encoding. Average compatible
    // density so uniform logits give every command the same target factor,
    // independent of whether 1, 5 or 25 encodings are compatible. Two-move
    // rankings are unchanged. 'mass' is retained only for diagnostic comparisons.
    components.target=targetScoring==='none'?0:targetLogMass-(targetScoring==='mean'?Math.log(compatibleTargetEncodings):0);
    components.mega=mega[megaChoice];
    const score=components.move.reduce((s,v)=>s+v,0)+components.switch.reduce((s,v)=>s+v,0)+(moveOnly?0:components.type+components.target+components.mega);
    if(!Number.isFinite(score))throw Error('Non-finite neural candidate score');
    return {...joint,score,components,targetLogMass,compatibleTargetEncodings};
  }).sort((a,b)=>b.score-a.score);
  const probabilities=logSoftmax(ranked.map(j=>j.score));return ranked.map((j,i)=>({...j,probability:Math.exp(probabilities[i])}));
}
export function neuralFeeds(encoded){return {
  categorical:new ort.Tensor('int64',BigInt64Array.from(encoded.categorical.flat(),BigInt),[1,TOKENS,CAT.length]),
  numeric:new ort.Tensor('float32',Float32Array.from(encoded.numeric.flat()),[1,TOKENS,NUM.length]),
  known:new ort.Tensor('bool',Uint8Array.from(encoded.known.flat(),Number),[1,TOKENS,NUM.length]),
  token_mask:new ort.Tensor('bool',Uint8Array.from(encoded.tokenMask,Number),[1,TOKENS]),
};}
export async function loadChampionsNeural(directory){
  const manifest=JSON.parse(await fs.readFile(path.join(directory,'manifest.json'),'utf8')),contractBytes=await fs.readFile(path.join(directory,'contract.json')),modelBytes=await fs.readFile(path.join(directory,'model.onnx'));
  const contract=JSON.parse(contractBytes);
  if(manifest.schema!=='champions-neural-model-v1'||manifest.observationSchema!==SCHEMA||manifest.format!==FORMAT||contract.schema!==SCHEMA||contract.format!==FORMAT||manifest.contractSha256!==sha(contractBytes)||manifest.modelSha256!==sha(modelBytes))throw Error('Champions model/contract/fingerprint mismatch');
  if(contract.tokens!==TOKENS||JSON.stringify(contract.categorical)!==JSON.stringify(CAT)||JSON.stringify(contract.numeric)!==JSON.stringify(NUM))throw Error('Champions feature layout mismatch');
  const session=await ort.InferenceSession.create(modelBytes,{executionProviders:['cpu'],intraOpNumThreads:1,interOpNumThreads:1});
  return {manifest,contract,session,async rank(tracker,request){
    if(request.side?.id!==tracker.state.side)throw Error('Champions neural firewall: opposing request');
    const legal=enumerateChampionsActions(request);if(request.teamPreview||!legal.length)throw Error('No neural turn candidates');
    const encoded=encodeChampionsObservation(neuralSnapshot(tracker),tracker.state.side,{dex:tracker.state.dex,request,phase:request.forceSwitch?'replacement':'turn'});
    const result=await session.run(neuralFeeds(encoded)),output=Object.fromEntries(Object.entries(result).map(([k,v])=>[k,v.data]));
    return {ranked:rankSemanticActions(legal,output,contract,request),value:Number(output.value[0]),encoded};
  }};
}
export async function chooseChampionsNeural(model,tracker,request,{rng=Math.random,window=.5,temperature=.2,strict=false}={}){
  if(request.teamPreview)return {chosen:chooseChampionsPreview(request,tracker.state.dex,{random:rng}),source:'heuristic-preview'};
  const legal=enumerateChampionsActions(request);
  if(!legal.length)throw Error('No legal Champions action');
  try{
    const result=await model.rank(tracker,request),pool=result.ranked.filter(j=>j.score>=result.ranked[0].score-window).slice(0,8);
    const weights=pool.map(j=>Math.exp((j.score-pool[0].score)/Math.max(.001,temperature)));let draw=rng()*weights.reduce((a,b)=>a+b,0),chosen=pool.at(-1);
    for(let i=0;i<pool.length;i++){draw-=weights[i];if(draw<=0){chosen=pool[i];break;}}
    if(!legal.some(j=>j.command===chosen.command))throw Error('Neural command failed legal membership');
    return {...result,chosen,source:'neural'};
  }catch(error){if(strict)throw error;return {...chooseChampionsLookahead(legal,tracker.state,tracker.state.dex,{request,random:rng}),source:'tactical-fallback',neuralError:error.message};}
}
