// Experimental, versioned repair. V3 encodings/checkpoints remain untouched.
import {ACTOR_FEATURES,encodeActorState,encodeActorActions} from './champions-actor-features.mjs';
export const SIGNAL_FEATURES=Object.freeze({...ACTOR_FEATURES,schema:'champions-signal-features-v4',knownMoves:4,evidence:4});
export const SIGNAL_INPUTS=['token_ids','token_num','field','action_links','action_num','pair_num','known_moves','known_mask','evidence'];
export function encodeSignalState(p,dex,publicEvidence=p.publicEvidence||[]){
 const state=encodeActorState(p,dex);
 const conditions=(side,id)=>Number(p.conditions[side].includes(id));
 state.field=[Math.min(p.turn,100)/100,Number(!!p.field.trickroom),['','sunnyday','raindance','sandstorm','snow','desolateland','primordialsea'].indexOf(p.field.weather||'')/6,['','electricterrain','grassyterrain','mistyterrain','psychicterrain'].indexOf(p.field.terrain||'')/4,
  ...['tailwind','reflect','lightscreen','safeguard','wideguard','auroraveil'].flatMap(id=>[conditions(0,id),conditions(1,id)])];
 state.known_moves=[];state.known_mask=[];state.evidence=[];
 for(let side=0;side<2;side++)for(let i=0;i<6;i++){
  const m=p.teams[side][i],moves=m?[...new Set(m.moves)].sort().slice(0,4):[];
  const numbers=Array.from({length:4},()=>Array(64).fill(0)),mask=Array(4).fill(0);
  for(const [index,id]of moves.entries()){
   // Only publicPosition is accepted; moves originate in the own request or
   // public disclosures. Do not inspect a live opposing set or stats object.
   if(!dex.moves.get(id).exists)continue;
   const copy={...p,active:p.active.map((a,s)=>s===side?[i,-1]:a)};
   numbers[index]=encodeActorActions(copy,[{actions:[{slot:0,type:'move',move:{id},target:0}]}],side,dex).action_num[0][0];mask[index]=1;
  }
  state.known_moves.push(numbers);state.known_mask.push(mask);
  if(m)state.token_num[side*6+i][44]=Number(m.volatiles?.includes('protect'))+Math.min(10,m.protectStreak||0)/11;
  const observations=side===1&&m?publicEvidence.filter(e=>e.species===m.species):[],speed=observations.filter(e=>e.kind==='speed'&&e.comparable),damage=observations.filter(e=>e.kind==='damage');
  const entropy=e=>{const xs=Object.values(e.likelihoods||{}).filter(x=>x>0),sum=xs.reduce((s,x)=>s+x,0);return xs.length>1&&sum?xs.reduce((s,x)=>s-x/sum*Math.log(x/sum),0)/Math.log(xs.length):0;};
  state.evidence.push([Math.min(4,speed.length)/4,speed.reduce((s,e)=>s+(e.faster?1:-1),0)/Math.max(1,speed.length),Math.min(4,damage.length)/4,damage.reduce((s,e)=>s+entropy(e),0)/Math.max(1,damage.length)]);
 }
 return state;
}
export {encodeActorActions as encodeSignalActions};
