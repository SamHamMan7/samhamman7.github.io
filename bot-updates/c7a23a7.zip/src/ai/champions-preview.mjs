﻿const id = value => String(value || '')
  .toLowerCase()
  .replace(/[^a-z0-9]+/g, '');

const FAKE_OUT = new Set(['fakeout']);
const SPEED_CONTROL = new Set([
  'tailwind',
  'trickroom',
  'icywind',
  'electroweb',
]);

const SETUP = new Set([
  'swordsdance',
  'nastyplot',
  'calmmind',
  'dragondance',
  'bulkup',
  'quiverdance',
]);

function permutations(values, length) {
  const out = [];

  function rec(prefix, remaining) {
    if (prefix.length === length) {
      out.push(prefix);
      return;
    }

    for (let i = 0; i < remaining.length; i++) {
      rec(
        [...prefix, remaining[i]],
        [
          ...remaining.slice(0, i),
          ...remaining.slice(i + 1),
        ]
      );
    }
  }

  rec([], values);
  return out;
}

function monInfo(pokemon, dex) {
  const speciesName = String(
    pokemon.details ||
    pokemon.speciesForme ||
    ''
  ).split(',')[0].trim();

  const species = dex.species.get(speciesName);

  const moves = (pokemon.moves || []).map(move => {
    const data = dex.moves.get(move);
    return {
      id: id(move),
      basePower: data.basePower || 0,
      category: data.category,
      priority: data.priority || 0,
      type: data.type,
    };
  });

  const item = id(pokemon.item);

  const bst = Object.values(
    species.baseStats || {}
  ).reduce((a, b) => a + b, 0);

  const damaging =
    moves.filter(m => m.basePower > 0).length;

  const maxPower = Math.max(
    0,
    ...moves.map(m => m.basePower)
  );

  return {
    species: species.name,
    types: species.types || [],
    speed: species.baseStats?.spe || 0,
    bst,
    moves,
    moveIds: new Set(moves.map(m => m.id)),
    damaging,
    maxPower,
    megaStone:
      !!dex.items.get(item).megaStone,
  };
}

function hasAny(mon, set) {
  for (const move of mon.moveIds) {
    if (set.has(move)) return true;
  }
  return false;
}

function leadMonScore(mon) {
  let score = 0;

  if (hasAny(mon, FAKE_OUT)) score += 9;

  if (mon.moveIds.has('tailwind')) score += 7;
  if (mon.moveIds.has('trickroom')) score += 6;
  if (mon.moveIds.has('icywind')) score += 4;
  if (mon.moveIds.has('electroweb')) score += 4;

  if (mon.moveIds.has('helpinghand')) score += 2;
  if (mon.moveIds.has('protect')) score += 1;

  score += Math.min(4, mon.maxPower / 35);

  if (mon.megaStone) score += 1.5;

  return score;
}

function pairScore(a, b) {
  let score =
    leadMonScore(a) +
    leadMonScore(b);

  const aFake = hasAny(a, FAKE_OUT);
  const bFake = hasAny(b, FAKE_OUT);

  const aSpeed = hasAny(a, SPEED_CONTROL);
  const bSpeed = hasAny(b, SPEED_CONTROL);

  if (
    (aFake && bSpeed) ||
    (bFake && aSpeed)
  ) {
    score += 7;
  }

  if (
    a.moveIds.has('fakeout') &&
    hasAny(b, SETUP)
  ) {
    score += 3;
  }

  if (
    b.moveIds.has('fakeout') &&
    hasAny(a, SETUP)
  ) {
    score += 3;
  }

  if (
    a.moveIds.has('trickroom') &&
    b.speed <= 70
  ) {
    score += 3;
  }

  if (
    b.moveIds.has('trickroom') &&
    a.speed <= 70
  ) {
    score += 3;
  }

  if (
    a.moveIds.has('tailwind') &&
    b.damaging >= 2
  ) {
    score += 2;
  }

  if (
    b.moveIds.has('tailwind') &&
    a.damaging >= 2
  ) {
    score += 2;
  }

  // Two passive leads tend to give away too much momentum.
  if (
    a.damaging <= 1 &&
    b.damaging <= 1
  ) {
    score -= 7;
  }

  // Only one Pokemon can Mega Evolve per battle.
  if (a.megaStone && b.megaStone) {
    score -= 4;
  }

  return score;
}

function scorePreview(order, mons) {
  const picked = order.map(i => mons[i]);

  const leadA = picked[0];
  const leadB = picked[1];

  let score = pairScore(leadA, leadB);

  // Slight preference for generally stronger brought Pokemon.
  for (const mon of picked) {
    score += Math.max(
      0,
      (mon.bst - 450) / 75
    );
  }

  const megaCount =
    picked.filter(mon => mon.megaStone).length;

  if (megaCount === 1) score += 3;
  if (megaCount >= 2) score += 0.5;

  const types = new Set(
    picked.flatMap(mon => mon.types)
  );

  score += types.size * 0.35;

  // Bench should contain actual damage output.
  score +=
    Math.min(2, picked[2].damaging) +
    Math.min(2, picked[3].damaging);

  return score;
}

function sampleNearBest(
  scored,
  {
    window = 8,
    temperature = 2.5,
    maxCandidates = 24,
    random = Math.random,
  } = {}
) {
  scored.sort((a, b) => b.score - a.score);

  const best = scored[0].score;

  const candidates = scored
    .filter(x => x.score >= best - window)
    .slice(0, maxCandidates);

  const weights = candidates.map(x =>
    Math.exp((x.score - best) / temperature)
  );

  let draw =
    random() *
    weights.reduce((a, b) => a + b, 0);

  for (let i = 0; i < candidates.length; i++) {
    draw -= weights[i];

    if (draw <= 0) {
      return {
        ...candidates[i],
        candidates: candidates.length,
        bestScore: best,
      };
    }
  }

  return {
    ...candidates[0],
    candidates: candidates.length,
    bestScore: best,
  };
}

// Shared proposal scores only; the existing chooser retains its exact sampling.
export function rankChampionsPreview(request, dex) {
  const pokemon =
    request?.side?.pokemon || [];

  if (pokemon.length < 4) {
    throw new Error(
      'Champions preview has fewer than four Pokemon'
    );
  }

  const mons = pokemon.map(p =>
    monInfo(p, dex)
  );

  const orders = permutations(
    mons.map((_, i) => i),
    4
  );

  const scored = orders.map(order => ({
    order,
    score: scorePreview(order, mons),
  }));

  return scored;
}

export function chooseChampionsPreview(request, dex, options = {}) {
  const mons = (request?.side?.pokemon || []).map(p => monInfo(p, dex));
  const chosen = sampleNearBest(rankChampionsPreview(request, dex), options);

  // Showdown team-preview indices are 1-based.
  const digits = chosen.order
    .map(i => i + 1)
    .join('');

  return {
    command: `team ${digits}`,
    order: chosen.order,
    score: chosen.score,
    bestScore: chosen.bestScore,
    candidates: chosen.candidates,
    names: chosen.order.map(
      i => mons[i].species
    ),
  };
}
