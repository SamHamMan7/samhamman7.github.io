import {chooseSimultaneousResourceAction} from './singles-response-search.mjs';
import {randbatsSetBeliefs} from './randbats-set-beliefs.mjs';
import {chooseAction as stable} from './singles-stable.js';

// Explicit research entry; the normal chooser never imports this module.
export function choosePublicSetResourceAction(view, options = {}) {
  return chooseSimultaneousResourceAction(view, {...options, hypothesisFactory: randbatsSetBeliefs});
}

/** Conservative experiment: stable ordinary actions, explicit review of a
 * proposed Tera only. Both that exact action and its no-Tera counterpart must
 * receive comparable lookahead; saving the resource must not increase KO risk. */
export function choosePublicSetTeraReview(view, options = {}) {
  const base = stable(view, options);
  if (view.format !== 'gen9randombattle' || !base.choice?.includes('terastallize')) return base;
  const candidate = choosePublicSetResourceAction(view, {...options, depth: 2, requiredChoice: base.choice});
  if (candidate.diagnostics?.searchError) return {...base, diagnostics: {...base.diagnostics, searchError: candidate.diagnostics.searchError}};
  const proposed = candidate.scores.find(s => s.choice === candidate.choice), original = candidate.scores.find(s => s.choice === base.choice);
  const accepted = !!candidate.diagnostics?.completeLookahead && original && proposed && !candidate.choice.includes('terastallize') &&
    proposed.score >= original.score && proposed.ownKO <= original.ownKO + 1e-9;
  const review = {accepted: !!accepted, baselineChoice: base.choice, alternative: candidate.choice, complete: candidate.diagnostics?.completeLookahead,
    margin: original && proposed ? proposed.score - original.score : null, baselineKO: original?.ownKO, alternativeKO: proposed?.ownKO};
  const result = accepted ? candidate : base;
  return {...result, diagnostics: {...result.diagnostics, policy: 'randbats-public-set-tera-review-v1', resourceReview: review,
    reviewMs: candidate.diagnostics?.ms, publicSetWorlds: candidate.diagnostics?.publicSetWorlds}};
}
