// Public-position helpers for offline supervision and isolated arena experiments.
// No new checkpoint is promoted through the app difficulty dispatcher here.
import {createBeliefWorlds} from './champions-belief-worlds.mjs';
import {createChampionsDamageDecision} from './champions-damage.mjs';
import {createSearchOracle} from './champions-search-oracle.mjs';
import {teacherActionIdentity,teacherOutcomeValue} from './champions-search-teacher.mjs';
import {solveMatrixGame} from './champions-matrix-solver.mjs';
import {sanitizePublicEffects} from './champions-public-effects.mjs';

export function signalPublicPosition(p){
  // Whitelist before cloning/hashing: opposing stats/set/spreads are never read,
  // including when a caller accidentally attaches a private simulator object.
  return {turn:p.turn,active:p.active.map(a=>[...a]),conditions:p.conditions.map(a=>[...a]),field:{...p.field},megaUsed:[...p.megaUsed],...(p.publicEffects?{publicEffects:sanitizePublicEffects(p.publicEffects,p.conditions)}:{}),teams:p.teams.map((team,side)=>team.map(m=>({
    ...Object.fromEntries(['ident','species','types','hp','status','boosts','volatiles','moves','revealed','acted','lastMove','protectStreak','perishTurns','choiceLock'].filter(k=>m[k]!==undefined).map(k=>[k,structuredClone(m[k])])),
    knowledge:{...m.knowledge},nature:side===0||m.knowledge?.nature?m.nature:'Serious',item:side===0||m.knowledge?.item?m.item:'',ability:side===0||m.knowledge?.ability?m.ability:'',
    ...(side===0?{stats:{...m.stats},...(m.movePP?{movePP:{...m.movePP}}:{})}:{})
  })))};
}
export function signalBuildWorlds(p,dex,mode='bo3',count=4){
  const clean=signalPublicPosition(p),beliefs=createBeliefWorlds(clean,dex,{mode});
  const unique=[...new Map(beliefs.worlds.map(w=>[JSON.stringify(w.position.teams[1].map(m=>[m.hp,m.stats,m.nature,m.item,m.ability,m.moves])),w])).values()];
  // Stable public archetypes; do not resample from a game/client/seat seed.
  return unique.slice(0,count);
}
export function evaluateSignalMatrix(position,rows,columns,dex,{mode='bo3',seeds=[17,101,409,1237],rolls=[85,100],nativeChance=false,worldCount=4}={}){
  const started=performance.now(),p=signalPublicPosition(position),worlds=signalBuildWorlds(p,dex,mode,worldCount),decision=createChampionsDamageDecision(p),oracle=createSearchOracle(p,dex,{nodes:1000000,timeMs:1e12});
  try{
    const legal=worlds.map(w=>new Map(oracle.legalActions(w.position,1).map(a=>[teacherActionIdentity(a),a])));
    const unavailableByColumn=columns.map(b=>legal.filter(xs=>!xs.has(teacherActionIdentity(b))).length);
    if(unavailableByColumn.some(n=>n===worlds.length))throw Error('Public candidate not legal in any signal belief world');
    const matrix=rows.map(a=>columns.map(b=>{
      const means=worlds.flatMap((w,i)=>{
        const member=legal[i].get(teacherActionIdentity(b));
        // Condition on the public hypothesis allowing this response. Never
        // replace an impossible switch with a different attacking command.
        if(!member)return [];
        const values=[];for(const [seedIndex,seed]of seeds.entries())for(const roll of rolls)values.push(teacherOutcomeValue(dex,decision.exchange(w.position,a,member,{seed,roll,nativeChance,tie:seedIndex%2})));
        return [values.reduce((s,x)=>s+x,0)/values.length];
      });
      // Average chance first. The risk term concerns uncertain builds, rather
      // than pessimistically treating one sampled critical hit as a build.
      return .7*means.reduce((s,x)=>s+x,0)/means.length+.3*Math.min(...means);
    }));
    return {matrix,diagnostics:{...decision.metrics,ms:performance.now()-started,worlds:worlds.map(w=>w.id),seeds,rolls,nativeChance,tiePolicy:'alternating seed index; native RNG when nativeChance',unavailableByColumn,scope:'Fixed public builds and common RNG samples; risk across compatible build means, conditioning on hypothetical response legality. One-exchange evaluator proxy, not exact chance expectation or eventual win probability.'}};
  }finally{decision.dispose();oracle.dispose();}
}
export function stableSignalTargets(position,rows,columns,A,dex,options={}){
  const {matrix,diagnostics}=evaluateSignalMatrix(position,rows,columns,dex,options),solved=solveMatrixGame(matrix,{iterations:3000,tolerance:.005}),n=rows.length;
  if(A.length!==n+columns.length)throw Error('Signal target/candidate alignment');
  for(const mass of [A.slice(0,n),A.slice(n)])if(mass.some(x=>!Number.isFinite(x)||x<0)||Math.abs(mass.reduce((s,x)=>s+x,0)-1)>1e-8)throw Error('Signal target mass');
  const value=policy=>matrix.reduce((s,row,i)=>s+policy[i]*row.reduce((v,x,j)=>v+x*solved.columnStrategy[j],0),0),gain=value(solved.rowStrategy)-value(A),weight=Math.max(0,Math.min(.75,gain/.15)),B=[...solved.rowStrategy,...solved.columnStrategy];
  return {policies:{A:[...A],B,C:A.map((x,i)=>(1-weight)*x+weight*B[i])},matrix,diagnostics:{...diagnostics,gain,mixtureWeight:weight,residual:solved.residual,deepened:0}};
}
