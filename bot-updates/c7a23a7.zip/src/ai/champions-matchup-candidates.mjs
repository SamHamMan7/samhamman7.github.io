// Experimental public move+target candidates. No private requests/sets/stats.
// Damage is the existing cheap public estimate, NOT an authoritative KO promise.
import {combatant,toID} from './champions-public.mjs';
import {candidateFeatures,CANDIDATE_FEATURES} from './champions-candidates.mjs';
import {estimateChampionsDamage} from './champions-search.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
import {neuralSnapshot} from './champions-neural.mjs';
import {createPublicDamageBattle} from './champions-damage.mjs';
export const MATCHUP_SCHEMA='champions-public-move-target-v3';
const targets=[0,-1,-2,1,2];
const pairFields=['present','hp','hpKnown','speedRatio','approxDamageLow','approxDamageMean','approxDamageHigh','approxKO','approxIncoming'];
export const MATCHUP_FEATURES=[...CANDIDATE_FEATURES,...targets.map(t=>'target:'+t),'actorHP','actorHPKnown','actorActed','actorProtectStreak','trickroom','tailwindOwn','tailwindOpp',...['foeA','foeB','ally'].flatMap(t=>pairFields.map(k=>t+':'+k))];
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export function matchupSnapshot(tracker){
 const observation=neuralSnapshot(tracker);
 const publicHP=hp=>hp===1?1:Math.min(.99,Math.ceil(hp*100-1e-10)/100);
 for(const side of ['p1','p2'])observation.publicTeams[side].roster.forEach((m,i)=>{const source=tracker.state.roster[side][i];m.nature=source.sheet?source.nature??null:null;if(m.hp!==null)m.hp=publicHP(m.hp);});
 // Own player streams disclose exact fractions; replay spectators see rounded
 // percentages. Normalize BOTH board HP and event arguments, otherwise damage
 // history also hashes a different categorical effect for the identical state.
 for(const e of observation.publicHistory)if(['-damage','-heal','-sethp','switch','drag','replace'].includes(e.type))e.args=e.args.map(a=>a.replace(/^(\d+)\/(\d+)(?= |$)/,(_,hp,max)=>`${Number(hp)===Number(max)?100:Math.min(99,Math.ceil(Number(hp)/Number(max)*100-1e-10))}/100`));
 return observation;
}
export function publicMatchupPosition(observation,side,dex){
 if(observation.schema!=='champions-public-spectator-v1'||observation.format!=='gen9championsvgc2026regmc'||!['p1','p2'].includes(side))throw Error('Invalid matchup observation');
 const order=[side,side==='p1'?'p2':'p1'];
 const teams=order.map(s=>observation.publicTeams[s].roster.map(m=>{
  // Do not forward arbitrary fields (including stats/evs/ivs/private/future).
  const form=dex.species.get(m.species),ability=m.ability??(form.isMega?form.abilities['0']:'');
  const publicMon={species:m.species,ident:m.ident,hp:m.hp??1,status:m.status,boosts:m.boosts,volatiles:m.volatiles,acted:m.acted,lastMove:m.lastMove,protectStreak:m.protectStreak,revealed:m.revealed,moves:m.movesRevealed||[],item:m.item??'',ability,nature:m.ots?m.nature:undefined};
  return {...combatant(dex,publicMon),hpKnown:m.hp!==null&&m.hp!==undefined};
 }));
 return {turn:observation.turn,teams,active:order.map(s=>[...(observation.publicTeams[s].active||[-1,-1])]),conditions:order.map(s=>[...(observation.publicTeams[s].conditions||[])]),field:{weather:observation.field?.weather||'',terrain:observation.field?.terrain||'',trickroom:!!observation.field?.trickroom},megaUsed:order.map(s=>!!observation.publicTeams[s].megaUsed)};
}
const mon=(p,s,k)=>p.teams[s][p.active[s][k]];
function speed(p,s,m){const n=m.boosts.spe||0,b=n>=0?(2+n)/2:2/(2-n);return m.stats.spe*b*(p.conditions[s].includes('tailwind')?2:1)*(m.status==='par'?.5:1)*(toID(m.item)==='choicescarf'?1.5:1);}
function resolvedTargets(b,slot,id,location){
 const actor=b.p1.active[slot];let move=b.dex.getActiveMove(id),target=b.getTarget(actor,move,location);
 b.setActiveMove(move,actor,target);b.singleEvent('ModifyType',move,null,actor,target,move,move);b.singleEvent('ModifyMove',move,null,actor,target,move,move);
 move=b.runEvent('ModifyType',actor,target,move,move);if(move)move=b.runEvent('ModifyMove',actor,target,move,move);
 // A known public restriction may cancel the move (e.g. Throat Chop blocks
 // Hyper Voice). Keep the permissive candidate but expose zero affected damage.
 if(move===false||move===null)return {affected:new Set(),spread:false};
 if(!move?.flags)throw Error('Unexpected native public move result for '+id);
 b.setActiveMove(move,actor,target);
 // Continuous OTS abilities (Storm Drain, Lightning Rod, etc.) and public move
 // target changes (Expanding Force, Curse) use the pinned native engine.
 const affected=new Set(actor.getMoveTargets(move,target).targets.filter(m=>m?.hp>0).map(m=>(m.side.n===1?1:-1)*(m.side.active.indexOf(m)+1)));
 return {affected,spread:['allAdjacent','allAdjacentFoes','all'].includes(move.target)&&affected.size>1};
}
function descriptor(p,slot,move,target,dex,battle){
 const actor=mon(p,0,slot);if(!actor)throw Error('Candidate has no public actor');
 const {affected,spread}=resolvedTargets(battle,slot,move.id,target);
 const fields=[...targets.map(t=>+(target===t)),actor.hp,+actor.hpKnown,+actor.acted,clamp(actor.protectStreak/5),+p.field.trickroom,+p.conditions[0].includes('tailwind'),+p.conditions[1].includes('tailwind')];
 for(const [s,k,t]of [[1,0,1],[1,1,2],[0,1-slot,-(2-slot)]]){
  const other=mon(p,s,k);if(!other||other.hp<=0){fields.push(...Array(pairFields.length).fill(0));continue;}
  const outgoing=affected.has(t)?[.85,.925,1].map(roll=>estimateChampionsDamage(dex,p,0,actor,other,move,{spread,roll})):Array.from({length:3},()=>({fraction:0,ko:0}));
  const incoming=s===1?Math.max(0,...other.moves.map(id=>estimateChampionsDamage(dex,p,1,other,actor,dex.moves.get(id)).fraction)):0;
  const a=speed(p,0,actor),b=speed(p,s,other);
  fields.push(1,other.hp,+other.hpKnown,(a-b)/Math.max(1,a+b)*(p.field.trickroom?-1:1),...outgoing.map(x=>clamp(x.fraction,0,2)/2),clamp(outgoing[1].ko),clamp(incoming,0,2)/2);
 }
 return [...candidateFeatures(move),...fields];
}
export const matchupID=(move,target)=>toID(move)+':'+target;
export function encodeMatchupCandidates(observation,side,slots,dex){
 const p=publicMatchupPosition(observation,side,dex),unique=slots.map(slot=>[...new Map(slot.filter(a=>dex.moves.get(a.move).exists).map(a=>[matchupID(a.move,a.target),{move:toID(a.move),target:a.target}])).entries()].sort(([a],[b])=>a.localeCompare(b)));
 const count=Math.max(1,...unique.map(s=>s.length));
 const battle=createPublicDamageBattle(p);let result;try{result={schema:MATCHUP_SCHEMA,ids:unique.map(s=>s.map(([id])=>id)),moves:unique.map(s=>s.map(([,a])=>a.move)),targets:unique.map(s=>s.map(([,a])=>a.target)),mask:unique.map(s=>Array.from({length:count},(_,i)=>i<s.length)),features:unique.map((s,k)=>Array.from({length:count},(_,i)=>i<s.length?descriptor(p,k,dex.moves.get(s[i][1].move),s[i][1].target,dex,battle):Array(MATCHUP_FEATURES.length).fill(0)))};}finally{battle.destroy();}
 if(result.features.flat(2).some(x=>!Number.isFinite(x))||result.features.some(s=>s.some(f=>f.length!==MATCHUP_FEATURES.length)))throw Error('Invalid public matchup features');return result;
}
export function legalMatchupCandidates(observation,side,legal,dex){return encodeMatchupCandidates(observation,side,[0,1].map(k=>legal.flatMap(j=>j.actions[k]?.type==='move'?[{move:j.actions[k].move.id||j.actions[k].move.move,target:j.actions[k].target||0}]:[])),dex);}
export function replayMatchupCandidates(observation,side,dex){
 // Only a permissive PUBLIC candidate set, not claimed exact PP/disable legality.
 const team=observation.publicTeams[side],battle=createPublicDamageBattle(publicMatchupPosition(observation,side,dex));
 try{
  // Native public sandbox supplies Curse's type-dependent request target and
  // other public request-target rules. Ignore PP/disabled flags: they are not
  // exact private replay information. The real live request remains authority.
  const request={side:{pokemon:[0,1].map(k=>({active:true,condition:team.roster[team.active[k]]?.hp===0?'0 fnt':'100/100'}))},active:[0,1].map(k=>{const actor=team.roster[team.active[k]],native=battle.p1.active[k]?.getMoves()||[];return actor?{trapped:true,moves:(actor.movesRevealed||[]).filter(id=>dex.moves.get(id).exists).map(id=>({id,target:native.find(m=>m.id===id)?.target||dex.moves.get(id).target,pp:1}))}:null;})};
  return legalMatchupCandidates(observation,side,enumerateChampionsActions(request),dex);
 }finally{battle.destroy();}
}
export function compatibleMatchupLabels(row,candidates){
 return [0,1].map(k=>{
  const action=row.labels.actions[k];if(!row.masks['knownActionSlot'+(k+1)]||action?.type!=='move')return candidates.mask[k].map(()=>false);
  const t=action.target,known=row.masks['knownTargetSlot'+(k+1)],target=known?(t.mode==='automatic'?0:(t.side===row.side?-1:1)*(t.slot+1)):null;
  return candidates.mask[k].map((valid,i)=>valid&&candidates.moves[k][i]===action.move&&(!known||candidates.targets[k][i]===target));
 });
}
export function assertMatchupLayout(contract){if(contract.candidateSchema!==MATCHUP_SCHEMA||!same(contract.candidateFeatures,MATCHUP_FEATURES))throw Error('Public matchup contract mismatch');}
