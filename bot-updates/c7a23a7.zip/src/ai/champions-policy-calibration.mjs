// Normalize conditional command probabilities inside each exact legal joint
// action family. Family mass comes only from the trained nine-way type head.
const logSumExp=xs=>{const m=Math.max(...xs);return m+Math.log(xs.reduce((s,x)=>s+Math.exp(x-m),0));};
export function calibrateCandidateFamilies(ranked){
  const groups=new Map();
  for(const j of ranked){
    const family=j.actions.map(a=>a.type).join(',');
    if(!groups.has(family))groups.set(family,[]);groups.get(family).push(j);
  }
  const familyZ=logSumExp([...groups.values()].map(g=>g[0].components.type));
  const out=[];
  for(const [family,group] of groups){
    const z=logSumExp(group.map(j=>j.score-j.components.type));
    for(const j of group){
      const components={...j.components,type:j.components.type-familyZ,conditionalNormalization:-z};
      const score=j.score-familyZ-z;
      out.push({...j,family,score,components,probability:Math.exp(score)});
    }
  }
  return out.sort((a,b)=>b.score-a.score);
}
