// Interrupted turns: own committed actions are known; enemy queues are never read.
import {supervisionWorlds,applyPublicReplacement,canonicalSupervisionKey,supervisionPublicPosition} from './champions-supervision.mjs';
import {createChampionsDamageDecision} from './champions-damage.mjs';
import {createSearchOracle} from './champions-search-oracle.mjs';
import {teacherActionIdentity,teacherBoardValue,teacherOpponentPool} from './champions-search-teacher.mjs';
import {scoreChampionsCandidates,shortlistChampionsCandidates} from './champions-search.mjs';
import {solveMatrixGame} from './champions-matrix-solver.mjs';
const canonical=xs=>[...new Map(xs.map(j=>[teacherActionIdentity(j),j])).values()].sort((a,b)=>teacherActionIdentity(a).localeCompare(teacherActionIdentity(b)));
const pass=slot=>({slot,type:'pass'}),identity=id=>String(id).replace(/^(p[12])[ab]:/,'$1:'),toID=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
export function isLivingReplacement(p,request){return !!request.forceSwitch?.some((f,slot)=>f&&p.teams[0][p.active[0][slot]]?.hp>0);}
export function pivotPublicContext(position,request,history,lastOwn){
 if(!isLivingReplacement(position,request))return null;
 if(!lastOwn||lastOwn.turn!==position.turn)throw Error('Interrupted turn requires the AI own previously committed choice');
 const marker=history.findLastIndex(h=>h.type==='turn'&&+h.args[0]===position.turn),events=history.slice(marker+1),side=request.side.id,foe=side==='p1'?'p2':'p1';
 const acted=position.teams.map(t=>t.map(m=>events.some(h=>['move','cant'].includes(h.type)&&identity(h.args[0])===m.ident)));
 const ownPending=lastOwn.joint.actions.filter(a=>a.type==='move'&&!request.forceSwitch[a.slot]&&!acted[0][position.active[0][a.slot]]).map(a=>({...a,move:{id:a.move.id},mega:!!a.mega&&!position.megaUsed[0]}));
 const protections=[];
 for(const h of events)if(h.type==='-singleturn'){
  const s=h.args[0]?.startsWith(side)?0:h.args[0]?.startsWith(foe)?1:null;if(s===null)continue;
  const index=position.teams[s].findIndex(m=>m.ident===identity(h.args[0]));if(index<0)continue;
  protections.push({side:s,index,id:toID(h.args[1].replace(/^move: /,''))});
 }
 return {ownPending,acted,anyMoveOccurred:events.some(h=>h.type==='move'),protections,origin:'own previously submitted choice and own split-stream turn events only'};
}
export function installPivotPublicContext(position,context){
 const p=supervisionPublicPosition(position);p.publicContext.pivot=structuredClone(context);
 for(const e of context.protections){
  if(['wideguard','quickguard','craftyshield','matblock'].includes(e.id)){if(!p.conditions[e.side].includes(e.id))p.conditions[e.side].push(e.id);}
  else if(!p.teams[e.side][e.index].volatiles.includes(e.id))p.teams[e.side][e.index].volatiles.push(e.id);
 }
 return p;
}
const pendingOwn=p=>({command:'known own pending actions',actions:[0,1].map(slot=>p.publicContext.pivot.ownPending.find(a=>a.slot===slot)||pass(slot))});
function pendingFoes(p,world,oracle,dex,cap=4){
 const context=p.publicContext.pivot;
 const possible=oracle.legalActions(world.position,1).filter(j=>!context.anyMoveOccurred||j.actions.every(a=>a.type!=='switch')).map(j=>({...j,actions:j.actions.map(a=>context.acted[1][world.position.active[1][a.slot]]?pass(a.slot):a)}));
 return canonical(shortlistChampionsCandidates(scoreChampionsCandidates(dex,world.position,canonical(possible),1),cap,dex));
}
export function evaluatePivotSupervision(position,rows,dex,{mode='bo3',seeds=[17,101],worldCount=4}={}){
 const started=performance.now(),p=supervisionPublicPosition(position);if(!p.publicContext.pivot)throw Error('Missing public interrupted-turn context');
 const worlds=supervisionWorlds(p,dex,mode,worldCount),oracle=createSearchOracle(p,dex,{nodes:1e6,timeMs:1e12}),coverage=new Map(),decision=createChampionsDamageDecision(p,{prepareBattle:b=>{
  // BeforeTurn already happened. Preserve observed Protect/redirection, then
  // execute remaining hypotheses and exactly one native residual phase.
  b.midTurn=true;b.queue.addChoice({choice:'residual'});
 }});
 try{
  const canonicalRows=canonical(rows),foes=worlds.map(w=>pendingFoes(p,w,oracle,dex)),columns=canonical(teacherOpponentPool(foes)),maps=foes.map(xs=>new Map(xs.map(j=>[teacherActionIdentity(j),j]))),entries=new Map();
  if(!columns.length)throw Error('No public pending opponent hypothesis');
  const own=pendingOwn(p),value=r=>r.ended?(r.winner==='Public own'?1:r.winner==='Public opponent'?-1:0):teacherBoardValue(dex,r.position,coverage);
  const matrix=canonicalRows.map(a=>columns.map(b=>{
   const means=[];
   for(const [i,w]of worlds.entries()){
    const response=maps[i].get(teacherActionIdentity(b));if(!response)continue;
    const key=JSON.stringify([i,teacherActionIdentity(a)]);if(!entries.has(key))entries.set(key,applyPublicReplacement(w.position,a));
    const entry=entries.get(key),samples=seeds.map(seed=>entry.ended?value(entry):value(decision.exchange(entry.position,own,response,{seed,nativeChance:true})));
    means.push({weight:w.weight,value:samples.reduce((s,x)=>s+x,0)/samples.length});
   }
   if(!means.length)throw Error('Impossible pending opponent column');
   const total=means.reduce((s,x)=>s+x.weight,0);return .7*means.reduce((s,x)=>s+x.value*x.weight,0)/total+.3*Math.min(...means.map(x=>x.value));
  }));
  const solved=solveMatrixGame(matrix,{iterations:3000,tolerance:.005});
  return {rows:canonicalRows,columns,matrix,policy:[...solved.rowStrategy,...solved.columnStrategy],actionValues:matrix.map(row=>row.reduce((s,x,j)=>s+x*solved.columnStrategy[j],0)),value:solved.value,key:canonicalSupervisionKey(p,canonicalRows,columns,{mode,replacement:true,config:{schema:'champions-pending-turn-supervision-v1',seeds,worldCount}}),diagnostics:{...decision.metrics,ms:performance.now()-started,tier:'pending-turn',worlds:worlds.map(w=>w.id),seeds,residual:solved.residual,ownLockedActions:own.actions,opponentScope:'unacted public move hypotheses only; switches possible only before any public move occurred',depth:'native entry, remaining committed-own/public-enemy actions, one residual',scope:'Own previous command is legitimate private-own information; no opposing queue or future stream. Pending enemy commands are bounded public hypotheses, never their true hidden choices.'}};
 }finally{oracle.dispose();decision.dispose();}
}
