// Experimental target repair. A/B/C share states, candidates and actor features.
// Incumbent proposals never supply labels by fiat: a simultaneous public-world
// matrix evaluates them against additional defensive and attacking responses.
import {publicDamagePosition,createChampionsDamageDecision} from './champions-damage.mjs';
import {createBeliefWorlds} from './champions-belief-worlds.mjs';
import {createSearchOracle} from './champions-search-oracle.mjs';
import {teacherActionIdentity,teacherOpponentPool,teacherOutcomeValue} from './champions-search-teacher.mjs';
import {chooseChampionsSearch,SEARCH_SETTINGS,scoreChampionsCandidates,shortlistChampionsCandidates,seededChampionsRandom} from './champions-search.mjs';
import {solveMatrixGame} from './champions-matrix-solver.mjs';
import {enumerateChampionsActions} from './champions-actions.mjs';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const expectation=(p,m,q)=>m.reduce((s,row,i)=>s+p[i]*row.reduce((v,x,j)=>v+x*q[j],0),0);
export async function distillChampionsTargets(tracker,request,teacher,{seed=1,priorModel=null,worldCount=2,rowCap=10,columnCap=8,deepen=true}={}){
  if(tracker.state.side!==request.side.id)throw Error('Distillation firewall');
  const started=performance.now(),dex=tracker.state.dex,p=publicDamagePosition(tracker.state,request),legal=enumerateChampionsActions(request),members=new Map(legal.map(j=>[j.command,j]));
  if(!teacher.policy||request.forceSwitch)throw Error('Distillation requires an ordinary matrix decision');
  const beliefs=createBeliefWorlds(p,dex,{mode:'bo3'}),worlds=beliefs.worlds.filter(w=>w.position.teams[1].every((m,i)=>!p.teams[1][i].knowledge?.nature||m.nature===p.teams[1][i].nature));
  // Distinct public investment classes, never an actual opposing set. Sheets
  // reveal Nature/item/ability/moves; stat points remain uncertain.
  const distinct=[...new Map(worlds.map(w=>[JSON.stringify(w.position.teams[1].map(m=>[m.hp,m.stats,m.nature,m.item,m.ability,m.moves])),w])).values()];
  const selected=distinct.slice(0,worldCount);
  const oracle=createSearchOracle(p,dex,{nodes:10000,timeMs:1e12}),decision=createChampionsDamageDecision(p);
  try{
    const prior=priorModel?(await priorModel.rank(tracker,request)).ranked:[];
    const guide=chooseChampionsSearch(legal,tracker.state,dex,{...SEARCH_SETTINGS,depth:2,enemyStatProfile:'offense',request,prior,random:seededChampionsRandom(seed)});
    const unique=(xs,side)=>[...new Map(xs.map(j=>[teacherActionIdentity(j),j])).values()];
    const baseRows=teacher.policy.map(x=>members.get(x.command));
    if(baseRows.some(x=>!x))throw Error('Teacher label is not an own legal member');
    const cheapOwn=scoreChampionsCandidates(dex,selected[0].position,legal,0);
    const familyPicks=['switch','protect','support'].map(f=>cheapOwn.find(j=>j.actions.some(a=>f==='switch'?a.type==='switch':a.type==='move'&&(f==='protect'?dex.moves.get(a.move.id).stallingMove:dex.moves.get(a.move.id).category==='Status'&&!dex.moves.get(a.move.id).stallingMove)))).filter(Boolean);
    const rows=unique([...baseRows,members.get(guide.chosen.command),...familyPicks,...guide.top.map(j=>members.get(j.command)),...shortlistChampionsCandidates(cheapOwn,rowCap,dex)]).slice(0,Math.max(rowCap,baseRows.length));
    const legalFoes=selected.map(w=>oracle.legalActions(w.position,1)),foePool=teacherOpponentPool(legalFoes),cheapFoes=scoreChampionsCandidates(dex,selected[0].position,foePool,1);
    const columns=teacherOpponentPool([teacher.opponentActions,shortlistChampionsCandidates(cheapFoes,columnCap,dex)]).slice(0,Math.max(columnCap,teacher.opponentActions.length));
    const foeMaps=legalFoes.map(xs=>new Map(xs.map(j=>[teacherActionIdentity(j),j]))),fallbacks=legalFoes.map((xs,i)=>scoreChampionsCandidates(dex,selected[i].position,xs,1)[0]);
    const samples=new Map(),matrix=rows.map(a=>columns.map(b=>{
      const results=[];
      for(let i=0;i<selected.length;i++)for(const roll of [85,100]){
        const foe=foeMaps[i].get(teacherActionIdentity(b))||fallbacks[i];
        const r=decision.exchange(selected[i].position,a,foe,{roll,tie:i%2,seed:seed%65500});
        results.push({...r,value:teacherOutcomeValue(dex,r)});
      }
      samples.set(JSON.stringify([a.command,b.command]),results);
      const values=results.map(r=>r.value);return .7*values.reduce((s,x)=>s+x,0)/values.length+.3*Math.min(...values);
    }));
    let solved=solveMatrixGame(matrix,{iterations:3000,tolerance:.005}),deepened=0;
    if(deepen){
      const likely=rows.flatMap((a,i)=>columns.map((b,j)=>({a,b,i,j,mass:solved.rowStrategy[i]*solved.columnStrategy[j]}))).sort((a,b)=>b.mass-a.mass).slice(0,2);
      for(const cell of likely){
        const results=samples.get(JSON.stringify([cell.a.command,cell.b.command])),values=[];
        for(const r of results){
          if(r.ended){values.push(r.value);continue;}
          const own=shortlistChampionsCandidates(scoreChampionsCandidates(dex,r.position,oracle.legalActions(r.position,0),0),2,dex),foe=shortlistChampionsCandidates(scoreChampionsCandidates(dex,r.position,oracle.legalActions(r.position,1),1),2,dex);
          if(!own.length||!foe.length){values.push(r.value);continue;}
          const m=own.map(a=>foe.map(b=>teacherOutcomeValue(dex,decision.exchange(r.position,a,b,{roll:93,tie:1,seed:seed%65500}))));
          values.push(solveMatrixGame(m,{iterations:1000}).value);
        }
        matrix[cell.i][cell.j]=.3*matrix[cell.i][cell.j]+.7*(.7*values.reduce((s,x)=>s+x,0)/values.length+.3*Math.min(...values));deepened++;
      }
      solved=solveMatrixGame(matrix,{iterations:3000,tolerance:.005});
    }
    const aligned=(policy,actions)=>actions.map(a=>policy.find(x=>x.command===a.command)?.probability||0),Aown=aligned(teacher.policy,rows),Afoe=columns.map(a=>teacher.opponentPolicy.find(x=>teacherActionIdentity(teacher.opponentActions.find(j=>j.command===x.command))===teacherActionIdentity(a))?.probability||0);
    // The source distributions must retain all mass after canonical alignment.
    for(const dist of [Aown,Afoe])if(Math.abs(dist.reduce((s,x)=>s+x,0)-1)>1e-8)throw Error('Distillation label alignment lost mass');
    const aValue=expectation(Aown,matrix,solved.columnStrategy),bValue=expectation(solved.rowStrategy,matrix,solved.columnStrategy),gain=bValue-aValue;
    // C trusts broader incumbent-guided reasoning in proportion to the measured
    // advantage, rather than assuming the incumbent always makes better moves.
    const weight=clamp(gain/.15,0,.75),mix=(a,b)=>a.map((x,i)=>(1-weight)*x+weight*b[i]);
    const policies={A:[...Aown,...Afoe],B:[...solved.rowStrategy,...solved.columnStrategy],C:[...mix(Aown,solved.rowStrategy),...mix(Afoe,solved.columnStrategy)]};
    return {position:p,rows,columns,groups:[rows.length,columns.length],policies,searchValue:solved.value,diagnostics:{...decision.metrics,ms:performance.now()-started,worlds:selected.map(w=>w.id),matrixDimensions:[rows.length,columns.length],guide:guide.chosen.command,guideCoveredByA:baseRows.some(a=>a.command===guide.chosen.command),aValue,bValue,gain,mixtureWeight:weight,residual:solved.residual,deepened,scope:'bounded public builds and endpoint rolls, partial continuation; heuristic action quality, not eventual win probability'},matrix};
  }finally{decision.dispose();oracle.dispose();}
}
