// Format-specific calibration plugs into this API. No absolute ladder rating
// is asserted without an external anchor; these are compute profiles only.
export const SEARCH_PROFILES=Object.freeze({
  casual:Object.freeze({nodes:64,timeMs:100,candidates:6,initial:2,worlds:1,chanceCalls:1,oracleIterations:2,solverIterations:100,depth:1,deepenCells:0}),
  medium:Object.freeze({nodes:192,timeMs:500,candidates:8,initial:2,worlds:2,chanceCalls:3,oracleIterations:3,solverIterations:400,depth:1,deepenCells:0}),
  high:Object.freeze({nodes:640,timeMs:1500,candidates:12,initial:3,worlds:3,chanceCalls:5,oracleIterations:4,solverIterations:1200,depth:2,deepenCells:2}),
  maximum:Object.freeze({nodes:2400,timeMs:6000,candidates:20,initial:4,worlds:6,chanceCalls:20,oracleIterations:6,solverIterations:3000,depth:2,deepenCells:4}),
});
export function difficultyProfile(format,strength='medium',calibration=null){
  if(!['champions-bo1','champions-bo3','gen9ou','gen9randombattle'].includes(format))throw Error('Unknown difficulty format');
  const settings=SEARCH_PROFILES[strength];if(!settings)throw Error('Unknown search strength');
  const row=calibration?.format===format?calibration.profiles?.find(p=>p.id===strength):null;
  const anchored=calibration?.absoluteAnchor?.validated&&row?.absoluteAnchorValidated&&Number.isFinite(row.absoluteElo);
  return {format,strength,...settings,absoluteElo:anchored?row.absoluteElo:null,relativeRating:row?.relativeRating??null,relativeCalibrationAvailable:!!row,status:anchored?'anchored':'uncalibrated'};
}
