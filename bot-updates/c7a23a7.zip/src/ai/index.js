import {Dex} from '@pkmn/sim';
import {clamp, toID, fromRequest, damageEstimate, effectiveSpeed, hazardCost, typeEffectiveness} from './damage.js';
import {possibleMoves, opponentHypotheses} from './priors.js';
import {chooseDoubles} from './doubles.js';
import {createTeamSafety} from './team-safety.js';
import {chooseAction as chooseStableAction} from './singles-corrected.js';
import {chooseAction as chooseFrozenDefault} from './singles-stable.js';
import {resolvePublicResiduals, replacementAfterKO} from './singles-mechanics.js';
import {choosePublicSetResourceAction} from './singles-set-response-search.mjs';

export const DIFFICULTIES = Object.freeze({
  Medium: {depth: 1, responses: 3, hypotheses: 1, searchWidth: 3, maxCalculations: 220,
    downside: 0.12, variance: 0.02, reliability: 0.35, teraReserve: 0.85, mixWindow: 0, temperature: 0},
  Strong: {depth: 2, responses: 5, hypotheses: 2, searchWidth: 5, maxCalculations: 800,
    downside: 0.24, variance: 0.05, reliability: 0.6, teraReserve: 1, mixWindow: 3.5, temperature: 1.7},
  'Very Strong': {depth: 2, responses: 7, hypotheses: 4, searchWidth: 8, maxCalculations: 1800,
    downside: 0.34, variance: 0.08, reliability: 0.85, teraReserve: 1.15, mixWindow: 6, temperature: 2.4},
});

const first = value => Array.isArray(value) ? value[0] : value;
const alive = mon => !mon.fainted && !String(mon.condition || '').includes('fnt') && (mon.hpFraction ?? 1) > 0;
const cloneMon = mon => ({...mon, boosts: {...mon.boosts}});
const isForced = request => request.forceSwitch?.some(Boolean);
const choiceItem = mon => ['choiceband', 'choicespecs', 'choicescarf'].includes(toID(mon.item));

function volatileIDs(mon) {
  const value = mon?.volatiles;
  const ids = new Set();
  const add = item => {
    if (!item) return;
    if (typeof item === 'string') ids.add(toID(item));
    else if (typeof item === 'object') {
      if (item.id || item.name) ids.add(toID(item.id || item.name));
    }
  };
  if (!value) return ids;
  if (Array.isArray(value) || value instanceof Set) {
    for (const item of value) add(item);
  } else if (typeof value === 'object') {
    for (const [key, item] of Object.entries(value)) {
      ids.add(toID(key));
      add(item);
    }
  } else add(value);
  return ids;
}
const hasVolatile = (mon, id) => volatileIDs(mon).has(toID(id));
const RECOVERY_MOVES = new Set(['recover','roost','slackoff','softboiled','milkdrink','shoreup','strengthsap','synthesis','morningsun','moonlight','rest','wish']);
const PROTECT_MOVES = new Set(['protect','detect','spikyshield','banefulbunker','silktrap','burningbulwark','kingsshield','obstruct','endure','maxguard']);
const isProtectMove = move => PROTECT_MOVES.has(toID(move));
// In modern Showdown mechanics, the second consecutive Protect-family use succeeds
// only about one third of the time (and later chains get even worse). The public
// player view reliably gives us the immediately previous move, so never evaluate a
// double Protect as guaranteed protection.
const protectSuccessChance = mon => isProtectMove(mon?.lastMove) ? 1 / 3 : 1;

function seededRandom(seed) {
  let value = (Number(seed) || 1) >>> 0;
  return () => {
    value += 0x6D2B79F5;
    let t = value;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function weightedTail(outcomes, fraction = 0.25) {
  const ordered = [...outcomes].sort((a, b) => a.outcome.score - b.outcome.score);
  const totalWeight = ordered.reduce((sum, entry) => sum + entry.weight, 0) || 1;
  let remaining = fraction * totalWeight, total = 0, weight = 0;
  for (const entry of ordered) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, entry.weight);
    total += entry.outcome.score * take;
    weight += take;
    remaining -= take;
  }
  return weight ? total / weight : ordered[0]?.outcome.score || 0;
}

function outcomeMetrics(outcomes) {
  const weight = outcomes.reduce((sum, entry) => sum + entry.weight, 0) || 1;
  const mean = outcomes.reduce((sum, entry) => sum + entry.outcome.score * entry.weight, 0) / weight;
  const variance = outcomes.reduce((sum, entry) => sum + (entry.outcome.score - mean) ** 2 * entry.weight, 0) / weight;
  const ownHP = outcomes.reduce((sum, entry) => sum + entry.outcome.own.hpFraction * entry.weight, 0) / weight;
  const opponentHP = outcomes.reduce((sum, entry) => sum + entry.outcome.opponent.hpFraction * entry.weight, 0) / weight;
  const ownKO = outcomes.reduce((sum, entry) => sum + (entry.outcome.own.hpFraction <= 0 ? entry.weight : 0), 0) / weight;
  const opponentKO = outcomes.reduce((sum, entry) => sum + (entry.outcome.opponent.hpFraction <= 0 ? entry.weight : 0), 0) / weight;
  const incomingThreat = outcomes.reduce((sum, entry) => sum + entry.outcome.incomingThreat * entry.weight, 0) / weight;
  const incomingKOThreat = outcomes.reduce((sum, entry) => sum + entry.outcome.incomingKOThreat * entry.weight, 0) / weight;
  return {mean, tail: weightedTail(outcomes), deviation: Math.sqrt(variance), ownHP, opponentHP, ownKO, opponentKO, incomingThreat, incomingKOThreat};
}

function actionMissChance(action) {
  if (action.kind !== 'move') return 0;
  const move = Dex.moves.get(action.move);
  if (!move.exists || move.target === 'self' || move.accuracy === true) return 0;
  return 1 - clamp(Number(move.accuracy || 100) / 100);
}

function publicHpFraction(mon) {
  if (Number.isFinite(mon?.hpFraction)) return clamp(mon.hpFraction);
  const condition = String(mon?.condition || '');
  if (condition.includes('fnt')) return 0;
  const match = condition.match(/(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)/);
  if (match) return clamp(Number(match[1]) / Math.max(1, Number(match[2])));
  return 1;
}

function materialEdge(ctx) {
  const teamSize = Math.max(1, ctx.roster.length || 6);
  const ownMaterial = ctx.roster.reduce((sum, mon) => sum + (alive(mon) ? publicHpFraction(mon) : 0), 0);
  const revealed = ctx.view.opponent?.revealed || [];
  const knownMaterial = revealed.reduce((sum, mon) => sum + (alive(mon) ? publicHpFraction(mon) : 0), 0);
  // Unrevealed slots are conservatively treated as healthy rather than as missing.
  // This prevents Random Battles from thinking it is far ahead just because the
  // opponent has not shown the back of its team yet.
  const opponentMaterial = knownMaterial + Math.max(0, teamSize - revealed.length);
  return (ownMaterial - opponentMaterial) / teamSize * 100;
}

export function teraOpportunityCost(ctx, candidate) {
  if (!candidate.tera) return 0;
  const aliveCount = ctx.roster.filter(alive).length;
  // Tera is a one-use team resource. Its option value is highest while several
  // healthy teammates could still use it, and lower in the endgame.
  const cost = (5 + Math.max(0, aliveCount - 1) * 2.2) * ctx.profile.teraReserve;
  // Damage, KOs and survival are ALREADY valued in the exchange. The team's
  // lost option cannot become almost free just because this use is beneficial.
  // Defensive and offensive uses face the same resource cost; a truly necessary
  // defensive Tera wins through the survival it actually buys, not a refund.
  return Math.max(2, cost);
}

function chooseMixed(scores, profile, seed, turn = 0) {
  if (!profile.temperature || !profile.mixWindow || scores.length < 2) return scores[0];
  const best = scores[0];
  const pool = scores.filter(candidate => candidate.score >= best.score - profile.mixWindow &&
    candidate.metrics.tail >= best.metrics.tail - profile.mixWindow * 1.75);
  if (pool.length < 2) return best;
  const weights = pool.map(candidate => Math.exp((candidate.score - best.score) / profile.temperature));
  const total = weights.reduce((sum, weight) => sum + weight, 0);
  const random = seededRandom((Number(seed) || 1) ^ Math.imul((turn || 0) + 1, 0x9e3779b1));
  let pick = random() * total;
  for (let i = 0; i < pool.length; i++) {
    pick -= weights[i];
    if (pick <= 0) return pool[i];
  }
  return pool[0];
}

/** Legal candidates derive solely from the player's own request. */
export function legalActions(view) {
  const request = view.request || view;
  if (request.wait) return [];
  const roster = request.side?.pokemon || [];
  if (request.teamPreview) return roster.length ? [{choice: `team ${roster.map((_, i) => i + 1).join('')}`, kind: 'team'}] : [];
  if (roster.some(mon=>mon.active&&mon.reviving)) return roster.flatMap((mon,index)=>String(mon.condition).includes('fnt')?[{kind:'revive',choice:`switch ${index+1}`,slot:index+1}]:[]);
  const active = request.active?.[0];
  const actions = [];
  if (!isForced(request) && active) {
    (active.moves || []).forEach((move, index) => {
      if (!move.disabled && (move.pp === undefined || move.pp > 0)) {
        actions.push({kind: 'move', choice: `move ${index + 1}`, move: move.move || move.id, slot: index + 1});
        if (active.canTerastallize) actions.push({kind: 'move', choice: `move ${index + 1} terastallize`, move: move.move || move.id, slot: index + 1, tera: active.canTerastallize});
      }
    });
  }
  if (isForced(request) || !active?.trapped) roster.forEach((mon, index) => {
    if (!mon.active && alive(mon) && !String(mon.condition).startsWith('0 ')) actions.push({kind: 'switch', choice: `switch ${index + 1}`, slot: index + 1});
  });
  return actions;
}

function contextFor(view, profile) {
  const request = view.request;
  const publicOwn = Array.isArray(view.own?.active) ? view.own.active : [view.own?.active].filter(Boolean);
  const roster = (request.side?.pokemon || []).map(mon => fromRequest(mon, publicOwn.find(p => p?.ident === mon.ident) || (mon.active ? publicOwn[0] : {}) || {}));
  const alliesFainted=roster.filter(mon=>!alive(mon)).length;
  for(const mon of roster)mon.alliesFainted=alliesFainted;
  const own = roster.find(mon => mon.active) || roster.find(alive);
  const publicOpponent = first(view.opponent?.active);
  const opponent = publicOpponent && {hpFraction: 1, boosts: {}, movesSeen: [], alliesFainted:(view.opponent?.revealed||[]).filter(mon=>!alive(mon)).length, ...publicOpponent,
    level: publicOpponent.level || Number(publicOpponent.details?.match(/, L(\d+)/)?.[1]) || 100};
  const ctx = {view, profile, request, roster, own, opponent, field: view.field || {}, cache: new Map(), calculations: 0, failures: 0};
  ctx.damage = (a, d, move, reverse = false) => {
    const key = JSON.stringify([a.species, a.hpFraction, a.exactStats, a.level, a.boosts, a.status, a.item, a.ability, a.terastallized, a.teraType, a.evs, a.ivs, a.nature,
      d.species, d.hpFraction, d.exactStats, d.level, d.boosts, d.status, d.item, d.ability, d.terastallized, d.teraType, d.evs, d.ivs, d.nature, move, reverse]);
    if (ctx.cache.has(key)) return ctx.cache.get(key);
    ctx.calculations++;
    let result;
    try { result = damageEstimate(a, d, move, ctx.field, reverse); }
    catch {
      ctx.failures++;
      // Conservative degradation for a calc/Showdown metadata version mismatch; no rule resolution here.
      const data = Dex.moves.get(move);
      const mean = data.category === 'Status' ? 0 : Math.min(0.7, (data.basePower || 60) / 300 * typeEffectiveness(data.type, d));
      result = {mean, min: mean * 0.8, max: mean * 1.2, ko: mean > (d.hpFraction ?? 1) ? 0.5 : 0, accuracy: 1};
    }
    ctx.cache.set(key, result);
    return result;
  };
  return ctx;
}

// Research planners share the existing serializable player-view boundary.
export {contextFor as createResourceContext};

function residual(mon) {
  let heal = toID(mon.item) === 'leftovers' ? 1 / 16 : 0;
  if (toID(mon.item) === 'blacksludge') heal += Dex.species.get(mon.species).types.includes('Poison') ? 1 / 16 : -1 / 8;
  if (toID(mon.ability) === 'poisonheal' && ['tox', 'psn'].includes(mon.status)) return heal + 1 / 8;
  if (toID(mon.ability) !== 'magicguard') {
    if (mon.status === 'brn') heal -= 1 / 16;
    if (mon.status === 'psn') heal -= 1 / 8;
    if (mon.status === 'tox') heal -= (mon.toxicCounter || 1) / 16;
    if (hasVolatile(mon, 'leechseed')) heal -= 1 / 8;
  }
  return heal;
}

function statusValue(move, own, opponent, ctx) {
  const data = Dex.moves.get(move), moveID = data.id;
  const types = opponent.terastallized ? [opponent.teraType || opponent.terastallized] : Dex.species.get(opponent.species).types;
  let value = 0;
  if (data.status && opponent.status) value -= 55;
  if (data.status && !opponent.status && !hasVolatile(opponent, 'substitute') && !hasVolatile(opponent, 'protect')) {
    const immunity = ['goodasgold','purifyingsalt','comatose'].includes(toID(opponent.ability)) ||
      (toID(ctx.field.terrain)==='mistyterrain'&&typeEffectiveness('Ground',opponent)>0) ||
      (['tox', 'psn'].includes(data.status) && types.some(t => ['Poison', 'Steel'].includes(t))) ||
      (data.status === 'brn' && types.includes('Fire')) || (data.status === 'par' && types.includes('Electric')) ||
      (data.flags?.powder && (types.includes('Grass') || ['overcoat'].includes(toID(opponent.ability)) || toID(opponent.item)==='safetygoggles')) ||
      (moveID === 'thunderwave' && !typeEffectiveness('Electric', opponent));
    if (!immunity) {
      value += {slp: 34, par: 23, brn: 20, tox: 26, psn: 16}[data.status] || 0;
      if (data.status === 'brn' && Dex.species.get(opponent.species).baseStats.atk > Dex.species.get(opponent.species).baseStats.spa) value += 13;
      if (toID(opponent.ability) === 'guts') value -= 26;
    }
  }
  if (data.sideCondition) {
    const conditions = (ctx.field.opponentSideConditions || []).map(c => toID(typeof c === 'string' ? c : c.id));
    const enemyCount = 6 - (ctx.view.opponent?.revealed || []).filter(p => !alive(p)).length;
    if (!conditions.includes(toID(data.sideCondition))) value += ({stealthrock: 6, spikes: 5, toxicspikes: 4, stickyweb: 5}[data.sideCondition] || 0) * Math.max(1, enemyCount - 1);
  }
  const ownHazards = (ctx.field.sideConditions || []).filter(c => /stealthrock|spikes|stickyweb/.test(toID(typeof c === 'string' ? c : c.id))).length;
  if (['rapidspin', 'mortalspin', 'defog', 'tidyup'].includes(moveID)) value += ownHazards * 12;
  if (moveID === 'taunt') {
    if (hasVolatile(opponent, 'taunt')) value -= 55;
    else if ((opponent.movesSeen || []).some(m => Dex.moves.get(m).category === 'Status')) value += 14;
  }
  if (moveID === 'encore') {
    if (hasVolatile(opponent, 'encore')) value -= 50;
    else if (opponent.lastMove && Dex.moves.get(opponent.lastMove).category === 'Status') value += 18;
  }
  if (moveID === 'leechseed') {
    if (types.includes('Grass') || hasVolatile(opponent, 'leechseed')) value -= 90;
    else {
      value += 21;
      // Repeating Leech Seed can be a legitimate double/prediction into a
      // switch. Only penalize the repetition when this scenario has the
      // opponent staying in; switch scenarios should evaluate the incoming
      // target normally. The response distribution decides whether the read is
      // worth taking.
      if (toID(own.lastMove) === 'leechseed' && !ctx.opponentSwitched) value -= 28;
    }
  }
  if (data.volatileStatus === 'substitute') value += hasVolatile(own, 'substitute') ? -70 : (own.hpFraction > 0.6 ? 5 : -12);
  if (isProtectMove(moveID)) {
    const successChance = protectSuccessChance(own);
    // Protect is useful for scouting/residual turns, but a consecutive use must
    // carry the actual failure risk instead of being scored like a guaranteed block.
    value += Math.max(0, residual(own) - residual(opponent)) * 100 * successChance - 6;
    if (successChance < 1) value -= 18;
  }
  if (['roar', 'whirlwind', 'haze', 'clearsmog'].includes(moveID)) value += Math.max(0, Object.values(opponent.boosts || {}).reduce((a, b) => a + b, 0)) * 9;
  if (['reflect', 'lightscreen', 'auroraveil'].includes(moveID)) {
    const conditions = (ctx.field.sideConditions || []).map(c => toID(typeof c === 'string' ? c : c.id));
    if (!conditions.includes(moveID)) value += 18;
  }
  return value;
}

function applyBoosts(mon, boosts) {
  for (const [stat, amount] of Object.entries(boosts || {})) mon.boosts[stat] = clamp((mon.boosts[stat] || 0) + amount, -6, 6);
}

function boostsValue(mon, boosts) {
  const physical = (mon.moves || []).some(m => Dex.moves.get(m).category === 'Physical');
  const special = (mon.moves || []).some(m => Dex.moves.get(m).category === 'Special');
  return Object.entries(boosts || {}).reduce((sum, [stat, amount]) => {
    const gained = clamp((mon.boosts?.[stat] || 0) + amount, -6, 6) - (mon.boosts?.[stat] || 0);
    return sum + gained * ({atk: physical ? 9 : 0, spa: special ? 9 : 0, spe: 8, def: 4, spd: 4, accuracy: 2, evasion: 5}[stat] || 0);
  }, 0);
}

function moveEffect(mon, opponent, action, ctx) {
  const data = Dex.moves.get(action.move), id = data.id;
  let score = statusValue(action.move, mon, opponent, ctx);
  const accuracy = data.accuracy === true ? 1 : clamp(Number(data.accuracy || 100) / 100);
  // Damage estimates already include accuracy. Do the same for targeted status
  // utility so inaccurate utility moves are not treated as guaranteed value.
  if (data.target !== 'self' && data.category === 'Status') score *= accuracy;
  let healing = 0;
  if (data.heal) healing = Math.min(1 - mon.hpFraction, data.heal[0] / data.heal[1]);
  if (id === 'rest') healing = Math.min(1 - mon.hpFraction, 1) - (mon.status === 'slp' ? 0 : 0.2);
  if (id === 'wish') healing = Math.min(1 - mon.hpFraction, 0.5) * 0.7;
  // Recovery is valued in pairOutcome from the HP it actually preserves after
  // the opponent's likely response. This avoids infinite Recover/Roost loops
  // where gross healing is immediately erased by incoming damage.
  const boosts = data.boosts || data.self?.boosts;
  if (boosts && (data.target === 'self' || data.self)) score += boostsValue(mon, boosts);
  if (id === 'bellydrum' && mon.hpFraction <= 0.5) score -= 60;
  if (data.category === 'Status' && score === 0) score = -12;
  return {score, healing: Math.max(0, healing), boosts: data.target === 'self' || data.self ? boosts : undefined};
}

function moveFirst(own, opponent, ourMove, theirMove, field) {
  let a = Dex.moves.get(ourMove).priority || 0, b = Dex.moves.get(theirMove).priority || 0;
  if(toID(field.terrain)==='grassyterrain') {if(toID(ourMove)==='grassyglide')a++;if(toID(theirMove)==='grassyglide')b++;}
  if (toID(own.ability) === 'prankster' && Dex.moves.get(ourMove).category === 'Status') a++;
  if (toID(opponent.ability) === 'prankster' && Dex.moves.get(theirMove).category === 'Status') b++;
  if (a !== b) return a > b ? 1 : 0;
  const speedA = effectiveSpeed(own, field), speedB = effectiveSpeed(opponent, field, true);
  if (speedA === speedB) return 0.5;
  return field.trickRoom ? (speedA < speedB ? 1 : 0) : (speedA > speedB ? 1 : 0);
}

export function pairOutcome(ownOriginal, opponentOriginal, action, response, ctx, forced = false) {
  const own = cloneMon(action.kind === 'switch' ? ctx.roster[action.slot - 1] : ownOriginal);
  const opponent = cloneMon(response.kind === 'switch' ? response.mon : opponentOriginal);
  if (action.tera) { own.teraType = action.tera; own.terastallized = action.tera; }
  let score = action.tera ? -9 : 0;
  if (action.kind === 'switch') {
    const hazards = hazardCost(own, ctx.field.sideConditions);
    own.hpFraction = Math.max(0, own.hpFraction - hazards);
    score -= hazards * 100 + (forced ? 0 : 8);
    if (!forced && toID(ownOriginal.ability) === 'regenerator') score += Math.min(1 - ownOriginal.hpFraction, 1 / 3) * 65;
    own.boosts = {};
    own.volatiles = []; own.lastMove = null;
  }
  if (response.kind === 'switch') {
    const hazards = hazardCost(opponent, ctx.field.opponentSideConditions);
    opponent.hpFraction = Math.max(0, opponent.hpFraction - hazards);
    opponent.boosts = {};
    opponent.volatiles = []; opponent.lastMove = null;
    score += hazards * 100 + 6;
  }
  const firstChance = action.kind === 'switch' ? 0 : response.kind === 'switch' ? 1 : moveFirst(own, opponent, action.move, response.move, ctx.field);
  const ourHaze = action.kind === 'move' && toID(action.move) === 'haze';
  const theirHaze = !forced && response.kind === 'move' && toID(response.move) === 'haze';
  // A faster Haze clears BOTH sides before the slower attack. It is a field
  // effect and is not stopped by Protect. Do not assume a favorable speed tie.
  const clearedBeforeDamage = ourHaze && firstChance === 1 || theirHaze && firstChance === 0;
  const damageOwn = clearedBeforeDamage ? {...own, boosts: {}} : own;
  const damageOpponent = clearedBeforeDamage ? {...opponent, boosts: {}} : opponent;
  let outgoing = action.kind === 'move' ? ctx.damage(damageOwn, damageOpponent, action.move) : {mean: 0, ko: 0};
  let incoming = response.kind === 'move' && !forced ? ctx.damage(damageOpponent, damageOwn, response.move, true) : {mean: 0, ko: 0};
  const rawOutgoingMean = outgoing.mean, rawIncomingMean = incoming.mean;
  const protects=isProtectMove;
  const ourProtectChance = action.kind === 'move' && protects(action.move) ? protectSuccessChance(own) : 0;
  const theirProtectChance = response.kind === 'move' && protects(response.move) ? protectSuccessChance(opponent) : 0;
  if(toID(action.move)==='suckerpunch' && (response.kind!=='move'||Dex.moves.get(response.move).category==='Status'))outgoing={mean:0,ko:0};
  if(toID(response.move)==='suckerpunch' && (action.kind!=='move'||Dex.moves.get(action.move).category==='Status'))incoming={mean:0,ko:0};
  if(protects(response.move) && !Dex.moves.get(action.move).breaksProtect && !(toID(own.ability)==='unseenfist'&&Dex.moves.get(action.move).flags.contact)) {
    outgoing={mean:outgoing.mean*(1-theirProtectChance),ko:outgoing.ko*(1-theirProtectChance)};
  }
  if(protects(action.move) && !Dex.moves.get(response.move).breaksProtect && !(toID(opponent.ability)==='unseenfist'&&Dex.moves.get(response.move).flags.contact)) {
    incoming={mean:incoming.mean*(1-ourProtectChance),ko:incoming.ko*(1-ourProtectChance)};
  }
  const ourEffect = action.kind === 'move' ? moveEffect(own, opponent, action, {...ctx, opponentSwitched: response.kind === 'switch'}) : {score: 0, healing: 0};
  const theirEffect = !forced && response.kind === 'move' ? moveEffect(opponent, own, response, {...ctx, opponentSwitched: action.kind === 'switch', field: {...ctx.field, sideConditions: ctx.field.opponentSideConditions, opponentSideConditions: ctx.field.sideConditions}}) : {score: 0, healing: 0};
  if (action.kind === 'move') {
    const move = Dex.moves.get(action.move);
    const repeated = toID(own.lastMove) === move.id;
    // Repeating an idempotent status move after its effect is already public is
    // almost always a blunder. Penalize the loop instead of letting a shallow
    // heuristic settle into it.
    if (repeated && move.category === 'Status' && !RECOVERY_MOVES.has(move.id)) {
      if ((move.id === 'leechseed' && hasVolatile(opponent, 'leechseed')) ||
          (move.status && opponent.status) ||
          (move.volatileStatus === 'substitute' && hasVolatile(own, 'substitute')) ||
          (move.id === 'taunt' && hasVolatile(opponent, 'taunt')) ||
          (move.id === 'encore' && hasVolatile(opponent, 'encore'))) score -= 45;
    }
  }
  const ourHealthBeforeHit = Math.min(1, own.hpFraction + ourEffect.healing * firstChance);
  const theirHealthBeforeHit = Math.min(1, opponent.hpFraction + theirEffect.healing * (1 - firstChance));
  const incomingKO = incoming.mean >= ourHealthBeforeHit ? Math.max(0.8, incoming.ko) : incoming.ko;
  const outgoingKO = outgoing.mean >= theirHealthBeforeHit ? Math.max(0.8, outgoing.ko) : outgoing.ko;
  const ourSurvival = action.kind === 'switch' ? 1 : 1 - (1 - firstChance) * incomingKO;
  const theirSurvival = response.kind === 'switch' ? 1 : 1 - firstChance * outgoingKO;
  const outgoingDamage = Math.min(opponent.hpFraction + theirEffect.healing, outgoing.mean) * ourSurvival;
  const incomingDamage = Math.min(own.hpFraction + ourEffect.healing, incoming.mean) * theirSurvival;
  const outgoingKOValue = 50 + (opponent.hpFraction ?? 1) * 12;
  const incomingKOValue = 60 + (own.hpFraction ?? 1) * 18;
  score += outgoingDamage * 100 - incomingDamage * 100 + outgoingKO * ourSurvival * outgoingKOValue - incomingKO * theirSurvival * incomingKOValue;
  score += ourEffect.score * ourSurvival - theirEffect.score * theirSurvival * 0.65;

  // Value recovery by *net progress*, not gross HP restored. If Recover heals
  // 30% and the expected reply deals 30%, repeatedly clicking Recover should
  // not look like a +33 point action forever. It remains valuable when it
  // actually gains HP, prevents a likely KO, or stalls a foe that is losing to
  // public residual damage.
  if (ourEffect.healing > 0) {
    const startHP = own.hpFraction;
    const healed = ourEffect.healing * ourSurvival;
    const endHP = clamp(startHP + healed - incomingDamage);
    const netGain = Math.max(0, endHP - startHP);
    const withoutHeal = clamp(startHP - incomingDamage);
    const survivalGain = Math.max(0, endHP - withoutHeal);
    const favorableStall = residual(opponent) < residual(own) - 0.035 || hasVolatile(opponent, 'leechseed');
    score += netGain * 105 + Math.min(0.35, survivalGain) * 28;
    const repeated = toID(own.lastMove) === toID(action.move);
    if (repeated && netGain < 0.08 && !favorableStall) score -= 26;
    if (incomingDamage >= healed * 0.85 && netGain < 0.04 && !favorableStall) score -= 14;
  }
  if (theirEffect.healing > 0) {
    const startHP = opponent.hpFraction;
    const healed = theirEffect.healing * theirSurvival;
    const endHP = clamp(startHP + healed - outgoingDamage);
    const netGain = Math.max(0, endHP - startHP);
    const withoutHeal = clamp(startHP - outgoingDamage);
    const survivalGain = Math.max(0, endHP - withoutHeal);
    score -= netGain * 88 + Math.min(0.35, survivalGain) * 22;
  }
  if (action.kind === 'move') {
    const data = Dex.moves.get(action.move);
    if (data.drain) { const drain = outgoingDamage * data.drain[0] / data.drain[1]; score += Math.min(1 - own.hpFraction + incomingDamage, drain) * 60; own.hpFraction += drain; }
    if (data.recoil) { const recoil = outgoingDamage * data.recoil[0] / data.recoil[1]; score -= recoil * 55; own.hpFraction -= recoil; }
    if (data.selfdestruct) score -= own.hpFraction * 85;
    if (data.selfSwitch && ctx.roster.filter(alive).length > 1) score += Math.max(4, incomingDamage * 25);
    if (data.secondary?.status && !opponent.status) score += (data.secondary.chance || 0) / 100 * 10;
  }
  const clearBoosts = () => {own.boosts = {}; opponent.boosts = {};};
  const ourStages = () => {if (ourHaze && ourSurvival >= 1 - 1e-9) clearBoosts(); else applyBoosts(own, ourEffect.boosts);};
  const theirStages = () => {if (theirHaze && theirSurvival >= 1 - 1e-9) clearBoosts(); else applyBoosts(opponent, theirEffect.boosts);};
  if (firstChance === 0) {theirStages(); ourStages();} else {ourStages(); theirStages();}
  const end = resolvePublicResiduals({own, opponent,
    ownHP: own.hpFraction + ourEffect.healing * ourSurvival - incomingDamage,
    opponentHP: opponent.hpFraction + theirEffect.healing * theirSurvival - outgoingDamage,
    ownMove: action.move, opponentMove: response.move, field: ctx.field,
    ownHitChance: rawOutgoingMean > 0 ? outgoing.mean / rawOutgoingMean * ourSurvival : 0,
    opponentHitChance: rawIncomingMean > 0 ? incoming.mean / rawIncomingMean * theirSurvival : 0,
    ownResidual: residual(own), opponentResidual: residual(opponent)});
  score += end.score; own.hpFraction = end.ownHP; opponent.hpFraction = end.opponentHP;
  if (action.kind === 'move' && ourSurvival >= 1 - 1e-9) own.lastMove = action.move;
  if (!forced && response.kind === 'move' && theirSurvival >= 1 - 1e-9) opponent.lastMove = response.move;
  // Repeated switching is penalized by surrendering a turn; the continuation evaluates the resulting matchup.
  return {score, own, opponent, incomingThreat: Math.min(ourHealthBeforeHit, incoming.mean), incomingKOThreat: incomingKO};
}

export function responseOptions(opponent, own, ctx) {
  const assumedPool = opponent.inferred && Array.isArray(opponent.assumedMovePool) ? opponent.assumedMovePool : null;
  let moves = assumedPool ? choiceItem(opponent) && opponent.lastMove ? [opponent.lastMove] : assumedPool : possibleMoves(opponent, 9, ctx.view.format);
  if (assumedPool && toID(opponent.item) === 'assaultvest') moves = moves.filter(m => Dex.moves.get(m).category !== 'Status');
  const rankedMoves = moves.map(move => {
    const damage = ctx.damage(opponent, own, move, true);
    const seen = (opponent.movesSeen || []).some(m => toID(m) === toID(move));
    return {kind: 'move', move, rank: damage.mean * 100 + damage.ko * 50 + statusValue(move, opponent, own, ctx) * 0.5 + (seen ? 7 : 0)};
  }).sort((a, b) => b.rank - a.rank);
  let scored = rankedMoves.slice(0, ctx.profile.responses);
  if (ctx.view.format === 'gen9randombattle') {
    // Several redundant Fighting attacks must not erase the Dark coverage that
    // punishes a Ghost Tera, or the Ground coverage that catches a switch-in.
    const selected = [], covered = new Set();
    const add = r => {if (r && selected.length < ctx.profile.responses && !selected.includes(r)) {selected.push(r); const m = Dex.moves.get(r.move); if (m.category !== 'Status') covered.add(m.type);}};
    add(rankedMoves[0]);
    add(rankedMoves.find(r => Dex.moves.get(r.move).priority > 0 && Dex.moves.get(r.move).category !== 'Status'));
    for (const r of rankedMoves) {const m = Dex.moves.get(r.move); if (m.category !== 'Status' && !covered.has(m.type)) add(r);}
    for (const r of rankedMoves) add(r);
    scored = selected;
  }

  // Publicly revealed switch-ins are real opponent responses too. Rank each one
  // by how well it absorbs our current pressure and threatens us back, rather
  // than assigning every bench Pokemon the same generic switch score.
  const currentThreat = (own.moves || []).reduce((max, move) => Math.max(max, ctx.damage(own, opponent, move).mean), 0);
  const bench = (ctx.view.opponent?.revealed || []).filter(mon => alive(mon) && mon.ident !== ctx.opponent?.ident && mon.species !== ctx.opponent?.species);
  for (const mon of bench.slice(0, 3)) {
    const inferred = opponentHypotheses(mon, ctx.view.format, 1)[0];
    if (!inferred) continue;
    const switchInDamage = (own.moves || []).reduce((max, move) => Math.max(max, ctx.damage(own, inferred, move).mean), 0);
    const counterPressure = possibleMoves(inferred, 6, ctx.view.format).reduce((max, move) => Math.max(max, ctx.damage(inferred, own, move, true).mean), 0);
    const hazards = hazardCost(inferred, ctx.field.opponentSideConditions);
    const rank = currentThreat * 38 + counterPressure * 48 - switchInDamage * 62 - hazards * 85;
    if (currentThreat > 0.22 || rank > 8) scored.push({kind: 'switch', mon: inferred, rank});
  }
  scored.sort((a, b) => b.rank - a.rank);
  const bestRank = scored[0]?.rank || 0;
  const total = scored.reduce((sum, response) => sum + (response.weight = Math.exp(clamp((response.rank - bestRank) / 28, -5, 1))), 0);
  for (const response of scored) response.weight /= total || 1;
  return scored.length ? scored : [{kind: 'move', move: 'Struggle', weight: 1}];
}

function nextMoves(mon, action) {
  const moves = mon.moves || mon.movesSeen || [];
  const options = action.kind === 'move' && choiceItem(mon) ? [action.move] : moves;
  return options.filter(move => Dex.moves.get(move).exists).map(move => ({kind: 'move', move}));
}

function continuation(outcome, action, ctx) {
  if (outcome.opponent.hpFraction <= 0) return 0;
  if (outcome.own.hpFraction <= 0) return replacementAfterKO(outcome, action, ctx,
    {pair: pairOutcome, responses: responseOptions, moves: nextMoves, limit: ctx.profile.maxCalculations + (ctx.safetyCalculations || 0)}).value;
  const actions = nextMoves(outcome.own, action);
  if (!actions.length) return 0;
  const responses = responseOptions(outcome.opponent, outcome.own, ctx).slice(0, 3);
  let best = -Infinity;
  for (const candidate of actions) {
    if (ctx.calculations > ctx.profile.maxCalculations + (ctx.safetyCalculations || 0)) break;
    let value = 0, weight = 0;
    for (const response of responses) {
      value += pairOutcome(outcome.own, outcome.opponent, candidate, response, ctx).score * response.weight;
      weight += response.weight;
    }
    best = Math.max(best, value / (weight || 1));
  }
  return Number.isFinite(best) ? best : 0;
}

/** One further simultaneous decision with the resource still available if saved.
 * The caller commits this layer only when its complete root beam finishes. */
export function resourceContinuation(outcome, action, ctx) {
  const limit = (ctx.searchBudget ?? ctx.profile.maxCalculations) + (ctx.safetyCalculations || 0);
  ctx.deferredTeraEvaluations ??= 0;
  if (outcome.own.hpFraction <= 0) {
    if (outcome.opponent.hpFraction <= 0) return {value: 0, complete: true};
    const result = replacementAfterKO(outcome, action, ctx, {pair: pairOutcome, responses: responseOptions, moves: nextMoves, limit});
    return {...result, value: result.value * .52};
  }
  const same = (a, b) => a.ident === b.ident;
  const activeIndex = action.kind === 'switch' ? action.slot - 1 : ctx.roster.indexOf(ctx.own);
  const roster = ctx.roster.map((m, i) => {
    if (i === activeIndex) return {...outcome.own, active: true};
    if (m.active) return {...m, active: false, boosts: {}, volatiles: [], lastMove: null,
      hpFraction: clamp(m.hpFraction + (toID(m.ability) === 'regenerator' ? 1 / 3 : 0)),
      status: toID(m.ability) === 'naturalcure' ? '' : m.status};
    return m;
  });
  const revealed = (ctx.view.opponent?.revealed || []).map(m => same(m, outcome.opponent) ? outcome.opponent :
    same(m, ctx.opponent) ? {...m, boosts: {}, lastMove: null, volatiles: []} : m);
  const opponents = outcome.opponent.hpFraction > 0 ? [outcome.opponent] : revealed.filter(alive)
    .sort((a, b) => {
      const pressure = m => {const s = Dex.species.get(m.species).baseStats; return Math.max(s.atk, s.spa) + s.spe;};
      return pressure(b) - pressure(a) || a.species.localeCompare(b.species);
    }).slice(0, 2).map(m => opponentHypotheses({...m, boosts: {}, lastMove: null, volatiles: []}, ctx.view.format, 1)[0]);
  if (!opponents.length) return {value: 0, complete: true}; // never invent an unrevealed replacement
  let worst = Infinity;
  for (const opponent of opponents) {
    const next = {...ctx, own: roster[activeIndex], opponent, roster,
      view: {...ctx.view, opponent: {...ctx.view.opponent, active: [opponent], revealed}}};
    const sameVisit = action.kind !== 'switch';
    const requests = new Map((sameVisit ? ctx.request.active?.[0]?.moves || [] : []).map(m => [toID(m.id || m.move), m]));
    const moves = nextMoves(next.own, action).filter(a => {
      const request = requests.get(toID(a.move));
      return !request || !request.disabled && (request.pp === undefined || request.pp - Number(toID(a.move) === toID(action.move)) > 0);
    });
    const actions = [...moves];
    const tera = !action.tera && !next.own.terastallized && ctx.request.active?.[0]?.canTerastallize && next.own.teraType;
    if (tera) actions.push(...moves.map(m => ({...m, tera})));
    const types = next.own.terastallized && next.own.terastallized !== 'Stellar'
      ? [next.own.teraType || next.own.terastallized] : Dex.species.get(next.own.species).types;
    const ghostOrShell = types.includes('Ghost') || toID(next.own.item) === 'shedshell';
    const ability = toID(opponent.ability);
    const publicTrap = sameVisit && same(opponent, ctx.opponent) && ctx.request.active?.[0]?.trapped ||
      ability === 'shadowtag' && toID(next.own.ability) !== 'shadowtag' ||
      ability === 'magnetpull' && types.includes('Steel') ||
      ability === 'arenatrap' && typeEffectiveness('Ground', next.own) > 0 && toID(next.own.ability) !== 'levitate' && toID(next.own.item) !== 'airballoon';
    if (ghostOrShell || !publicTrap) roster.forEach((m, i) => {
      if (i !== activeIndex && alive(m)) actions.push({kind: 'switch', slot: i + 1});
    });
    if (!actions.length) actions.push({kind: 'move', move: 'Struggle'});
    const responses = responseOptions(opponent, next.own, next).slice(0, 3);
    let best = -Infinity;
    for (const candidate of actions) {
      let score = 0, weight = 0;
      if (candidate.tera) ctx.deferredTeraEvaluations++;
      for (const response of responses) {
        if (ctx.calculations > limit) return {value: 0, complete: false};
        score += pairOutcome(next.own, opponent, candidate, response, next).score * response.weight;
        weight += response.weight;
      }
      // Discount future battle utility, but pay the entire one-use option cost.
      // Paying half the cost for a deferred Tera would create another bias.
      const value = score / (weight || 1) * .52 - teraOpportunityCost(next, candidate);
      best = Math.max(best, value);
    }
    worst = Math.min(worst, Number.isFinite(best) ? best : 0);
  }
  return {value: Number.isFinite(worst) ? worst : 0, complete: true};
}

function previewChoice(ctx) {
  const enemies = ctx.view.opponent?.revealed || [];
  const scores = ctx.roster.map((mon, index) => {
    let score = 0;
    for (const enemy of enemies) {
      const inferred = opponentHypotheses(enemy, ctx.view.format, 1)[0];
      const offense = Math.max(0, ...(mon.moves || []).map(move => ctx.damage(mon, inferred, move).mean));
      const danger = Math.max(0, ...possibleMoves(enemy, 4, ctx.view.format).map(move => ctx.damage(inferred, mon, move, true).mean));
      score += offense - danger * 0.7;
    }
    if ((mon.moves || []).some(move => ['stealthrock', 'spikes', 'stickyweb'].includes(toID(move)))) score += 0.25;
    if ((mon.moves || []).some(move => ['uturn', 'voltswitch', 'flipturn'].includes(toID(move)))) score += 0.15;
    return {slot: index + 1, score};
  }).sort((a, b) => b.score - a.score);
  return {choice: `team ${scores.map(s => s.slot).join('')}`, reason: 'Lead planned against public team preview; keeps all six teammates.', scores};
}

/** Pure decision boundary: only a serializable player view enters, never an engine or seed. */
export function chooseResourceAction(view, {difficulty = 'Strong', seed = 1, resourcePlanning = false, futureResources = view?.format === 'gen9randombattle', requiredChoice = null} = {}) {
  if ((view.request?.active?.length || view.request?.forceSwitch?.length || 0) > 1 && !view.request?.teamPreview) return chooseDoubles(view,{difficulty,seed});
  const start = performance.now();
  const profile = DIFFICULTIES[difficulty] || DIFFICULTIES.Strong;
  const actions = legalActions(view);
  if (!actions.length) return {choice: null, reason: 'Waiting for a player request.', scores: []};
  const ctx = contextFor(view, profile);
  if(actions[0].kind==='revive') {
    const ranked=actions.map(action=>{const mon=ctx.roster[action.slot-1];const stats=Dex.species.get(mon.species).baseStats;return {...action,score:Math.max(stats.atk,stats.spa)+stats.spe*.6+stats.hp*.3};}).sort((a,b)=>b.score-a.score);
    return {choice:ranked[0].choice,reason:'Revive a teammate with strong remaining offensive potential.',scores:ranked};
  }
  if (view.request.teamPreview) return {...previewChoice(ctx), diagnostics: {calculations: ctx.calculations, ms: performance.now() - start}};
  if (!ctx.own || !ctx.opponent) return {choice: actions[0].choice, reason: 'No opponent is currently revealed.', scores: []};
  const hypotheses = opponentHypotheses(ctx.opponent, view.format || 'gen9ou', profile.hypotheses);
  const totalBelief = hypotheses.reduce((sum, h) => sum + h.weight, 0) || 1;
  const scenarios = hypotheses.flatMap(h => responseOptions(h, ctx.own, ctx).map(response => ({opponent: h, response, weight: h.weight / totalBelief * response.weight})));

  // First evaluate the full public-information response distribution. Very Strong
  // deliberately uses lower-tail and variance information instead of optimizing
  // only the expectation; when a good safe line exists it should not volunteer
  // a high-variance read just because the upside is flashy.
  const scores = actions.map(action => {
    const outcomes = [];
    for (const scenario of scenarios) {
      const outcome = pairOutcome(ctx.own, scenario.opponent, action, scenario.response, ctx, isForced(view.request));
      outcomes.push({outcome, weight: scenario.weight});
    }
    return {...action, outcomes, metrics: outcomeMetrics(outcomes), score: 0, future: 0, teraCost: 0};
  });
  const safety = resourcePlanning ? createTeamSafety(ctx, moveFirst) : null;
  ctx.safetyCalculations = safety?.calculations || 0;
  if (safety) for (const candidate of scores) {
    let adjustment = 0, weight = 0;
    for (const entry of candidate.outcomes) {
      const change = safety.adjustment(entry.outcome, candidate);
      entry.outcome.score += change.score;
      adjustment += change.score * entry.weight; weight += entry.weight;
    }
    candidate.checkCost = -adjustment / (weight || 1);
    candidate.metrics = outcomeMetrics(candidate.outcomes);
  }
  const bestMean = Math.max(...scores.map(candidate => candidate.metrics.mean));
  const teamEdge = materialEdge(ctx);
  const positionSignal = bestMean * 0.65 + teamEdge * 0.8;
  const downsideWeight = clamp(profile.downside + positionSignal / 320, 0.08, 0.58);
  const varianceWeight = profile.variance * (positionSignal >= 0 ? 1.2 : 0.7);
  for (const candidate of scores) {
    const {mean, tail, deviation} = candidate.metrics;
    const miss = actionMissChance(candidate);
    const reliabilityPenalty = miss * profile.reliability * (12 + Math.max(0, bestMean) * 0.08);
    candidate.score = mean * (1 - downsideWeight) + tail * downsideWeight - deviation * varianceWeight - reliabilityPenalty;
  }

  // Charge Tera for its lost future option value. Defensive Tera that actually
  // improves survival earns that cost back; a marginal offensive boost does not.
  const baselines = new Map(scores.filter(candidate => candidate.kind === 'move' && !candidate.tera)
    .map(candidate => [`${toID(candidate.move)}:${candidate.slot || 0}`, candidate]));
  for (const candidate of scores) {
    if (!candidate.tera) continue;
    const baseline = baselines.get(`${toID(candidate.move)}:${candidate.slot || 0}`);
    candidate.teraCost = teraOpportunityCost(ctx, candidate, baseline);
    candidate.score -= candidate.teraCost;
  }
  scores.sort((a, b) => b.score - a.score);

  let eligible = scores, completeLookahead = false;
  ctx.deferredTeraEvaluations = 0;
  const teraAvailable = !!view.request.active?.[0]?.canTerastallize;
  ctx.searchBudget = profile.maxCalculations + (futureResources && teraAvailable && profile.depth < 2 ? 600 :
    futureResources && teraAvailable && difficulty === 'Strong' ? 600 : 0);
  if (futureResources && teraAvailable) {
    // A shallow beam must include an escape and a non-Tera alternative. Otherwise
    // only the immediate Tera leader receives any credit for its next turn.
    const beam = [...new Set([scores.find(a => a.choice === requiredChoice), scores[0], scores.find(a => a.kind === 'move' && !a.tera), scores.find(a => a.kind === 'switch'), ...scores].filter(Boolean))].slice(0, profile.searchWidth);
    const updates = [];
    completeLookahead = true;
    for (const candidate of beam) {
      let value = 0, weight = 0;
      for (const entry of candidate.outcomes) {
        const result = resourceContinuation(entry.outcome, candidate, ctx);
        if (!result.complete) {completeLookahead = false; break;}
        value += result.value * entry.weight; weight += entry.weight;
      }
      if (!completeLookahead) break;
      updates.push({candidate, value: value / (weight || 1)});
    }
    if (completeLookahead) {
      for (const {candidate, value} of updates) {candidate.future = value; candidate.score += value;}
      eligible = beam.sort((a, b) => b.score - a.score);
    }
    // An incomplete depth is discarded as a whole, never assigned to only the
    // early candidates while their alternatives silently keep a zero future.
    scores.sort((a, b) => b.score - a.score);
  } else if (profile.depth > 1) {
    for (const candidate of scores.slice(0, profile.searchWidth)) {
      if (ctx.calculations > profile.maxCalculations + ctx.safetyCalculations) break;
      let future = 0, weight = 0;
      for (const result of candidate.outcomes) {
        if (ctx.calculations > profile.maxCalculations + ctx.safetyCalculations) break;
        future += continuation(result.outcome, candidate, ctx) * result.weight;
        weight += result.weight;
      }
      candidate.future = future / (weight || 1);
      candidate.score += candidate.future * 0.52;
    }
    scores.sort((a, b) => b.score - a.score);
  }

  // Mix only between genuinely close robust lines. The seed makes this
  // reproducible for tests while avoiding a perfectly exploitable fixed policy.
  const best = chooseMixed(eligible, profile, seed, view.turn);
  const selectedRank = eligible.indexOf(best) + 1;
  const actionDescription = best.kind === 'switch' ? `Switch to ${ctx.roster[best.slot - 1].species}` : `${best.tera ? `Tera ${best.tera}, then ` : ''}${Dex.moves.get(best.move).name}`;
  const orderedScores = eligible === scores ? scores : [...eligible, ...scores.filter(a => !eligible.includes(a))];
  return {choice: best.choice, reason: `${actionDescription}: robust value across ${scenarios.length} public-information responses${selectedRank > 1 ? ' (mixed among near-equal strong lines)' : ''}.`,
    scores: orderedScores.map(({choice, score, metrics, teraCost, checkCost}) => ({choice, score: Math.round(score * 100) / 100,
      tail: Math.round(metrics.tail * 100) / 100, deviation: Math.round(metrics.deviation * 100) / 100,
      ownKO: metrics.ownKO, ownHP: metrics.ownHP,
      teraCost: teraCost ? Math.round(teraCost * 100) / 100 : 0, checkCost: Math.round((checkCost || 0) * 100) / 100})),
    diagnostics: {policy: 'risk-calibrated-belief-search-v4', difficulty, hypotheses: hypotheses.length, scenarios: scenarios.length,
      downsideWeight: Math.round(downsideWeight * 1000) / 1000, varianceWeight: Math.round(varianceWeight * 1000) / 1000,
      materialEdge: Math.round(teamEdge * 10) / 10, selectedRank, calculations: ctx.calculations, calcFailures: ctx.failures, budget: ctx.searchBudget + ctx.safetyCalculations,
      teamSafety: safety ? {calculations: safety.calculations, threats: safety.threats} : null,
      futureResources: !!futureResources, completeLookahead, deferredTeraEvaluations: ctx.deferredTeraEvaluations,
      ms: Math.round((performance.now() - start) * 10) / 10}};
}

/** Experimental corrected-base policy; review the one-use commitment only. */
export function chooseGuardedResourceAction(view, options = {}) {
  if (options.strategy === 'full' || options.resourcePlanning) return chooseResourceAction(view, options);
  const baseline = chooseStableAction(view, options);
  if (view.format !== 'gen9randombattle' || options.strategy === 'baseline' || !baseline.choice?.includes('terastallize')) return baseline;
  try {
    const planned = chooseResourceAction(view, {...options, requiredChoice: baseline.choice});
    const alternative = planned.scores.find(s => s.choice === planned.choice), tera = planned.scores.find(s => s.choice === baseline.choice);
    const accepted = !!planned.diagnostics.completeLookahead && !planned.choice.includes('terastallize') &&
      alternative.score >= tera.score && alternative.ownKO <= tera.ownKO + 1e-9;
    const review = {accepted, baselineChoice: baseline.choice, alternative: planned.choice,
      complete: planned.diagnostics.completeLookahead, margin: alternative.score - tera.score,
      baselineKO: tera.ownKO, alternativeKO: alternative.ownKO, fullTeraCost: tera.teraCost,
      livingTeam: (view.request.side?.pokemon || []).filter(alive).length,
      reason: accepted ? 'better conserving line at no greater immediate KO risk' : !planned.diagnostics.completeLookahead ? 'incomplete review' :
        planned.choice.includes('terastallize') ? 'Tera remains best' : alternative.ownKO > tera.ownKO + 1e-9 ? 'increased immediate KO risk' : 'insufficient value'};
    const result = accepted ? planned : baseline;
    return {...result, diagnostics: {...result.diagnostics, policy: 'randbats-guarded-resource-v1', resourceReview: review}};
  } catch (error) {
    return {...baseline, diagnostics: {...baseline.diagnostics, resourceReview: {accepted: false, error: String(error.message)}}};
  }
}

/** Promoted only for the tested format/tier after two fresh matched runs:
 * reports/randbats-set-priors-strength-gate-2026-11-10.json. Other tiers/formats
 * retain f652196; arbitrary research flags cannot select another controller. */
export function chooseAction(view, options = {}) {
  if (view?.format === 'gen9randombattle' && options.difficulty === 'Very Strong') return choosePublicSetResourceAction(view, options);
  return chooseFrozenDefault(view, options);
}

/** Development baselines only; these are not user-facing difficulty levels. */
export function chooseBaseline(view, {policy = 'greedy', seed = 1} = {}) {
  const actions = legalActions(view);
  if (!actions.length) return {choice: null};
  if (policy === 'random') {
    let value = (seed + (view.turn || 0) * 0x9e3779b9 + (view.request.rqid || 0)) >>> 0;
    value ^= value << 13; value ^= value >>> 17; value ^= value << 5;
    return {choice: actions[(value >>> 0) % actions.length].choice};
  }
  const ctx = contextFor(view, DIFFICULTIES.Medium);
  if (view.request.teamPreview) return {choice: actions[0].choice};
  const enemy = ctx.opponent && opponentHypotheses(ctx.opponent, view.format, 1)[0];
  const moves = actions.filter(action => action.kind === 'move');
  if (enemy && moves.length) {
    moves.sort((a, b) => ctx.damage(ctx.own, enemy, b.move).mean - ctx.damage(ctx.own, enemy, a.move).mean);
    return {choice: moves[0].choice};
  }
  return {choice: actions[0].choice};
}

export {damageEstimate, possibleMoves, opponentHypotheses};
