// Experimental input contract. v2 remains available for existing deployed models.
export const OBSERVATION_VERSION = 3;
export const TOKEN_COUNT = 42;
export const CAT_FEATURES = 12;
export const NUM_FEATURES = 52;
export const HISTORY_TOKEN_START = 26;
export const HISTORY_TOKEN_COUNT = 16;
export const ROLE_STRIDE = 2050; // PAD=0, role-local UNK=1, 2048 hashed known values
export const HASH_BUCKETS = CAT_FEATURES * ROLE_STRIDE - 1;
export const TOKEN_KIND_MAX = 8;
export const CATEGORY_ENCODING = 'disjoint-field-roles-2050-v1';
