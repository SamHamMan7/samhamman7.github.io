import {chooseNeuralPreview} from './experimental.js';

/** Keep the normal worker path synchronous except for the opt-in preview. */
export async function chooseWorkerAction(data, {chooseAction, legalActions}) {
  if (data?.difficulty !== 'Neural Preview') {
    return chooseAction(data.view, {difficulty: data.difficulty, seed: data.seed});
  }
  return chooseNeuralPreview(data.view, {
    seed: data.seed,
    chooseAction,
    legalActions,
  });
}
