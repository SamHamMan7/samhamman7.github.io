import {validateOnnxManifest, verifyModelBytes, onnxSessionBackend, LOCAL_MANIFEST_URL, MAX_MODEL_BYTES} from './onnx-common.js';
import {createBeliefBackend, validateBeliefManifest} from './belief-model.js';
import {withBeliefs} from './with-beliefs.js';

async function localFetch(fetchImpl, url, kind) {
  const response = await fetchImpl(url, {credentials: 'same-origin', redirect: 'error', cache: 'no-cache', signal: AbortSignal.timeout(30000)});
  if (!response.ok) throw new Error(`Local ONNX ${kind} unavailable: HTTP ${response.status}`);
  return response;
}

/** All model/runtime resources resolve on the APK/browser's local origin. */
export async function createBrowserOnnxBackend({ort, fetch: fetchImpl = globalThis.fetch,
  crypto: cryptoImpl = globalThis.crypto, manifestUrl = LOCAL_MANIFEST_URL, wasmPath = '/ort/'} = {}) {
  if (manifestUrl !== LOCAL_MANIFEST_URL) throw new Error('Only the bundled Random Battle ONNX manifest may be loaded');
  if (typeof wasmPath !== 'string' || !/^\/[A-Za-z0-9_/-]+\/$/.test(wasmPath) || wasmPath.startsWith('//') || wasmPath.includes('..')) {
    throw new Error('ONNX WASM path must be an absolute local directory');
  }
  if (typeof fetchImpl !== 'function' || !cryptoImpl?.subtle) throw new Error('Local fetch and Web Crypto are required for ONNX inference');
  const response = await localFetch(fetchImpl, manifestUrl, 'manifest');
  const text = await response.text();
  if (text.length > 256 * 1024) throw new Error('ONNX manifest is too large');
  const manifest = validateOnnxManifest(JSON.parse(text));
  const modelResponse = await localFetch(fetchImpl, '/models/gen9randombattle/' + manifest.model, 'model');
  const size = Number(modelResponse.headers.get('content-length'));
  if (size > MAX_MODEL_BYTES) throw new Error('ONNX model is too large');
  const bytes = new Uint8Array(await modelResponse.arrayBuffer());
  await verifyModelBytes(bytes, manifest, async value => {
    const hash = await cryptoImpl.subtle.digest('SHA-256', value);
    return [...new Uint8Array(hash)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  });
  const runtime = ort || await import('onnxruntime-web/wasm');
  // A dedicated AI worker already isolates inference. One WASM thread works
  // without SharedArrayBuffer/COOP/COEP and avoids ORT spawning proxy workers.
  runtime.env.wasm.numThreads = 1;
  runtime.env.wasm.proxy = false;
  runtime.env.wasm.wasmPaths = wasmPath;
  const session = await runtime.InferenceSession.create(bytes, {executionProviders: ['wasm'], graphOptimizationLevel: 'all'});
  try {
    const policy=onnxSessionBackend({ort: runtime, session, manifest, runtime: 'onnxruntime-web-wasm'});
    if(!manifest.beliefs)return policy;
    try {
      const response=await localFetch(fetchImpl,'/models/gen9randombattle/'+manifest.beliefs,'belief manifest');
      const contents=await response.text();
      if(contents.length>256*1024)throw new Error('Belief manifest is too large');
      const beliefManifest=validateBeliefManifest(JSON.parse(contents));
      const responseModel=await localFetch(fetchImpl,'/models/gen9randombattle/'+beliefManifest.model,'belief model');
      if(Number(responseModel.headers.get('content-length'))>32*1024*1024)throw new Error('Belief model is too large');
      const beliefs=await createBeliefBackend({ort:runtime,manifest:beliefManifest,bytes:new Uint8Array(await responseModel.arrayBuffer()),
        digest:async value=>[...new Uint8Array(await cryptoImpl.subtle.digest('SHA-256',value))].map(b=>b.toString(16).padStart(2,'0')).join(''),
        sessionOptions:{executionProviders:['wasm'],graphOptimizationLevel:'all'},runtime:'onnxruntime-web-wasm'});
      return withBeliefs(policy,beliefs);
    }catch(error){return withBeliefs(policy,null,String(error.message||error));}
  }
  catch (error) {await session.release?.(); throw error;}
}

/** No imports, model reads or fetches happen until the first explicit load(). */
export function createLazyBrowserOnnxBackend(options = {}) {
  let pending;
  return {
    load() { return pending ||= createBrowserOnnxBackend(options); },
    async predict(observation) {return (await this.load()).predict(observation);},
    async dispose() {if (pending) await (await pending).dispose();},
  };
}

export {LOCAL_MANIFEST_URL};
