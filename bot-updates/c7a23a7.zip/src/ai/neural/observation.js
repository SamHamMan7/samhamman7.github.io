import {publicIdentity} from '../../core/public-identity.js';
import {
  OBSERVATION_VERSION, TOKEN_COUNT, CAT_FEATURES, NUM_FEATURES,
  HASH_BUCKETS, TOKEN_KIND, HISTORY_TOKEN_START, HISTORY_TOKEN_COUNT, HISTORY_EVENT_TYPES,
} from './contract.js';
import {legalMask} from './action-space.js';

const STATUS = new Map([['', 0], ['brn', 1], ['par', 2], ['psn', 3], ['tox', 4], ['slp', 5], ['frz', 6], ['fnt', 7]]);
const BOOST_KEYS = ['atk', 'def', 'spa', 'spd', 'spe', 'accuracy', 'evasion'];
const HISTORY_TYPES = new Set(HISTORY_EVENT_TYPES);
const EXACT_STATS = ['atk', 'def', 'spa', 'spd', 'spe'];

function toID(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}

/** Stable FNV-1a hash. Zero is reserved for unknown/padding. */
export function hashFeature(namespace, value) {
  const id = toID(value);
  if (!id) return 0;
  const text = `${namespace}:${id}`;
  let hash = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return ((hash >>> 0) % HASH_BUCKETS) + 1;
}

function conditionParts(mon) {
  const condition = String(mon?.condition || '');
  const fainted = Boolean(mon?.fainted) || /\bfnt\b/.test(condition);
  let hp = Number.isFinite(mon?.hpFraction) ? Number(mon.hpFraction) : null;
  if (hp === null) {
    const match = condition.match(/(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)/);
    hp = match ? Number(match[1]) / Math.max(1, Number(match[2])) : (fainted ? 0 : 1);
  }
  hp = Math.max(0, Math.min(1, hp));
  let status = toID(mon?.status);
  if (!status) {
    const match = condition.match(/\b(brn|par|psn|tox|slp|frz|fnt)\b/i);
    status = toID(match?.[1]);
  }
  return {hp, fainted, status};
}

function speciesName(mon) {
  if (mon?.species) return mon.species;
  if (mon?.speciesForme) return mon.speciesForme;
  const details = String(mon?.details || '');
  if (details) return details.split(',')[0].trim();
  return mon?.name || mon?.ident || '';
}

function normalizeBoost(value) {
  return Math.max(-6, Math.min(6, Number(value) || 0)) / 6;
}

function pokemonToken(mon, kind, {knownExact = false} = {}) {
  const {hp, fainted, status} = conditionParts(mon);
  const types = Array.isArray(mon?.types) ? mon.types : [];
  const boosts = mon?.boosts || {};
  const cats = Array(CAT_FEATURES).fill(0);
  cats[0] = hashFeature('species', speciesName(mon));
  cats[1] = hashFeature('item', mon?.item);
  cats[2] = hashFeature('ability', mon?.ability);
  cats[3] = hashFeature('type', types[0]);
  cats[4] = hashFeature('type', types[1]);
  // Own Tera is known; an opponent's type is only public after activation.
  const tera = knownExact || mon?.terastallized ? mon?.teraType || mon?.terastallized : '';
  cats[5] = hashFeature('teratype', typeof tera === 'string' ? tera : '');
  cats[6] = hashFeature('status', status);
  cats[7] = hashFeature('role', mon?.role);
  if (knownExact) {
    const moves = Array.isArray(mon?.moves) ? mon.moves : [];
    for (let i = 0; i < 4; i++) cats[8 + i] = hashFeature('move', moveName(moves[i]));
  }

  const nums = Array(NUM_FEATURES).fill(0);
  nums[0] = hp;
  nums[1] = Math.max(0, Math.min(1.5, (Number(mon?.level) || Number(String(mon?.details || '').match(/, L(\d+)/)?.[1]) || 100) / 100));
  nums[2] = mon?.active ? 1 : 0;
  nums[3] = fainted ? 1 : 0;
  nums[4] = mon?.item ? 1 : 0;
  nums[5] = mon?.ability ? 1 : 0;
  nums[6] = (mon?.terastallized || mon?.teraUsed) ? 1 : 0;
  BOOST_KEYS.forEach((key, index) => { nums[7 + index] = normalizeBoost(boosts[key]); });
  nums[14] = knownExact ? 1 : 0;
  nums[15] = status && status !== 'fnt' ? 1 : 0;
  // Own request stats are legal private information. Opponent exact stat slots stay zero.
  if (knownExact) {
    const maxHP = Number(String(mon?.condition || '').match(/^\d+\/(\d+)/)?.[1]);
    nums[16] = Number.isFinite(maxHP) ? Math.max(0, Math.min(2, maxHP / 1000)) : 0;
    EXACT_STATS.forEach((key, i) => {
      const stat = Number(mon?.stats?.[key]);
      nums[17 + i] = Number.isFinite(stat) ? Math.max(0, Math.min(2, stat / 1000)) : 0;
    });
  }
  return {kind, cats, nums};
}

function moveName(entry) {
  if (typeof entry === 'string') return entry;
  return entry?.id || entry?.move || entry?.name || '';
}

function moveToken(entry, kind, {revealed = false} = {}) {
  const cats = Array(CAT_FEATURES).fill(0);
  const nums = Array(NUM_FEATURES).fill(0);
  cats[0] = hashFeature('move', moveName(entry));
  nums[0] = Number.isFinite(entry?.pp) && Number.isFinite(entry?.maxpp) && entry.maxpp > 0 ? entry.pp / entry.maxpp : 0;
  nums[1] = entry?.disabled ? 1 : 0;
  nums[2] = revealed ? 1 : 0;
  return {kind, cats, nums};
}

function samePokemon(a, b) {
  if (!a || !b) return false;
  // Requests name the party member (p1: name); public events name its active
  // position (p1a: name). Keep the side/name, remove ONLY the active letter.
  if (a.ident && b.ident) return publicIdentity(a.ident) !== null && publicIdentity(a.ident) === publicIdentity(b.ident);
  const as = toID(speciesName(a)), bs = toID(speciesName(b));
  return Boolean(as && as === bs && Boolean(a.active) === Boolean(b.active));
}

/**
 * Public opponent roster only. Intentionally ignores every unrecognized/secret field.
 * Active public data is merged into the matching revealed slot where possible.
 */
function publicOpponentRoster(view) {
  const revealed = Array.isArray(view?.opponent?.revealed) ? view.opponent.revealed : [];
  const activeRaw = view?.opponent?.active;
  const active = Array.isArray(activeRaw) ? activeRaw.filter(Boolean) : (activeRaw ? [activeRaw] : []);
  const roster = revealed.slice(0, 6).map(mon => ({...mon}));
  for (const mon of active) {
    const index = roster.findIndex(item => samePokemon(item, mon));
    if (index >= 0) roster[index] = {...roster[index], ...mon, active: true};
    else if (roster.length < 6) roster.push({...mon, active: true});
  }
  return roster.slice(0, 6);
}

function ownRoster(view) {
  const request = view?.request || {};
  const side = Array.isArray(request?.side?.pokemon) ? request.side.pokemon : [];
  const publicActiveRaw = view?.own?.active;
  const publicActive = Array.isArray(publicActiveRaw) ? publicActiveRaw.filter(Boolean) : (publicActiveRaw ? [publicActiveRaw] : []);
  return side.slice(0, 6).map(mon => {
    const publicMon = mon.active ? publicActive.find(item => samePokemon(item, mon)) : undefined;
    // Own set supplies defaults only; current request fields (including empty item)
    // are authoritative over both defaults and the accumulated public state.
    return {
      ...mon.ownSet, ...publicMon, ...mon,
      ability: mon.ability ?? publicMon?.ability ?? mon.baseAbility ?? mon.ownSet?.ability,
      active: Boolean(mon.active || publicMon?.active),
    };
  });
}

function globalToken(view, own, opponent) {
  const field = view?.field || {};
  const request = view?.request || {};
  const cats = Array(CAT_FEATURES).fill(0);
  const nums = Array(NUM_FEATURES).fill(0);
  cats[0] = hashFeature('format', view?.format);
  cats[1] = hashFeature('weather', field.weather);
  cats[2] = hashFeature('terrain', field.terrain);
  cats[3] = hashFeature('pseudoweather', Array.isArray(field.pseudoWeather) ? field.pseudoWeather.map(x => x?.id || x).sort().join('-') : '');
  const hazards = values => Array.isArray(values) ? values.map(value => toID(value?.id || value)).sort().join('-') : '';
  cats[4] = hashFeature('sideconditions', hazards(field.sideConditions));
  cats[5] = hashFeature('sideconditions', hazards(field.opponentSideConditions));
  nums[0] = Math.max(0, Math.min(1, (Number(view?.turn) || 0) / 100));
  nums[1] = own.filter(mon => !conditionParts(mon).fainted).length / 6;
  nums[2] = opponent.filter(mon => !conditionParts(mon).fainted).length / 6;
  nums[3] = opponent.length / 6;
  nums[4] = request?.active?.[0]?.canTerastallize ? 1 : 0;
  nums[5] = request?.forceSwitch?.some(Boolean) ? 1 : 0;
  nums[6] = request?.wait ? 1 : 0;
  nums[7] = request?.teamPreview ? 1 : 0;
  nums[8] = field.trickRoom || field?.pseudoWeather?.trickroom ? 1 : 0;
  return {kind: TOKEN_KIND.GLOBAL, cats, nums};
}

function historyToken(event, turn) {
  const cats = Array(CAT_FEATURES).fill(0);
  const nums = Array(NUM_FEATURES).fill(0);
  const side = value => value === 'own' || value === 'opponent' ? value : '';
  // Fixed allowlist: never hash a raw line, request, nickname, or nested object.
  const feature = (namespace, value) => typeof value === 'string' ? hashFeature(namespace, value.slice(0, 80)) : 0;
  cats[0] = hashFeature('event', event.type);
  cats[1] = hashFeature('side', side(event.actor));
  cats[2] = feature('species', event.species);
  cats[3] = feature('move', event.move);
  cats[4] = hashFeature('side', side(event.target));
  cats[5] = feature('species', event.targetSpecies);
  cats[6] = feature('historyeffect', event.effect);
  cats[7] = STATUS.has(event.status) ? hashFeature('status', event.status) : 0;
  nums[0] = Math.max(0, Math.min(HISTORY_TOKEN_COUNT, turn - event.turn)) / HISTORY_TOKEN_COUNT;
  nums[1] = side(event.actor) && Number.isInteger(event.slot) && event.slot >= 0 && event.slot < 3 ? (event.slot + 1) / 3 : 0;
  nums[2] = side(event.target) && Number.isInteger(event.targetSlot) && event.targetSlot >= 0 && event.targetSlot < 3 ? (event.targetSlot + 1) / 3 : 0;
  // Re-quantize defensively; precise HP cannot cross the history contract.
  const publicHP = value => value === 1 ? 1 : Math.max(0, Math.min(99, Math.ceil(value * 100 - 1e-10))) / 100;
  const hasHP = Number.isFinite(event.hp) && event.hp >= 0 && event.hp <= 1;
  const hasBefore = Number.isFinite(event.hpBefore) && event.hpBefore >= 0 && event.hpBefore <= 1;
  nums[3] = hasHP ? publicHP(event.hp) : 0;
  nums[4] = hasBefore ? publicHP(event.hpBefore) : 0;
  nums[5] = hasHP && hasBefore ? Math.round((nums[3] - nums[4]) * 100) / 100 : 0;
  nums[6] = hasHP ? 1 : 0;
  nums[7] = hasBefore ? 1 : 0;
  nums[8] = normalizeBoost(event.amount);
  nums[9] = Number.isFinite(event.amount) ? 1 : 0;
  return {kind: TOKEN_KIND.HISTORY, cats, nums};
}

function writeToken(output, index, token) {
  if (index < 0 || index >= TOKEN_COUNT || !token) return;
  output.tokenKinds[index] = token.kind;
  output.tokenMask[index] = 1;
  output.categorical[index] = token.cats;
  output.numeric[index] = token.nums;
}

/**
 * Encode ONLY the player's serializable public view plus their own request.
 * Unknown opponent slots stay zero/padded. No simulator/battle object is accepted.
 */
export function encodeObservation(view, actions = []) {
  const own = ownRoster(view);
  const opponent = publicOpponentRoster(view);
  const output = {
    version: OBSERVATION_VERSION,
    tokenKinds: Array(TOKEN_COUNT).fill(TOKEN_KIND.PAD),
    tokenMask: Array(TOKEN_COUNT).fill(0),
    categorical: Array.from({length: TOKEN_COUNT}, () => Array(CAT_FEATURES).fill(0)),
    numeric: Array.from({length: TOKEN_COUNT}, () => Array(NUM_FEATURES).fill(0)),
    legalMask: legalMask(actions),
    meta: {
      format: String(view?.format || ''),
      turn: Number(view?.turn) || 0,
      rqid: Number(view?.request?.rqid) || 0,
    },
  };

  writeToken(output, 0, globalToken(view, own, opponent));
  for (let i = 0; i < 6; i++) if (own[i]) writeToken(output, 1 + i, pokemonToken(own[i], TOKEN_KIND.OWN_POKEMON, {knownExact: true}));
  for (let i = 0; i < 6; i++) if (opponent[i]) writeToken(output, 7 + i, pokemonToken(opponent[i], TOKEN_KIND.OPPONENT_POKEMON));

  const activeMoves = view?.request?.active?.[0]?.moves || [];
  for (let i = 0; i < Math.min(4, activeMoves.length); i++) writeToken(output, 13 + i, moveToken(activeMoves[i], TOKEN_KIND.OWN_MOVE, {revealed: true}));

  const opponentActive = opponent.find(mon => mon.active) || opponent[0];
  const seenMoves = opponentActive?.movesSeen || [];
  for (let i = 0; i < Math.min(4, seenMoves.length); i++) writeToken(output, 17 + i, moveToken(seenMoves[i], TOKEN_KIND.OPPONENT_MOVE, {revealed: true}));

  const turn = Number(view?.turn) || 0;
  const history = Array.isArray(view?.history) ? view.history.filter(event =>
    event && typeof event === 'object' && HISTORY_TYPES.has(event.type) &&
    Number.isInteger(event.turn) && event.turn >= 0 && event.turn <= turn && turn - event.turn <= HISTORY_TOKEN_COUNT
  ).slice(-HISTORY_TOKEN_COUNT) : [];
  for (let i = 0; i < history.length; i++) writeToken(output, HISTORY_TOKEN_START + i, historyToken(history[i], turn));
  return output;
}
