import * as V3 from './contract-v3.js';
import {OBSERVATION_VERSION, ACTION_COUNT, TOKEN_COUNT, CAT_FEATURES, NUM_FEATURES, HASH_BUCKETS, TOKEN_KIND, MATCHUP_VERSION, MATCHUP_FEATURES} from './contract.js';

export const LOCAL_MANIFEST_URL = '/models/gen9randombattle/manifest.json';
export const MAX_MODEL_BYTES = 128 * 1024 * 1024;
const INPUT_NAMES = ['token_kinds', 'categorical', 'numeric', 'token_mask', 'legal_mask'];
const EXPECTED_OUTPUTS = {policy: 'policy_logits', value: 'value_logit', opponentPolicy: 'opponent_policy_logits'};
const isArray = value => Array.isArray(value) || (ArrayBuffer.isView(value) && !(value instanceof DataView));

function contract(version) {
  if(version===3)return V3;
  if(version===2)return {OBSERVATION_VERSION,TOKEN_COUNT,CAT_FEATURES,NUM_FEATURES,HASH_BUCKETS,TOKEN_KIND_MAX:6};
  throw new Error(`Unsupported observation version: ${version}`);
}
export function validateOnnxManifest(manifest) {
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) throw new Error('ONNX manifest must be an object');
  const {OBSERVATION_VERSION,TOKEN_COUNT,CAT_FEATURES,NUM_FEATURES,HASH_BUCKETS}=contract(manifest.observationVersion);
  if(manifest.observationVersion===3&&manifest.categoryEncoding!==V3.CATEGORY_ENCODING)throw new Error('ONNX v3 category encoding mismatch');
  const expected = {schemaVersion: 1, observationVersion: OBSERVATION_VERSION, format: 'gen9randombattle',
    actionCount: ACTION_COUNT, tokenCount: TOKEN_COUNT, catFeatures: CAT_FEATURES, numFeatures: NUM_FEATURES, hashBuckets: HASH_BUCKETS};
  for (const [key, value] of Object.entries(expected)) {
    if (manifest[key] !== value) throw new Error(`ONNX manifest ${key} mismatch: expected ${value}`);
  }
  if (manifest.trained !== true) throw new Error('ONNX manifest does not identify a trained checkpoint');
  if ((manifest.matchupVersion !== undefined || manifest.matchupFeatures !== undefined) &&
      (manifest.matchupVersion !== MATCHUP_VERSION || manifest.matchupFeatures !== MATCHUP_FEATURES)) throw new Error('ONNX matchup contract mismatch');
  if (typeof manifest.model !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]*\.onnx$/.test(manifest.model) || manifest.model.includes('..')) {
    throw new Error('ONNX model must be a local .onnx filename without directories or URLs');
  }
  if (typeof manifest.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(manifest.sha256)) throw new Error('ONNX manifest requires a SHA-256 model hash');
  if (manifest.bytes !== undefined && (!Number.isInteger(manifest.bytes) || manifest.bytes < 1 || manifest.bytes > MAX_MODEL_BYTES)) throw new Error('ONNX model size is invalid');
  if (manifest.checkpointHash !== undefined && !/^[a-f0-9]{64}$/i.test(manifest.checkpointHash)) throw new Error('ONNX checkpoint hash is invalid');
  if (manifest.beliefs !== undefined && (typeof manifest.beliefs !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]*\.json$/.test(manifest.beliefs) || manifest.beliefs.includes('..'))) throw new Error('Belief manifest must be a local JSON filename');
  for (const [key, value] of Object.entries(EXPECTED_OUTPUTS)) {
    if (manifest.outputs?.[key] !== value) throw new Error(`ONNX output contract mismatch: ${key}`);
  }
  if (Object.keys(manifest.outputs).some(key => !(key in EXPECTED_OUTPUTS))) throw new Error('Unsupported ONNX output head');
  return manifest;
}

export async function verifyModelBytes(bytes, manifest, digest) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength === 0 || bytes.byteLength > MAX_MODEL_BYTES) throw new Error('ONNX model bytes are empty or too large');
  if (manifest.bytes !== undefined && bytes.byteLength !== manifest.bytes) throw new Error('ONNX model byte count mismatch');
  const hash = await digest(bytes);
  if (hash.toLowerCase() !== manifest.sha256.toLowerCase()) throw new Error('ONNX model SHA-256 mismatch');
}

function vector(value, length, name, valid) {
  if (!isArray(value) || value.length !== length) throw new Error(`ONNX observation ${name} must have length ${length}`);
  const result = Array.from(value);
  if (!result.every(valid)) throw new Error(`ONNX observation ${name} contains invalid values`);
  return result;
}

function matrix(value, rows, cols, name, valid) {
  if (!Array.isArray(value) || value.length !== rows) throw new Error(`ONNX observation ${name} must have ${rows} rows`);
  return value.flatMap((row, index) => vector(row, cols, `${name}[${index}]`, valid));
}

/** Tensor conversion accepts only the fixed public observation, never a battle object. */
export function observationFeeds(ort, observation, manifest = {}) {
  const version=manifest.observationVersion??2;
  if (observation?.version !== version) throw new Error(`Unsupported observation version: ${observation?.version}; model expects ${version}`);
  const {TOKEN_COUNT,CAT_FEATURES,NUM_FEATURES,HASH_BUCKETS,TOKEN_KIND_MAX}=contract(version);
  if(version===3&&observation.categoryEncoding!==V3.CATEGORY_ENCODING)throw new Error('Observation v3 category encoding mismatch');
  if (observation.meta?.format !== 'gen9randombattle') throw new Error('ONNX backend supports only gen9randombattle');
  const integer = value => Number.isSafeInteger(value) && value >= 0;
  const bit = value => value === 0 || value === 1 || value === false || value === true;
  const finite = value => typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= 3.4028234663852886e38;
  const kinds = vector(observation.tokenKinds, TOKEN_COUNT, 'tokenKinds', value => integer(value) && value <= TOKEN_KIND_MAX);
  const categories = matrix(observation.categorical, TOKEN_COUNT, CAT_FEATURES, 'categorical', value => integer(value) && value <= HASH_BUCKETS);
  if(version===3&&categories.some((value,i)=>value!==0&&Math.floor(value/V3.ROLE_STRIDE)!==i%CAT_FEATURES))throw new Error('Observation v3 categorical role mismatch');
  const numeric = matrix(observation.numeric, TOKEN_COUNT, NUM_FEATURES, 'numeric', finite);
  const mask = vector(observation.tokenMask, TOKEN_COUNT, 'tokenMask', bit);
  const legal = vector(observation.legalMask, ACTION_COUNT, 'legalMask', bit);
  if (!mask[0] || !mask.some(Boolean)) throw new Error('ONNX observation must contain its global token');
  if (!legal.some(Boolean)) throw new Error('ONNX observation has no legal actions');
  const candidate = manifest.matchupVersion ? matrix(observation.candidateFeatures, ACTION_COUNT, MATCHUP_FEATURES, 'candidateFeatures', value=>finite(value)&&Math.abs(value)<=4) : null;
  if (candidate && observation.matchupVersion !== MATCHUP_VERSION) throw new Error('ONNX observation matchup version mismatch');
  return {
    token_kinds: new ort.Tensor('int64', BigInt64Array.from(kinds, BigInt), [1, TOKEN_COUNT]),
    categorical: new ort.Tensor('int64', BigInt64Array.from(categories, BigInt), [1, TOKEN_COUNT, CAT_FEATURES]),
    numeric: new ort.Tensor('float32', Float32Array.from(numeric), [1, TOKEN_COUNT, NUM_FEATURES]),
    token_mask: new ort.Tensor('bool', Uint8Array.from(mask, Number), [1, TOKEN_COUNT]),
    legal_mask: new ort.Tensor('bool', Uint8Array.from(legal, Number), [1, ACTION_COUNT]),
    ...(candidate ? {candidate_features:new ort.Tensor('float32',Float32Array.from(candidate),[1,ACTION_COUNT,MATCHUP_FEATURES])}:{}),
  };
}

function outputVector(tensor, name, dimensions) {
  if (!tensor || !['float32', 'float64'].includes(tensor.type) || !isArray(tensor.data)) throw new Error(`ONNX output ${name} must be a float tensor`);
  if (!Array.isArray(tensor.dims) || tensor.dims.length !== dimensions.length || tensor.dims.some((size, index) => size !== dimensions[index])) {
    throw new Error(`ONNX output ${name} has incorrect dimensions`);
  }
  return vector(tensor.data, dimensions.reduce((a, b) => a * b, 1), name, value => typeof value === 'number' && Number.isFinite(value));
}

export function decodeOnnxOutputs(outputs, manifest) {
  const policyLogits = outputVector(outputs[manifest.outputs.policy], 'policy_logits', [1, ACTION_COUNT]);
  const opponentPolicyLogits = outputVector(outputs[manifest.outputs.opponentPolicy], 'opponent_policy_logits', [1, ACTION_COUNT]);
  const [logit] = outputVector(outputs[manifest.outputs.value], 'value_logit', [1]);
  // Stable sigmoid: the exported model returns a logit, not an already calibrated probability.
  const value = logit >= 0 ? 1 / (1 + Math.exp(-logit)) : Math.exp(logit) / (1 + Math.exp(logit));
  return {policyLogits, value, opponentPolicyLogits};
}

/** Real ORT session wrapper shared by native Node and browser/WASM runtimes. */
export function onnxSessionBackend({ort, session, manifest, runtime}) {
  validateOnnxManifest(manifest);
  const inputNames = manifest.matchupVersion ? [...INPUT_NAMES,'candidate_features'] : INPUT_NAMES;
  if (!ort?.Tensor || !session?.run) throw new Error('A valid ONNX Runtime session is required');
  if (!Array.isArray(session.inputNames) || session.inputNames.length !== inputNames.length || inputNames.some(name => !session.inputNames.includes(name))) {
    throw new Error('ONNX model input names do not match the observation contract');
  }
  const outputNames = Object.values(manifest.outputs);
  if (!Array.isArray(session.outputNames) || session.outputNames.length !== outputNames.length || outputNames.some(name => !session.outputNames.includes(name))) {
    throw new Error('ONNX model output names do not match the policy/value/opponent contract');
  }
  const c=contract(manifest.observationVersion);
  const shapes={token_kinds:[c.TOKEN_COUNT],categorical:[c.TOKEN_COUNT,c.CAT_FEATURES],numeric:[c.TOKEN_COUNT,c.NUM_FEATURES],token_mask:[c.TOKEN_COUNT],legal_mask:[ACTION_COUNT],candidate_features:[ACTION_COUNT,MATCHUP_FEATURES]};
  if(manifest.observationVersion===3&&!Array.isArray(session.inputMetadata))throw new Error('v3 ONNX requires graph input metadata for version validation');
  if(Array.isArray(session.inputMetadata))for(const input of session.inputMetadata) {
    const expected=shapes[input.name];
    if(expected&&(!input.isTensor||input.shape.length!==expected.length+1||expected.some((v,i)=>input.shape[i+1]!==v)))
      throw new Error(`ONNX graph shape/version mismatch: ${input.name}`);
  }
  let disposed = false;
  return {
    metadata: Object.freeze({runtime, model: manifest.model, observationVersion: manifest.observationVersion, sha256: manifest.sha256, trained: true, matchupVersion:manifest.matchupVersion||null}),
    async predict(observation) {
      if (disposed) throw new Error('ONNX backend has been disposed');
      const feeds = observationFeeds(ort, observation, manifest);
      let outputs;
      try {
        outputs = await session.run(feeds);
        return decodeOnnxOutputs(outputs, manifest);
      } finally {
        for (const tensor of Object.values(feeds)) tensor.dispose?.();
        if (outputs) for (const tensor of Object.values(outputs)) tensor.dispose?.();
      }
    },
    async dispose() {
      if (!disposed) {disposed = true; await session.release?.();}
    },
  };
}
