import {encodeObservation,hashFeature} from './observation.js';
import * as C from './contract-v3.js';
import {SEMANTIC_EVENTS,VOLATILES_V3,publicTimer} from '../../core/public-state-v3.js';
import {publicIdentity} from '../../core/public-identity.js';
const id=value=>String(value||'').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,80);
const cap=(value,max)=>Math.max(0,Math.min(max,Number(value)||0))/max;
// Each categorical COLUMN has a disjoint vocabulary partition. Actor fields
// 1/2/3 and target fields 4/5/6 can never share IDs, even after hash collisions.
export function typedCategory(column, namespace, value) {
  return column*C.ROLE_STRIDE + (id(value)?2+(hashFeature(namespace,value)-1)%2048:1);
}
function token(kind,cats=[],nums=[]) {
  return {kind,cats:Array.from({length:C.CAT_FEATURES},(_,i)=>typedCategory(i,cats[i]?.[0]||'unknown',cats[i]?.[1])),
    nums:Array.from({length:C.NUM_FEATURES},(_,i)=>Number.isFinite(nums[i])?nums[i]:0)};
}
function mechanics(mon,side,turn) {
  const m=mon?.v3||{},p=mon?.publicMechanics||{},conditions=m.conditions||{},protect=p.protect||{};
  const last=m.lastMove||id(mon?.lastMove);
  const choiceItem=/^choice(band|scarf|specs)$/.test(id(mon?.item));
  // A revealed Choice item + last move is inferential evidence, not a certain lock.
  const choice=m.choiceMove||(choiceItem?last:'');
  const cats=[['side',side],['move',last],['move',conditions.encore?.move],['move',conditions.disable?.move],
    ['move',choice],['outcome',protect.lastOutcome],['entry',m.entryKind],['identity',mon?.publicRef]];
  const nums=Array(C.NUM_FEATURES).fill(0);
  nums[0]=last?1:0;nums[1]=m.enteredTurn!=null?cap(turn-m.enteredTurn,32):0;nums[2]=m.enteredTurn!=null?1:0;
  nums[3]=m.enteredTurn!=null&&!m.actionObserved?1:0;nums[4]=m.actionObserved?1:0;
  nums[5]=cap(protect.consecutiveAttempts,8);nums[6]=protect.lastAttemptTurn!=null?cap(turn-protect.lastAttemptTurn,32):0;
  nums[7]=protect.lastAttemptTurn!=null?1:0;nums[8]=choice?1:0;nums[9]=choiceItem?1:0;
  nums[10]=mon?.status==='tox'?cap(m.toxicMin,15):0;nums[11]=mon?.status==='tox'?cap(m.toxicMax,15):0;
  nums[12]=mon?.status==='tox'&&m.enteredTurn!=null?1:0;
  ['encore','disable','taunt'].forEach((effect,i)=>{nums[13+i*5]=conditions[effect]?1:0;nums.splice(14+i*5,4,...publicTimer(conditions[effect],turn));});
  // Dedicated presence bits plus compositional categorical volatile tokens below.
  VOLATILES_V3.forEach((effect,i)=>{nums[28+i]=conditions[effect]?1:0;});
  return token(7,cats,nums);
}
function fieldToken(view,side) {
  const f=view.field||{},turn=view.turn||0,nums=Array(C.NUM_FEATURES).fill(0),cats=[['fieldside',side]];
  const timers=f.publicTimers?.[side]||{};
  if(side==='global') {
    ['weather','terrain','trickroom','gravity'].forEach((effect,i)=>{
      cats[i+1]=['field',timers[effect]?.effect];nums.splice(i*5,5,timers[effect]?1:0,...publicTimer(timers[effect],turn));
    });
  } else {
    const conditions=side==='own'?f.sideConditions:f.opponentSideConditions;
    ['stealthrock','spikes','toxicspikes','stickyweb'].forEach((effect,i)=>{nums[i]=cap((conditions||[]).filter(x=>id(x)===effect).length,effect==='spikes'?3:effect==='toxicspikes'?2:1);});
    ['reflect','lightscreen','auroraveil','tailwind','safeguard','mist'].forEach((effect,i)=>{
      nums.splice(4+i*5,5,timers[effect]?1:0,...publicTimer(timers[effect],turn));
    });
  }
  return token(8,cats,nums);
}
export function semanticToken(event,turn) {
  const participant=p=>p&&['own','opponent'].includes(p.side)?p:{};
  const a=participant(event.actor),t=participant(event.target);
  const cats=[['event',event.kind],['side',a.side],['publicref',a.ref||''],['species',a.species],
    ['side',t.side],['publicref',t.ref||''],['species',t.species],['move',event.move],
    ['effect',event.effect],['publicvalue',event.value],['result',event.result],['evidence',event.evidence]];
  const nums=Array(C.NUM_FEATURES).fill(0);
  nums[0]=cap(turn-event.turn,32);nums[1]=cap(event.ordinal,64);
  nums[2]=Number.isInteger(a.slot)&&a.slot>=0&&a.slot<3?(a.slot+1)/3:0;
  nums[3]=Number.isInteger(t.slot)&&t.slot>=0&&t.slot<3?(t.slot+1)/3:0;
  ['hpBefore','hpAfter'].forEach((key,i)=>{if(Number.isFinite(event[key])&&event[key]>=0&&event[key]<=1){nums[4+i]=Math.round(event[key]*100)/100;nums[8+i]=1;}});
  ['failed','blocked','immune','missed','critical'].forEach((key,i)=>{nums[12+i]=event[key]||event.result===key?1:0;});
  nums[17]=event.kind==='faint'?1:0;
  nums[19]=Number.isFinite(event.amount)?Math.max(-6,Math.min(6,event.amount))/6:0;nums[20]=Number.isFinite(event.amount)?1:0;
  nums[21]=turn-event.turn>32||event.ordinal>64?1:0;
  return token(6,cats,nums);
}
export function encodeObservationV3(view,actions=[]) {
  const legacy=encodeObservation(view,actions);
  const output={version:3,categoryEncoding:C.CATEGORY_ENCODING,tokenKinds:Array(C.TOKEN_COUNT).fill(0),tokenMask:Array(C.TOKEN_COUNT).fill(0),
    categorical:Array.from({length:C.TOKEN_COUNT},()=>Array(C.CAT_FEATURES).fill(0)),
    numeric:Array.from({length:C.TOKEN_COUNT},()=>Array(C.NUM_FEATURES).fill(0)),legalMask:legacy.legalMask,meta:legacy.meta};
  const write=(i,t)=>{output.tokenKinds[i]=t.kind;output.tokenMask[i]=1;output.categorical[i]=t.cats;output.numeric[i]=t.nums;};
  for(let i=0;i<21;i++)if(legacy.tokenMask[i]) {
    write(i,{kind:legacy.tokenKinds[i],cats:legacy.categorical[i].map((value,col)=>col*C.ROLE_STRIDE+(value?2+(value-1)%2048:1)),
      nums:[...legacy.numeric[i],...Array(C.NUM_FEATURES-22).fill(0)]});
  }
  // v3 board knownness and per-member public move reveals survive switches.
  const own=view.request?.side?.pokemon||[];
  const opponent=(view.opponent?.revealed||[]).slice(0,6);
  for(const [base,roster,isOwn] of [[1,own,true],[7,opponent,false]]) for(let i=0;i<Math.min(6,roster.length);i++) {
    const r=roster[i],publicMon=(isOwn?view.own?.revealed:opponent)?.find(m=>publicIdentity(m.ident)&&publicIdentity(m.ident)===publicIdentity(r.ident))||r;
    const n=output.numeric[base+i];
    n[22]=Number.isFinite(r.hpFraction)||/^\d+\/\d+/.test(r.condition||'')?1:0;
    n[23]=isOwn||publicMon.itemKnown||publicMon.item?1:0;n[24]=isOwn||publicMon.abilityKnown||publicMon.ability?1:0;
    n[25]=cap(publicMon.publicRef,12);
    if(!isOwn)for(let j=0;j<4;j++)output.categorical[base+i][8+j]=typedCategory(8+j,'move',publicMon.movesSeen?.[j]);
  }
  const turn=view.turn||0;
  const ownPublic=view.own?.active?.[0],requestActive=own.find(m=>m.active);
  const ownMon=ownPublic&&requestActive&&publicIdentity(ownPublic.ident)===publicIdentity(requestActive.ident)
    ? {...ownPublic,item:requestActive.item??ownPublic.item}:ownPublic;
  write(21,mechanics(ownMon,'own',turn));write(22,mechanics(view.opponent?.active?.[0],'opponent',turn));
  write(23,fieldToken(view,'own'));write(24,fieldToken(view,'opponent'));write(25,fieldToken(view,'global'));
  const events=(view.semanticHistory||[]).filter(e=>SEMANTIC_EVENTS.includes(e.kind)&&Number.isInteger(e.turn)&&e.turn>=0&&e.turn<=turn).slice(-16);
  events.forEach((event,i)=>write(C.HISTORY_TOKEN_START+i,semanticToken(event,turn)));
  return output;
}
