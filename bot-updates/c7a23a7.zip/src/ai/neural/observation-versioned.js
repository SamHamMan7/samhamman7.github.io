import {encodeObservation} from './observation.js';
import {encodeObservationV3} from './observation-v3.js';
export function encodeVersionedObservation(view, actions, version=2) {
  if(version===2)return encodeObservation(view,actions);
  if(version===3)return encodeObservationV3(view,actions);
  throw new Error(`Unsupported observation version: ${version}`);
}
