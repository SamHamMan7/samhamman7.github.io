export const GENERAL_VERSION=1;
export const FORMAT_IDS=Object.freeze(['gen9randombattle','gen9ou','vgc/champions-doubles']);
export const EXTRA_TOKENS=14;
export function formatContext(id,options={}) {
  const index=FORMAT_IDS.indexOf(id);
  if(index<0)throw new Error('Unsupported general format identity');
  if(index<2) {
    if(options.rulesetId&&options.rulesetId!==id)throw new Error('Singles ruleset mismatch');
    return {id,index,rulesetId:id,activeSlots:1,teraEnabled:true,previewPick:index===1?6:0,teamSource:index===0?'generated':'supplied'};
  }
  if(typeof options.rulesetId!=='string'||!/^[a-z0-9][a-z0-9-]{0,95}$/.test(options.rulesetId)||typeof options.teraEnabled!=='boolean'||!Number.isInteger(options.previewPick)||options.previewPick<0||options.previewPick>6)
    throw new Error('Doubles requires explicit rulesetId, teraEnabled and previewPick; no implicit Champions rules');
  return {id,index,rulesetId:options.rulesetId,activeSlots:2,teraEnabled:options.teraEnabled,previewPick:options.previewPick,teamSource:'supplied'};
}
export function validateContext(context,expected=context) {
  const same=(a,b)=>!!a&&!!b&&Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>a[k]===b[k]);
  if(!same(context,formatContext(context?.id,context)))throw new Error('Invalid format/ruleset context');
  if(!same(context,expected))throw new Error('Format/ruleset mismatch');
  return context;
}
