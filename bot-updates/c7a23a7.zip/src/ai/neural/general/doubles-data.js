// Player-channel boundary for doubles DATA only. No engine object or future log.
import {Teams,Dex} from '@pkmn/sim';
import {PlayerView,id} from '../../../core/view.js';
import {encodeGeneralObservation,validateGeneralObservation} from './observation.js';
import {typedCategory} from '../observation-v3.js';
import {serializeAction,conditionalSlot} from './actions.js';

export const DOUBLES_ROW_SCHEMA='doubles-decision-v1';
export class DoublesPlayerView extends PlayerView {
  receive(chunk) {
    // Preserve the base class's atomic rejection of split/wrong-side requests.
    const requested=super.receive(chunk);
    for(const line of chunk.split('\n'))if(line.startsWith('|showteam|')) {
      const [, ,side,...packed]=line.split('|');
      if(!['p1','p2'].includes(side)||this.state.turn!==0)throw new Error('Unsupported public team-sheet timing/side');
      const sheet=Teams.unpack(packed.join('|'));
      if(!sheet?.length||sheet.length>6)throw new Error('Invalid public team sheet');
      for(const entry of sheet) {
        const matches=this.party(side).revealed.filter(m=>id(m.species)===id(entry.species));
        if(matches.length!==1)throw new Error('Ambiguous public sheet identity');
        // The protocol has explicitly disclosed these fields. Do not retain
        // packed input, EVs/IVs/nature/stats, or any other unpacked field.
        Object.assign(matches[0],{item:entry.item||'',itemKnown:true,ability:entry.ability||'',abilityKnown:true,
          movesSeen:entry.moves.map(m=>Dex.moves.get(m).name),sheetTeraType:entry.teraType||''});
      }
    }
    return requested;
  }
}

export function doublesObservation(view,context) {
  if(context.id!=='vgc/champions-doubles')throw new Error('Doubles data requires a doubles context');
  const o=encodeGeneralObservation(view,context);
  // Use an existing category, not a new model feature. Known sheet Tera is not
  // activated Tera: leave the activation bit and mechanics unchanged.
  for(const [i,mon] of (view.opponent?.revealed||[]).slice(0,6).entries())
    if(mon.sheetTeraType&&!mon.terastallized)o.base.categorical[7+i][5]=typedCategory(5,'teratype',mon.sheetTeraType);
  return o;
}

/** Canonical inputlog choices, NOT inferred |move| results (which can redirect). */
export function parseDoublesChoice(command,view,contract) {
  if(contract.mode==='ordered-team-selection-v1') {
    const match=command.match(/^team ([1-6](?:[1-6]|,\s*[1-6])*)$/);
    if(!match)throw new Error('Explicit complete preview order required');
    const order=match[1].replace(/[, ]/g,'').split('').map(Number);
    serializeAction(contract,order);return order;
  }
  if(contract.mode!=='doubles-factorized-v1')throw new Error('Choice outside decision phase');
  const pieces=command.split(',').map(s=>s.trim());
  if(pieces.length!==2)throw new Error('Require both allied actions including protocol pass');
  const actions=pieces.map((text,slot)=>{
    if(text==='pass')return {slot,type:'pass'};
    let match=text.match(/^switch ([1-6])$/);
    if(match)return {slot,type:'switch',choice:Number(match[1])};
    match=text.match(/^move ([a-zA-Z0-9]+)(?: ([+-]?[12]))?( terastallize)?$/);
    if(!match)throw new Error('Unsupported doubles choice syntax');
    let choice=Number(match[1]);
    if(!/^[1-4]$/.test(match[1])) {
      const candidates=(view.request.active?.[slot]?.moves||[]).map((m,i)=>id(m.id||m.move)===id(match[1])?i+1:0).filter(Boolean);
      if(candidates.length!==1)throw new Error('Move identity absent/ambiguous in own request');
      choice=candidates[0];
    }
    return {slot,type:'move',choice,target:match[2]?Number(match[2]):0,tera:!!match[3]};
  });
  serializeAction(contract,actions);return actions;
}

export function conditionalMasks(contract,action) {
  if(contract.mode==='ordered-team-selection-v1')return action.map((_,i)=>contract.available.map(n=>Number(!action.slice(0,i).includes(n))));
  return [conditionalSlot(contract,0),conditionalSlot(contract,1,[action[0]])];
}
export function makeDoublesRow(view,context,command,{gameId,decisionIndex,sequence,provenance}) {
  const observation=doublesObservation(view,context),chosen=parseDoublesChoice(command,view,observation.actions);
  const row={schema:DOUBLES_ROW_SCHEMA,adapterVersion:1,gameId,side:view.side,decisionIndex,sequence,turn:view.turn,
    phase:observation.actions.mode==='ordered-team-selection-v1'?'preview':view.request.forceSwitch?.some(Boolean)?'replacement':'turn',
    format:context,observation,chosen,command:serializeAction(observation.actions,chosen),
    conditionalMasks:conditionalMasks(observation.actions,chosen),provenance};
  validateDoublesRow(row,context);return row;
}
export function validateDoublesRow(row,expected=row?.format) {
  if(row?.schema!==DOUBLES_ROW_SCHEMA||row.adapterVersion!==1||typeof row.gameId!=='string'||!row.gameId||!['p1','p2'].includes(row.side)||
      ![row.decisionIndex,row.sequence,row.turn].every(n=>Number.isSafeInteger(n)&&n>=0)||!['preview','replacement','turn'].includes(row.phase))throw new Error('Doubles row schema/identity mismatch');
  validateGeneralObservation(row.observation,expected);
  if(row.turn!==row.observation.base.meta.turn)throw new Error('Doubles observation/turn mismatch');
  if(JSON.stringify(row.format)!==JSON.stringify(row.observation.context)||row.format.id!=='vgc/champions-doubles')throw new Error('Doubles row format mismatch');
  const c=row.observation.actions;
  if((row.phase==='preview')!==(c.mode==='ordered-team-selection-v1')||row.phase!=='preview'&&(c.mode!=='doubles-factorized-v1'||(row.phase==='replacement')!==(c.requiredSwitches!==null)))throw new Error('Doubles phase mismatch');
  if(row.command!==serializeAction(c,row.chosen)||JSON.stringify(row.conditionalMasks)!==JSON.stringify(conditionalMasks(c,row.chosen)))throw new Error('Doubles labels/masks mismatch');
  if(!row.provenance||row.provenance.replayId!==row.gameId||!Number.isSafeInteger(row.provenance.inputCommandIndex)||row.provenance.inputCommandIndex<0||
      !['inputlogSha256','logSha256','publicPrefixSha256','engineSha256'].every(k=>/^[a-f0-9]{64}$/.test(row.provenance[k]||'')))throw new Error('Doubles provenance mismatch');
  return row;
}
