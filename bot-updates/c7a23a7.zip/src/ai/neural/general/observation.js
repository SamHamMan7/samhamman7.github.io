import {addMatchupFeatures} from '../matchup.js';
import {encodeObservationV3,typedCategory} from '../observation-v3.js';
import {hashFeature} from '../observation.js';
import {publicIdentity} from '../../../core/public-identity.js';
import {GENERAL_VERSION,EXTRA_TOKENS,formatContext,validateContext} from './formats.js';
import {actionContract,validateActionContract} from './actions.js';
import * as V3 from '../contract-v3.js';
const blank=()=>({tokenKinds:Array(EXTRA_TOKENS).fill(0),tokenMask:Array(EXTRA_TOKENS).fill(0),categorical:Array.from({length:EXTRA_TOKENS},()=>Array(12).fill(0)),numeric:Array.from({length:EXTRA_TOKENS},()=>Array(52).fill(0))});
const same=(a,b)=>!!publicIdentity(a)&&publicIdentity(a)===publicIdentity(b);
function envelope(base,context,actions,extra=blank()) {
  return {generalVersion:GENERAL_VERSION,context,formatIndex:context.index,rulesetHash:hashFeature('ruleset',context.rulesetId),
    ruleFeatures:[context.activeSlots/2,Number(context.teraEnabled),context.previewPick/6],base,extra,actions};
}
/** Deterministic, lossless wrapper for existing saved v3 RandBats decisions. */
export function wrapRandBatsV3(base) {
  const actions=base.legalMask.map((bit,i)=>bit?{choice:i>=8?`switch ${i-7}`:`move ${i%4+1}${i>=4?' terastallize':''}`} :null).filter(Boolean);
  const result=envelope(base,formatContext('gen9randombattle'),{mode:'singles-14-v1',legalMask:[...base.legalMask],actions});
  validateGeneralObservation(result);return result;
}
export function encodeGeneralObservation(view,context) {
  validateContext(context);
  if(view.request?.side?.id!==view.side)throw new Error('Information firewall: wrong player request');
  const actions=actionContract(view,context);
  let base=encodeObservationV3(view,actions.mode==='singles-14-v1'?actions.actions:[]);
  if(actions.mode==='singles-14-v1') {
    // Existing matchup v1 includes RandBats set priors. Do not smuggle those
    // priors into OU: validity=0 explicitly marks unavailable optional features.
    base=context.id==='gen9randombattle'?addMatchupFeatures(base,view,actions.actions):
      {...base,matchupVersion:1,candidateFeatures:Array.from({length:14},()=>Array(28).fill(0))};
  }
  const extra=blank();
  const copy=(dst,src,index)=>{for(const key of ['tokenKinds','tokenMask','categorical','numeric'])extra[key][dst]=structuredClone(src[key][index]);};
  if(context.activeSlots===2) {
    // Projection of the SAME public view onto slot b. No private engine object.
    const project=slot=>{
      const ownMon=view.own?.active?.[slot],opponentMon=view.opponent?.active?.[slot];
      return encodeObservationV3({...view,own:{...view.own,active:ownMon?[ownMon]:[]},opponent:{...view.opponent,active:opponentMon?[opponentMon]:[]},
        request:{...view.request,active:view.request.active?.[slot]?[view.request.active[slot]]:[],
          side:{...view.request.side,pokemon:view.request.side.pokemon.map(m=>({...m,active:same(m.ident,ownMon?.ident)}))}}},[]);
    };
    // Party order is not active-slot order, particularly after a switch. Keep
    // shared board tokens intact, but bind BOTH sets of active-only tokens.
    const slotA=project(0),slotB=project(1);
    for(let i=13;i<=22;i++)for(const key of ['tokenKinds','tokenMask','categorical','numeric'])base[key][i]=structuredClone(slotA[key][i]);
    const ownMon=view.own?.active?.[1],opponentMon=view.opponent?.active?.[1];
    if(ownMon)for(let i=0;i<4;i++)copy(i,slotB,13+i);
    if(opponentMon)for(let i=0;i<4;i++)copy(4+i,slotB,17+i);
    if(ownMon)copy(8,slotB,21);if(opponentMon)copy(9,slotB,22);
    for(const [side,offset,roster,start] of [['own',10,view.request.side.pokemon,1],['opponent',12,view.opponent?.revealed||[],7]])for(let slot=0;slot<2;slot++) {
      const mon=view[side]?.active?.[slot];if(!mon)continue;
      const matches=roster.map((m,i)=>same(m.ident,mon.ident)?i:-1).filter(i=>i>=0);
      if(matches.length!==1)throw new Error('Ambiguous public active/roster identity');
      const i=offset+slot;extra.tokenKinds[i]=7;extra.tokenMask[i]=1;
      const fields=[['side',side],['publicref',mon.publicRef||''],['species',mon.species],['activeslot',String(slot+1)]];
      extra.categorical[i]=Array.from({length:12},(_,c)=>typedCategory(c,...(fields[c]||['unknown',''])));
      extra.numeric[i][0]=(slot+1)/2;extra.numeric[i][1]=(start+matches[0])/12;
      extra.numeric[i][2]=1; // identity binding is known, distinct from absent/empty slot
    }
  }
  const result=envelope(base,context,actions,extra);validateGeneralObservation(result);return result;
}
function validateBlock(block,count) {
  for(const key of ['tokenKinds','tokenMask','categorical','numeric'])if(!Array.isArray(block?.[key])||block[key].length!==count)throw new Error('General token shape mismatch');
  for(let i=0;i<count;i++) {
    if(![0,1].includes(block.tokenMask[i])||!Number.isInteger(block.tokenKinds[i])||block.tokenKinds[i]<0||block.tokenKinds[i]>8)throw new Error('Invalid general kind/mask');
    if(block.categorical[i]?.length!==12||block.numeric[i]?.length!==52||!block.numeric[i].every(Number.isFinite))throw new Error('Invalid general feature shape');
    block.categorical[i].forEach((v,c)=>{if(!Number.isInteger(v)||v<0||v>V3.HASH_BUCKETS||v&&Math.floor(v/2050)!==c)throw new Error('General categorical role mismatch');});
  }
}
export function validateGeneralObservation(o,expected=o?.context) {
  if(o?.generalVersion!==1)throw new Error('General contract version mismatch');
  validateContext(o.context,expected);
  if(o.formatIndex!==o.context.index||o.rulesetHash!==hashFeature('ruleset',o.context.rulesetId)||JSON.stringify(o.ruleFeatures)!==JSON.stringify([o.context.activeSlots/2,Number(o.context.teraEnabled),o.context.previewPick/6]))throw new Error('Format tensor/context mismatch');
  if(o.base?.version!==3||o.base.categoryEncoding!==V3.CATEGORY_ENCODING||o.base.meta?.format!==o.context.rulesetId||o.base.categorical?.[0]?.[0]!==typedCategory(0,'format',o.context.rulesetId))throw new Error('Base observation format/version mismatch');
  validateBlock(o.base,42);validateBlock(o.extra,14);
  if(!o.base.tokenMask[0])throw new Error('Missing global token');
  if(!Array.isArray(o.base.legalMask)||o.base.legalMask.length!==14||o.base.legalMask.some(x=>x!==0&&x!==1))throw new Error('Invalid base legal mask');
  const mode=o.actions?.mode;
  validateActionContract(o.actions,o.context);
  if(o.context.activeSlots===1) {
    if(o.extra.tokenMask.some(Boolean))throw new Error('Singles cannot contain doubles extensions');
    if(!['singles-14-v1','ordered-team-selection-v1','wait'].includes(mode))throw new Error('Wrong singles action adapter');
  } else if(!['doubles-factorized-v1','ordered-team-selection-v1','wait'].includes(mode))throw new Error('Wrong doubles action adapter');
  if(mode==='singles-14-v1'&&(JSON.stringify(o.actions.legalMask)!==JSON.stringify(o.base.legalMask)||!o.base.legalMask.some(Boolean)))throw new Error('Singles mask mismatch');
  if(mode!=='singles-14-v1'&&o.base.legalMask.some(Boolean))throw new Error('Non-singles decisions cannot use 14-action mask');
  return o;
}
