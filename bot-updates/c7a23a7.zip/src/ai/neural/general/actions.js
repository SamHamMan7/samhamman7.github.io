import {legalActions} from '../../index.js';
import {legalMask,legalActionForIndex} from '../action-space.js';
import {validateContext} from './formats.js';
import {publicIdentity} from '../../../core/public-identity.js';
export const TARGETS=Object.freeze([0,-1,-2,1,2]); // automatic, ally a/b, opponent a/b
const living=m=>!!m&&!m.fainted&&!/\bfnt\b/.test(m.condition||'')&&m.hpFraction!==0;
const bits=n=>Array(n).fill(0);
export function actionContract(view,context) {
  validateContext(context);
  if(view.format!==context.rulesetId)throw new Error('View format/ruleset mismatch');
  const r=view.request||{},roster=r.side?.pokemon||[];
  if(r.wait)return {mode:'wait'};
  if(r.teamPreview)return {mode:'ordered-team-selection-v1',available:roster.map((_,i)=>i+1),pickCount:r.maxTeamSize||context.previewPick||roster.length};
  if(context.activeSlots===1) {
    if(Math.max(r.active?.length||0,r.forceSwitch?.length||0)>1)throw new Error('Doubles request cannot use singles adapter');
    const actions=legalActions(view);
    return {mode:'singles-14-v1',legalMask:legalMask(actions),actions};
  }
  if(roster.some(m=>m.reviving))throw new Error('Doubles revival request requires a separate adapter');
  if(Math.max(r.active?.length||0,r.forceSwitch?.length||0)!==2)throw new Error('Doubles requires a two-slot request');
  const own=(view.own?.active||[]);
  const bench=roster.map((m,i)=>!m.active&&living(m)?i+1:0).filter(Boolean),forced=r.forceSwitch?.filter(Boolean).length||0;
  const teraUsed=roster.some(m=>m.terastallized)||(view.own?.revealed||[]).some(m=>m.terastallized);
  const slots=Array.from({length:2},(_,slot)=>{
    const req=r.active?.[slot],needsSwitch=!!r.forceSwitch?.[slot];
    const out={slot,familyMask:bits(3),moveMask:bits(4),switchMask:bits(6),targetMask:Array.from({length:4},()=>bits(5)),teraMask:Array.from({length:4},()=>bits(2))};
    // Pass is a protocol necessity for an empty/non-replacing slot, never a heuristic action.
    const member=roster.find(m=>publicIdentity(m.ident)===publicIdentity(own[slot]?.ident));
    if(r.forceSwitch&&!needsSwitch||!r.forceSwitch&&(!req||!living(own[slot])||member?.commanding)) {out.familyMask[2]=1;return out;}
    if(needsSwitch||!req.trapped)for(const n of bench)out.switchMask[n-1]=1;
    out.familyMask[1]=Number(out.switchMask.some(Boolean));
    if(needsSwitch){out.familyMask[2]=Number(forced>bench.length);return out;}
    for(const [i,move] of (req.moves||[]).entries()) {
      if(i>=4)throw new Error('Unsupported move count');
      if(move.disabled||move.pp===0)continue;
      let targets;
      // Showdown validates target LOCATIONS, not their present HP. A legal
      // fainted target can be retargeted/fail by engine rules. Do not ban it.
      switch(move.target) {
      case 'normal':case 'any': targets=[1,2,-(2-slot)];break;
      case 'adjacentFoe':targets=[1,2];break;
      case 'adjacentAlly':targets=[-(2-slot)];break;
      case 'adjacentAllyOrSelf':targets=[-1,-2];break;
      case 'self':case 'all':case 'allAdjacent':case 'allAdjacentFoes':case 'allySide':case 'foeSide':case 'allyTeam':case 'randomNormal':case 'scripted':targets=[0];break;
      default:throw new Error(`Unsupported request target class: ${move.target}`);
      }
      out.targetMask[i]=TARGETS.map(t=>Number(targets.includes(t)));
      out.moveMask[i]=Number(targets.length>0);
      out.teraMask[i]=[out.moveMask[i],Number(!!out.moveMask[i]&&context.teraEnabled&&!teraUsed&&!!req.canTerastallize)];
    }
    out.familyMask[0]=Number(out.moveMask.some(Boolean));return out;
  });
  return {mode:'doubles-factorized-v1',targets:[...TARGETS],slots,requiredSwitches:r.forceSwitch?Math.min(forced,bench.length):null,maxTera:context.teraEnabled&&!teraUsed?1:0};
}
function localLegal(slot,action) {
  if(action?.slot!==slot.slot)return false;
  if(action.type==='pass')return !!slot.familyMask[2]&&!action.tera&&!action.target;
  if(action.type==='switch')return !!slot.familyMask[1]&&Number.isInteger(action.choice)&&!!slot.switchMask[action.choice-1]&&!action.tera&&!action.target;
  return action.type==='move'&&!!slot.familyMask[0]&&Number.isInteger(action.choice)&&!!slot.moveMask[action.choice-1]&&
    !!slot.targetMask[action.choice-1][TARGETS.indexOf(action.target)]&&typeof action.tera==='boolean'&&!!slot.teraMask[action.choice-1][Number(action.tera)];
}
export function jointLegal(contract,actions) {
  if(contract.mode!=='doubles-factorized-v1'||actions.length!==2||!actions.every((a,i)=>localLegal(contract.slots[i],a)))return false;
  const switches=actions.filter(a=>a.type==='switch');
  return new Set(switches.map(a=>a.choice)).size===switches.length&&actions.filter(a=>a.tera).length<=contract.maxTera&&
    (contract.requiredSwitches===null||switches.length===contract.requiredSwitches);
}
export function conditionalSlot(contract,slot,prefix=[]) {
  if(contract.mode!=='doubles-factorized-v1'||![0,1].includes(slot)||prefix.length!==slot||prefix.some((a,i)=>!localLegal(contract.slots[i],a)))throw new Error('Invalid conditional action prefix');
  const result=structuredClone(contract.slots[slot]);
  for(const action of prefix) {
    if(action.type==='switch')result.switchMask[action.choice-1]=0;
    if(action.tera)for(const mask of result.teraMask)mask[1]=0;
  }
  result.familyMask[1]=Number(result.switchMask.some(Boolean));
  if(contract.requiredSwitches!==null) {
    const left=contract.requiredSwitches-prefix.filter(a=>a.type==='switch').length;
    if(left===2-slot)result.familyMask[2]=0;
    if(left===0){result.switchMask.fill(0);result.familyMask[1]=0;}
  }
  return result;
}
export function serializeAction(contract,action) {
  if(contract.mode==='singles-14-v1') {
    const selected=legalActionForIndex(action,contract.actions);if(!selected)throw new Error('Illegal singles action');return selected.choice;
  }
  if(contract.mode==='ordered-team-selection-v1') {
    if(!Array.isArray(action)||action.length!==contract.pickCount||new Set(action).size!==action.length||action.some(n=>!contract.available.includes(n)))throw new Error('Illegal ordered preview selection');
    return `team ${action.join('')}`;
  }
  if(!jointLegal(contract,action))throw new Error('Illegal joint action');
  return action.map(a=>a.type==='pass'?'pass':a.type==='switch'?`switch ${a.choice}`:`move ${a.choice}${a.target?' '+a.target:''}${a.tera?' terastallize':''}`).join(', ');
}

/** Greedy scaffold only; conditional masks, never an enormous Cartesian action list. */
export function decodeDoubles(contract,logits) {
  const selected=[];
  const pick=(values,mask)=>{
    if(!Array.isArray(values)||values.length!==mask.length)throw new Error('Factor logits shape mismatch');
    let best=-1;for(let i=0;i<mask.length;i++)if(mask[i]&&Number.isFinite(values[i])&&(best<0||values[i]>values[best]))best=i;
    if(best<0)throw new Error('No finite legal factor choice');return best;
  };
  for(let slot=0;slot<2;slot++) {
    const m=conditionalSlot(contract,slot,selected),family=pick(logits.family_logits[slot],m.familyMask);
    if(family===2){selected.push({slot,type:'pass'});continue;}
    if(family===1){selected.push({slot,type:'switch',choice:pick(logits.switch_logits[slot],m.switchMask)+1});continue;}
    const move=pick(logits.move_logits[slot],m.moveMask);
    selected.push({slot,type:'move',choice:move+1,target:TARGETS[pick(logits.target_logits[slot][move],m.targetMask[move])],tera:!!pick(logits.tera_logits[slot][move],m.teraMask[move])});
  }
  if(!jointLegal(contract,selected))throw new Error('Decoded joint action is invalid');return selected;
}
export function validateActionContract(contract,context) {
  if(contract.mode==='doubles-factorized-v1') {
    const vector=(v,n)=>Array.isArray(v)&&v.length===n&&v.every(x=>x===0||x===1);
    if(context.activeSlots!==2||JSON.stringify(contract.targets)!==JSON.stringify(TARGETS)||contract.slots?.length!==2||![0,1].includes(contract.maxTera)||(!context.teraEnabled&&contract.maxTera)||!(contract.requiredSwitches===null||[0,1,2].includes(contract.requiredSwitches)))throw new Error('Invalid doubles contract');
    for(const [i,s] of contract.slots.entries())if(s.slot!==i||!vector(s.familyMask,3)||!vector(s.moveMask,4)||!vector(s.switchMask,6)||s.targetMask?.length!==4||s.teraMask?.length!==4||!s.targetMask.every(m=>vector(m,5))||!s.teraMask.every(m=>vector(m,2)))throw new Error('Invalid doubles factor mask');
  } else if(contract.mode==='ordered-team-selection-v1') {
    if(!Number.isInteger(contract.pickCount)||contract.pickCount<1||contract.pickCount>contract.available?.length||contract.available.length>6||new Set(contract.available).size!==contract.available.length||contract.available.some(x=>!Number.isInteger(x)||x<1||x>6))throw new Error('Invalid preview contract');
  } else if(contract.mode==='singles-14-v1'&&JSON.stringify(legalMask(contract.actions))!==JSON.stringify(contract.legalMask))throw new Error('Singles action/mask mismatch');
}
