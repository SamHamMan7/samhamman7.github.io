// Optional policy input v1. Only PlayerView + its own request cross this boundary.
// No generated opponent team, replay labels, simulator object or future log.
import {Dex} from '@pkmn/sim';
import {fromRequest,damageEstimate,effectiveSpeed,hazardCost,toID,clamp} from '../damage.js';
import {opponentHypotheses,possibleMoves} from '../priors.js';
import randomSets from '../random-priors.js';
import {actionIndexFromChoice} from './action-space.js';
import {MATCHUP_VERSION,MATCHUP_FEATURES} from './contract.js';
export {MATCHUP_VERSION,MATCHUP_FEATURES};
export const MATCHUP_NAMES=['valid','switch','tera','hp','entryHazard','speedAdvantage','trickRoom',
  'outMin','outMean','outMax','outKO','responseMean','responseMax','responseKO','priority','accuracy',
  'statusMove','recovery','protect','pivot','setup','revealedMoveFraction','abilityWorldFraction',
  'itemKnown','abilityKnown','teraOutDelta','teraResponseDelta','hpAfterEntry'];

function publicMon(mon={}) {
  // Deliberate allowlist. Never spread caller-controlled opponent objects into calc.
  const result={species:mon.species,level:mon.level,hpFraction:mon.hpFraction,status:mon.status,
    types:mon.types,boosts:Object.fromEntries(['atk','def','spa','spd','spe'].map(k=>[k,Number(mon.boosts?.[k])||0])),
    movesSeen:Array.isArray(mon.movesSeen)?mon.movesSeen.filter(m=>typeof m==='string'):[],
    lastMove:mon.lastMove,terastallized:mon.terastallized,boostedStat:mon.boostedStat};
  if(Object.hasOwn(mon,'item'))result.item=mon.item;
  if(mon.ability)result.ability=mon.ability;
  // An unrevealed Tera type is not legal input, even if supplied on an object.
  if(mon.terastallized)result.teraType=mon.teraType||mon.terastallized;
  return result;
}
const active=value=>Array.isArray(value)?value.find(Boolean):value;
const average=values=>values.reduce((a,b)=>a+b,0)/Math.max(1,values.length);

export function matchupFeatures(view,actions) {
  if(view.format!=='gen9randombattle')throw new Error('Matchup features support RandBats singles only');
  const result=Array.from({length:14},()=>Array(MATCHUP_FEATURES).fill(0));
  const opponent=publicMon(active(view.opponent?.active));
  if(!Dex.species.get(opponent.species).exists)return result;
  const field=view.field||{},ownPublic=active(view.own?.active),party=view.request?.side?.pokemon||[];
  const own=party.map(mon=>fromRequest(mon,mon.active?ownPublic||{}:{}));
  const current=party.findIndex(mon=>mon.active),slot=view.request?.active?.[0];
  const base=opponentHypotheses(opponent,'gen9randombattle',1)[0];
  const species=Dex.species.get(opponent.species),pool=randomSets[species.id]||randomSets[toID(species.baseSpecies)];
  const families=pool?.sets.filter(s=>opponent.movesSeen.every(m=>s.movepool.some(x=>toID(x)===toID(m))))||[];
  const abilities=opponent.ability?[opponent.ability]:[...new Set(families.flatMap(s=>s.abilities))];
  const worlds=(abilities.length?abilities:[base.ability]).slice(0,4).map(ability=>({...base,ability}));
  // Uniform public ability hypotheses, NOT calibrated hidden-set probabilities.
  // Unknown items remain neutral and are explicitly flagged as unknown.
  const responseMoves=possibleMoves(opponent,12,'gen9randombattle').slice(0,12);
  const trick=!!field.trickRoom;
  const summaries=new Map();
  function matchup(mon,move,entry=0) {
    const key=JSON.stringify([mon,move,entry]);if(summaries.has(key))return summaries.get(key);
    const defender={...mon,hpFraction:Math.max(0,mon.hpFraction-entry)};
    const outgoing=worlds.map(w=>move?damageEstimate(mon,w,move,field):{min:0,mean:0,max:0,ko:0});
    const responses=worlds.map(w=>responseMoves.map(m=>damageEstimate(w,defender,m,field,true)));
    const speed=worlds.map(w=>{const a=effectiveSpeed(mon,field),b=effectiveSpeed(w,field,true);return (a===b?0:a>b?1:-1)*(trick?-1:1);});
    const values=[Math.min(...outgoing.map(d=>d.min)),average(outgoing.map(d=>d.mean)),Math.max(...outgoing.map(d=>d.max)),average(outgoing.map(d=>d.ko)),
      average(responses.map(r=>average(r.map(d=>d.mean)))),Math.max(0,...responses.flat().map(d=>d.max)),average(responses.map(r=>Math.max(0,...r.map(d=>d.ko)))),average(speed)];
    summaries.set(key,values);return values;
  }
  for(const action of actions){
    const index=actionIndexFromChoice(action.choice);if(index<0)continue;
    const switching=index>=8,tera=index>=4&&index<8,mon=own[switching?index-8:current];if(!mon)continue;
    const chosen=tera?{...mon,terastallized:slot?.canTerastallize||mon.teraType}:mon;
    const move=switching?null:slot?.moves?.[index%4]?.id||slot?.moves?.[index%4]?.move;
    const data=Dex.moves.get(move||''),entry=switching?hazardCost(mon,field.sideConditions):0;
    try {
      // Switch offense is its best known follow-up move, not immediate switch damage.
      const follow=switching?(mon.moves||[]).map(m=>[m,matchup(chosen,m,entry)]).sort((a,b)=>b[1][1]-a[1][1])[0]:null;
      const stats=follow?.[1]||matchup(chosen,move,entry),normal=tera?matchup(mon,move,entry):stats;
      const row=[1,+switching,+tera,mon.hpFraction,entry,stats[7],+trick,...stats.slice(0,7),
        (data.priority||0)/7,data.accuracy===true?1:(data.accuracy||100)/100,+(data.category==='Status'),
        +(!!data.heal||['wish','rest','strengthsap'].includes(data.id)),+(!!data.stallingMove),+(!!data.selfSwitch),
        +(!!data.boosts||!!data.self?.boosts),opponent.movesSeen.length/4,worlds.length/4,
        +Object.hasOwn(opponent,'item'),+!!opponent.ability,stats[1]-normal[1],stats[5]-normal[5],Math.max(0,mon.hpFraction-entry)];
      if(row.length!==MATCHUP_FEATURES||!row.every(Number.isFinite))throw new Error('Invalid matchup calculation');
      result[index]=row.map(x=>clamp(x,-4,4));
    }catch{/* Unsupported calc forms/mechanics are explicit validity=0, never fake damage. */}
  }
  return result;
}

export function addMatchupFeatures(observation,view,actions) {
  return {...observation,matchupVersion:MATCHUP_VERSION,candidateFeatures:matchupFeatures(view,actions)};
}
