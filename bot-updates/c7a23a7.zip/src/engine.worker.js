import {BattleSession} from './core/session.js';
import {validateTeam} from './core/teams.js';
let session;
let failures = 0;
const send = data => postMessage(data);
self.onmessage = async ({data}) => {
  try {
    if (data.type === 'validate') { const {team, ...validation} = validateTeam(data.paste, data.format); send({type:'validation', validation}); }
    if (data.type === 'start') {
      await session?.close(); failures = 0;
      session = new BattleSession({
        onUpdate: update => { if (update.side === 'p1') send({type:'update', ...update}); },
        onRequest: request => send({type:'request', ...request}),
        onError: (error, side) => {
          if (side === 'p2' && error.message.startsWith('[Invalid choice]') && ++failures <= 3) { send({type:'ai-retry', message:error.message}); session.retry(side); }
          else { send({type:'error', message:error.message}); if (side === 'p1' && error.message.startsWith('[Invalid choice]')) session.retry(side); }
        },
      });
      await session.start(data.options);
    }
    if (data.type === 'choose') await session?.choose(data.side, data.token, data.choice);
    if (data.type === 'forfeit') await session?.forfeit('p1');
    if (data.type === 'close') await session?.close();
  } catch (error) { send({type:'error',message:error.message}); }
};
send({type:'ready'});
