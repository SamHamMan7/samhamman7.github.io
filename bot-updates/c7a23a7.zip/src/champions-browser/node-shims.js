// Minimal browser stand-ins for the few Node APIs reached by the battle/AI code.
// Model loading (fs/onnx) is never used by the search bot, so those throw.
const K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
export function sha256Hex(input){
 const bytes=typeof input==='string'?new TextEncoder().encode(input):new Uint8Array(input),len=bytes.length,total=((len+9+63)>>6)<<6,m=new Uint8Array(total);m.set(bytes);m[len]=0x80;
 const bits=len*8;for(let i=0;i<8;i++)m[total-1-i]=Math.floor(bits/2**(8*i))&255;
 const H=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]),W=new Uint32Array(64),r=(x,n)=>(x>>>n)|(x<<(32-n));
 for(let o=0;o<total;o+=64){for(let i=0;i<16;i++)W[i]=(m[o+4*i]<<24)|(m[o+4*i+1]<<16)|(m[o+4*i+2]<<8)|m[o+4*i+3];
  for(let i=16;i<64;i++){const a=W[i-15],b=W[i-2];W[i]=(W[i-16]+(r(a,7)^r(a,18)^(a>>>3))+W[i-7]+(r(b,17)^r(b,19)^(b>>>10)))>>>0;}
  let [a,b,c,d,e,f,g,h]=H;
  for(let i=0;i<64;i++){const t1=(h+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+K[i]+W[i])>>>0,t2=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}
  H[0]+=a;H[1]+=b;H[2]+=c;H[3]+=d;H[4]+=e;H[5]+=f;H[6]+=g;H[7]+=h;}
 return [...H].map(x=>x.toString(16).padStart(8,'0')).join('');
}
export function createHash(algorithm){if(algorithm!=='sha256')throw Error('Only sha256 is available in the browser');const parts=[];
 return {update(x){parts.push(typeof x==='string'?x:new TextDecoder().decode(x));return this;},digest(enc){if(enc!=='hex')throw Error('Only hex digests are available');return sha256Hex(parts.join(''));}};}
export const randomUUID=()=>globalThis.crypto.randomUUID();
const unavailable=()=>{throw Error('Not available in the browser edition');};
export default {createHash,randomUUID,readFile:unavailable,readdirSync:()=>['champions']};
export const readFile=unavailable,InferenceSession={create:unavailable},Tensor=function(){unavailable();};
export const createRequire=unavailable,fileURLToPath=x=>String(x),pathToFileURL=x=>x;
