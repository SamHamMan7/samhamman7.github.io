export const inspect={custom:Symbol.for("nodejs.util.inspect.custom")};
export function isDeepStrictEqual(a,b){if(Object.is(a,b))return true;if(typeof a!=="object"||typeof b!=="object"||!a||!b||Object.getPrototypeOf(a)!==Object.getPrototypeOf(b))return false;const ka=Object.keys(a),kb=Object.keys(b);return ka.length===kb.length&&ka.every(k=>Object.hasOwn(b,k)&&isDeepStrictEqual(a[k],b[k]));}
export default {inspect,isDeepStrictEqual};
