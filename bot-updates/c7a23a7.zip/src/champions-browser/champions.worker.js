// Static-site Champions VGC worker: runs the pinned simulator and the Discharge
// search bot entirely in the browser. Same message protocol as
// champions.remote.worker.js, so the battle UI is unchanged.
import * as sim from './ps-sim.js';
import {enumerateChampionsActions} from '../ai/champions-actions.mjs';
import {chooseChampionsPreview} from '../ai/champions-preview.mjs';
import {chooseChampionsLookahead} from '../ai/champions-lookahead.mjs';
import {createChampionsPublic,observeChampionsPublic} from '../ai/champions-public.mjs';
import {createNeuralTracker,observeNeuralTracker} from '../ai/champions-neural.mjs';
import {chooseArenaRollout} from '../../scripts/lib/vgc-arena-rollout.mjs';
import {chooseArenaPreview} from '../../scripts/lib/vgc-arena-preview.mjs';
import {chooseArenaReplacement} from '../../scripts/lib/vgc-arena-phase.mjs';
import {ARENA_PROFILES} from '../../scripts/lib/vgc-arena-agent.mjs';
import {createChampionsBrowserTeamPool} from '../../scripts/lib/champions-ai-teams.mjs';

const FORMAT='gen9championsvgc2026regmc',dex=sim.Dex.mod('champions'),aiTeams=createChampionsBrowserTeamPool(sim);
// "Very Strong" is the same stable search Discharge uses on vgc.bot.
const STABLE=ARENA_PROFILES['native-reply-control'];
// Sparring variety: sample among moves the search rates close to its best
// (within 0.06 on its -1..1 scale) instead of nearly always the top one, so
// the same position is not always answered the same way. Search is unchanged.
const DISCHARGE={...STABLE,settings:{...STABLE.settings,mixWindow:.06,mixTemperature:.03}};
export function validateChampionsTeam(paste){
 try{
  if(typeof paste!=='string'||!paste.trim())return {errors:['Select a Champions team first.'],notes:[],team:null};
  const team=sim.Teams.import(paste);if(!team?.length)return {errors:['Could not import the selected team.'],notes:[],team:null};
  const errors=sim.TeamValidator.get(FORMAT).validateTeam(team)||[];if(team.length!==6)errors.push('Champions M-C practice requires a full team of six.');
  return {errors,notes:[],team:errors.length?null:team};
 }catch(error){return {errors:[error.message],notes:[],team:null};}
}
const randomSeed=()=>Array.from(crypto.getRandomValues(new Uint16Array(4)));
class Session{
 constructor({teamPaste,seed,difficulty='Very Strong',informationMode='bo3'}){
  if(!['bo1','bo3'].includes(informationMode))throw Error('Invalid Champions information mode');
  Object.assign(this,{teamPaste,seed:seed||randomSeed(),difficulty,informationMode,turn:0,ended:false,request:null,token:0,pending:null,closed:false,failures:0});
  this.discharge=difficulty==='Very Strong';this.aiState=createChampionsPublic('p2',dex,sim.Teams);this.tracker=this.discharge?createNeuralTracker('p2',dex,sim.Teams):null;
  let s=this.seed.reduce((a,w)=>Math.imul(a^w,16777619)>>>0,2166136261);this.random=()=>{s=(s+0x6d2b79f5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
 }
 async start(){
  const v=validateChampionsTeam(this.teamPaste);if(v.errors.length)throw Error(v.errors.join('\n'));
  const packed=sim.Teams.pack(v.team);this.aiTeam=aiTeams.select(this.seed);this.streams=sim.getPlayerStreams(new sim.BattleStream());
  void this.consumeP1();void this.consumeP2();
  for(const c of ['omniscient','spectator','p3','p4'])void(async()=>{try{for await(const _ of this.streams[c]){}}catch{}})();
  await this.streams.omniscient.write(`>start ${JSON.stringify({formatid:FORMAT,seed:this.seed})}`);
  await this.streams.omniscient.write(`>player p1 ${JSON.stringify({name:'You',team:packed})}`);
  await this.streams.omniscient.write(`>player p2 ${JSON.stringify({name:'Discharge',team:this.aiTeam.packed})}`);
  if(this.informationMode==='bo3')await this.streams.omniscient.write('>show-openteamsheets');
 }
 async consumeP1(){
  try{for await(const chunk of this.streams.p1){if(this.closed)return;let seen=false;const lines=[];
   for(const line of chunk.split('\n')){if(!line)continue;if(line.startsWith('|request|')){this.request=JSON.parse(line.slice(9));seen=true;continue;}lines.push(line);
    const t=line.match(/^\|turn\|(\d+)$/);if(t)this.turn=+t[1];if(line.startsWith('|win|')||line==='|tie')this.ended=true;if(line.startsWith('|error|'))postMessage({type:'error',message:line.slice(7)});}
   if(lines.length)postMessage({type:'update',side:'p1',view:{turn:this.turn,ended:this.ended,request:this.request},lines});
   if(seen&&!this.ended){this.pending=++this.token;postMessage({type:'request',side:'p1',token:this.pending,view:{turn:this.turn,ended:false,request:this.request,format:FORMAT}});}
  }}catch(e){if(!this.closed)postMessage({type:'error',message:e.message});}
 }
 async decide(request){
  const options={random:this.random};
  if(this.discharge){
   if(request.teamPreview)return chooseArenaPreview(this.tracker,request,{...options,settings:DISCHARGE.previewSearch});
   if(request.forceSwitch?.some(Boolean))return chooseArenaReplacement(this.tracker,request,options);
   return chooseArenaRollout(this.tracker,request,{...options,settings:DISCHARGE.settings});
  }
  if(request.teamPreview)return {chosen:chooseChampionsPreview(request,dex,{window:8,temperature:2.5,maxCandidates:24,random:this.random})};
  return chooseChampionsLookahead(enumerateChampionsActions(request),this.aiState,dex,{request,temperature:.65,window:2.5,random:this.random});
 }
 async consumeP2(){
  try{for await(const chunk of this.streams.p2){if(this.closed)return;observeChampionsPublic(this.aiState,chunk);if(this.tracker)observeNeuralTracker(this.tracker,chunk);const requests=[];
   for(const line of chunk.split('\n')){if(line.startsWith('|request|'))requests.push(JSON.parse(line.slice(9)));
    if(line.startsWith('|error|')&&++this.failures>3)postMessage({type:'error',message:'Champions AI repeatedly made an invalid choice: '+line.slice(7)});
    if(line.startsWith('|win|')||line==='|tie')this.ended=true;}
   for(const request of requests){if(this.ended||request.wait)continue;const legal=enumerateChampionsActions(request);
    let result;try{result=await this.decide(request);}catch(e){console.warn('[Discharge] search failed, using quick choice',e);result=request.teamPreview?{chosen:chooseChampionsPreview(request,dex,{window:8,temperature:2.5,maxCandidates:24,random:this.random})}:chooseChampionsLookahead(legal,this.aiState,dex,{request,temperature:.65,window:2.5,random:this.random});}
    const command=result?.chosen?.command;if(!command||!legal.some(j=>j.command===command))throw Error('Champions AI produced a nonmember legal command.');
    if(!this.closed)await this.streams.p2.write(command);}
  }}catch(e){if(!this.closed)postMessage({type:'error',message:e.message});}
 }
 async choose({side,token,choice}){if(side!=='p1'||this.closed||this.pending!==token)return;if(typeof choice!=='string'||choice.length>250||/[\r\n|>]/.test(choice))throw Error('Invalid battle command');this.pending=null;await this.streams.p1.write(choice);}
 async forfeit(){if(this.streams&&!this.closed)await this.streams.omniscient.write('>forcewin p2');}
 async close(){if(this.closed)return;this.closed=true;if(this.streams)await this.streams.omniscient.writeEnd();}
}
let session=null;
self.onmessage=async({data})=>{
 try{
  if(data.type==='validate')return postMessage({type:'validation',validation:validateChampionsTeam(data.paste)});
  if(data.type==='start'){await session?.close();const o=data.options||{};if(o.format!==FORMAT)throw Error("Unsupported Champions format");session=new Session({teamPaste:o.teamPaste,seed:Array.isArray(o.seed)&&o.seed.length===4?o.seed:null,difficulty:o.difficulty,informationMode:o.informationMode||'bo3'});await session.start();return;}
  if(data.type==='choose')return void await session?.choose(data);
  if(data.type==='forfeit')return void await session?.forfeit();
  if(data.type==='close'){await session?.close();session=null;}
 }catch(e){postMessage({type:'error',message:e.message});}
};
postMessage({type:'ready'});
