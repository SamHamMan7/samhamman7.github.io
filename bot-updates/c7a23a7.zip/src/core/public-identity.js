// Only public protocol identities. Never substitute species or an engine slot.
export function publicIdentity(value) {
  return typeof value === 'string' && /^p[12](?:[a-c])?: /.test(value)
    ? value.replace(/^(p[12])[a-c]:/, '$1:') : null;
}
export function publicSlot(value) {
  const match = typeof value === 'string' && value.match(/^p[12]([a-c]): /);
  return match ? match[1].charCodeAt(0) - 97 : -1;
}
export function resolvePublicIdentity(party, ident) {
  const key = publicIdentity(ident);
  if (!key) return null;
  const matches = party.revealed.filter(mon => publicIdentity(mon.ident) === key);
  // Ambiguous public identities remain unknown; the old active position is not evidence.
  return matches.length === 1 ? matches[0] : null;
}
