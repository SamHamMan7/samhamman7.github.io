import {publicIdentity, publicSlot} from './public-identity.js';

const id = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 80);
const effectID = value => id(String(value || '').replace(/^(move|item|ability): /, ''));
const hp = mon => Number.isFinite(mon?.hpFraction) ? (mon.hpFraction === 1 ? 1 : Math.min(99, Math.ceil(mon.hpFraction * 100 - 1e-10)) / 100) : null;
const TYPES = Object.freeze({move:'move',cant:'cant',switch:'switch',drag:'forcedswitch',replace:'identityreveal',faint:'faint',
  '-damage':'damage','-heal':'heal','-sethp':'sethp','-status':'status','-curestatus':'curestatus',
  '-boost':'boost','-unboost':'unboost','-setboost':'setboost','-clearboost':'clearboost','-clearallboost':'clearallboost',
  '-copyboost':'copyboost','-swapboost':'swapboost','-invertboost':'invertboost',
  '-start':'volatilestart','-end':'volatileend','-singleturn':'singleturn','-singlemove':'singlemove',
  '-fail':'fail','-immune':'immune','-miss':'miss','-crit':'crit','-activate':'activate',
  '-item':'item','-enditem':'enditem','-ability':'ability','-terastallize':'tera',
  '-weather':'weather','-fieldstart':'fieldstart','-fieldend':'fieldend','-sidestart':'sidestart','-sideend':'sideend',
  '-formechange':'form','detailschange':'form','-transform':'transform','-prepare':'prepare','-mustrecharge':'recharge'});
export const SEMANTIC_EVENTS = Object.freeze([...new Set(Object.values(TYPES)), 'reveal']);
export const VOLATILES_V3 = Object.freeze(['substitute','confusion','leechseed','yawn','perish0','perish1','perish2','perish3','ingrain','aquaring','smackdown','magnetrise','telekinesis','gastroacid','embargo','healblock','torment','attract','curse','saltcure','partiallytrapped','recharge','twoturnmove']);
const timer = (turn, min, max) => ({startedTurn:turn, minDuration:min, maxDuration:max});
export function publicTimer(value, turn) {
  if (!value || !Number.isInteger(value.startedTurn)) return [0,0,0,0];
  const age = Math.max(0, turn-value.startedTurn);
  return [Math.min(age,32)/32, Math.max(0,value.minDuration-age)/8, Math.max(0,value.maxDuration-age)/8,1];
}
function participant(view, ident) {
  if (!publicIdentity(ident)) return null;
  const mon = view.mon(ident), side = ident.slice(0,2) === view.side ? 'own' : 'opponent';
  const active = view.party(ident.slice(0,2)).active;
  return {side, ref:mon?.publicRef || 0, species:id(mon?.species), slot:mon && active.includes(mon) ? active.indexOf(mon) : -1};
}
export function beforePublicV3(view, type, args) {
  view.state.semanticHistory ||= [];
  if (['turn','request','move','cant','switch','drag','replace','upkeep'].includes(type)) view.v3PendingMove = null;
  return {actor:participant(view,args[0]), target:participant(view,type==='move'?args[2]:args[1]), hp:hp(view.mon(args[0] || '')),
    otherHP:type==='-sethp'?hp(view.mon(args[2]||'')):null,
    outgoing:['switch','drag','replace'].includes(type) ? view.party(args[0].slice(0,2)).active[publicSlot(args[0])] : null};
}
function append(view, event) {
  view.v3PendingMove=null;
  if (view.v3OrdinalTurn !== view.state.turn) {view.v3OrdinalTurn=view.state.turn;view.v3Ordinal=0;}
  event.turn=view.state.turn;event.ordinal=++view.v3Ordinal;
  view.state.semanticHistory.push(event);
  view.state.semanticHistory=view.state.semanticHistory.slice(-16);
}
function freshVisit(turn, type) {
  return {enteredTurn:turn, entryKind:type, actionObserved:false, visitMoves:[],visitReveals:{}, toxicMin:0,toxicMax:0,toxicDamage:false,conditions:{}};
}
export function updatePublicV3(view, type, args, before) {
  const state=view.state, field=state.field;
  field.publicTimers ||= {own:{},opponent:{},global:{}};
  if (['switch','drag','replace'].includes(type)) {
    const mon=view.mon(args[0]);
    if (mon) {
      // References are monotonically allocated per public side, never hidden team indices.
      const party=view.party(args[0].slice(0,2));
      if (!mon.publicRef) {party.nextPublicRef=(party.nextPublicRef||0)+1;mon.publicRef=party.nextPublicRef;}
      if (type!=='replace') {
        if (before.outgoing) before.outgoing.v3=freshVisit(null,null);
        mon.v3=freshVisit(state.turn,type);
      }
      mon.v3 ||= freshVisit(state.turn,type);
    }
  }
  const mon=view.mon(args[0] || '');
  if (mon) {
    mon.v3 ||= freshVisit(null,null);
    const m=mon.v3;
    if (type==='move'||type==='cant') {m.actionObserved=true;m.lastActionTurn=state.turn;}
    if (type==='move') {m.lastMove=id(args[1]);if(!m.visitMoves.includes(args[1]))m.visitMoves.push(args[1]);}
    if (type==='-start') {
      const effect=effectID(args[1]);
      // Public start/end bound durations. Hidden queue/PP/item state never tightens these intervals.
      const durations={encore:[0,4],disable:[0,5],taunt:[0,4],confusion:[0,5],magnetrise:[5,5]};
      const bounds=durations[effect];
      m.conditions[effect]={...(bounds?timer(state.turn,...bounds):{}),move:mon.publicMechanics?.conditions[effect]?.move || null};
    }
    if (type==='-end') delete m.conditions[effectID(args[1])];
    if (type==='-mustrecharge') m.conditions.recharge={};
    if (type==='cant' && effectID(args[1])==='recharge') delete m.conditions.recharge;
    if (type==='-prepare') m.conditions.twoturnmove={move:id(args[1])};
    if (type==='move') delete m.conditions.twoturnmove;
    if (type==='-status' || type==='-curestatus') {m.toxicMin=0;m.toxicMax=0;m.toxicDamage=false;}
    if (type==='-damage' && mon.status==='tox' && args.some(x=>x==='[from] psn')) m.toxicDamage=true;
    if (['-item','-enditem'].includes(type)) {mon.itemKnown=true;mon.lastRevealedItem=id(args[1]);}
    if (type==='-ability') mon.abilityKnown=true;
    if (['-item','-enditem','-ability','-terastallize'].includes(type)) {
      const fields=type==='-ability'?['ability','abilityKnown']:type==='-terastallize'?['terastallized','teraType']:['item','itemKnown','lastRevealedItem'];
      for(const field of fields)m.visitReveals[field]=mon[field];
    }
    // Last observed move + publicly revealed Choice item is evidence, not a hidden lock flag.
    if (type==='move' && /^choice(band|scarf|specs)$/.test(id(mon.item))) m.choiceMove=id(args[1]);
    if (type==='-item' || type==='-enditem') delete m.choiceMove;
  }
  if (type==='upkeep') for(const party of [state.own,state.opponent]) for(const active of party.active) {
    if(active?.status!=='tox'||active.fainted||!active.v3)continue;
    const m=active.v3;m.toxicMax=Math.min(15,m.toxicMax+1);
    if(m.toxicDamage)m.toxicMin=Math.min(15,m.toxicMin+1);
    m.toxicDamage=false;
  }
  const ft=field.publicTimers;
  if(type==='-weather'&&!args.includes('[upkeep]')) {
    if(args[0]==='none')delete ft.global.weather;
    else ft.global.weather={...timer(state.turn,5,8),effect:effectID(args[0])};
  }
  if(type==='-fieldstart'||type==='-fieldend') {
    const effect=effectID(args[0]),key=effect.endsWith('terrain')?'terrain':effect;
    if(type==='-fieldend')delete ft.global[key];
    else ft.global[key]={...timer(state.turn,5,key==='terrain'?8:5),effect};
  }
  if(type==='-sidestart'||type==='-sideend') {
    const side=args[0].startsWith(view.side)?'own':'opponent',effect=effectID(args[1]);
    if(type==='-sideend')delete ft[side][effect];
    else if(['reflect','lightscreen','auroraveil','tailwind','safeguard','mist'].includes(effect))
      ft[side][effect]={...timer(state.turn,effect==='tailwind'?4:5,['reflect','lightscreen','auroraveil'].includes(effect)?8:effect==='tailwind'?4:5),effect};
  }
  // Explicit source revelations can occur on field lines with no primary Pok�mon.
  for(const extra of args) {
    const match=extra.match(/^\[from\] (item|ability): (.+)$/);
    if(!match)continue;
    const ownerArg=args.find(a=>a.startsWith('[of] '));
    const owner=ownerArg?view.mon(ownerArg.slice(5)):mon;
    if(!owner)continue;
    owner[match[1]]=match[2];owner[match[1]+'Known']=true;
    if(owner.v3)Object.assign(owner.v3.visitReveals,{[match[1]]:match[2],[match[1]+'Known']:true});
    append(view,{kind:'reveal',actor:participant(view,owner.ident),effect:match[1],value:id(match[2]),result:'revealed'});
  }
  if (!TYPES[type] || type==='-weather'&&args.includes('[upkeep]')) return;
  const actor=['switch','drag','replace'].includes(type)?participant(view,args[0]):before.actor;
  const event={kind:TYPES[type],actor,target:before.target, effect:'',result:'observed'};
  if(type==='move') {event.move=id(args[1]);event.result='attempted';event.target=participant(view,args[2]);}
  else if(type==='cant'){event.effect=effectID(args[1]);event.move=id(args[2]);event.result='unable';}
  else if(type==='-miss'){event.target=participant(view,args[1]);event.result='missed';}
  else if(['-damage','-heal','-sethp','faint','switch','drag','replace'].includes(type)) {
    event.hpBefore=['switch','drag','replace'].includes(type)?null:before.hp;event.hpAfter=hp(mon);
    event.effect=effectID(args.find(a=>a.startsWith('[from] '))?.slice(7));
  } else if (['-weather','-fieldstart','-fieldend'].includes(type)) event.effect=effectID(args[0]);
  else event.effect=effectID(args[1]);
  if(type==='-sidestart'||type==='-sideend')event.actor={side:args[0].startsWith(view.side)?'own':'opponent',ref:0,slot:-1,species:''};
  if(['-boost','-unboost','-setboost'].includes(type))event.amount=Math.max(-6,Math.min(6,Number(args[2])||0))*(type==='-unboost'?-1:1);
  const results={'-fail':'failed','-immune':'immune','-miss':'missed','-crit':'critical'};
  const protection=type==='-singleturn'&&mon?.publicMechanics?.protect?.lastOutcome==='succeeded';
  const blocked=type==='-activate'&&['protect','detect','kingsshield','spikyshield','banefulbunker','silktrap','burningbulwark','obstruct'].includes(event.effect);
  if(results[type]||protection||blocked) {
    event.result=results[type]||(blocked?'blocked':'succeeded');
    const pending=view.v3PendingMove,who=event.actor;
    const same=(a,b)=>a&&b&&a.side===b.side&&a.ref!==0&&a.ref===b.ref;
    const attributable=pending&&(type==='-fail'||protection?same(who,pending.actor):same(type==='-miss'?event.target:who,pending.target));
    if(attributable) {
      pending.result=event.result;pending[event.result]=true;
      return;
    }
  }
  append(view,event);
  if(type==='-sethp'&&args[2])append(view,{kind:'sethp',actor:participant(view,args[2]),effect:'painsplit',hpBefore:before.otherHP,hpAfter:hp(view.mon(args[2])),result:'observed'});
  if(type==='move')view.v3PendingMove=event;
  // A lifecycle/HP message is retained in order; do not merge an outcome across it.
  else view.v3PendingMove=null;
}
