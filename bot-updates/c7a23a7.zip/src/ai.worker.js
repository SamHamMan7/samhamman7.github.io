﻿import {chooseAction, legalActions} from './ai/policy.js';
import {chooseWorkerAction} from './ai/neural/worker-dispatch.js';
import {initializeBundledNeuralPreview} from './ai/neural/experimental.js';
self.onmessage = async ({data}) => {
  try {
    const started = performance.now();
    if(data.difficulty==='Neural Preview'&&data.view?.format==='gen9randombattle')await initializeBundledNeuralPreview();
    const result = await chooseWorkerAction(data, {chooseAction, legalActions});
    if (!result.choice) throw new Error('No legal action found for the current request');
    postMessage({type:'decision',token:data.token,side:data.side,choice:result.choice,elapsedMs:performance.now()-started,diagnostics:result.diagnostics});
  } catch (error) {
    postMessage({type:'error',token:data.token,side:data.side,message:error.message});
  }
};

