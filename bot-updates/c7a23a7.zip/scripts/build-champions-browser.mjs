// Bundles the Champions VGC battle engine + search bot into one static web worker.
//   node scripts/build-champions-browser.mjs [OUTPUT_DIR]
// Only the pinned simulator's battle modules and the base + champions data files
// are included; no server, database, model weights or credentials.
import fs from 'node:fs';import path from 'node:path';import {build} from 'esbuild';import {createHash} from 'node:crypto';
const root=path.resolve('.'),ps=path.join(root,'.tools/pokemon-showdown-current/dist'),out=path.resolve(process.argv[2]||'dist-champions');
const DATA=['abilities','aliases','conditions','formats-data','items','learnsets','moves','natures','pokedex','pokemongo','rulesets','scripts','tags','typechart'];
const MOD=fs.readdirSync(path.join(ps,'data/mods/champions')).filter(f=>f.endsWith('.js')).map(f=>f.slice(0,-3));
const shims=path.join(root,'src/champions-browser/node-shims.js'),posix=p=>p.split(path.sep).join('/');
// Static registry for the simulator's computed require() calls (data/config files).
const registry=[...DATA.map(f=>['/ps/data/'+f,path.join(ps,'data',f+'.js')]),...MOD.map(f=>['/ps/data/mods/champions/'+f,path.join(ps,'data/mods/champions',f+'.js')]),['/ps/config/formats',path.join(ps,'config/formats.js')]];
const registrySource=registry.map(([k,f],i)=>`import * as m${i} from ${JSON.stringify(posix(f))};`).join('\n')+`\nconst table={${registry.map(([k],i)=>`${JSON.stringify(k)}:m${i}`).join(',')}};
export function psRequire(p){const parts=[];for(const s of String(p).replace(/\\.js$/,'').split('/')){if(!s||s==='.')continue;if(s==='..')parts.pop();else parts.push(s);}const k='/'+parts.join('/');if(table[k])return table[k].default&&Object.keys(table[k]).length===1?table[k].default:table[k];const e=new Error('Cannot find module '+k);e.code='MODULE_NOT_FOUND';throw e;}`;
// Each rewrite is [file, needle, replacement]; every needle must match exactly once.
const rewrite=[
 ['sim/dex.js','require(filePath)','__ps.psRequire(filePath)'],
 ['sim/dex.js','require(path.resolve(DATA_DIR, "aliases"))','__ps.psRequire("/ps/data/aliases")'],
 // Every mod name exists (formats refer to them), but only champions data is bundled.
 ['sim/dex.js','fs.readdirSync(MODS_DIR)',JSON.stringify(fs.readdirSync(path.join(ps,'data/mods')).filter(m=>fs.statSync(path.join(ps,'data/mods',m)).isDirectory()))],
 ['sim/dex.js','path.resolve(__dirname, "../data")','"/ps/data"'],
 ['sim/dex.js','path.resolve(DATA_DIR, "./mods")','"/ps/data/mods"'],
 ['sim/dex-formats.js','require(`${__dirname}/../config/custom-formats`)','__ps.psRequire("/ps/config/custom-formats")'],
 ['sim/dex-formats.js','require(`${__dirname}/../config/formats`)','__ps.psRequire("/ps/config/formats")'],
 ['sim/dex-text.js','path.resolve(__dirname, "../data/text")','"/ps/data/text"'],
 ['sim/dex-text.js','require(filePath)','__ps.psRequire(filePath)'],
 ['sim/teams.js','require(`../data/random-battles/${mod}/teams`)','__ps.psRequire("/ps/random-battles/"+mod)'],
 ['sim/teams.js','require("../data/mods/afd/random-teams")','__ps.psRequire("/ps/random-battles/afd")'],
 ['sim/teams.js','require("../data/mods/gen9ssb/random-teams")','__ps.psRequire("/ps/random-battles/gen9ssb")'],
 ['sim/teams.js','require("../data/random-battles/gen9baby/teams")','__ps.psRequire("/ps/random-battles/gen9baby")'],
 ['sim/teams.js','require("../data/random-battles/gen9cap/teams")','__ps.psRequire("/ps/random-battles/gen9cap")'],
 ['sim/teams.js','require("../data/random-battles/gen9ffa/teams")','__ps.psRequire("/ps/random-battles/gen9ffa")'],
 ['sim/battle-stream.js','require("../lib")','{Streams:require("../lib/streams"),Utils:require("../lib/utils").Utils}'],
 ['sim/prng.js','globalThis.crypto = require("node:crypto")','globalThis.crypto = undefined'],
];
const rewriteFile=(rel,s)=>{for(const [f,a,b]of rewrite)if(f===rel){const n=s.split(a).length-1;if(n!==1)throw Error(`Rewrite needle matched ${n} times in ${rel}: ${a}`);s=s.replace(a,()=>b);}return s;};
const plugin={name:'champions-browser',setup(b){
 if(process.env.TRACE)b.onResolve({filter:/.*/},a=>{console.error('TRACE',a.path,'<-',path.relative(root,a.importer));return undefined;});
 b.onResolve({filter:/^ps-registry$/},()=>({path:'ps-registry',namespace:'ps-registry'}));
 b.onLoad({filter:/.*/,namespace:'ps-registry'},()=>({contents:registrySource,resolveDir:root,loader:'js'}));
 b.onResolve({filter:/^(node:)?(crypto|fs|fs\/promises|path|module|url|util)$|^onnxruntime-(node|web)$/},a=>a.path.replace('node:','')==='util'?{path:path.join(root,'src/champions-browser/util-shim.js')}:{path:shims});
 b.onLoad({filter:/pokemon-showdown-current[\\/]dist[\\/]sim[\\/].*\.js$/},a=>{const rel=posix(path.relative(ps,a.path));let s=fs.readFileSync(a.path,'utf8');if(rewrite.some(x=>x[0]===rel)){s='var __ps=require("ps-registry");\n'+rewriteFile(rel,s);}return {contents:s,loader:'js'};});
 b.onLoad({filter:/src[\\/]ai[\\/]champions-damage\.mjs$/},a=>{const s=fs.readFileSync(a.path,'utf8'),line="const {Battle,Dex}=createRequire(import.meta.url)(fileURLToPath(new URL('../../.tools/pokemon-showdown-current/dist/sim/index.js',import.meta.url)));";if(!s.includes(line))throw Error('Damage simulator import changed');return {contents:s.replace(line,"import {Battle,Dex} from '../champions-browser/ps-sim.js';"),loader:'js',resolveDir:path.dirname(a.path)};});
}};
fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(path.join(root,'src/champions-browser/util-shim.js'),'export const inspect={custom:Symbol.for("nodejs.util.inspect.custom")};\nexport function isDeepStrictEqual(a,b){if(Object.is(a,b))return true;if(typeof a!=="object"||typeof b!=="object"||!a||!b||Object.getPrototypeOf(a)!==Object.getPrototypeOf(b))return false;const ka=Object.keys(a),kb=Object.keys(b);return ka.length===kb.length&&ka.every(k=>Object.hasOwn(b,k)&&isDeepStrictEqual(a[k],b[k]));}\nexport default {inspect,isDeepStrictEqual};\n');
await build({entryPoints:{'champions.worker':path.join(root,'src/champions-browser/champions.worker.js')},bundle:true,outdir:out,format:'esm',platform:'browser',target:'chrome120',minify:true,define:{__dirname:'"/ps/sim"','process.env.NODE_ENV':'"production"'},plugins:[plugin],logLevel:'warning',legalComments:'none',metafile:true}).then(r=>fs.writeFileSync(path.join(out,'champions-meta.json'),JSON.stringify(r.metafile)));
const file=path.join(out,'champions.worker.js'),bytes=fs.readFileSync(file);console.log(JSON.stringify({file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')}));
