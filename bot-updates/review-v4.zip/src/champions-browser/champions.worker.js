// Static-site Champions VGC worker: runs the pinned simulator and the Discharge
// search bot entirely in the browser. Same message protocol as
// champions.remote.worker.js, so the battle UI is unchanged.
import * as sim from './ps-sim.js';
import {enumerateChampionsActions} from '../ai/champions-actions.mjs';
import {chooseChampionsPreview} from '../ai/champions-preview.mjs';
import {chooseChampionsLookahead} from '../ai/champions-lookahead.mjs';
import {createChampionsPublic,observeChampionsPublic} from '../ai/champions-public.mjs';
import {createNeuralTracker,observeNeuralTracker} from '../ai/champions-neural.mjs';
import {chooseArenaRollout} from '../../scripts/lib/vgc-arena-rollout.mjs';
import {chooseArenaPreview} from '../../scripts/lib/vgc-arena-preview.mjs';
import {chooseArenaReplacement} from '../../scripts/lib/vgc-arena-phase.mjs';
import {ARENA_PROFILES} from '../../scripts/lib/vgc-arena-agent.mjs';
import {createChampionsBrowserTeamPool,createChampionsAITeamPool} from '../../scripts/lib/champions-ai-teams.mjs';
import {createTeamVariety} from '../../scripts/lib/champions-team-variety.mjs';
import {createSwitchTempo,SPARRING_SWITCH_COST} from '../../scripts/lib/vgc-switch-tempo.mjs';

const FORMAT='gen9championsvgc2026regmc',dex=sim.Dex.mod('champions'),aiTeams=createChampionsBrowserTeamPool(sim);
// "Very Strong" is the same stable search Discharge uses on vgc.bot.
const STABLE=ARENA_PROFILES['native-reply-control'];
// Sparring variety: sample among moves the search rates close to its best
// (within 0.09 on its -1..1 scale) instead of nearly always the top one, so
// the same position is not always answered the same way. Search is unchanged.
const DISCHARGE={...STABLE,settings:{...STABLE.settings,mixWindow:.09,mixTemperature:.045}};
// Every level is Discharge's search. Lower levels pick more often among moves the search
// rates a little below its best (wider window, higher temperature) and lead more loosely,
// instead of using a different, weaker bot that plays normally and then blunders.
const LEVELS={
 'Very Strong':DISCHARGE,
 Strong:{...STABLE,settings:{...STABLE.settings,mixWindow:.2,mixTemperature:.08},previewSearch:{...STABLE.previewSearch,window:.1,temperature:.04}},
 Medium:{...STABLE,settings:{...STABLE.settings,mixWindow:.38,mixTemperature:.16,timeMs:10000},previewSearch:{...STABLE.previewSearch,window:.2,temperature:.08,timeMs:8000}},
};
// Team variety: the page counts games and keeps a shuffle seed, so the bot works through the
// whole pool in a shuffled order before any team comes back, and each team's sets are remixed.
const varyTeam=createTeamVariety(sim,FORMAT,aiTeams.entries,createChampionsAITeamPool(sim).entries);
function nextTeam(seed,random,rotation){
 let team=aiTeams.select(seed);const n=aiTeams.entries.length;
 if(rotation&&Number.isInteger(rotation.game)&&rotation.game>=0&&Number.isInteger(rotation.seed)){
  let s=(rotation.seed^Math.imul(Math.floor(rotation.game/n)+1,2654435761))>>>0;const r=()=>{s=(s+0x6d2b79f5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
  const order=aiTeams.entries.map((_,i)=>i);for(let i=n-1;i>0;i--){const j=Math.floor(r()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
  team=aiTeams.entries[order[rotation.game%n]];
 }
 return {id:team.id,packed:varyTeam(team.packed,random)};
}
export function validateChampionsTeam(paste){
 try{
  if(typeof paste!=='string'||!paste.trim())return {errors:['Select a Champions team first.'],notes:[],team:null};
  const team=sim.Teams.import(paste);if(!team?.length)return {errors:['Could not import the selected team.'],notes:[],team:null};
  const errors=sim.TeamValidator.get(FORMAT).validateTeam(team)||[];if(team.length!==6)errors.push('Champions M-C practice requires a full team of six.');
  return {errors,notes:[],team:errors.length?null:team};
 }catch(error){return {errors:[error.message],notes:[],team:null};}
}
const randomSeed=()=>Array.from(crypto.getRandomValues(new Uint16Array(4)));
class Session{
 constructor({teamPaste,seed,difficulty='Very Strong',informationMode='bo3',rotation=null}){
  if(!['bo1','bo3'].includes(informationMode))throw Error('Invalid Champions information mode');
  Object.assign(this,{teamPaste,seed:seed||randomSeed(),difficulty,informationMode,rotation,turn:0,ended:false,request:null,token:0,pending:null,closed:false,failures:0,log:[],recorded:false,switchTempo:createSwitchTempo()});
  this.discharge=true;this.level=LEVELS[difficulty]||DISCHARGE;this.aiState=createChampionsPublic('p2',dex,sim.Teams);this.tracker=this.discharge?createNeuralTracker('p2',dex,sim.Teams):null;
  let s=this.seed.reduce((a,w)=>Math.imul(a^w,16777619)>>>0,2166136261);this.random=()=>{s=(s+0x6d2b79f5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
 }
 async start(){
  const v=validateChampionsTeam(this.teamPaste);if(v.errors.length)throw Error(v.errors.join('\n'));
  const packed=sim.Teams.pack(v.team);this.packed=packed;this.aiTeam=nextTeam(this.seed,this.random,this.rotation);this.streams=sim.getPlayerStreams(new sim.BattleStream());
  void this.consumeP1();void this.consumeP2();
  for(const c of ['omniscient','spectator','p3','p4'])void(async()=>{try{for await(const _ of this.streams[c]){}}catch{}})();
  await this.streams.omniscient.write(`>start ${JSON.stringify({formatid:FORMAT,seed:this.seed})}`);
  await this.streams.omniscient.write(`>player p1 ${JSON.stringify({name:'You',team:packed})}`);
  await this.streams.omniscient.write(`>player p2 ${JSON.stringify({name:'Discharge',team:this.aiTeam.packed})}`);
  if(this.informationMode==='bo3')await this.streams.omniscient.write('>show-openteamsheets');
 }
 async consumeP1(){
  try{for await(const chunk of this.streams.p1){if(this.closed)return;let seen=false;const lines=[];
   for(const line of chunk.split('\n')){if(!line)continue;if(line.startsWith('|request|')){this.request=JSON.parse(line.slice(9));seen=true;continue;}lines.push(line);
    const t=line.match(/^\|turn\|(\d+)$/);if(t)this.turn=+t[1];if(line.startsWith('|win|')||line==='|tie')this.ended=true;if(line.startsWith('|error|'))postMessage({type:'error',message:line.slice(7)});}
   if(lines.length)postMessage({type:'update',side:'p1',view:{turn:this.turn,ended:this.ended,request:this.request},lines});
   // After the game only: everything needed to replay it for the review page.
   if(this.ended&&!this.recorded){this.recorded=true;postMessage({type:'record',record:{v:1,format:FORMAT,seed:this.seed,p1:this.packed,p2:this.aiTeam.packed,informationMode:this.informationMode,difficulty:this.difficulty,choices:this.log}});}
   if(seen&&!this.ended){this.pending=++this.token;postMessage({type:'request',side:'p1',token:this.pending,view:{turn:this.turn,ended:false,request:this.request,format:FORMAT}});}
  }}catch(e){if(!this.closed)postMessage({type:'error',message:e.message});}
 }
 async decide(request){
  const options={random:this.random};
  if(this.discharge){
   if(request.teamPreview)return chooseArenaPreview(this.tracker,request,{...options,settings:this.level.previewSearch});
   if(request.forceSwitch?.some(Boolean))return chooseArenaReplacement(this.tracker,request,options);
   // No switch charge (user decision 2026-11-19): the search decides switches on its own.
   const rowBias=this.switchTempo.bias(request),result=await chooseArenaRollout(this.tracker,request,{...options,settings:{...this.level.settings,...(rowBias?{rowBias}:{})}});
   this.switchTempo.record(request,result.chosen);
   return result;
  }
  if(request.teamPreview)return {chosen:chooseChampionsPreview(request,dex,{window:8,temperature:2.5,maxCandidates:24,random:this.random})};
  return chooseChampionsLookahead(enumerateChampionsActions(request),this.aiState,dex,{request,temperature:.65,window:2.5,random:this.random});
 }
 async consumeP2(){
  try{for await(const chunk of this.streams.p2){if(this.closed)return;observeChampionsPublic(this.aiState,chunk);if(this.tracker)observeNeuralTracker(this.tracker,chunk);const requests=[];
   for(const line of chunk.split('\n')){if(line.startsWith('|request|'))requests.push(JSON.parse(line.slice(9)));
    if(line.startsWith('|error|')&&++this.failures>3)postMessage({type:'error',message:'Champions AI repeatedly made an invalid choice: '+line.slice(7)});
    if(line.startsWith('|win|')||line==='|tie')this.ended=true;}
   for(const request of requests){if(this.ended||request.wait)continue;const legal=enumerateChampionsActions(request);
    let result;try{result=await this.decide(request);}catch(e){console.warn('[Discharge] search failed, using quick choice',e);result=request.teamPreview?{chosen:chooseChampionsPreview(request,dex,{window:8,temperature:2.5,maxCandidates:24,random:this.random})}:chooseChampionsLookahead(legal,this.aiState,dex,{request,temperature:.65,window:2.5,random:this.random});}
    const command=result?.chosen?.command;if(!command||!legal.some(j=>j.command===command))throw Error('Champions AI produced a nonmember legal command.');
    if(!this.closed){this.log.push(['p2',command]);await this.streams.p2.write(command);}}
  }}catch(e){if(!this.closed)postMessage({type:'error',message:e.message});}
 }
 async choose({side,token,choice}){if(side!=='p1'||this.closed||this.pending!==token)return;if(typeof choice!=='string'||choice.length>250||/[\r\n|>]/.test(choice))throw Error('Invalid battle command');this.pending=null;this.log.push(['p1',choice]);await this.streams.p1.write(choice);}
 async forfeit(){if(this.streams&&!this.closed)this.log.push(['end','forcewin p2']);if(this.streams&&!this.closed)await this.streams.omniscient.write('>forcewin p2');}
 async close(){if(this.closed)return;this.closed=true;if(this.streams)await this.streams.omniscient.writeEnd();}
}

// ---- Game review -----------------------------------------------------------------
// Replays a finished game from its record and, at each of the player's decisions, asks
// Discharge what it would have played in the player's seat (using only what the player
// could see). Runs after the game, never during it.
const signedToChance=v=>Math.round(Math.max(0,Math.min(1,(v+1)/2))*1000)/10;
const canon=c=>String(c).toLowerCase().replace(/\+/g,'').replace(/\s+/g,' ').replace(/\s*,\s*/g,', ').trim();
function matchLegal(choice,legal,request){
 const want=canon(choice);let hit=legal.find(j=>canon(j.command)===want);if(hit)return hit;
 // The client may name a move or leave out a target the search writes down.
 const parts=want.split(', ').map((part,slot)=>{const w=part.split(' ');if(w[0]!=='move')return part;const mega=w.includes('mega');let rest=w.slice(1).filter(x=>x!=='mega');let target='';if(rest.length>1&&/^-?[12]$/.test(rest[rest.length-1]))target=rest.pop();let id=rest.join('');
  if(!/^\d+$/.test(id)){const moves=request.active?.[slot]?.moves||[];const k=moves.findIndex(m=>m.id===id.replace(/[^a-z0-9]/g,''));if(k>=0)id=String(k+1);}
  return {id,target,mega};});
 const same=(j)=>{const js=canon(j.command).split(', ');if(js.length!==parts.length)return false;return js.every((part,i)=>{const p=parts[i];if(typeof p==='string')return part===p||(p==='default'||p==='pass');const w=part.split(' ');if(w[0]!=='move'||w[1]!==p.id||w.includes('mega')!==p.mega)return false;const t=w.slice(2).find(x=>/^-?[12]$/.test(x))||'';return !p.target||!t||t===p.target;});};
 return legal.find(same)||null;
}
class Review{
 constructor(record){this.record=record;this.steps=0;this.stopped=false;this.active={};this.fresh=[];this.turn=0;
  let s=record.seed.reduce((a,w)=>Math.imul(a^w,16777619)>>>0,40503);this.random=()=>{s=(s+0x6d2b79f5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
  this.queue={p1:[],p2:[]};this.forfeit=false;for(const [side,choice] of record.choices){if(side==='end')this.forfeit=true;else this.queue[side].push(choice);}
  this.total=this.queue.p1.length;this.tracker=createNeuralTracker('p1',dex,sim.Teams);
 }
 name(ident){return String(ident||'').replace(/^p\d[a-d]?: /,'');}
 seat(side,target,slot){ // target as written in a command by `side`
  const foe=side==='p1'?'p2':'p1',t=+target;if(!t)return '';const key=t>0?foe+'ab'[t-1]:side+'ab'[-t-1];return this.active[key]||(t>0?'foe '+t:'ally');}
 labelOwn(command,request){
  if(command.startsWith('team '))return command.slice(5).split('').map(n=>request.side.pokemon[n-1]?.details.split(',')[0]).join(', ');
  return canon(command).split(', ').map((part,slot)=>{const w=part.split(' '),who=request.side.pokemon[slot]?.details.split(',')[0]||'Your Pokémon';
   if(w[0]==='pass')return null;if(w[0]==='switch')return `${who} switches to ${request.side.pokemon[w[1]-1]?.details.split(',')[0]}`;
   if(w[0]==='move'){const move=request.active?.[slot]?.moves?.[w[1]-1],t=w.slice(2).find(x=>/^-?[12]$/.test(x));return `${who}${w.includes('mega')?' (Mega)':''}: ${move?.move||'move '+w[1]}${t?' into '+this.seat('p1',t,slot):''}`;}
   return part;}).filter(Boolean).join(' + ');
 }
 labelFoe(joint){
  return (joint.actions||[]).map((a,slot)=>{const who=this.active['p2'+'ab'[a.slot??slot]]||'Foe';
   if(a.type==='pass')return null;if(a.type==='switch')return `${who} switches${a.species||a.name?' to '+(a.species||a.name):''}`;
   const id=a.move?.id||a.moveId||a.id,move=id?dex.moves.get(id).name:'a move';return `${who}${a.mega?' (Mega)':''}: ${move}${a.target?' into '+this.seat('p2',a.target,slot):''}`;}).filter(Boolean).join(' + ')||joint.command;
 }
 observe(line){
  const p=line.split('|');
  if(['switch','drag','replace'].includes(p[1])){const m=/^(p[12][ab]): (.*)$/.exec(p[2]);if(m)this.active[m[1]]=p[3].split(',')[0];}
  if(p[1]==='detailschange'){const m=/^(p[12][ab]): /.exec(p[2]);if(m)this.active[m[1]]=p[3].split(',')[0];}
  if(p[1]==='turn')this.turn=+p[2];
 }
 async analyse(request,choice){
  const legal=enumerateChampionsActions(request),mine=matchLegal(choice,legal,request),step={n:++this.steps,of:this.total,turn:this.turn,board:{yours:[this.active.p1a,this.active.p1b].filter(Boolean),theirs:[this.active.p2a,this.active.p2b].filter(Boolean)},yours:{command:choice,label:mine?this.labelOwn(mine.command,request):choice}};
  try{
   if(request.teamPreview){step.kind='preview';const r=await chooseArenaPreview(this.tracker,request,{random:this.random,settings:DISCHARGE.previewSearch});step.bot={command:r.chosen.command,label:this.labelOwn(r.chosen.command,request)};
    const lead=c=>c.replace('team ','').slice(0,2).split('').sort().join(''),back=c=>c.replace('team ','').slice(2).split('').sort().join('');step.same=lead(canon(choice))===lead(r.chosen.command)&&back(canon(choice))===back(r.chosen.command);step.sameFour=canon(choice).replace('team ','').split('').sort().join('')===r.chosen.command.replace('team ','').split('').sort().join('');}
   else if(request.forceSwitch?.some(Boolean)){step.kind='replace';const r=await chooseArenaReplacement(this.tracker,request,{random:this.random});step.bot={command:r.chosen.command,label:this.labelOwn(r.chosen.command,request)};step.same=!!mine&&mine.command===r.chosen.command;
    if(r.policy)step.rows=r.policy.map(x=>({command:x.command,label:this.labelOwn(x.command,request),share:Math.round(x.probability*1000)/10})).sort((a,b)=>b.share-a.share).slice(0,4);}
   else{step.kind='move';
    const r=await chooseArenaRollout(this.tracker,request,{random:this.random,settings:{...DISCHARGE.settings,timeMs:12000,trace:true,...(mine?{inspectRows:[mine.command]}:{})}}),t=r.diagnostics.searchTrace,values=t.weightedValues||t.rows.map((_,i)=>t.payoffs[i].reduce((s,x,j)=>s+x*t.equilibriumColumns[j],0)),replies=r.diagnostics.responseProbabilities||t.equilibriumColumns;
    const share=new Map(r.policy.map(x=>[x.command,x.probability]));
    const rows=t.rows.map((command,i)=>({command,label:this.labelOwn(command,request),share:Math.round((share.get(command)||0)*1000)/10,chance:signedToChance(values[i]),i}));
    const best=rows.reduce((a,b)=>b.chance>a.chance?b:a),you=mine?rows.find(x=>x.command===mine.command):null;
    const order=replies.map((p,j)=>[p,j]).sort((a,b)=>b[0]-a[0]).filter(x=>x[0]>.02).slice(0,3),foes=order.map(([p,j])=>({label:this.labelFoe({command:t.columns[j],actions:t.columnActions?.[j]}),share:Math.round(p*1000)/10,j}));
    step.bot={command:best.command,label:best.label,chance:best.chance};step.same=!!you&&you.command===best.command;if(you){step.yours.chance=you.chance;step.loss=Math.round((best.chance-you.chance)*10)/10;}
    const shown=[...rows].sort((a,b)=>b.chance-a.chance).slice(0,4);if(you&&!shown.includes(you))shown.push(you);
    step.rows=shown.map(x=>({label:x.label,share:x.share,chance:x.chance,you:x===you,grid:foes.map(f=>signedToChance(t.payoffs[x.i][f.j]))}));step.replies=foes.map(f=>({label:f.label,share:f.share}));
    step.ms=Math.round(r.diagnostics.totalMs);}
  }catch(e){step.kind=step.kind||'move';step.error=e.message;step.midTurn=/Interrupted turn/.test(e.message);}
  return step;
 }
 async run(){
  const r=this.record;this.streams=sim.getPlayerStreams(new sim.BattleStream());
  for(const c of ['omniscient','spectator','p3','p4'])void(async()=>{try{for await(const _ of this.streams[c]){}}catch{}})();
  const feed=async side=>{try{for await(const chunk of this.streams[side]){if(this.stopped)return;if(side==='p1')observeNeuralTracker(this.tracker,chunk);let request=null,retry=false;
    for(const line of chunk.split('\n')){if(!line)continue;if(line.startsWith('|request|')){request=JSON.parse(line.slice(9));continue;}if(line.startsWith('|error|'))retry=true;
     if(side==='p1'){this.observe(line);this.fresh.push(line);if(line.startsWith('|win|')||line==='|tie'){postMessage({type:'review-done',lines:this.fresh.splice(0),winner:line.startsWith('|win|')?line.slice(5):''});this.stopped=true;}}}
    if(this.stopped)return;
    if(request&&!request.wait||retry){const choice=this.queue[side].shift();
     if(choice===undefined){if(side==='p1'){postMessage({type:'review-done',lines:this.fresh.splice(0),winner:this.forfeit?'Discharge':'',forfeit:this.forfeit});this.stopped=true;}continue;}
     if(side==='p1'&&request&&!retry){const lines=this.fresh.splice(0),step=await this.analyse(request,choice);if(this.stopped)return;postMessage({type:'review-step',step:{...step,lines}});}
     await this.streams[side].write(choice);}
   }}catch(e){if(!this.stopped)postMessage({type:'review-error',message:e.message});}};
  void feed('p1');void feed('p2');
  await this.streams.omniscient.write(`>start ${JSON.stringify({formatid:FORMAT,seed:r.seed})}`);
  await this.streams.omniscient.write(`>player p1 ${JSON.stringify({name:'You',team:r.p1})}`);
  await this.streams.omniscient.write(`>player p2 ${JSON.stringify({name:'Discharge',team:r.p2})}`);
  if(r.informationMode==='bo3')await this.streams.omniscient.write('>show-openteamsheets');
 }
 stop(){this.stopped=true;try{void this.streams?.omniscient.writeEnd();}catch{}}
}
function validRecord(r){return r&&r.v===1&&r.format===FORMAT&&Array.isArray(r.seed)&&r.seed.length===4&&r.seed.every(Number.isInteger)&&typeof r.p1==='string'&&typeof r.p2==='string'&&r.p1.length<6000&&r.p2.length<6000&&['bo1','bo3'].includes(r.informationMode)&&Array.isArray(r.choices)&&r.choices.length<=400&&r.choices.every(c=>Array.isArray(c)&&['p1','p2','end'].includes(c[0])&&typeof c[1]==='string'&&c[1].length<=250&&!/[\r\n|>]/.test(c[1]));}
let review=null;

// ---- Damage calc game ---------------------------------------------------------------
// Builds a real battle from two pool teams, leads one attacker into one defender (entry
// abilities such as Intimidate, weather and terrain apply as in a real game), then asks
// the simulator for all 16 damage rolls of one move. Answers come from Showdown itself.
const STATS=['hp','atk','def','spa','spd','spe'];
function calcRandom(seed){let s=seed>>>0||1;return ()=>{s=(s+0x6d2b79f5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
function monInfo(m){const set=m.set,boosts=Object.fromEntries(Object.entries(m.boosts).filter(([,v])=>v));
 return {species:m.species.name,sprite:m.species.spriteid,item:m.getItem().name||'',ability:m.getAbility().name,nature:set.nature||'',level:m.level,types:m.getTypes(),
  stats:{hp:m.maxhp,...Object.fromEntries(STATS.slice(1).map(k=>[k,m.storedStats[k]]))},points:set.evs,boosts,status:m.status||'',hp:m.hp,maxhp:m.maxhp,mega:!!m.species.isMega};}
function damageQuestion(seed,{allowCrit=true}={}){
 const random=calcRandom(seed),pick=xs=>xs[Math.floor(random()*xs.length)],n=aiTeams.entries.length;
 for(let attempt=0;attempt<40;attempt++){
  const a=aiTeams.entries[Math.floor(random()*n)],d=aiTeams.entries[Math.floor(random()*n)];
  const ai=1+Math.floor(random()*6),di=1+Math.floor(random()*6),order=x=>[x,...[1,2,3,4,5,6].filter(y=>y!==x)].slice(0,4).join('');
  let b;try{b=new sim.Battle({formatid:FORMAT,seed:[1+Math.floor(random()*60000),2,3,4]});b.setPlayer('p1',{name:'Attacker',team:a.packed});b.setPlayer('p2',{name:'Defender',team:d.packed});
   b.choose('p1','team '+order(ai));b.choose('p2','team '+order(di));}catch{continue;}
  const atk=b.p1.active[0],def=b.p2.active[0];if(!atk||!def||atk.fainted||def.fainted)continue;
  const moves=atk.moveSlots.map(x=>b.dex.moves.get(x.id)).filter(m=>m.category!=='Status'&&!m.damageCallback&&!m.ohko&&!m.damage&&m.basePower>0&&!m.multihit&&!m.selfdestruct&&!['allySide','ally','adjacentAlly','adjacentAllyOrSelf','self'].includes(m.target));
  if(!moves.length||atk.getAbility().id==='parentalbond')continue;
  const mega=atk.canMegaEvo&&random()<.5;
  if(mega){try{b.actions.runMegaEvo(atk);}catch{}}
  const move=pick(moves),crit=allowCrit&&random()<.12,spread=['allAdjacentFoes','allAdjacent'].includes(move.target)&&b.p2.active.filter(x=>x&&!x.fainted).length>1;
  // The same type/move-changing steps Showdown runs before damage (Weather Ball, -ate abilities, ...).
  const prepared=()=>{let am=b.dex.getActiveMove(move.id);b.setActiveMove(am,atk,def);b.singleEvent('ModifyType',am,null,atk,def,am,am);b.singleEvent('ModifyMove',am,null,atk,def,am,am);
   am=b.runEvent('ModifyType',atk,def,am,am);am=b.runEvent('ModifyMove',atk,def,am,am);am.willCrit=crit;if(spread)am.spreadHit=true;return am;};
  const real=b.random.bind(b);let roll=0;const rolls=[];
  try{
   b.random=(m,n)=>m===16&&n===undefined?roll:real(m,n);
   for(roll=0;roll<16;roll++){const am=prepared();const dmg=b.actions.getDamage(atk,def,am,true);if(typeof dmg!=='number'){rolls.length=0;break;}rolls.push(dmg);}
  }catch{rolls.length=0;}finally{b.random=real;}
  if(rolls.length!==16||rolls[15]<=0)continue;
  rolls.sort((x,y)=>x-y);let am;b.random=(m,n)=>m===16&&n===undefined?0:real(m,n);try{am=prepared();}finally{b.random=real;b.clearActiveMove?.(true);}const eff=def.runEffectiveness(am),immune=!def.runImmunity(am);
  const hp=def.hp,ko=rolls.filter(x=>x>=hp).length;
  return {id:seed,attacker:monInfo(atk),defender:monInfo(def),move:{name:move.name,type:am.type,category:am.category,basePower:am.basePower,spread},crit,
   field:{weather:b.field.weather?b.dex.conditions.get(b.field.weather).name:'',terrain:b.field.terrain?b.dex.conditions.get(b.field.terrain).name:'',
    attackerSide:Object.keys(b.p1.sideConditions).map(k=>b.dex.conditions.get(k).name),defenderSide:Object.keys(b.p2.sideConditions).map(k=>b.dex.conditions.get(k).name),
    partner:{attacker:b.p1.active[1]?.species.name||'',defender:b.p2.active[1]?.species.name||''}},
   effectiveness:immune?0:2**eff,rolls,hp,maxhp:def.maxhp,koRolls:ko,
   min:Math.round(rolls[0]/def.maxhp*1000)/10,max:Math.round(rolls[15]/def.maxhp*1000)/10};
 }
 throw Error('Could not build a damage question');
}
let session=null;
self.onmessage=async({data})=>{
 try{
  if(data.type==='validate')return postMessage({type:'validation',validation:validateChampionsTeam(data.paste)});
  if(data.type==='start'){await session?.close();const o=data.options||{};if(o.format!==FORMAT)throw Error("Unsupported Champions format");session=new Session({teamPaste:o.teamPaste,seed:Array.isArray(o.seed)&&o.seed.length===4?o.seed:null,difficulty:o.difficulty,informationMode:o.informationMode||'bo3',rotation:o.rotation&&typeof o.rotation==='object'?{seed:o.rotation.seed|0,game:o.rotation.game|0}:null});await session.start();return;}
  if(data.type==='calc')return postMessage({type:'calc',question:damageQuestion((data.seed>>>0)||1,{allowCrit:data.crit!==false}),token:data.token});
  if(data.type==='review'){review?.stop();if(!validRecord(data.record))throw Error('This saved game cannot be reviewed.');review=new Review(data.record);await review.run();return;}
  if(data.type==='review-stop'){review?.stop();review=null;return;}
  if(data.type==='choose')return void await session?.choose(data);
  if(data.type==='forfeit')return void await session?.forfeit();
  if(data.type==='close'){await session?.close();session=null;}
 }catch(e){postMessage({type:'error',message:e.message});}
};
postMessage({type:'ready'});
