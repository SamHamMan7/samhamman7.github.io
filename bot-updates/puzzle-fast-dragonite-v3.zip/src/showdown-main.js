﻿import {createBattleAssets} from './transport/battle-assets.js';
// Offline transport and entry points for the pinned official Showdown client.
import {parseLocalCommand} from './transport/commands.js';
const {App, MainMenuRoom, TeambuilderRoom, Storage, Dex, BattleLog, Popup} = window;
const state = {ready:false, busy:false, error:'', turn:0, ended:false, request:null};
let engine, policies={}, roomid, packedTeam='', generation=0, mode='play', difficulty='Rated'; // every game is rated (user decision 2026-11-21)
let tokens={}, timers={}, battleCount=0;
// Champions VGC runs entirely in its own browser worker (simulator + Discharge search).
const CHAMPIONS_FORMAT='gen9championsvgc2026regmc', GAMES_KEY='offline-showdown-games';
let championsValidator=null;
// Rated play: your rating on this device moves with each result, and the AI level follows it.
// The numbers are this site's own scale (not a Showdown ladder rating).
const RATING_KEY='offline-showdown-rating', TIERS=[['Medium',1000],['Strong',1250],['Very Strong',1500]];
let rated=null, playLevel='Very Strong';
// Counts Champions games on this device so the bot can go through its whole team pool,
// in a shuffled order, before bringing any team back.
function nextRotation(){
  try{let r=JSON.parse(localStorage.getItem('offline-showdown-rotation')||'null');if(!r||!Number.isInteger(r.seed)||!Number.isInteger(r.game))r={seed:crypto.getRandomValues(new Uint32Array(1))[0]|0,game:-1};
    r.game++;localStorage.setItem('offline-showdown-rotation',JSON.stringify(r));return r;}catch{return null;}
}
const levelLabel=v=>v==='Rated'?'Rated':'Unrated: '+v;
function ratingStore(){try{const v=JSON.parse(localStorage.getItem(RATING_KEY)||'{}');return v&&typeof v==='object'?v:{};}catch{return {};}}
function ratingFor(format){const r=ratingStore()[format];return r&&Number.isFinite(r.rating)?r:{rating:1000,wins:0,losses:0,ties:0,peak:1000};}
function tierFor(rating){return rating<1125?TIERS[0]:rating<1375?TIERS[1]:TIERS[2];}
function ratedResult(score){
  if(!rated)return null; const {format,tier}=rated; rated=null;
  const store=ratingStore(), mine=ratingFor(format), games=mine.wins+mine.losses+mine.ties, k=games<10?40:24;
  const expected=1/(1+10**((tier[1]-mine.rating)/400)), next=Math.max(100,Math.round(mine.rating+k*(score-expected)));
  const updated={rating:next,wins:mine.wins+(score===1),losses:mine.losses+(score===0),ties:mine.ties+(score===.5),peak:Math.max(mine.peak||0,next),last:{from:mine.rating,to:next,level:tier[0],at:Date.now()}};
  store[format]=updated; try{localStorage.setItem(RATING_KEY,JSON.stringify(store));}catch{}
  return {from:mine.rating,to:next,level:tier[0],nextLevel:tierFor(next)[0]};
}
function ratingLine(format){const r=ratingFor(format);return `Your rating: <strong>${r.rating}</strong> <small>(${r.wins}W ${r.losses}L, next opponent: ${tierFor(r.rating)[0]})</small>`;}

const battleAssets=createBattleAssets({Dex,Storage});

function receive(data) { window.app.receive(data); }
function roomReceive(data) { if(roomid) receive(`>${roomid}\n${data}`); }
function fail(message) { state.error=message; state.busy=false; window.app.addPopupMessage(message); }
function fatal(message) {
  engine?.terminate(); for(const policy of Object.values(policies)) policy.terminate();
  for(const timer of Object.values(timers)) clearTimeout(timer);
  tokens={}; state.aborted=true; state.ready=false; state.busy=false;
  roomReceive('|request|null'); roomReceive('|allowleave|');
  if(roomid) receive(`>${roomid}\n|expire|Local battle stopped`);
  fail(message+' Return Home to start a new battle. Your saved teams are intact.');
}
function workers(format='') {
  generation++; engine?.terminate(); for(const policy of Object.values(policies)) policy.terminate();
  for(const timer of Object.values(timers)) clearTimeout(timer);
  timers={}; tokens={};
  const champions=format===CHAMPIONS_FORMAT;
  engine=new Worker(new URL(champions?'./champions.worker.js':'./engine.worker.js',location.href),{type:'module'});
  policies={};
  engine.onerror=e=>fatal(`Battle engine error: ${e.message}`);
  // Each watch-mode player has an isolated policy worker. No policy process
  // receives both private player views, including when history models are added.
  if(!champions) for(const side of mode==='watch'?['p1','p2']:['p2']) {
    const policy=policies[side]=new Worker(new URL('./ai.worker.js',location.href),{type:'module'});
    policy.onerror=e=>fatal(`AI error: ${e.message}`);
    policy.onmessage=({data})=>{
      clearTimeout(timers[data.side]);
      if(data.type==='decision') {
        engine.postMessage({type:'choose',side:data.side,token:data.token,choice:data.choice});
        state.lastDecisionMs=data.elapsedMs;
        state.neural=data.diagnostics?{backend:!!data.diagnostics.neuralBackend,fallback:data.diagnostics.neuralFallback||null,observationVersion:data.diagnostics.observationVersion||null}:null;
      } else fatal('AI evaluation failed: '+data.message);
    };
  }
  const workerGeneration=generation;
  let incoming=Promise.resolve();
  engine.onmessage=({data})=>{ incoming=incoming.then(async()=>{
    if(workerGeneration!==generation||state.aborted)return;
    if(data.type==='ready') state.ready=true;
    if(data.type==='validation') receive('|popup|'+(data.validation.errors.length ? data.validation.errors.join('\n') : 'Your team is valid for this format.'));
    if(data.type==='error') {
      if(!state.request&&!state.turn) state.ended=true;
      if(data.message.startsWith('[Invalid choice]')) roomReceive('|error|'+data.message);
      else fail(data.message);
    }
    if(data.type==='record'&&mode==='play') {
      // A finished Champions game: keep it (last 8) so the review page can replay it.
      const id=Date.now().toString(36)+Math.random().toString(36).slice(2,6), game={id,at:Date.now(),result:state.lastResult||'',record:data.record};
      try{const games=JSON.parse(localStorage.getItem(GAMES_KEY)||'[]');games.unshift(game);localStorage.setItem(GAMES_KEY,JSON.stringify(games.slice(0,8)));
        roomReceive(`|raw|<div class="broadcast-blue"><a href="./review.html?game=${encodeURIComponent(id)}" target="_blank" rel="noopener"><strong>Review this game</strong></a>: see what Discharge would have played in your seat, turn by turn.</div>`);}catch{}
    }
    if(data.type==='update') {
      // Team preview/reveal lines give us a head start on image decode without
      // exposing any hidden information to the AI or renderer.
      await battleAssets.prepare({lines:data.lines});
      if(workerGeneration!==generation||state.aborted)return;
      Object.assign(state,{turn:data.view.turn,ended:!!data.view.ended,request:data.view.request});
      if(data.lines.length) roomReceive(data.lines.join('\n'));
      if(data.view.ended) {
        if(rated&&mode==='play') {
          const win=data.lines.map(l=>/^\|win\|(.*)$/.exec(l)).find(Boolean), tie=data.lines.some(l=>/^\|tie(\||$)/.test(l));
          const change=win||tie?ratedResult(tie?.5:win[1].trim()==='You'?1:0):null;
          if(change) roomReceive(`|raw|<div class="broadcast-blue"><strong>Rated game:</strong> ${change.from} &rarr; <strong>${change.to}</strong> (${change.to>=change.from?'+':''}${change.to-change.from}) against ${BattleLog.escapeHTML(change.level)}. Next opponent: ${BattleLog.escapeHTML(change.nextLevel)}.</div>`);
          const menu=window.app.rooms['']; if(menu) offlineMenu(menu);
        }
        {const win=data.lines.map(l=>/^\|win\|(.*)$/.exec(l)).find(Boolean);state.lastResult=win?(win[1].trim()==='You'?'win':'loss'):data.lines.some(l=>/^\|tie(\||$)/.test(l))?'tie':'';}
        state.busy=false; roomReceive('|allowleave|'); for(const timer of Object.values(timers)) clearTimeout(timer); }
    }
    if(data.type==='request') {
      tokens[data.side]=data.token;
      if(data.side==='p1') {
        state.request=data.view.request; state.busy=false;
        // Only the human player's private request is used for private prewarming.
        // Never inspect p2's private request here.
        await battleAssets.prepare({request:data.view.request});
        if(workerGeneration!==generation||state.aborted)return;
        // BattleStream has no server rqid: our one-use token supplies that boundary.
        // BattleRoom.add requires each request in a separate protocol message.
        if(mode==='play') roomReceive('|request|'+JSON.stringify({...data.view.request,rqid:data.token,noCancel:true}));
      }
      if(data.side==='p2'||mode==='watch') {
        if(data.view.request?.wait) return;
        policies[data.side].postMessage({...data,difficulty:playLevel,seed:data.token*7919+generation+(data.side==='p1'?104729:0)});
        clearTimeout(timers[data.side]);
        timers[data.side]=setTimeout(()=>fatal('The local AI took more than 30 seconds.'),30000);
      }
    }
  }).catch(e=>fatal('Battle resource error: '+e.message)); };
}
function start(format, options={}) {
  if(!state.ready&&!state.aborted) return fail('The local battle engine is still loading.');
  if(roomid&&!state.ended&&!state.aborted) return fail('Finish or forfeit the current local battle first.');
  const menu=window.app.rooms[''];
  difficulty='Rated'; mode=options.mode||'play';
  playLevel=difficulty; rated=null;
  if(difficulty==='Rated') { const tier=tierFor(ratingFor(format).rating); playLevel=tier[0]; if(mode==='play') rated={format,tier}; }
  battleAssets.reset();
  Object.assign(state,{ready:false,busy:true,error:'',turn:0,ended:false,aborted:false,request:null});
  if(format===CHAMPIONS_FORMAT&&mode==='watch') { state.busy=false; return fail('Champions VGC supports playing against the AI, not watch mode.'); }
  workers(format);
  roomid=`battle-${format}-${Date.now()}${++battleCount}`;
  const title=mode==='watch'?'AI 1 vs. AI 2':format===CHAMPIONS_FORMAT?'You vs. Discharge':'You vs. Offline AI';
  receive(`>${roomid}\n|init|battle\n|title|${title}`);
  roomReceive('|cantleave|');
  window.app.focusRoom(roomid);
  const teamPaste=mode==='watch'?'':Storage.exportTeam(Storage.unpackTeam(packedTeam));
  engine.postMessage({type:'start',options:{
    format,teamPaste,autoTeamP1:mode==='watch',playerNames:mode==='watch'?{p1:'AI 1',p2:'AI 2'}:{p1:'You',p2:'Offline AI'},
    ...(format===CHAMPIONS_FORMAT?{difficulty:playLevel,informationMode:'bo3',rotation:nextRotation()}:{}),
    seed:Array.from(crypto.getRandomValues(new Uint16Array(4))),
  }});
  if(rated) roomReceive(`|raw|<div class="broadcast-blue"><strong>Rated game.</strong> Your rating is ${ratingFor(format).rating}; this opponent plays at ${BattleLog.escapeHTML(rated.tier[0])} (${rated.tier[1]}).</div>`);
}
function localSend(message) {
  for(const part of message.split('\n')) {
    const cmd=parseLocalCommand(part);
    if(cmd.type==='team') packedTeam=cmd.team;
    else if(cmd.type==='start') start(cmd.format);
    else if(cmd.type==='validate'&&cmd.format===CHAMPIONS_FORMAT) {
      if(!championsValidator){championsValidator=new Worker(new URL('./champions.worker.js',location.href),{type:'module'});championsValidator.onmessage=({data})=>{if(data.type==='validation')receive('|popup|'+(data.validation.errors.length?data.validation.errors.join('\n'):'Your team is valid for this format.'));};}
      championsValidator.postMessage({type:'validate',paste:Storage.exportTeam(Storage.unpackTeam(packedTeam)),format:cmd.format});
    }
    else if(cmd.type==='validate') engine.postMessage({type:'validate',paste:Storage.exportTeam(Storage.unpackTeam(packedTeam)),format:cmd.format});
    else if(cmd.type==='choice'&&cmd.room===roomid&&mode==='play') {
      if(cmd.rqid!==null&&cmd.rqid!==tokens.p1) continue;
      if(tokens.p1===undefined) continue;
      const token=tokens.p1; delete tokens.p1; state.busy=true;
      engine.postMessage({type:'choose',side:'p1',token,choice:cmd.choice});
    } else if(cmd.type==='forfeit'&&cmd.room===roomid) engine.postMessage({type:'forfeit'});
    else if(cmd.type==='rooms') receive('|queryresponse|rooms|'+JSON.stringify({official:[],chat:[],userCount:1,battleCount:state.ended?0:1}));
    else if(cmd.type==='unsupported') fail('This command needs the online Showdown service. Local battles and the teambuilder work offline.');
  }
}
Dex.resourcePrefix='/'; Dex.fxPrefix='/fx/';
// The pinned client builds move buttons from a stale request after its active
// Pokemon faints (double KOs, instant playback). Render those buttons without
// effectiveness tags instead of throwing and stopping the local battle.
if(window.BattleTooltips){const moveTypeText=window.BattleTooltips.prototype.getMoveTypeText;
window.BattleTooltips.prototype.getMoveTypeText=function(move,value,forMaxMove){if(value&&!value.pokemon){let type=move.type;try{type=this.getMoveType(move,value,forMaxMove)[0];}catch{}return [type,''];}return moveTypeText.call(this,move,value,forMaxMove);};}
// Browser edition: bundled static sprites, move animations on, silent play.
const nativePrefs=Dex.prefs.bind(Dex);
Dex.prefs=(key)=>['bwgfx','nogif'].includes(key)?true:key==='noanim'?false:nativePrefs(key);
Storage.prefs('mute',true);
if(window.BattleSound){window.BattleSound.setMute(true);window.BattleSound.getSound=()=>undefined;}

const getSpriteData=Dex.getSpriteData.bind(Dex);
Dex.getSpriteData=function(...args) {
  const data=getSpriteData(...args), fallback=window.OfflineResourceFallbacks||{};
  if(Object.hasOwn(fallback,data.url)) Object.assign(data,{url:fallback[data.url],w:96,h:96,pixelated:true});
  const cry='/'+data.cryurl?.replace(/^\//,'');
  if(Object.hasOwn(fallback,cry)) data.cryurl=fallback[cry];
  data.cryurl='';
  return data;
};
const getTypeIcon=Dex.getTypeIcon.bind(Dex);
Dex.getTypeIcon=(...args)=>getTypeIcon(...args).replace(/%3f%3f%3f\.png/ig,'unknown.png');
Storage.loadRemoteTeams=after=>after?.();
TeambuilderRoom.prototype.tryLoadFormatResource=function() {};
App.prototype.initializeCCPAIntercept=function() {};
App.prototype.connect=function() {
  this.socket={readyState:1,send:localSend,close(){}}; this.isDisconnected=false;
  queueMicrotask(()=>{
    this.trigger('init:socketopened');
    this.user.loaded=true;
    this.user.set({name:'You',userid:'you',named:true,avatar:'1'});
    this.receive('|formats|,1|Offline Practice|[Gen 9 Champions] VGC 2026 Reg M-C,e|[Gen 9] OU,e|[Gen 9] Random Battle,f|[Gen 9] Random Doubles Battle,f');
    for(const message of this.sendQueue||[]) localSend(message);
    this.sendQueue=[]; this.resize();
  });
};
const OfflineDifficultyPopup=Popup.extend({
  type:'semimodal',
  events:{'click button[name=selectDifficulty]':'selectDifficulty'},
  initialize(data) {
    this.sourceEl=data.sourceEl;
    const current=data.current||'Rated';
    const options=['Rated','Medium','Strong','Very Strong'].map(value=>
      `<li><button name="selectDifficulty" value="${value}" class="option${value===current?' cur':''}">${value==='Rated'?'Rated (follows my rating)':'Unrated: '+value}</button></li>`
    ).join('');
    this.$el.html(`<ul class="popupmenu">${options}</ul>`);
  },
  selectDifficulty(event, target) {
    // Called once by the popup's own click event and once by the client's button dispatcher.
    const value=typeof event==='string'?event:event?.currentTarget?.value??target?.value; if(!value) return;
    difficulty=value; try{localStorage.setItem('offline-showdown-level',value);}catch{}
    this.sourceEl.val(value).html(BattleLog.escapeHTML(levelLabel(value)));
    this.close(); const menu=window.app.rooms['']; if(menu) offlineMenu(menu);
  },
});
MainMenuRoom.prototype.events={...MainMenuRoom.prototype.events,'click button.offline-difficulty':'selectOfflineDifficulty'};
MainMenuRoom.prototype.selectOfflineDifficulty=function(event) {
  event.preventDefault();
  const source=window.jQuery(event.currentTarget);
  window.app.addPopup(OfflineDifficultyPopup,{sourceEl:source,current:source.val()});
};
function offlineMenu(menu) {
  menu.$('button[name=search]').html('<strong>Offline Battle</strong><br /><small>Play against local AI</small>');
  menu.$('input[name=private]').closest('p').remove();
  menu.$('button[value=ladder],button[value="/smogtours"],button[value=battles],button[name=finduser],button[value="/friends"]').closest('p').remove();
  menu.$('.rightmenu,.activitymenu').empty();
  // The AI's competitive opponent pool is intentionally private to the engine.
  // Do not expose those teams in Storage, Teambuilder, or a main-menu selector.
  menu.$('select[name=offlineOpponent]').closest('p').remove();
  if(!menu.$('button[name=offlineWatch]').length) menu.$('button[name=search]').closest('p').after('<p><button class="button" name="offlineWatch">Watch AI Battle</button></p>');
  // Rating line under the level picker, only while Rated is selected.
  menu.$('p.offline-rating').remove();
  menu.$('button[name=search]').closest('p').before(`<p class="offline-rating">${ratingLine(menu.$('button[name=format]').val()||'')}</p>`);
}
const menuInitialize=MainMenuRoom.prototype.initialize;
MainMenuRoom.prototype.initialize=function() {
  menuInitialize.apply(this,arguments); offlineMenu(this);
  window.app.user.on('saveteams',()=>offlineMenu(this));
};
const updateSearch=MainMenuRoom.prototype.updateSearch;
MainMenuRoom.prototype.updateSearch=function() { updateSearch.apply(this,arguments); offlineMenu(this); };
const updateFormats=MainMenuRoom.prototype.updateFormats;
MainMenuRoom.prototype.updateFormats=function() { updateFormats.apply(this,arguments); offlineMenu(this); };
function selectedBattle(menu,watch=false) {
  const format=menu.$('button[name=format]').val(), index=menu.$('button[name=team]').val();
  if(!watch&&!window.BattleFormats[format]?.team&&(index===''||!Storage.teams[index])) return fail('Please select a team in the Showdown team selector.');
  packedTeam=watch?'':(Storage.teams[index]?.team||'');

  start(format,{mode:watch?'watch':'play'});
}
MainMenuRoom.prototype.search=function() { selectedBattle(this); };
MainMenuRoom.prototype.offlineWatch=function() { selectedBattle(this,true); };

// Keep user teams and AI opponent teams in separate stores. The AI pool now
// exists only inside the engine worker/session bundle, never the client/Storage.
Storage.whenTeamsLoaded(()=>{
  if(!localStorage.getItem('offline-showdown-native-migration')) {
    let previous=[];
    try { previous=JSON.parse(localStorage.getItem('offline-showdown-teams-v1')||'[]'); } catch {}
    for(const team of previous) {
      if(!team.paste) continue;
      const packed=Storage.packTeam(Storage.importTeam(team.paste));
      if(!Storage.teams.some(t=>t.team===packed)) Storage.teams.push({name:team.name||'Imported team',format:'gen9ou',folder:'',team:packed,capacity:6});
    }
    Storage.saveTeams(); localStorage.setItem('offline-showdown-native-migration','1');
  }
  if(!localStorage.getItem('offline-showdown-private-ai-pool-v2')) {
    // A saved team may have been edited without being renamed. Never delete it
    // by a bundled sample's name. New AI teams remain private to the engine;
    // existing user storage is preserved, including previously saved samples.
    localStorage.setItem('offline-showdown-private-ai-pool-v2','1');
  }
});
window.app=new App(); workers();

if('serviceWorker' in navigator&&!location.hostname.endsWith('androidplatform.net')) navigator.serviceWorker.register('/sw.js').catch(e=>{state.cacheError=e.message;});
Object.defineProperty(window,'offlinePractice',{value:{
  snapshot:()=>JSON.parse(JSON.stringify({...state,roomid,mode,client:'smogon/pokemon-showdown-client'})),
  warmAssets:()=>battleAssets.snapshot(),
}});

