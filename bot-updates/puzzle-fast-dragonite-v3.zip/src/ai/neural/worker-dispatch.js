import {chooseNeuralPreview} from './experimental.js';
import {chooseFoulPlayAction} from '../foulplay/randbats.mjs';

/** Keep the normal worker path synchronous except for the opt-in preview. */
export async function chooseWorkerAction(data, {chooseAction, legalActions}) {
  // Very Strong Random Battles: the Foul Play-style search, with the previous bot as a fallback.
  if (data?.difficulty === 'Very Strong' && data.view?.format === 'gen9randombattle' && data.view.request && !data.view.request.teamPreview) {
    try { return await chooseFoulPlayAction(data.view, {seed: data.seed}); }
    catch (error) { const result = chooseAction(data.view, {difficulty: data.difficulty, seed: data.seed}); return {...result, diagnostics: {...result.diagnostics, foulPlayFallback: error.message}}; }
  }
  if (data?.difficulty !== 'Neural Preview') {
    return chooseAction(data.view, {difficulty: data.difficulty, seed: data.seed});
  }
  return chooseNeuralPreview(data.view, {
    seed: data.seed,
    chooseAction,
    legalActions,
  });
}
