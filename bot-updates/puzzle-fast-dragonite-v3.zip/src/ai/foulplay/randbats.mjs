// Random Battle bot after Foul Play (pmariglia/foul-play, GPL-3.0; this file is a port and is
// GPL-3.0 too), searching with poke-engine (pmariglia/poke-engine, MIT) compiled to WebAssembly.
//
// Each decision: guess the opponent's hidden sets several times (weighted by how often the
// site's own Random Battle generator makes each set, and consistent with everything revealed),
// fill unrevealed opponents with plausible Pokemon, run the engine's MCTS on each guess, add up
// how often each of our options was visited, and pick among the options close to the best one.
// Only public information and our own request are used.
import {Dex} from '@pkmn/sim';
import initEngine, {search as engineSearch, canon as engineCanon} from './pkg/poke_engine_wasm.js';
import SETS from './randbats-sets.js';

const id = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
let loading = null;
/** Loads the engine once. In the site worker the .wasm sits next to the worker script. */
export function loadEngine(source) {
  loading ??= initEngine({module_or_path: source ?? new URL('./poke-engine.wasm', self.location.href)});
  return loading;
}

const names = new Map();
function canon(kind, name) {
  const key = kind + ':' + name;
  if (!names.has(key)) names.set(key, name ? engineCanon(kind, name) : '');
  return names.get(key);
}
// Engine spelling of a species, falling back to its base forme when the engine lacks the forme.
function speciesName(species) {
  const s = Dex.species.get(species);
  return canon('pokemon', id(s.name)) || canon('pokemon', id(s.baseSpecies)) || '';
}
const STATUS = {brn: 'BURN', par: 'PARALYZE', psn: 'POISON', tox: 'TOXIC', slp: 'SLEEP', frz: 'FREEZE'};
const WEATHER = {sunnyday: 'SUN', raindance: 'RAIN', sandstorm: 'SAND', snowscape: 'SNOW', snow: 'SNOW', hail: 'HAIL', desolateland: 'HARSHSUN', primordialsea: 'HEAVYRAIN'};
const typePair = types => [canon('type', id(types[0])) || 'TYPELESS', canon('type', id(types[1])) || 'TYPELESS'];
const maxPP = move => { const m = Dex.moves.get(move); return Math.min(127, m.noPPBoosts ? m.pp : Math.floor(m.pp * 8 / 5)); };
// Random Battle sets use 85 EVs and 31 IVs in every stat with a neutral nature.
function stats(species, level) {
  const b = Dex.species.get(species).baseStats, f = x => Math.floor((2 * x + 31 + 21) * level / 100);
  return {hp: species === 'shedinja' ? 1 : f(b.hp) + level + 10, atk: f(b.atk) + 5, def: f(b.def) + 5, spa: f(b.spa) + 5, spd: f(b.spd) + 5, spe: f(b.spe) + 5};
}
function moveField(move, {pp, disabled = false} = {}) {
  const name = canon('move', id(move));
  return name ? `${name};${disabled};${Math.max(0, Math.min(127, pp ?? maxPP(move)))}` : 'NONE;true;0';
}
function pokemonField(p) {
  const moves = p.moves.slice(0, 4).map(m => moveField(m.id, m)); while (moves.length < 4) moves.push('NONE;true;0');
  return [p.name, p.level, ...p.types, ...p.baseTypes, Math.max(0, Math.round(p.hp)), Math.max(1, p.maxhp), p.ability, p.ability, p.item, 'SERIOUS', '85;85;85;85;85;85',
    p.atk, p.def, p.spa, p.spd, p.spe, p.status || 'NONE', 0, p.sleepTurns || 0, p.weight, ...moves, false, !!p.terastallized, p.teraType || 'TYPELESS'].join(',');
}
const EMPTY = 'PIKACHU,1,ELECTRIC,TYPELESS,ELECTRIC,TYPELESS,0,1,NONE,NONE,NONE,SERIOUS,85;85;85;85;85;85,1,1,1,1,1,NONE,0,0,6,NONE;true;0,NONE;true;0,NONE;true;0,NONE;true;0,false,false,TYPELESS';
const CONDITIONS = ['auroraveil', 'craftyshield', 'healingwish', 'lightscreen', 'luckychant', 'lunardance', 'matblock', 'mist', 'protect', 'quickguard', 'reflect', 'safeguard', 'spikes', 'stealthrock', 'stickyweb', 'tailwind', 'toxiccount', 'toxicspikes', 'wideguard'];
const CONDITION_TURNS = {auroraveil: 4, lightscreen: 4, reflect: 4, safeguard: 4, mist: 4, tailwind: 3};
function sideConditions(list = []) {
  const count = {}; for (const c of list) { const k = id(c); count[k] = (count[k] || 0) + 1; }
  return CONDITIONS.map(k => !count[k] ? 0 : CONDITION_TURNS[k] ?? Math.min(count[k], k === 'spikes' ? 3 : k === 'toxicspikes' ? 2 : 1)).join(';');
}
function sideField(mons, active, {conditions, forceSwitch = false} = {}) {
  const fields = [...mons.map(pokemonField)]; while (fields.length < 6) fields.push(EMPTY);
  const volatiles = [...new Set((active?.volatiles || []).map(v => canon('volatile', id(String(v).replace(/^(move|ability|item): /i, ''))) ).filter(Boolean))];
  const sub = volatiles.includes('SUBSTITUTE') ? Math.floor((mons[0]?.maxhp || 4) / 4) : 0, b = active?.boosts || {};
  return [...fields.slice(0, 6), '0', sideConditions(conditions), volatiles.map(v => v + ':').join(''), '0;0;0;0;0;0', sub,
    b.atk || 0, b.def || 0, b.spa || 0, b.spd || 0, b.spe || 0, b.accuracy || 0, b.evasion || 0, 0, 0, 0, 0, forceSwitch, 'NONE', false, false, false, lastUsed(mons[0], active), false].join('=');
}
// Fake Out and First Impression only work the turn a Pokemon comes in; the engine reads that
// from "last used move".
function lastUsed(mon, active) {
  const memory = active?.publicMechanics;
  if (!mon || !memory) return 'move:none';
  if (memory.lastMoveTurn === null || memory.lastMoveTurn === undefined || memory.lastMoveTurn < (memory.enteredTurn ?? 0)) return 'switch:0';
  const i = mon.moves.findIndex(m => id(m.id) === id(active.lastMove));
  return i >= 0 ? `move:${i}` : 'move:none';
}

// ---------- our side, from the request ----------
function ownSide(view) {
  const req = view.request, order = req.side.pokemon.map((m, i) => ({m, i})), activeIdx = order.findIndex(x => x.m.active), lineup = [];
  if (activeIdx > 0) order.unshift(...order.splice(activeIdx, 1));
  const anyTera = req.side.pokemon.some(m => m.terastallized), canTera = !!req.active?.[0]?.canTerastallize;
  for (const {m, i} of order) {
    const sp = Dex.species.get(m.speciesForme || m.details.split(',')[0]), level = Number((m.details.match(/, L(\d+)/) || [])[1] || 100);
    const [hp, max] = String(m.condition).split(' ')[0].split('/').map(Number), status = (String(m.condition).split(' ')[1] || '').replace('fnt', '');
    const activeMoves = m.active ? req.active?.[0]?.moves || [] : [];
    const moves = m.moves.map(mv => { const a = activeMoves.find(x => id(x.id || x.move) === id(mv)); return {id: id(mv), pp: a ? a.pp : undefined, disabled: !!a?.disabled}; });
    const name = speciesName(sp.name); if (!name) throw new Error('engine does not know ' + sp.name);
    const tera = m.terastallized ? id(m.terastallized) : id(m.teraType);
    lineup.push({index: i, name, level, types: typePair(m.terastallized ? [m.terastallized] : sp.types), baseTypes: typePair(sp.types), hp: String(m.condition).includes('fnt') ? 0 : hp, maxhp: max || 1,
      ability: canon('ability', id(m.ability || m.baseAbility)) || 'NONE', item: canon('item', id(m.item)) || 'NONE', ...m.stats, status: STATUS[status] || 'NONE', weight: sp.weightkg,
      moves, terastallized: !!m.terastallized, teraType: canon('type', tera) || 'TYPELESS'});
  }
  // A Tera already spent elsewhere, or not offered by the game, is not available to the search.
  if (!canTera && !anyTera) for (const p of lineup) p.teraType = 'TYPELESS';
  return lineup;
}

// ---------- the opponent: revealed facts, then guesses ----------
function parseSet(key) { const [level, item, ability, m1, m2, m3, m4, tera] = key.split(','); return {level: +level, item, ability, moves: [m1, m2, m3, m4].filter(Boolean), tera}; }
const setCache = new Map();
function setsFor(species) {
  const sid = id(species);
  if (!setCache.has(sid)) {
    let table = SETS[sid];
    if (!table) { const base = id(Dex.species.get(species).baseSpecies); table = SETS[base]; }
    setCache.set(sid, table ? Object.entries(table).map(([k, n]) => ({...parseSet(k), weight: n})) : []);
  }
  return setCache.get(sid);
}
function revealed(mon) {
  return {moves: [...new Set((mon.movesSeen || []).map(id))].filter(m => !['struggle', 'recharge'].includes(m)), item: mon.item === undefined ? null : id(mon.item), ability: mon.ability ? id(mon.ability) : null, tera: mon.terastallized ? id(mon.teraType) : null, level: mon.level};
}
function candidates(mon) {
  const all = setsFor(mon.species), r = revealed(mon);
  const strict = all.filter(s => (!r.level || s.level === r.level) && r.moves.every(m => s.moves.includes(m)) && (!r.item || s.item === r.item) && (!r.ability || s.ability === r.ability) && (!r.tera || s.tera === r.tera));
  if (strict.length) return strict;
  const loose = all.filter(s => r.moves.every(m => s.moves.includes(m)));
  return loose.length ? loose : all;
}
const pick = (list, random) => { let total = 0; for (const x of list) total += x.weight; let r = random() * total; for (const x of list) { r -= x.weight; if (r <= 0) return x; } return list[list.length - 1]; };
function opponentMon(mon, set) {
  const sp = Dex.species.get(mon.species), level = mon.level || set?.level || 80, st = stats(sp.id, level), r = revealed(mon);
  const moves = [...r.moves]; for (const m of set?.moves || []) if (moves.length < 4 && !moves.includes(m)) moves.push(m);
  // An item that was used up or knocked off is gone: "" in the public view.
  const item = mon.item === '' ? 'NONE' : canon('item', r.item || set?.item || '') || 'UNKNOWNITEM';
  const name = speciesName(sp.name); if (!name) throw new Error('engine does not know ' + sp.name);
  const teraType = canon('type', r.tera || set?.tera || '') || 'TYPELESS';
  return {name, level, types: typePair(mon.terastallized ? [mon.teraType] : mon.types?.length ? mon.types : sp.types), baseTypes: typePair(sp.types), hp: mon.fainted ? 0 : Math.round((mon.hpFraction ?? 1) * st.hp), maxhp: st.hp,
    ability: canon('ability', r.ability || set?.ability || '') || 'NONE', item, ...st, status: STATUS[mon.status] || 'NONE', weight: sp.weightkg, moves: moves.map(m => ({id: m})), terastallized: !!mon.terastallized, teraType};
}
function unrevealed(count, taken, random) {
  const out = [], pool = Object.keys(SETS);
  for (let guard = 0; out.length < count && guard < 400; guard++) {
    const species = pool[Math.floor(random() * pool.length)], base = id(Dex.species.get(species).baseSpecies);
    if (taken.has(base)) continue; taken.add(base);
    const set = pick(setsFor(species), random); if (!set || !speciesName(species)) continue;
    out.push(opponentMon({species, level: set.level, hpFraction: 1, status: '', movesSeen: [], types: Dex.species.get(species).types}, set));
  }
  return out;
}
function opponentSides(view, worlds, random) {
  const opp = view.opponent, active = opp.active?.[0], seen = (opp.revealed || []).filter(m => m.species && !m.preview);
  const others = seen.filter(m => m !== active && !(active && m.ident && m.ident === active.ident));
  const anyTera = seen.some(m => m.terastallized);
  const sides = [];
  for (let w = 0; w < worlds; w++) {
    const lineup = [];
    for (const mon of [active, ...others].filter(Boolean)) { const c = candidates(mon); lineup.push(opponentMon(mon, c.length ? pick(c, random) : null)); }
    const taken = new Set(lineup.map(p => id(Dex.species.get(p.name).baseSpecies || p.name)));
    lineup.push(...unrevealed(Math.max(0, 6 - lineup.length), taken, random));
    if (anyTera) for (const p of lineup) if (!p.terastallized) p.teraType = 'TYPELESS';
    sides.push(sideField(lineup, active, {conditions: view.field?.opponentSideConditions}));
  }
  return sides;
}

function fieldParts(view) {
  const f = view.field || {}, weather = WEATHER[id(f.weather)], terrain = canon('terrain', id(f.terrain));
  return [weather ? `${weather};4` : 'NONE;-1', terrain ? `${terrain};4` : 'NONE;0', f.trickRoom ? 'true;3' : 'false;0', 'false'];
}

function rng(seed) { let s = (seed >>> 0) || 1; return () => { s = (s + 0x6d2b79f5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/** Builds the engine states for one decision (exported for tests). */
export function buildStates(view, {worlds = 4, seed = 1} = {}) {
  const random = rng(seed), own = ownSide(view), force = !!view.request.forceSwitch?.[0];
  const ownActive = view.own?.active?.[0];
  const mine = sideField(own, force ? null : ownActive, {conditions: view.field?.sideConditions, forceSwitch: force});
  return {own, states: opponentSides(view, worlds, random).map(theirs => [mine, theirs, ...fieldParts(view)].join('/'))};
}

/** Chooses a Showdown command for a singles Random Battle request. */
export async function chooseFoulPlayAction(view, {seed = 1, timeMs = 2400, worlds} = {}) {
  await loadEngine();
  const req = view.request; if (!req || req.wait || req.teamPreview) throw new Error('not an ordinary request');
  const opp = view.opponent?.active?.[0], early = opp && !(opp.movesSeen || []).length;
  const n = worlds ?? (early ? 6 : 4), per = Math.max(60, Math.floor(timeMs / n));
  const {own, states} = buildStates(view, {worlds: n, seed});
  // Foul Play's rule: each guess's visit shares, added up; then choose at random among the
  // options at least 75% as visited as the best, in proportion to their visits.
  const total = new Map(); let iterations = 0;
  for (const state of states) {
    const r = JSON.parse(engineSearch(state, per, 0)); iterations += r.iterations;
    const visits = r.s1.reduce((s, x) => s + x.visits, 0) || 1;
    for (const x of r.s1) total.set(x.choice, (total.get(x.choice) || 0) + x.visits / visits / states.length);
  }
  const ranked = [...total].sort((a, b) => b[1] - a[1]); if (!ranked.length) throw new Error('engine found no option');
  const close = ranked.filter(([, v]) => v >= ranked[0][1] * .75), random = rng(seed ^ 0x9e3779b9);
  let draw = random() * close.reduce((s, [, v]) => s + v, 0), pickChoice = close[0][0];
  for (const [c, v] of close) { draw -= v; if (draw <= 0) { pickChoice = c; break; } }
  // The game can offer fewer moves than the Pokemon knows (locked into Outrage, recharging,
  // Choice-locked): take the first option, in the engine's order of preference, the game allows.
  let choice = toCommand(pickChoice, req, own);
  for (const [c] of ranked) { if (choice) break; choice = toCommand(c, req, own); }
  if (!choice) { const only = (req.active?.[0]?.moves || []).findIndex(m => !m.disabled); if (only >= 0) choice = `move ${only + 1}`; }
  if (!choice) throw new Error('no legal option among ' + ranked.map(([c]) => c).join(', '));
  return {choice, diagnostics: {policy: 'foul-play-port-v1', worlds: states.length, msPerWorld: per, iterations, considered: close.map(([c, v]) => `${c} ${(v * 100).toFixed(1)}%`), engine: 'poke-engine 0.0.48'}};
}

// Engine output: "psyshock", "psyshock-tera" or a species ("zapdosgalar") for a switch.
// Returns null when the game does not currently offer that option.
function toCommand(choice, req, own) {
  const forced = !!req.forceSwitch?.[0], active = req.active?.[0];
  const switchTo = own.slice(1).find(p => p.name.toLowerCase() === choice && p.hp > 0);
  if (switchTo) return active?.trapped && !forced ? null : `switch ${switchTo.index + 1}`;
  if (forced) { const p = own.slice(1).find(x => x.hp > 0); return p ? `switch ${p.index + 1}` : null; }
  const tera = choice.endsWith('-tera'), move = choice.replace(/-tera$/, ''), moves = active?.moves || [];
  const i = moves.findIndex(m => !m.disabled && (canon('move', id(m.id || m.move)) || '').toLowerCase() === move);
  if (i < 0) return null;
  return `move ${i + 1}${tera && active.canTerastallize ? ' terastallize' : ''}`;
}
