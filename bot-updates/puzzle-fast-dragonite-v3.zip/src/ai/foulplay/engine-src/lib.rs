// Thin browser wrapper around poke-engine (MIT, pmariglia). Takes a serialized engine State and a
// time budget, runs the engine's own MCTS for side one, and returns each option with its visits
// and average score as JSON: {"iterations":N,"s1":[{"choice":..,"visits":..,"score":..}],"s2":[...]}
use poke_engine::mcts::perform_mcts;
use poke_engine::state::State;
use std::time::Duration;
use wasm_bindgen::prelude::*;

fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }

#[wasm_bindgen]
pub fn search(serialized_state: &str, max_ms: u32, max_iterations: u32) -> String {
    let mut state = State::deserialize(serialized_state);
    let (s1, s2) = state.root_get_all_options();
    let result = perform_mcts(&mut state, s1, s2, Duration::from_millis(max_ms as u64), max_iterations);
    let side = |rows: &Vec<poke_engine::mcts::MctsSideResult>, one: bool| rows.iter().map(|x| {
        let name = x.move_choice.to_string(if one { &state.side_one } else { &state.side_two });
        let avg = if x.visits > 0 { x.total_score / x.visits as f32 } else { 0.0 };
        format!("{{\"choice\":\"{}\",\"visits\":{},\"score\":{:.4}}}", esc(&name), x.visits, avg)
    }).collect::<Vec<_>>().join(",");
    format!("{{\"iterations\":{},\"s1\":[{}],\"s2\":[{}]}}", result.iteration_count, side(&result.s1, true), side(&result.s2, false))
}

#[wasm_bindgen]
pub fn version() -> String { "poke-engine 0.0.48 (gen9, terastallization)".into() }

// Name check before building a state: the engine stops outright on a name it does not know
// (a Rust panic is fatal in WebAssembly), so the JavaScript side asks first. Returns the
// engine's own spelling, or "" when the engine does not know the name.
#[wasm_bindgen]
pub fn canon(kind: &str, name: &str) -> String {
    use poke_engine::choices::Choices;
    use poke_engine::engine::abilities::Abilities;
    use poke_engine::engine::items::Items;
    use poke_engine::engine::state::{PokemonVolatileStatus, Terrain, Weather};
    use poke_engine::pokemon::PokemonName;
    use poke_engine::state::{PokemonStatus, PokemonType};
    use std::str::FromStr;
    let up = name.to_uppercase();
    let out = match kind {
        "pokemon" => PokemonName::from_str(&up).map(|x| x.to_string()).ok(),
        "move" => Choices::from_str(&up).map(|x| format!("{:?}", x)).ok(),
        "item" => Items::from_str(&up).map(|x| x.to_string()).ok(),
        "ability" => Abilities::from_str(&up).map(|x| x.to_string()).ok(),
        "type" => PokemonType::from_str(&up).map(|x| x.to_string()).ok(),
        "status" => PokemonStatus::from_str(&up).map(|x| x.to_string()).ok(),
        "volatile" => PokemonVolatileStatus::from_str(&up).map(|x| x.to_string()).ok(),
        "weather" => Weather::from_str(&up).map(|x| x.to_string()).ok(),
        "terrain" => Terrain::from_str(&up).map(|x| x.to_string()).ok(),
        _ => None,
    };
    match out { Some(s) if s.to_uppercase() == up => s, _ => String::new() }
}
