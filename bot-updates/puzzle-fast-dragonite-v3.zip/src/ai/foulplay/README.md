# Random Battle bot after Foul Play

`randbats.mjs` ports the Random Battle decision logic of Foul Play (https://github.com/pmariglia/foul-play,
GPL-3.0, tested at 8f541f8) to JavaScript; that file is GPL-3.0 (LICENSE-foul-play-GPL-3.0.txt).
The search runs in poke-engine (https://github.com/pmariglia/poke-engine, MIT, tested at f7b147f),
compiled to WebAssembly with the wrapper in `engine-src/` (pkg/LICENSE-poke-engine-MIT.txt).
`randbats-sets.js` counts sets from 100,000 teams of the site's bundled Random Battle generator.

Rebuild the engine: see engine-src/ and bot repo third_party/poke-engine-wasm/README.md.
The .wasm is served next to the worker as /poke-engine.wasm.
