# Jaxcalibur-inspired Stage 2 bootstrap

Current implementation and measured results are in [PROGRESS.md](PROGRESS.md).
The initial bootstrap description below is retained for provenance. Since its
installation, observation v2 public history, real Node/WASM ONNX inference,
trained checkpoint export, true schema-3 neural rollouts, and resumable PPO
with verified historical checkpoints have been implemented and exercised.
This does not establish playing strength; compare the measured benchmarks.

Stage 2 intentionally goes farther than a model skeleton so Ultra can start from
working training/search infrastructure rather than from notes.

## Added in Stage 2

- response-distribution risk aggregation
  - expected win probability
  - lower-tail/CVaR-like downside
  - state-dependent risk tolerance
  - near-best mixed strategy only
- optional response-conditioned inference hook
  - neural policy logits propose candidate actions
  - opponent-next-action logits define response probabilities
  - an optional backend response matrix supplies post-response win probabilities
  - robust scoring can override a flashy raw-policy argmax when ahead
- schema-2 sequential trajectory collection
  - observation/action/opponent-action
  - next observation
  - terminal reward/done
  - full-game return
- advantage-weighted BC bridge
- reusable GAE + clipped PPO math
- a working PPO trainer for schema-3 neural rollouts
- tiny historical checkpoint-league helper
- training-only privileged Random Battle collector for future hidden-set auxiliary
  labels; live actions still receive only sanitized PlayerView snapshots
- regression tests for ahead/even/behind risk behavior

## What is live today

`Neural Preview` remains a separate menu option. Without trained weights it
still falls back to current Very Strong. This is intentional; a randomly
initialized neural network should never replace a legal working bot.

If a future backend implements both:

```text
predict(observation)
evaluateResponseMatrix(...)
```

then the current `NeuralPolicy` already has a response-conditioned selection
path. If only `predict()` exists it uses the legal masked policy argmax.

## Why Stage 2 is still not Jaxcalibur

The important unfinished pieces are substantial:

1. no live ONNX/native runtime is connected yet;
2. no true neural self-play collector produces schema-3 policy log-prob/value
   rollouts yet;
3. no hidden-world sampler from Random Battle beliefs yet;
4. response-matrix evaluation is an interface, not yet backed by simulator
   rollouts/value evaluation;
5. current observation v1 lacks a real short event-history token sequence;
6. item/ability/move/Tera auxiliary prediction heads are not wired to the
   privileged labels yet;
7. no large learned-vs-baseline evaluation has been run.

Ultra should improve/replace these pieces, not discard the working contracts.

## Important risk rule

The Stage-2 risk code does not contain Pokemon-specific hard bans. It never says
"do not Tera early" or "do not double Protect." It expects each action/response
branch to eventually be evaluated in long-run win probability. Ahead states put
more weight on downside; behind states put less. A risky line is still allowed
when it truly has the best comeback chance.
