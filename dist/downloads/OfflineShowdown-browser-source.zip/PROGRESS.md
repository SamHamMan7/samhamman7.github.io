# Offline Showdown progress

## Current checkpoint — Android v1, 2026-09-14
Latest user priority: stable Android v1; Very Strong stays the default strongest AI, Neural Preview stays experimental. No redesign or automatic neural promotion. Broader goal remains active; physical Pixel 9a performance and genuinely strong learned AI are not yet verified.

- APK: artifacts/OfflineShowdown-v1.apk (identical to OfflineShowdown-debug.apk), versionName1.0.0/versionCode2, 537.27MiB.
- SHA256: 4d16fff6a2893ac707343ade102432f8a73394bb8a018a693f8bd6d763bb1bf6.
- Existing development signing key retained; install with adb install -r. Signature v2/v3, ZIP alignment, required assets and absence of INTERNET permission verified.
- Production remains src/showdown-main.js + pinned official smogon/pokemon-showdown-client 1e3b209011340e7c149a2e94769183eb4351b2e9, local BattleStream/@pkmn/sim and isolated public-view policy workers. Upstream battle UI, teambuilder and animation logic retained.
- Fixed startup deletion of saved teams based only on old sample names. Existing saved/edited teams are now preserved; new AI pools remain inside the engine.
- Exact build/install and acceptance commands: docs/android.md. Source ZIP: artifacts/OfflineShowdown-source.zip, generated with scripts/source-package.ps1 (includes pinned source, trained optional graphs/contracts, no privileged label datasets).
- No specific-opponent matchup selector in v1. Custom frontend remains recoverable from ee606ef.

## Verification
- npm.cmd test: 45/45 pass. Python PPO terminal win/loss gradient/KL tests pass; seven belief privacy/pairing tests pass.
- npm.cmd run build passes. Browser native identity, team import/save/reload, offline core reload + prepared OU18 turns; Random20 and Doubles6 on local server; Watch22; zero errors/external/missing/CSP. reports/showdown-browser-offline.json.
- Final APK Android15 emulator5554, airplane1/Wi-Fi0: OU19 turns, Random16, Doubles11, Watch21; team import/validation/persistence; zero errors/external/missing/CSP. reports/showdown-android-offline.json and android-environment.json bind evidence to APK hash.
- Upgrade regression: old service worker/cache retired; every saved team preserved, including an edited team named like an old bundled sample. reports/showdown-android-upgrade.json.
- Rotation412x843→867x388 and brief background/resume preserve document, active battle and saved teams. reports/showdown-android-lifecycle.json.
- Browser worker-error recovery passed for engine and AI workers. reports/showdown-recovery.json.
- First-use animation fixture: 14/14 images decoded before use, zero unready frames, 236 decoded assets on Android and browser. Browser artificial350ms image delay reproduces one unready baseline frame; decode gate removes it. Android max preparation1.40s. Fixture scope only, not every move or physical Pixel.
- Real installed neural + auxiliary ONNX/WASM worker inference passed in browser and Android without fallback. Emulator initial load3.21s, warm wall30.5–73.4ms; not Pixel measurements. reports/showdown-android-neural.json.
- Verification index: reports/android-v1.json. Old failure-named reports are historical failures superseded by the success reports above.

## Neural review — real results, no strength claim
- Stage2 bootstrap integrated; do NOT reapply over current changes. Observationv2:29x12 categorical/29x22 numeric, eight allowlisted public history events, own legal private request data, no hidden opponent inputs.
- Completed 2,000 Very Strong teacher games:127,430 rows/4,000 trajectories,87.4% opponent labels; zero invalid/illegal/hidden-stat rows. Existing user teacher500 and privileged500 files retained. No more teacher generation needed now.
- BC epochs1 and4 each7/100 vs Very Strong. Earlier two-iteration PPO2/100 was not deployed. User's latest conservative PPO11/100 confirmed from artifacts/neural/manual-ppo1/vs-very-strong.jsonl.report.json. Same paired seed918311: exploratory, not independent significance evidence.
- Neural Preview remains pinned to previously deployed BC epoch1 hash c7be6af0c7d8a575b7c3ac2ea36c25d6ccfdc9c7dded2bfb79fde5caf5ca5299. Very Strong fallback remains for unavailable/invalid models and unsupported formats. No checkpoint was promoted during v1 stabilization.
- True PPO self-play completed200 games/7,093 learner rows with historical checkpoints. Conservative later PPO used200 games/5,351 sampled learner rows against Very Strong. Actual ONNX old log-probabilities/values, GAE and PPO updates; no fabricated teacher ratios.
- Value head overfits: BC epoch4 train Brier0.0073 vs heldout0.3653 (constant50/50 gives0.25). Signed value/export units are correct. Added nonnegative KL estimator and --target-kl0.015 early-stop guard against excessive policy drift from shared value updates; real-rollout guard smoke passed. Existing weights are unchanged and not calibrated.
- Separate compact auxiliary model trained on privileged labels ONLY as targets: item/ability/move/Tera and semantic next-move heads execute on sanitized observations. Semantic next move46.55% vs species prior43.59%; hidden-set heads underperform species priors. Predictions remain separate from decisions/public facts.
- Still incomplete: live hidden-world sampler, actual simulator response-conditioned neural search, calibrated long-run values, all nine requested risk positions, strong learned policy. Response matrix/risk aggregation currently an optional interface, not a verified live search.
- Consider public-only damage/KO/speed/hazards/Tera features using existing @smogon/calc after v1; preserve uncertainty over hidden sets and version the encoder. No neural architecture change was made for v1.
- Exact training/export/benchmark commands and detailed limitations: docs/neural-training.md. Jaxcalibur/Metamon/VGC research queue retained; RandBats singles first.

## Continuation
- No training jobs are intentionally running. Prior sessions96859/8113 ended; BC4epoch/final and conservative PPO artifacts exist. Never restart a completed data run from old notes.
- Current local preview server exec26837 at127.0.0.1:4173; emulator5554 running, ADB/CDP9223 configured. Verify live state before restarting.
- Preserve .tools/offline-showdown-debug.keystore, prepared vendor assets/client, training artifacts and models. APK/source artifacts ignored by Git; source/model manifests and reports tracked.
- Next highest-value acceptance: physical Pixel9a install/update/airplane-mode test and latency. Then improve heldout neural policy/value generalization and compare against Very Strong under equal public-information/compute constraints.
