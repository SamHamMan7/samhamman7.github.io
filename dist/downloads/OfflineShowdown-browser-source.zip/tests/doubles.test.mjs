import test from 'node:test';
import assert from 'node:assert/strict';
import {BattleSession} from '../src/core/session.js';
import {chooseAction} from '../src/ai/index.js';

test('joint doubles policy completes eight seeded full battles without illegal commands', {timeout:60000}, async()=>{
  for(let seed=1;seed<=8;seed++) {
    let session,decisions=0,turn=0;
    try {
      await new Promise((resolve,reject)=>{
        session=new BattleSession({
          onUpdate:({view})=>{turn=view.turn;if(view.ended)resolve();},
          onRequest:({side,token,view})=>{
            try {
              const result=side==='p2'?chooseAction(view,{difficulty:'Strong'}):{choice:'default'};
              assert.ok(result.choice);assert.ok(++decisions<1800,'battle must terminate');
              queueMicrotask(()=>session.choose(side,token,result.choice).catch(reject));
            }catch(error){reject(error);}
          },onError:reject,
        });
        session.start({format:'gen9randomdoublesbattle',seed:[seed*997,17,23,101]}).catch(reject);
      });
      assert.ok(turn>1);
    } finally {await session?.close();}
  }
});
