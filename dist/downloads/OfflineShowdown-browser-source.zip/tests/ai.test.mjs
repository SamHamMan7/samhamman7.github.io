import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseAction, legalActions, damageEstimate, possibleMoves} from '../src/ai/index.js';
import {Dex} from '@pkmn/sim';
import {calcPokemon,fromRequest} from '../src/ai/damage.js';
import {opponentHypotheses} from '../src/ai/priors.js';

function view(species, moves, opponent, options = {}) {
  const own = {ident: `p2: ${species}`, details: species, condition: '300/300', active: true, moves,
    ...options.own};
  return {format: 'gen9ou', turn: 1, request: {side: {id: 'p2', pokemon: [own, ...(options.bench || [])]},
    active: [{moves: moves.map(move => ({move, pp: 10})), ...(options.requestActive || {})}], ...options.request},
    own: {active: [{species, ident: `p2a: ${species}`, boosts: {}, ...options.publicOwn}]},
    opponent: {active: [{species: opponent, hpFraction: 1, boosts: {}, movesSeen: [], ...options.opponent}], revealed: []},
    field: options.field || {}};
}

test('real damage calculator respects immunity and four-times effectiveness', () => {
  assert.equal(damageEstimate({species:'Garchomp'}, {species:'Corviknight'}, 'Earthquake').mean, 0);
  assert.ok(damageEstimate({species:'Garchomp'}, {species:'Heatran'}, 'Earthquake').mean > 1);
});

test('finishes a vulnerable opponent rather than gratuitously boosting', () => {
  const v = view('Garchomp', ['Earthquake','Dragon Claw','Swords Dance','Fire Fang'], 'Heatran');
  assert.equal(chooseAction(v).choice, 'move 1');
});

test('avoids immune attacks and request-disabled moves', () => {
  const v = view('Garchomp', ['Earthquake','Fire Fang','Swords Dance'], 'Corviknight', {
    requestActive:{moves:[{move:'Earthquake',pp:10},{move:'Fire Fang',pp:10},{move:'Swords Dance',pp:10,disabled:true}]},
    opponent:{movesSeen:['Brave Bird'],hpFraction:0.2},
  });
  assert.equal(chooseAction(v).choice, 'move 2');
});

test('priority secures a KO when an ordinary attack would move second', () => {
  const v = view('Dragonite', ['Extreme Speed','Dragon Claw','Dragon Dance'], 'Dragapult', {
    own:{condition:'45/300',item:'Choice Band'}, opponent:{hpFraction:0.1,movesSeen:['Draco Meteor']},
  });
  // Ghost immunity is also important: Extreme Speed cannot revenge Dragapult.
  assert.notEqual(chooseAction(v).choice, 'move 1');
  v.opponent.active[0].species = 'Iron Valiant';
  v.opponent.active[0].movesSeen = ['Moonblast'];
  assert.equal(chooseAction(v).choice, 'move 1');
});

test('forced replacement and trapped requests only return legal actions', () => {
  const bench = [{ident:'p2: Rotom',details:'Rotom-Wash',condition:'220/250',moves:['Hydro Pump','Volt Switch'],active:false}];
  const v = view('Garchomp', ['Earthquake'], 'Dondozo', {bench,requestActive:{trapped:true}});
  assert.ok(legalActions(v).every(a => a.kind === 'move'));
  v.request.forceSwitch = [true];
  assert.equal(chooseAction(v).choice, 'switch 2');
});

test('only serializable public player data is needed and the view is never mutated', () => {
  const v = view('Garchomp', ['Earthquake','Dragon Claw'], 'Heatran');
  const before = JSON.stringify(v);
  const a = chooseAction(JSON.parse(before));
  const b = chooseAction(JSON.parse(before));
  assert.equal(a.choice, b.choice);
  assert.equal(JSON.stringify(v), before);
  assert.equal(a.diagnostics.calcFailures, 0);
});

test('Random Battle beliefs use official public move families and revealed moves', () => {
  const moves = possibleMoves({species:'Garchomp',movesSeen:['Swords Dance']}, 10, 'gen9randombattle');
  assert.ok(moves.includes('Scale Shot'));
  assert.ok(!moves.includes('Spikes'));
  assert.ok(!moves.includes('Surf'));
});

test('all currently legal species and cosmetic forms can enter the damage calculator',()=>{
  for(const species of Dex.species.all().filter(s=>s.gen<=9&&!s.isNonstandard)) {
    const pokemon=calcPokemon({species:species.name});
    assert.ok(Number.isFinite(pokemon.rawStats.hp)&&pokemon.rawStats.hp>0,species.name);
  }
});

test('OU public priors respect revealed empty items and preserve uncertainty',()=>{
  const unseen=opponentHypotheses({species:'Great Tusk'},'gen9ou',3);
  assert.equal(unseen.length,3);
  assert.ok(unseen.every(h=>h.inferred&&h.priorSource));
  const revealed=opponentHypotheses({species:'Great Tusk',item:'',ability:'Protosynthesis'},'gen9ou',3);
  assert.ok(revealed.every(h=>h.item===''));
});

test('Supreme Overlord uses only known fainted teammate count',()=>{
  const a={species:'Kingambit',ability:'Supreme Overlord'};
  assert.ok(damageEstimate({...a,alliesFainted:5},{species:'Mew'},'Kowtow Cleave').mean>damageEstimate(a,{species:'Mew'},'Kowtow Cleave').mean);
});

test('Revival Blessing selects a fainted teammate instead of a living switch',()=>{
  const v=view('Rabsca',['Revival Blessing'],'Mew',{own:{reviving:true},request:{forceSwitch:[true]},bench:[
    {species:'Dragonite',details:'Dragonite',condition:'0 fnt',active:false,moves:['Dragon Claw']},
    {species:'Blissey',details:'Blissey',condition:'200/700',active:false,moves:['Seismic Toss']},
  ]});
  assert.deepEqual(legalActions(v).map(a=>a.choice),['switch 2']);
  assert.equal(chooseAction(v).choice,'switch 2');
});

test('own private request identity takes precedence over an Illusion display',()=>{
  assert.equal(fromRequest({details:'Zoroark',condition:'250/250',moves:['Dark Pulse']},{species:'Garchomp'}).species,'Zoroark');
});
