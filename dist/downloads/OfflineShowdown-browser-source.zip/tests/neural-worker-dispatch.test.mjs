import test from 'node:test';
import assert from 'node:assert/strict';

import {chooseWorkerAction} from '../src/ai/neural/worker-dispatch.js';
import {OBSERVATION_VERSION} from '../src/ai/neural/contract.js';

const baseView = {
  format: 'gen9randombattle',
  turn: 3,
  request: {
    side: {pokemon: [{ident:'p1: A', details:'Pikachu, L80', condition:'100/100', active:true}]},
    active: [{moves:[{move:'Thunderbolt', id:'thunderbolt', pp:10, maxpp:16}]}],
  },
  own: {active:[{ident:'p1: A', species:'Pikachu', condition:'100/100', active:true}]},
  opponent: {active:[{ident:'p2: B', species:'Gyarados', condition:'100/100', active:true}], revealed:[{ident:'p2: B', species:'Gyarados', condition:'100/100', active:true}]},
};
const actions = [{kind:'move', slot:1, move:'Thunderbolt', choice:'move 1'}];
const chooseAction = (_view, options) => ({choice:'move 1', diagnostics:{teacherDifficulty:options.difficulty}});
const legalActions = () => actions;

test('normal difficulties bypass Neural Preview dispatcher', async () => {
  const result = await chooseWorkerAction({view:baseView,difficulty:'Strong',seed:1},{chooseAction,legalActions});
  assert.equal(result.choice,'move 1');
  assert.equal(result.diagnostics.teacherDifficulty,'Strong');
});

test('Neural Preview is a separate live path with safe Very Strong bootstrap fallback', async () => {
  const result = await chooseWorkerAction({view:baseView,difficulty:'Neural Preview',seed:1},{chooseAction,legalActions});
  assert.equal(result.choice,'move 1');
  assert.equal(result.diagnostics.policy,'jaxlite-neural-preview-v1');
  assert.equal(result.diagnostics.teacherDifficulty,'Very Strong');
  assert.equal(result.diagnostics.neuralFallback,'no-trained-model-installed');
  assert.equal(result.diagnostics.observationVersion,OBSERVATION_VERSION);
});

test('Neural Preview declines unsupported formats without changing legality', async () => {
  const view = {...baseView,format:'gen9ou'};
  const result = await chooseWorkerAction({view,difficulty:'Neural Preview',seed:1},{chooseAction,legalActions});
  assert.equal(result.choice,'move 1');
  assert.equal(result.diagnostics.neuralFallback,'randbats-singles-only');
});
