import test from 'node:test';
import assert from 'node:assert/strict';

import {responseScore, scoreResponseMatrix, mixNearBest, softmax} from '../src/ai/neural/risk.js';
import {NeuralPolicy} from '../src/ai/neural/inference.js';

const probs = [0.7, 0.3];

test('ahead state prefers robust line over slightly higher-mean catastrophic read', () => {
  const safe = responseScore({outcomes:[0.72,0.72], probabilities:probs, currentWinProbability:0.82});
  const risky = responseScore({outcomes:[0.95,0.20], probabilities:probs, currentWinProbability:0.82});
  assert.ok(risky.expected > safe.expected, 'setup should give the flashy line slightly higher mean');
  assert.ok(safe.score > risky.score, 'ahead-state lower-tail protection should prefer robust line');
});

test('behind state can accept calculated variance with enough comeback value', () => {
  const safe = responseScore({outcomes:[0.26,0.26], probabilities:[0.5,0.5], currentWinProbability:0.20});
  const risky = responseScore({outcomes:[0.75,0.10], probabilities:[0.5,0.5], currentWinProbability:0.20});
  assert.ok(risky.score > safe.score);
});

test('mixed policy excludes materially inferior actions', () => {
  const mixed = mixNearBest([
    {actionIndex:0, score:0.70},
    {actionIndex:1, score:0.692},
    {actionIndex:2, score:0.51},
  ], {currentWinProbability:0.5});
  assert.deepEqual(mixed.map(x => x.actionIndex).sort(), [0,1]);
  assert.ok(Math.abs(mixed.reduce((a,b)=>a+b.probability,0)-1) < 1e-9);
});

test('optional neural response evaluator can override flashy policy argmax when ahead', async () => {
  const actions = [
    {kind:'move',slot:1,choice:'move 1'},
    {kind:'move',slot:2,choice:'move 2'},
  ];
  const view = {
    format:'gen9randombattle', turn:10,
    request:{side:{pokemon:[{ident:'p1: A',details:'Pikachu, L80',condition:'100/100',active:true}]},active:[{moves:[{move:'A',id:'a'},{move:'B',id:'b'}]}]},
    own:{active:[{ident:'p1: A',species:'Pikachu',condition:'100/100',active:true}]},
    opponent:{active:[{ident:'p2: B',species:'Garchomp',condition:'100/100',active:true}],revealed:[{ident:'p2: B',species:'Garchomp',condition:'100/100',active:true}]},
  };
  const policyLogits = Array(14).fill(-20); policyLogits[0]=5; policyLogits[1]=6; // raw policy wants risky move 2
  const opponentPolicyLogits = Array(14).fill(-20); opponentPolicyLogits[0]=5; opponentPolicyLogits[1]=4;
  const backend = {
    predict: async () => ({policyLogits, opponentPolicyLogits, value:0.82}),
    evaluateResponseMatrix: async ({ownActionIndices,opponentActionIndices}) => ownActionIndices.map(own =>
      opponentActionIndices.map(opp => own===0 ? 0.72 : (opp===0 ? 0.95 : 0.20))
    ),
  };
  const result = await new NeuralPolicy({backend}).choose(view, actions, {seed:1});
  assert.equal(result.choice, 'move 1');
  assert.ok(result.diagnostics.responseSearch);
});
