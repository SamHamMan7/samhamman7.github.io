import test from 'node:test';
import assert from 'node:assert/strict';
import {parseLocalCommand} from '../src/transport/commands.js';
import {BattleSession} from '../src/core/session.js';
test('native Showdown commands retain room, joint choices and request identity',()=>{
  assert.deepEqual(parseLocalCommand('battle-gen9ou-1|/team 321456|5'),{type:'choice',room:'battle-gen9ou-1',rqid:5,choice:'team 321456'});
  assert.deepEqual(parseLocalCommand('battle-gen9randomdoublesbattle-1|/choose move 1 2 terastallize, switch 3|29'),{type:'choice',room:'battle-gen9randomdoublesbattle-1',rqid:29,choice:'move 1 2 terastallize, switch 3'});
  assert.equal(parseLocalCommand('|/utm Name|Species|Item]Other|Pokemon').team,'Name|Species|Item]Other|Pokemon');
  assert.deepEqual(parseLocalCommand('|/vtm gen9ou'),{type:'validate',format:'gen9ou'});
});
test('an AI retry preserves Random Battle format and renews the request token',async()=>{
  let initialToken,resolveRetry;
  const retried=new Promise(resolve=>{resolveRetry=resolve;});
  const session=new BattleSession({onRequest:request=>{
    if(request.side!=='p2')return;
    if(initialToken===undefined){initialToken=request.token;session.retry('p2');}
    else resolveRetry(request);
  }});
  try {
    await session.start({format:'gen9randombattle',seed:[2,4,6,8]});
    const request=await retried;
    assert.equal(request.view.format,'gen9randombattle');
    assert.ok(request.token>initialToken);
    assert.equal(await session.choose('p2',initialToken,'default'),false);
  } finally {await session.close();}
});
