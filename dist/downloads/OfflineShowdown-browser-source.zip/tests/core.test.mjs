import test from 'node:test';
import assert from 'node:assert/strict';
import {BattleSession} from '../src/core/session.js';
import {PlayerView} from '../src/core/view.js';
import {validateTeam, assessTeam} from '../src/core/teams.js';
import {SAMPLE_TEAM} from '../src/data/teams.js';
import {extractChannelMessages} from '@pkmn/sim';

test('validator accepts starter and rejects illegal moves, duplicate species and junk', () => {
  assert.deepEqual(validateTeam(SAMPLE_TEAM).errors, []);
  assert.ok(validateTeam(SAMPLE_TEAM.replace('Rapid Spin','Spore')).errors.length);
  assert.ok(validateTeam(SAMPLE_TEAM + '\n' + SAMPLE_TEAM).errors.length);
  assert.ok(assessTeam([{species:'Pikachu', moves:['Splash'], item:'Assault Vest'}]).score < 50);
});

test('firewall preserves only selected player HP channel and own request', () => {
  const lines = '|split|p1\n|-damage|p1a: Secret|211/341\n|-damage|p1a: Secret|62/100\n|move|p1a: Secret|Earthquake|p2a: Rival';
  const channels = extractChannelMessages(lines, [1,2]);
  assert.ok(channels[1].join('\n').includes('211/341'));
  assert.ok(!channels[2].join('\n').includes('211/341'));
  const view = new PlayerView('p2');
  view.receive('|switch|p1a: Secret|Great Tusk, L100|100/100\n' + channels[2].join('\n'));
  assert.equal(view.snapshot().opponent.active[0].hpFraction, .62);
  assert.deepEqual(view.snapshot().opponent.active[0].movesSeen, ['Earthquake']);
  assert.throws(() => view.receive('|request|{"side":{"id":"p1","pokemon":[]}}'), /firewall/);
  assert.throws(() => view.receive(lines), /firewall/);
});

for (const format of ['gen9ou','gen9randombattle','gen9randomdoublesbattle']) {
  test(`official simulator completes ${format} with network APIs blocked`, {timeout: 60000}, async () => {
    const originalFetch = globalThis.fetch;
    globalThis.fetch = () => { throw new Error('Network disabled for complete battle test'); };
    let requests = 0, maxTurn = 0;
    let session;
    try {
      await new Promise((resolve, reject) => {
        session = new BattleSession({
          onUpdate: ({view}) => { maxTurn = Math.max(maxTurn, view.turn); if (view.ended) resolve(); },
          onRequest: ({side, token, view}) => {
            if (++requests > 3000) return reject(new Error('Battle stalled'));
            assert.equal(view.request.side.id, side);
            assert.ok(view.opponent.revealed.every(m => !m.ownSet && !m.stats && !m.evs));
            queueMicrotask(() => session.choose(side, token, 'default').catch(reject));
          },
          onError: reject,
        });
        session.start({format, teamPaste:SAMPLE_TEAM, seed:[11,22,33,44]}).catch(reject);
      });
      assert.ok(maxTurn > 1); assert.ok(requests > 10);
      console.log(`${format}: completed ${maxTurn} turns, ${requests} requests without network`);
    } finally { globalThis.fetch = originalFetch; await session?.close(); }
  });
}
