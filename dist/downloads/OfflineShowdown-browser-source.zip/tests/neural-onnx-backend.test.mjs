import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, writeFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHash, webcrypto} from 'node:crypto';
import schema from '../node_modules/onnxruntime-web/lib/onnxjs/ort-schema/protobuf/onnx.js';
import {createNodeOnnxBackend} from '../src/ai/neural/onnx-node.js';
import {createBrowserOnnxBackend, createLazyBrowserOnnxBackend, LOCAL_MANIFEST_URL} from '../src/ai/neural/onnx-browser.js';
import {validateOnnxManifest, decodeOnnxOutputs, observationFeeds} from '../src/ai/neural/onnx-common.js';
import {OBSERVATION_VERSION, ACTION_COUNT, TOKEN_COUNT, CAT_FEATURES, NUM_FEATURES, HASH_BUCKETS, TOKEN_KIND} from '../src/ai/neural/contract.js';

// A constant-output ONNX graph is a runtime transport fixture, never a shipped
// policy/checkpoint. Encode it with the ONNX schema included in pinned ORT.
function fixture() {
  const info = (name, elemType, shape) => ({name, type: {tensorType: {elemType, shape: {dim: shape.map(dimValue => ({dimValue}))}}}});
  const output = [info('policy_logits', 1, [1, ACTION_COUNT]), info('value_logit', 1, [1]), info('opponent_policy_logits', 1, [1, ACTION_COUNT])];
  const initializer = [
    {name: 'policy_logits', dataType: 1, dims: [1, ACTION_COUNT], floatData: Array.from({length: ACTION_COUNT}, (_, i) => i)},
    {name: 'value_logit', dataType: 1, dims: [1], floatData: [Math.log(3)]},
    {name: 'opponent_policy_logits', dataType: 1, dims: [1, ACTION_COUNT], floatData: Array.from({length: ACTION_COUNT}, (_, i) => -i)},
  ];
  const graph = {name: 'backend-contract-fixture', initializer, output, input: [
    info('token_kinds', 7, [1, TOKEN_COUNT]), info('categorical', 7, [1, TOKEN_COUNT, CAT_FEATURES]),
    info('numeric', 1, [1, TOKEN_COUNT, NUM_FEATURES]), info('token_mask', 9, [1, TOKEN_COUNT]), info('legal_mask', 9, [1, ACTION_COUNT]),
  ]};
  const model = {irVersion: 8, producerName: 'offline-showdown-runtime-test', opsetImport: [{version: 17}], graph};
  assert.equal(schema.onnx.ModelProto.verify(model), null);
  return schema.onnx.ModelProto.encode(schema.onnx.ModelProto.create(model)).finish();
}

function manifestFor(bytes) {
  return {schemaVersion: 1, trained: true, observationVersion: OBSERVATION_VERSION, format: 'gen9randombattle',
    actionCount: ACTION_COUNT, tokenCount: TOKEN_COUNT, catFeatures: CAT_FEATURES, numFeatures: NUM_FEATURES, hashBuckets: HASH_BUCKETS,
    model: 'runtime-fixture.onnx', bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'),
    outputs: {policy: 'policy_logits', value: 'value_logit', opponentPolicy: 'opponent_policy_logits'}};
}

function observation() {
  return {version: OBSERVATION_VERSION, meta: {format: 'gen9randombattle'},
    tokenKinds: [TOKEN_KIND.GLOBAL, ...Array(TOKEN_COUNT - 1).fill(TOKEN_KIND.PAD)],
    tokenMask: [1, ...Array(TOKEN_COUNT - 1).fill(0)], legalMask: [1, ...Array(ACTION_COUNT - 1).fill(0)],
    categorical: Array.from({length: TOKEN_COUNT}, () => Array(CAT_FEATURES).fill(0)),
    numeric: Array.from({length: TOKEN_COUNT}, () => Array(NUM_FEATURES).fill(0))};
}

function fakeFetch(bytes, manifest, requests = []) {
  return async (url, options) => {
    requests.push({url, options});
    if (url === LOCAL_MANIFEST_URL) return new Response(JSON.stringify(manifest));
    if (url === '/models/gen9randombattle/' + manifest.model) return new Response(bytes);
    throw new Error('Unexpected resource URL: ' + url);
  };
}

test('native ONNX Runtime loads local bytes and returns policy, sigmoid value and opponent heads', async () => {
  const directory = await mkdtemp(path.join(tmpdir(), 'showdown-ort-test-'));
  const bytes = fixture(), manifest = manifestFor(bytes);
  let backend;
  try {
    await writeFile(path.join(directory, manifest.model), bytes);
    await writeFile(path.join(directory, 'manifest.json'), JSON.stringify(manifest));
    backend = await createNodeOnnxBackend({manifestPath: path.join(directory, 'manifest.json')});
    const result = await backend.predict(observation());
    assert.deepEqual(result.policyLogits, Array.from({length: ACTION_COUNT}, (_, i) => i));
    assert.deepEqual(result.opponentPolicyLogits, Array.from({length: ACTION_COUNT}, (_, i) => -i));
    assert.ok(Math.abs(result.value - 0.75) < 1e-6);
    assert.equal(backend.metadata.runtime, 'onnxruntime-node-cpu');
    await backend.dispose();
    await assert.rejects(backend.predict(observation()), /disposed/);
  } finally {await backend?.dispose(); await rm(directory, {recursive: true, force: true});}
});

test('browser loader drives the real WASM runtime using only local model URLs', async () => {
  const wasm = await import('onnxruntime-web/wasm');
  const bytes = fixture(), manifest = manifestFor(bytes), requests = [];
  // In Node, Emscripten needs the package's filesystem directory; the browser
  // factory still configures and requests its origin-local /ort/ directory.
  const runtimeDirectory = new URL('../node_modules/onnxruntime-web/dist/', import.meta.url).href;
  const injected = {Tensor: wasm.Tensor, env: wasm.env, InferenceSession: {
    create: async (model, options) => {
      assert.equal(wasm.env.wasm.wasmPaths, '/ort/');
      assert.equal(wasm.env.wasm.numThreads, 1);
      assert.equal(wasm.env.wasm.proxy, false);
      wasm.env.wasm.wasmPaths = runtimeDirectory;
      return wasm.InferenceSession.create(model, options);
    },
  }};
  const backend = await createBrowserOnnxBackend({ort: injected, fetch: fakeFetch(bytes, manifest, requests), crypto: webcrypto});
  try {
    const result = await backend.predict(observation());
    assert.equal(result.policyLogits[13], 13);
    assert.ok(Math.abs(result.value - 0.75) < 1e-6);
    assert.equal(backend.metadata.runtime, 'onnxruntime-web-wasm');
    assert.deepEqual(requests.map(r => r.url), [LOCAL_MANIFEST_URL, '/models/gen9randombattle/runtime-fixture.onnx']);
    assert.ok(requests.every(r => r.options.redirect === 'error'));
  } finally {await backend.dispose();}
});

test('manifest rejects untrained, incompatible and remote models before session creation', async () => {
  const bytes = fixture(), manifest = manifestFor(bytes);
  for (const update of [{trained: false}, {observationVersion: -1}, {tokenCount: TOKEN_COUNT + 1}, {model: 'https://example.com/model.onnx'}, {model: '../model.onnx'}]) {
    assert.throws(() => validateOnnxManifest({...manifest, ...update}));
  }
  await assert.rejects(createBrowserOnnxBackend({manifestUrl: 'https://example.com/manifest.json'}), /bundled/);
  await assert.rejects(createBrowserOnnxBackend({wasmPath: '//example.com/ort/'}), /local/);
  await assert.rejects(createNodeOnnxBackend({manifestPath: 'https://example.com/manifest.json'}), /local/);
  let created = false;
  await assert.rejects(createBrowserOnnxBackend({
    ort: {InferenceSession: {create() {created = true;}}},
    fetch: fakeFetch(bytes, {...manifest, sha256: '0'.repeat(64)}), crypto: webcrypto,
  }), /SHA-256 mismatch/);
  assert.equal(created, false);
});

test('invalid observation dimensions, integer ranges and nonfinite outputs fail explicitly', async () => {
  const ort = await import('onnxruntime-node'), obs = observation();
  assert.throws(() => observationFeeds(ort, {...obs, numeric: []}), /numeric/);
  assert.throws(() => observationFeeds(ort, {...obs, legalMask: Array(ACTION_COUNT).fill(0)}), /no legal/);
  obs.categorical[0][0] = HASH_BUCKETS + 1;
  assert.throws(() => observationFeeds(ort, obs), /categorical/);
  const outputs = {
    policy_logits: new ort.Tensor('float32', Float32Array.from({length: ACTION_COUNT}, () => 0), [1, ACTION_COUNT]),
    value_logit: new ort.Tensor('float32', Float32Array.of(NaN), [1]),
    opponent_policy_logits: new ort.Tensor('float32', new Float32Array(ACTION_COUNT), [1, ACTION_COUNT]),
  };
  assert.throws(() => decodeOnnxOutputs(outputs, manifestFor(fixture())), /invalid values/);
  outputs.value_logit = new ort.Tensor('float32', Float32Array.of(0), [1, 1]);
  assert.throws(() => decodeOnnxOutputs(outputs, manifestFor(fixture())), /dimensions/);
});

test('lazy browser loader performs no request until first use and reuses its load failure', async () => {
  let attempts = 0;
  const lazy = createLazyBrowserOnnxBackend({fetch: async () => {attempts++; return new Response('', {status: 404});}, crypto: webcrypto});
  assert.equal(attempts, 0);
  await assert.rejects(lazy.load(), /404/);
  await assert.rejects(lazy.load(), /404/);
  assert.equal(attempts, 1);
});
