import test from 'node:test';
import assert from 'node:assert/strict';

import {actionIndexFromChoice, legalMask, legalActionForIndex} from '../src/ai/neural/action-space.js';
import {encodeObservation} from '../src/ai/neural/observation.js';
import {JsonlDatasetBuffer, trainingExample} from '../src/ai/neural/dataset.js';
import {NeuralPolicy} from '../src/ai/neural/inference.js';
import {TOKEN_COUNT, OBSERVATION_VERSION} from '../src/ai/neural/contract.js';

function sampleView(secret = 'hidden-a') {
  return {
    format: 'gen9randombattle',
    turn: 7,
    field: {weather: 'RainDance', terrain: ''},
    request: {
      rqid: 12,
      side: {pokemon: [
        {ident: 'p1: Pikachu', details: 'Pikachu, L80', condition: '80/100 par', active: true, item: 'Light Ball', ability: 'Static', teraType: 'Electric'},
        {ident: 'p1: Dragonite', details: 'Dragonite, L80', condition: '100/100', active: false, item: 'Heavy-Duty Boots', ability: 'Multiscale', teraType: 'Normal'},
      ]},
      active: [{canTerastallize: 'Electric', moves: [
        {move: 'Thunderbolt', id: 'thunderbolt', pp: 20, maxpp: 24},
        {move: 'Volt Switch', id: 'voltswitch', pp: 16, maxpp: 16},
      ]}],
    },
    own: {active: [{ident: 'p1: Pikachu', species: 'Pikachu', condition: '80/100 par', active: true}]},
    opponent: {
      active: [{ident: 'p2: Garchomp', species: 'Garchomp', details: 'Garchomp, L80', condition: '70/100', active: true, movesSeen: ['Earthquake']}],
      revealed: [{ident: 'p2: Garchomp', species: 'Garchomp', details: 'Garchomp, L80', condition: '70/100', active: true, movesSeen: ['Earthquake']}],
      privateTeam: secret,
      unrevealedMoves: secret,
      exactEVs: secret,
    },
    secretSimulatorState: secret,
  };
}

const actions = [
  {kind: 'move', slot: 1, move: 'Thunderbolt', choice: 'move 1'},
  {kind: 'move', slot: 1, move: 'Thunderbolt', choice: 'move 1 terastallize', tera: 'Electric'},
  {kind: 'switch', slot: 2, choice: 'switch 2'},
];

test('fixed RandBats action mapping is stable', () => {
  assert.equal(actionIndexFromChoice('move 1'), 0);
  assert.equal(actionIndexFromChoice('move 4 terastallize'), 7);
  assert.equal(actionIndexFromChoice('switch 1'), 8);
  assert.equal(actionIndexFromChoice('switch 6'), 13);
  assert.equal(actionIndexFromChoice('team 123456'), -1);
  const mask = legalMask(actions);
  assert.deepEqual(mask.map((v, i) => v ? i : null).filter(v => v !== null), [0, 4, 9]);
  assert.equal(legalActionForIndex(9, actions).choice, 'switch 2');
});

test('observation ignores private opponent fields and unknown simulator state', () => {
  const a = encodeObservation(sampleView('secret-a'), actions);
  const b = encodeObservation(sampleView('totally-different-secret-b'), actions);
  assert.deepEqual(a, b);
});

test('observation has fixed dimensions and padded unrevealed opponent slots', () => {
  const obs = encodeObservation(sampleView(), actions);
  assert.equal(obs.tokenKinds.length, TOKEN_COUNT);
  assert.equal(obs.categorical.length, TOKEN_COUNT);
  assert.equal(obs.numeric.length, TOKEN_COUNT);
  assert.equal(obs.legalMask.length, 14);
  assert.equal(obs.tokenMask[7], 1); // revealed Garchomp
  assert.equal(obs.tokenMask[8], 0); // unrevealed slot stays unknown/padded
});

test('training recorder emits one JSONL row with public observation', () => {
  const row = trainingExample({view: sampleView(), legalActions: actions, choice: 'move 1', opponentChoice: 'switch 2', outcome: 1, gameId: 'g1'});
  const buffer = new JsonlDatasetBuffer();
  buffer.append(row);
  const lines = buffer.toJSONL().trim().split('\n');
  assert.equal(lines.length, 1);
  const parsed = JSON.parse(lines[0]);
  assert.equal(parsed.action, 0);
  assert.equal(parsed.opponentAction, 9);
  assert.equal(parsed.outcome, 1);
  assert.equal(parsed.observation.version, OBSERVATION_VERSION);
});

test('neural inference always resolves through the authoritative legal action list', async () => {
  const logits = Array(14).fill(-10);
  logits[13] = 1000; // illegal in this request
  logits[9] = 20;    // legal switch 2
  const policy = new NeuralPolicy({backend: {predict: async () => ({policyLogits: logits, value: 0.6})}});
  const result = await policy.choose(sampleView(), actions);
  assert.equal(result.choice, 'switch 2');
  assert.equal(result.diagnostics.actionIndex, 9);
});
