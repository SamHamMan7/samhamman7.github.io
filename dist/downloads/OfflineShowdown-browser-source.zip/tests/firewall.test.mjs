import test from 'node:test';
import assert from 'node:assert/strict';
import {BattleSession} from '../src/core/session.js';
import {SAMPLE_TEAM} from '../src/data/teams.js';
import {chooseAction} from '../src/ai/index.js';

async function opponentView(teamPaste) {
  let session;
  try {
    return await new Promise((resolve,reject)=>{
      session=new BattleSession({onRequest:({side,token,view})=>{
        if(view.request.teamPreview)queueMicrotask(()=>session.choose(side,token,'default').catch(reject));
        else if(side==='p2')resolve(view);
      },onError:reject});
      session.start({teamPaste,opponentPaste:SAMPLE_TEAM,seed:[19,31,47,53]}).catch(reject);
    });
  } finally {await session?.close();}
}
test('changing opponent private moves, HP EVs and item cannot change initial AI view or choice',async()=>{
  const secretAlternative=SAMPLE_TEAM.replace('Great Tusk @ Heavy-Duty Boots','Great Tusk @ Leftovers').replace('252 Atk / 4 Def / 252 Spe','4 HP / 252 Atk / 252 Spe').replace('- Rapid Spin','- Ice Spinner');
  const before=await opponentView(SAMPLE_TEAM),after=await opponentView(secretAlternative);
  assert.deepEqual(before,after);
  assert.equal(chooseAction(before).choice,chooseAction(after).choice);
  assert.ok(before.opponent.revealed.every(mon=>!('ownSet' in mon)&&!('stats' in mon)&&!('evs' in mon)&&!('item' in mon)));
  assert.ok(!('seed' in before));
});
