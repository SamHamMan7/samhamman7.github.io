import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {hashFeature} from '../src/ai/neural/observation.js';
import {validateBeliefManifest, decodeBeliefOutputs, createBeliefBackend} from '../src/ai/neural/belief-model.js';

function observation() {
  const result = {version: 2, meta: {format: 'gen9randombattle'}, tokenKinds: Array(29).fill(0), tokenMask: Array(29).fill(0),
    categorical: Array.from({length: 29}, () => Array(12).fill(0)), numeric: Array.from({length: 29}, () => Array(22).fill(0)), legalMask: [1, ...Array(13).fill(0)]};
  result.tokenKinds[0] = 1; result.tokenMask[0] = 1;
  result.tokenKinds[7] = 3; result.tokenMask[7] = 1;
  result.categorical[7][0] = hashFeature('species', 'Pikachu'); result.numeric[7][2] = 1;
  return result;
}

function manifest() {
  return {schemaVersion: 1, kind: 'auxiliary-public-beliefs', trained: true, observationVersion: 2, format: 'gen9randombattle',
    tokenCount: 29, catFeatures: 12, numFeatures: 22, hashBuckets: 16384, actionCount: 14, opponentSlots: 6,
    model: 'beliefs.onnx', sha256: '0'.repeat(64), bytes: 1024, basePolicyModified: false,
    outputs: {item: 'item_logits', ability: 'ability_logits', tera: 'tera_logits', moves: 'move_logits', nextMove: 'next_move_logits'},
    vocabulary: {item: ['lightball', 'leftovers'], ability: ['static', 'lightningrod'], tera: ['electric', 'water'], moves: ['thunderbolt', 'surf', 'voltswitch', 'grassknot']},
    targetSemantics: 'initial-generated-set', nextMoveSemantics: 'ordinary-counterpart-move-identity'};
}

function outputs(m = manifest()) {
  return Object.fromEntries(Object.entries(m.outputs).map(([head, name]) => {
    const size = m.vocabulary[head === 'nextMove' ? 'moves' : head].length;
    return [name, {type: 'float32', dims: head === 'nextMove' ? [1, size] : [1, 6, size], data: new Float32Array((head === 'nextMove' ? 1 : 6) * size)}];
  }));
}

test('belief manifest is distinct, hash pinned and rejects policy or arbitrary-path contracts', () => {
  assert.equal(validateBeliefManifest(manifest()).kind, 'auxiliary-public-beliefs');
  for (const changes of [{kind: 'policy'}, {observationVersion: 1}, {basePolicyModified: true}, {model: '../other.onnx'}, {sha256: 'bad'}, {trained: false}]) {
    assert.throws(() => validateBeliefManifest({...manifest(), ...changes}));
  }
  const m = manifest(); m.vocabulary.moves.push('surf');
  assert.throws(() => validateBeliefManifest(m), /vocabulary/);
});

test('belief outputs contain only public revealed slots and preserve known current facts', () => {
  const obs = observation();
  obs.categorical[7][1] = hashFeature('item', 'Choice Scarf');
  const result = decodeBeliefOutputs(outputs(), manifest(), obs);
  assert.equal(result.opponents.length, 1);
  assert.deepEqual(result.opponents[0].item, {source: 'public', knownHash: hashFeature('item', 'Choice Scarf')});
  assert.equal(result.opponents[0].ability.candidates.reduce((sum, value) => sum + value.probability, 0), 1);
  assert.equal(result.opponents[0].moves.candidates.reduce((sum, value) => sum + value.probability, 0), 2); // independent marginals
  assert.equal(result.nextMove.conditionalOnOrdinaryMove, true);
  assert.equal(result.nextMove.includesSwitchProbability, false);
  assert.equal(result.calibrated, false);
});

test('belief decoder rejects hidden opponent stats, malformed outputs and nonfinite logits', () => {
  const obs = observation(); obs.numeric[7][17] = 0.5;
  assert.throws(() => decodeBeliefOutputs(outputs(), manifest(), obs), /exact/);
  const broken = outputs(); broken.move_logits.data[0] = NaN;
  assert.throws(() => decodeBeliefOutputs(broken, manifest(), observation()), /logits/);
  const shape = outputs(); shape.item_logits.dims = [1, 12];
  assert.throws(() => decodeBeliefOutputs(shape, manifest(), observation()), /shape/);
});

test('semantic move identity hashing agrees with the audited observation-v2 dataset', () => {
  assert.equal(hashFeature('species', 'Palossand'), 14971);
  assert.equal(hashFeature('species', 'Mesprit'), 180);
  assert.equal(hashFeature('item', 'Leftovers'), 5125);
});

const trainedPath = new URL('../models/gen9randombattle/beliefs-smoke.manifest.json', import.meta.url);
test('trained optional belief ONNX executes with exactly public feeds and deterministic hidden-label invariance', {skip: !fs.existsSync(trainedPath)}, async () => {
  const ort = await import('onnxruntime-node');
  const m = JSON.parse(fs.readFileSync(trainedPath, 'utf8'));
  const bytes = new Uint8Array(fs.readFileSync(new URL(m.model, trainedPath)));
  const digest = async data => createHash('sha256').update(data).digest('hex');
  await assert.rejects(createBeliefBackend({ort, manifest: {...m, sha256: '0'.repeat(64)}, bytes, digest}), /SHA-256 mismatch/);
  const backend = await createBeliefBackend({ort, manifest: m, bytes, digest, runtime: 'node-test',
    sessionOptions: {executionProviders: ['cpu'], intraOpNumThreads: 1, interOpNumThreads: 1}});
  try {
    const obs = observation();
    const first = await backend.predict(obs);
    const changed = {...obs, privilegedOpponentTeam: [{item: 'Unseen exact item', moves: ['secret']}], hiddenSeed: 999};
    const second = await backend.predict(changed);
    assert.deepEqual(first, second);
    assert.equal(first.opponents.length, 1);
    assert.ok(first.nextMove.candidates.every(candidate => Number.isFinite(candidate.probability)));
    await assert.rejects(backend.predict({observation: obs, privilegedOpponentTeam: []}), /public observation/);
  } finally { await backend.dispose(); }
  await assert.rejects(backend.predict(observation()), /disposed/);
});
