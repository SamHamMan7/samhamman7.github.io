import {Dex} from '@pkmn/sim';
import {calcPokemon} from '../../src/ai/damage.js';

/** Hand-authored legal singles requests; opponent fields are public revelations only. */
export function ownMon(species, moves, options = {}) {
  const set = {species, moves, level: 100, nature: 'Serious', ...options.set};
  const calculated = calcPokemon(set);
  const {hp, ...stats} = calculated.rawStats;
  const fraction = options.hp ?? 1;
  return {
    ident: `p1: ${species}`, species, details: `${species}, L100`,
    condition: fraction > 0 ? `${Math.max(1, Math.round(hp * fraction))}/${hp}${options.status ? ` ${options.status}` : ''}` : '0 fnt',
    active: false, moves, stats, item: set.item || '', ability: set.ability || '',
    teraType: set.teraType || Dex.species.get(species).types[0], ownSet: set,
    ...options.request,
  };
}

export function publicMon(species, movesSeen, options = {}) {
  return {ident: `p2a: ${species}`, species, details: `${species}, L100`, level: 100,
    hpFraction: 1, boosts: {}, movesSeen, ...options};
}

export function position(active, opponent, {bench = [], opponentBench = [], ownPublic = {}, tera = '', field = {}, turn = 12} = {}) {
  active = {...active, active: true};
  const current = {species: active.species, ident: `p1a: ${active.species}`, boosts: {}, ...ownPublic};
  return {
    format: 'gen9ou', side: 'p1', turn,
    request: {side: {id: 'p1', pokemon: [active, ...bench]}, active: [{
      moves: active.moves.map(move => ({move, id: Dex.moves.get(move).id, pp: 8, maxpp: 16})),
      ...(tera ? {canTerastallize: tera} : {}),
    }]},
    own: {active: [current], revealed: [current]},
    opponent: {active: [opponent], revealed: [opponent, ...opponentBench]},
    field: {sideConditions: [], opponentSideConditions: [], ...field},
  };
}

export const positions = {
  unnecessaryOffensiveTera: () => position(
    ownMon('Garchomp', ['Earthquake', 'Dragon Claw', 'Swords Dance', 'Fire Fang'], {set: {teraType: 'Ground', nature: 'Jolly', evs: {atk: 252, spe: 252}}}),
    publicMon('Heatran', ['Magma Storm', 'Earth Power', 'Taunt', 'Stealth Rock'], {hpFraction: 0.12, ability: 'Flash Fire', item: ''}),
    {tera: 'Ground', bench: [ownMon('Kingambit', ['Kowtow Cleave', 'Sucker Punch']), ownMon('Primarina', ['Moonblast', 'Surf'])]},
  ),
  defensiveTera: () => position(
    ownMon('Kingambit', ['Kowtow Cleave', 'Iron Head', 'Swords Dance', 'Sucker Punch'], {hp: 0.7, set: {teraType: 'Flying', ability: 'Supreme Overlord', nature: 'Adamant', evs: {hp: 252, atk: 252}}}),
    publicMon('Great Tusk', ['Close Combat', 'Headlong Rush', 'Knock Off', 'Rapid Spin'], {hpFraction: 0.15, item: 'Choice Scarf', lastMove: 'Close Combat', ability: 'Protosynthesis'}),
    {tera: 'Flying'},
  ),
  overprediction: () => position(
    ownMon('Garchomp', ['Earthquake', 'Fire Fang', 'Swords Dance', 'Dragon Claw'], {set: {nature: 'Jolly', evs: {atk: 252, spe: 252}}}),
    publicMon('Heatran', ['Magma Storm', 'Earth Power', 'Taunt', 'Stealth Rock'], {hpFraction: 0.15, item: '', ability: 'Flash Fire'}),
    {opponentBench: [publicMon('Corviknight', ['Brave Bird', 'Body Press', 'Roost', 'U-turn'], {ident: 'p2: Corviknight', hpFraction: 0.15, item: '', ability: 'Pressure'})],
      bench: [ownMon('Rotom-Wash', ['Hydro Pump', 'Volt Switch']), ownMon('Kingambit', ['Kowtow Cleave', 'Sucker Punch'])]},
  ),
  doubleProtect: () => position(
    ownMon('Gliscor', ['Protect', 'Earthquake', 'Toxic', 'Swords Dance'], {hp: 0.8, status: 'tox', set: {ability: 'Poison Heal', item: 'Toxic Orb'}}),
    publicMon('Heatran', ['Magma Storm', 'Earth Power', 'Taunt', 'Stealth Rock'], {hpFraction: 0.08, item: '', ability: 'Flash Fire', status: 'tox'}),
    {ownPublic: {lastMove: 'Protect'}},
  ),
  recoveryLoop: () => position(
    ownMon('Blissey', ['Soft-Boiled', 'Seismic Toss', 'Thunder Wave', 'Shadow Ball'], {hp: 0.6, set: {nature: 'Bold', evs: {hp: 252, def: 252}, ability: 'Natural Cure'}}),
    publicMon('Great Tusk', ['Close Combat', 'Headlong Rush', 'Knock Off', 'Rapid Spin'], {item: 'Choice Band', lastMove: 'Close Combat', ability: 'Protosynthesis'}),
    {ownPublic: {lastMove: 'Soft-Boiled'}, bench: [ownMon('Dragapult', ['Shadow Ball', 'Draco Meteor'], {set: {nature: 'Timid', evs: {spa: 252, spe: 252}}})]},
  ),
  predictiveLeechSeed: (incomingSeeded = false) => position(
    ownMon('Whimsicott', ['Leech Seed', 'Moonblast', 'Substitute', 'Encore'], {set: {ability: 'Prankster', evs: {spa: 252, spe: 252}, nature: 'Timid'}}),
    publicMon('Dondozo', ['Wave Crash', 'Body Press', 'Rest', 'Sleep Talk'], {hpFraction: 0.3, item: '', ability: 'Unaware', volatiles: ['leechseed']}),
    {ownPublic: {lastMove: 'Leech Seed'}, opponentBench: [publicMon('Heatran', ['Magma Storm', 'Earth Power', 'Taunt', 'Stealth Rock'], {
      ident: 'p2: Heatran', item: '', ability: 'Flash Fire', volatiles: incomingSeeded ? ['leechseed'] : [],
    })]},
  ),
  riskySwitch: () => position(
    ownMon('Garchomp', ['Earthquake', 'Dragon Claw', 'Swords Dance', 'Fire Fang']),
    publicMon('Heatran', ['Magma Storm', 'Earth Power', 'Taunt', 'Stealth Rock'], {hpFraction: 0.1, item: '', ability: 'Flash Fire'}),
    {bench: [ownMon('Charizard', ['Flamethrower', 'Air Slash'], {hp: 0.45, set: {item: ''}})], field: {sideConditions: ['Stealth Rock']}},
  ),
  preserveHealthyCheck: () => position(
    ownMon('Dondozo', ['Wave Crash', 'Body Press', 'Rest', 'Sleep Talk'], {hp: 0.9, set: {ability: 'Unaware', nature: 'Impish', evs: {hp: 252, def: 252}}}),
    publicMon('Rillaboom', ['Wood Hammer', 'Grassy Glide', 'Knock Off', 'U-turn'], {item: 'Choice Band', lastMove: 'Wood Hammer', ability: 'Grassy Surge'}),
    {bench: [ownMon('Corviknight', ['Brave Bird', 'Body Press', 'Roost', 'U-turn'], {set: {nature: 'Impish', evs: {hp: 252, def: 252}, ability: 'Pressure'}})],
      opponentBench: [publicMon('Kingambit', ['Kowtow Cleave', 'Sucker Punch', 'Swords Dance', 'Iron Head'], {ident: 'p2: Kingambit', item: '', ability: 'Supreme Overlord'})],
      field: {terrain: 'Grassy Terrain'}},
  ),
  simplifyWinningEndgame: () => position(
    ownMon('Dragapult', ['Shadow Ball', 'Draco Meteor', 'Thunder Wave', 'Substitute'], {set: {nature: 'Timid', evs: {spa: 252, spe: 252}}}),
    publicMon('Gholdengo', ['Make It Rain', 'Shadow Ball', 'Recover', 'Nasty Plot'], {hpFraction: 0.01, item: '', ability: 'Good as Gold'}),
    {opponentBench: ['Heatran', 'Great Tusk', 'Rillaboom', 'Primarina', 'Kingambit'].map(species => publicMon(species, [], {ident: `p2: ${species}`, hpFraction: 0, fainted: true}))},
  ),
};
