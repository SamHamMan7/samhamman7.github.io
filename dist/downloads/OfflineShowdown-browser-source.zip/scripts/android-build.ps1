[CmdletBinding()]
param(
    [string]$JavaHome = $env:JAVA_HOME,
    [string]$SdkRoot = '',
    [string]$WebRoot = '',
    [string]$OutputRoot = '',
    [int]$VersionCode = 2,
    [string]$VersionName = '1.0.0'
)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (!$SdkRoot) { $SdkRoot = Join-Path $projectRoot '.tools/android-sdk' }
if (!$WebRoot) { $WebRoot = Join-Path $projectRoot 'dist' }
$SdkRoot = [IO.Path]::GetFullPath($SdkRoot)
$WebRoot = [IO.Path]::GetFullPath($WebRoot)
if (!$JavaHome) {
    $compiler = Get-Command javac -ErrorAction SilentlyContinue
    if ($compiler) { $JavaHome = Split-Path (Split-Path $compiler.Source) }
}
if (!$JavaHome -or !(Test-Path -LiteralPath (Join-Path $JavaHome 'bin/javac.exe'))) {
    throw 'A JDK is required. Set JAVA_HOME or pass -JavaHome <JDK directory>. JDK 17 or newer is supported.'
}
$java = Join-Path $JavaHome 'bin/java.exe'
$javac = Join-Path $JavaHome 'bin/javac.exe'
$keytool = Join-Path $JavaHome 'bin/keytool.exe'
$platformJar = Join-Path $SdkRoot 'platforms/android-35/android.jar'
$buildTools = Join-Path $SdkRoot 'build-tools/android-15'
if (!(Test-Path -LiteralPath $buildTools)) { $buildTools = Join-Path $SdkRoot 'build-tools/35.0.0' }
if (!(Test-Path -LiteralPath $platformJar) -or !(Test-Path -LiteralPath (Join-Path $buildTools 'aapt2.exe'))) {
    throw 'Android SDK 35 is missing. Run scripts/android-setup.ps1 once while online, or supply -SdkRoot.'
}
if (!(Test-Path -LiteralPath (Join-Path $WebRoot 'index.html'))) {
    throw 'dist/index.html is missing. Run the web build (npm run build) first.'
}

function Invoke-Checked([string]$Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited with code $LASTEXITCODE" }
}

$buildRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot 'android/build'))
$expectedBuildRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot 'android/build'))
if ($buildRoot -ne $expectedBuildRoot -or !$buildRoot.StartsWith($projectRoot + [IO.Path]::DirectorySeparatorChar)) {
    throw 'Refusing to clean an unexpected build directory.'
}
if (Test-Path -LiteralPath $buildRoot) { Remove-Item -LiteralPath $buildRoot -Recurse -Force }
$generated = Join-Path $buildRoot 'generated'
$classes = Join-Path $buildRoot 'classes'
$dex = Join-Path $buildRoot 'dex'
$assets = Join-Path $buildRoot 'assets'
$webAssets = Join-Path $assets 'web'
$artifactRoot = if ($OutputRoot) { [IO.Path]::GetFullPath($OutputRoot) } else { Join-Path $projectRoot 'artifacts' }
New-Item -ItemType Directory -Force -Path $generated, $classes, $dex, $webAssets, $artifactRoot | Out-Null
Get-ChildItem -LiteralPath $WebRoot -Force | Copy-Item -Destination $webAssets -Recurse -Force
$sourceRoot = Join-Path $projectRoot 'android/app/src/main'
$compiledResources = Join-Path $buildRoot 'resources.zip'
$unsignedApk = Join-Path $buildRoot 'unsigned.apk'
$alignedApk = Join-Path $buildRoot 'aligned.apk'
$apk = Join-Path $artifactRoot 'OfflineShowdown-debug.apk'
$aapt2 = Join-Path $buildTools 'aapt2.exe'

Write-Host 'Compiling Android resources and bundling the complete offline web application...'
Invoke-Checked $aapt2 @('compile', '--dir', (Join-Path $sourceRoot 'res'), '-o', $compiledResources)
Invoke-Checked $aapt2 @('link', '-o', $unsignedApk, '-I', $platformJar,
    '--manifest', (Join-Path $sourceRoot 'AndroidManifest.xml'), '--java', $generated,
    '--min-sdk-version', '26', '--target-sdk-version', '35', '--version-code', "$VersionCode",
    '--version-name', $VersionName, $compiledResources)
$javaFiles = @((Get-ChildItem -LiteralPath (Join-Path $sourceRoot 'java'), $generated -Filter '*.java' -Recurse).FullName)
# Java 8 output keeps the Android bytecode simple; the host JDK may be newer.
$bootClasspath = $platformJar + [IO.Path]::PathSeparator + (Join-Path $buildTools 'core-lambda-stubs.jar')
Invoke-Checked $javac (@('-source', '8', '-target', '8', '-Xlint:-options', '-encoding', 'UTF-8', '-bootclasspath', $bootClasspath, '-d', $classes) + $javaFiles)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$classesJar = Join-Path $buildRoot 'classes.jar'
[IO.Compression.ZipFile]::CreateFromDirectory($classes, $classesJar)
Invoke-Checked $java @('-cp', (Join-Path $buildTools 'lib/d8.jar'), 'com.android.tools.r8.D8',
    '--min-api', '26', '--lib', $platformJar, '--output', $dex, $classesJar)
$zip = [IO.Compression.ZipFile]::Open($unsignedApk, [IO.Compression.ZipArchiveMode]::Update)
try {
    # AAPT2's Windows asset walker emits backslashes, which Android AssetManager
    # cannot resolve. Add assets with canonical APK forward-slash entry names.
    Get-ChildItem -LiteralPath $webAssets -File -Recurse | ForEach-Object {
        $relativeAsset = $_.FullName.Substring($webAssets.Length + 1).Replace('\', '/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, ('assets/web/' + $relativeAsset), [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    Get-ChildItem -LiteralPath $dex -Filter '*.dex' | ForEach-Object {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $_.Name, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $zip.Dispose() }
Invoke-Checked (Join-Path $buildTools 'zipalign.exe') @('-f', '-p', '4', $unsignedApk, $alignedApk)
$keyStore = Join-Path $projectRoot '.tools/offline-showdown-debug.keystore'
if (!(Test-Path -LiteralPath $keyStore)) {
    New-Item -ItemType Directory -Force -Path (Split-Path $keyStore) | Out-Null
    Invoke-Checked $keytool @('-genkeypair', '-keystore', $keyStore, '-storepass', 'android', '-keypass', 'android',
        '-alias', 'androiddebugkey', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
        '-dname', 'CN=Offline Showdown Development, O=Local Development, C=US')
}
$signer = Join-Path $buildTools 'lib/apksigner.jar'
Invoke-Checked $java @('-jar', $signer, 'sign', '--ks', $keyStore, '--ks-key-alias', 'androiddebugkey',
    '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', $apk, $alignedApk)
Invoke-Checked $java @('-jar', $signer, 'verify', '--verbose', $apk)
Invoke-Checked (Join-Path $buildTools 'zipalign.exe') @('-c', '-p', '4', $apk)
$verifyZip=[IO.Compression.ZipFile]::OpenRead($apk)
try {
    foreach($required in @('assets/web/index.html','assets/web/main.js','assets/web/js/oldclient/client-battle.js','assets/web/js/oldclient/client-teambuilder.js','assets/web/style/battle.css','assets/web/engine.worker.js','assets/web/ai.worker.js','assets/web/sprites/pokemonicons-sheet.png')) {
        if(!$verifyZip.GetEntry($required)){throw "APK is missing its required local asset: $required"}
    }
    if(@($verifyZip.Entries | Where-Object {$_.FullName.Contains('\')}).Count){throw 'APK contains invalid backslash asset paths.'}
} finally {$verifyZip.Dispose()}
$permissions = & (Join-Path $buildTools 'aapt.exe') dump permissions $apk
if ($LASTEXITCODE -ne 0) { throw 'Unable to inspect APK permissions.' }
if ($permissions -match 'android.permission.INTERNET') { throw 'Offline invariant violated: APK requests INTERNET permission.' }
$hash = (Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash.ToLowerInvariant()
Set-Content -LiteralPath (Join-Path $artifactRoot 'OfflineShowdown-debug.apk.sha256') -Value "$hash  OfflineShowdown-debug.apk" -Encoding ascii
Write-Host "APK ready: $apk"
Write-Host "Size: $([math]::Round((Get-Item -LiteralPath $apk).Length / 1MB, 2)) MiB. No INTERNET permission. SHA256: $hash"
