// Actual neural actions/log probabilities from local ONNX + authoritative sim.
import {mkdir,writeFile,open,readFile} from 'node:fs/promises';
import path from 'node:path';
import {BattleSession} from '../src/core/session.js';
import {chooseAction,legalActions} from '../src/ai/policy.js';
import {encodeObservation} from '../src/ai/neural/observation.js';
import {actionIndexFromChoice,legalActionForIndex} from '../src/ai/neural/action-space.js';
import {createNodeOnnxBackend} from '../src/ai/neural/onnx-node.js';
const arg=(name,fallback)=>{const i=process.argv.indexOf('--'+name);return i<0?fallback:process.argv[i+1];};
const games=Number(arg('games',50)),seed=Number(arg('seed',814121));
const manifest=arg('model','models/gen9randombattle/manifest.json');
const output=path.resolve(arg('output','artifacts/neural/rollouts-v2.jsonl'));
const opponent=arg('opponent','self'),leaguePath=arg('league','');
const evaluate=process.argv.includes('--evaluate');
const learner=await createNodeOnnxBackend({manifestPath:manifest});
const backends=new Map([[path.resolve(manifest),learner]]);
const historical=leaguePath?JSON.parse(await readFile(leaguePath,'utf8')).checkpoints.filter(e=>e.onnxManifest):[];
function rng(value){return()=>{value+=0x6D2B79F5;let t=value;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
const random=rng(seed);
function distribution(logits,mask) {
  const max=Math.max(...logits.filter((_,i)=>mask[i]));
  const weights=logits.map((v,i)=>mask[i]?Math.exp(v-max):0),sum=weights.reduce((a,b)=>a+b,0);
  return weights.map(v=>v/sum);
}
async function historicalBackend(game) {
  if(!historical.length||random()<0.45)return learner;
  const entry=historical[Math.floor(random()*historical.length)],key=path.resolve(entry.onnxManifest);
  if(!backends.has(key))backends.set(key,await createNodeOnnxBackend({manifestPath:key}));
  return backends.get(key);
}
async function play(game) {
  const learnerSide=game%2===0?'p1':'p2',otherSide=learnerSide==='p1'?'p2':'p1';
  const rival=opponent==='self'?await historicalBackend(game):null;
  const battleRandom=rng(seed+Math.imul(Math.floor(game/2)+1,104729));
  const battleSeed=Array.from({length:4},()=>Math.floor(battleRandom()*65536));
  const decisionRandom={p1:rng(seed+game*101+1),p2:rng(seed+game*101+2)};
  const rows=[],labels=[],latencies=[];let session,finish,fail,timer,ended=false,winner='tie';
  const completed=new Promise((resolve,reject)=>{finish=resolve;fail=reject;});
  timer=setTimeout(()=>fail(new Error(`Neural battle ${game} timed out`)),120000);
  session=new BattleSession({
    onUpdate({lines}){for(const line of lines){
      if(line.startsWith('|win|')||line==='|tie|'){
        winner=line==='|tie|'?'tie':line.slice(5)==='You'?'p1':'p2';ended=true;finish();
      }
    }},
    onRequest({side,token,view}){void(async()=>{
      const actions=legalActions(view),observation=encodeObservation(view,actions);
      const ordinary=!view.request.forceSwitch?.some(Boolean)&&!view.request.active?.some(s=>s.reviving);
      const backend=side===learnerSide?learner:rival;
      let choice,prediction,index,logProb;
      if(backend){
        const start=performance.now();prediction=await backend.predict(observation);latencies.push(performance.now()-start);
        const probabilities=distribution(prediction.policyLogits,observation.legalMask);
        if(evaluate)index=probabilities.indexOf(Math.max(...probabilities));
        else{let draw=decisionRandom[side]();index=probabilities.findIndex(p=>(draw-=p)<0);if(index<0)index=probabilities.findLastIndex(p=>p>0);}
        choice=legalActionForIndex(index,actions)?.choice;
        if(!choice)throw new Error('Neural sample failed legal-action resolution');
        logProb=Math.log(probabilities[index]);
      }else{choice=chooseAction(view,{difficulty:opponent,seed:seed+game*1009+token}).choice;index=actionIndexFromChoice(choice);}
      labels.push({side,turn:view.turn,index,ordinary});
      if(side===learnerSide){
        rows.push({schema:3,gameId:`neural-${seed}-${game}`,side,sequence:rows.length,turn:view.turn,ordinary,
          observation,action:index,opponentAction:-1,oldLogProb:logProb,oldValue:prediction.value*2-1,nextValue:0,reward:0,done:false,
          modelSha256:learner.metadata.sha256,opponentModelSha256:rival?.metadata.sha256||null});
      }
      if(!await session.choose(side,token,choice)&&!ended)throw new Error('Fresh neural choice token was rejected');
    })().catch(fail);},
    onError:fail,
  });
  try{await session.start({format:'gen9randombattle',seed:battleSeed});await completed;}
  finally{clearTimeout(timer);await session.close();}
  const result=winner==='tie'?0:winner===learnerSide?1:-1;
  for(let i=0;i<rows.length;i++){
    const row=rows[i],pair=labels.find(label=>label.side===otherSide&&label.turn===row.turn&&label.ordinary);
    if(row.ordinary&&pair)row.opponentAction=pair.index;
    row.done=i===rows.length-1;row.reward=row.done?result:0;row.return=result;
    row.nextValue=rows[i+1]?.oldValue||0;
  }
  return {rows,result,latencies,turns:rows.at(-1)?.turn||0,opponentModel:rival?.metadata.sha256||opponent};
}
await mkdir(path.dirname(output),{recursive:true});
const handle=await open(output,'w'),summary={games:0,wins:0,losses:0,ties:0,rows:0,opponents:{},decisionMs:[],mode:evaluate?'paired evaluation argmax':'sampled neural PPO collection',model:learner.metadata};
try{
  for(let game=0;game<games;game++){
    const result=await play(game);
    if(!evaluate)await handle.writeFile(result.rows.map(row=>JSON.stringify(row)).join('\n')+'\n');
    summary.games++;summary[result.result>0?'wins':result.result<0?'losses':'ties']++;summary.rows+=result.rows.length;
    summary.opponents[result.opponentModel]=(summary.opponents[result.opponentModel]||0)+1;
    summary.decisionMs.push(...result.latencies);
    if((game+1)%5===0)console.log(`games=${game+1}/${games} W/L/T=${summary.wins}/${summary.losses}/${summary.ties} rows=${summary.rows}`);
  }
}finally{await handle.close();for(const backend of backends.values())await backend.dispose();}
summary.decisionMs.sort((a,b)=>a-b);
summary.latency={p50:summary.decisionMs[Math.floor(summary.decisionMs.length*.5)],p95:summary.decisionMs[Math.floor(summary.decisionMs.length*.95)],max:summary.decisionMs.at(-1)};delete summary.decisionMs;
summary.testedAt=new Date().toISOString();summary.seed=seed;
await writeFile(output+'.report.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
