import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import {BattleSession} from '../src/core/session.js';
import {legalActions} from '../src/ai/policy.js';
const modelDirectory=path.resolve(process.argv[2]||'artifacts/neural/smoke');
const installed=process.argv.includes('--installed');
const android=process.argv.includes('--android');
if(android&&!installed)throw new Error('Android probe must use the installed APK model');
const manifest=JSON.parse(await fs.readFile(path.join(modelDirectory,'manifest.json'),'utf8'));
let resolveView;
const pending=new Promise(resolve=>{resolveView=resolve;});
const session=new BattleSession({onRequest:({side,view})=>{if(side==='p1')resolveView(view);},onError:error=>{throw error;}});
await session.start({format:'gen9randombattle',seed:[91,82,73,64]});
const view=await pending;await session.close();
const legal=legalActions(view).map(action=>action.choice);
const browser=android?await chromium.connectOverCDP('http://127.0.0.1:9223',{noDefaults:true}):await chromium.launch({channel:'chrome',headless:true});
try{
  const context=android?browser.contexts()[0]:await browser.newContext({serviceWorkers:'block'});
  if(!installed){
    await context.route('**/models/gen9randombattle/manifest.json',route=>route.fulfill({contentType:'application/json',body:JSON.stringify(manifest)}));
    await context.route('**/models/gen9randombattle/'+manifest.model,route=>route.fulfill({contentType:'application/octet-stream',path:path.join(modelDirectory,manifest.model)}));
  }
  const page=android?context.pages()[0]:await context.newPage();
  if(!android)await page.goto('http://127.0.0.1:4173/');
  await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
  if(installed){
    const deployed=await page.evaluate(async()=>await (await fetch('/models/gen9randombattle/manifest.json')).json());
    if(deployed.sha256!==manifest.sha256)throw new Error('Installed model differs from requested checkpoint');
  }
  const result=await page.evaluate(async view=>{
    const worker=new Worker('/ai.worker.js',{type:'module'}),rows=[];
    try{
      for(let token=1;token<=8;token++){
        const started=performance.now();
        const result=await new Promise((resolve,reject)=>{
          const timer=setTimeout(()=>reject(new Error('Browser neural inference timed out')),30000);
          worker.onerror=e=>{clearTimeout(timer);reject(new Error(e.message));};
          worker.onmessage=({data})=>{clearTimeout(timer);data.type==='error'?reject(new Error(data.message)):resolve(data);};
          worker.postMessage({difficulty:'Neural Preview',side:'p1',token,seed:42,view});
        });
        rows.push({...result,wallMs:performance.now()-started});
      }
    }finally{worker.terminate();}
    return rows;
  },view);
  if(result.some(row=>!row.diagnostics?.neuralBackend||row.diagnostics?.usedFallback||!legal.includes(row.choice)))throw new Error('Browser did not use a legal trained neural policy: '+JSON.stringify(result));
  if(manifest.beliefs&&result.some(row=>!row.diagnostics?.learnedBeliefs?.nextMove||row.diagnostics?.beliefError))throw new Error('Installed auxiliary inference failed');
  const report={testedAt:new Date().toISOString(),installedModel:installed,runtime:(android?'Android WebView':'Chrome')+' dedicated worker / ONNX WASM, one thread',modelSha256:manifest.sha256,trained:true,strengthValidated:manifest.strengthValidated,rows:result.map(r=>({choice:r.choice,wallMs:r.wallMs,inferenceMs:r.elapsedMs,neuralBackend:r.diagnostics.neuralBackend,learnedBeliefs:!!r.diagnostics.learnedBeliefs,value:r.diagnostics.value}))};
  await fs.writeFile(path.join(modelDirectory,android?'android-inference.json':'browser-inference.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{await browser.close();}
