import fs from 'node:fs';
import {BattleSession} from '../src/core/session.js';
import {SAMPLE_TEAM, TEAM_POOL} from '../src/data/teams.js';
import {COMPETITIVE_TEAMS} from '../src/data/competitive-teams.js';
import {chooseAction, chooseBaseline} from '../src/ai/index.js';

const count = Number(process.argv[2] || 8);
const format = process.argv[3] || 'gen9randombattle';
const difficulty = process.argv[4] || 'Strong';
const baseline = process.argv[5] || 'greedy';
const seedOffset=Number(process.argv[6]||0);
const rows = [];
globalThis.fetch = () => {throw new Error('Network is disabled during AI battle benchmark');};

for (let index = 0; index < count; index++) {
  const aiSide = index % 2 === 0 ? 'p1' : 'p2';
  const latencies = [];
  let session, requests = 0, errors = 0, calculations = 0, calcFailures = 0;
  const previous = {};
  const started = performance.now();
  const row = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Benchmark battle timed out')), 120000);
    session = new BattleSession({
      onUpdate: ({view}) => {
        if (view.ended) {
          clearTimeout(timeout);
          resolve({index, aiSide, winner:view.winner, won:view.winner === (aiSide === 'p1' ? 'You' : 'Offline AI'), turns:view.turn});
        }
      },
      onRequest: ({side, token, view}) => {
        if (++requests > 1600) {clearTimeout(timeout); return reject(new Error('Battle exceeded 1600 decisions'));}
        try {
          const start = performance.now();
          const decision = side === aiSide ? chooseAction(view,{difficulty}) : baseline==='default' ? {choice:'default'} : ['Medium','Strong','Very Strong'].includes(baseline) ? chooseAction(view,{difficulty:baseline}) : chooseBaseline(view,{policy:baseline,seed:index+923});
          if (side === aiSide) {latencies.push(performance.now()-start); calculations += decision.diagnostics?.calculations || 0; calcFailures += decision.diagnostics?.calcFailures || 0;}
          if (!decision.choice) {fs.mkdirSync('reports',{recursive:true});fs.writeFileSync('reports/request-failure.json',JSON.stringify({format,index,side,view},null,2));clearTimeout(timeout); return reject(new Error('No choice during decision request'));}
          previous[side] = {choice:decision.choice,active:view.request.active};
          queueMicrotask(() => session.choose(side,token,decision.choice).catch(reject));
        } catch (error) {clearTimeout(timeout); reject(error);}
      },
      onError: (error, side) => {
        errors++;
        if (errors <= 8 && /trapped/.test(error.message)) {queueMicrotask(() => session.retry(side)); return;}
        clearTimeout(timeout);reject(new Error(`${side}: ${error.message} ${JSON.stringify(previous[side])}`));
      },
    });
    // Paired seeds with side reversal reduce team-assignment bias.
    const seed = [Math.floor((index+seedOffset)/2)+37, 113, 217, 997];
    const pool=[...COMPETITIVE_TEAMS,...TEAM_POOL];
    session.start({format, teamPaste:pool[Math.floor(index/2)%pool.length].paste, opponentPaste:pool[(Math.floor(index/2)+1)%pool.length].paste, seed}).catch(reject);
  });
  await session.close();
  latencies.sort((a,b)=>a-b);
  Object.assign(row,{requests,errors,calculations,calcFailures,ms:Math.round(performance.now()-started),
    decisionMeanMs:Math.round(latencies.reduce((a,b)=>a+b,0)/latencies.length*10)/10,
    decisionP95Ms:Math.round(latencies[Math.floor(latencies.length*.95)]*10)/10});
  rows.push(row);
  console.log(JSON.stringify(row));
}
const wins = rows.filter(row=>row.won).length;
const summary = {generatedAt:new Date().toISOString(),format,difficulty,baseline,seedOffset,games:count,wins,winRate:wins/count,
  note:'Small fixed-seed local baseline comparison; not ladder Elo or Pixel device validation.',rows};
fs.mkdirSync('reports',{recursive:true});
fs.writeFileSync(`reports/ai-${format}-${difficulty.toLowerCase().replaceAll(' ','-')}-${baseline}${seedOffset?'-holdout-'+seedOffset:''}.json`,JSON.stringify(summary,null,2));
console.log(JSON.stringify({format,difficulty,baseline,games:count,wins,winRate:wins/count}));
