/**
 * Training-only RandBats collector with privileged hidden-set LABELS.
 *
 * Critical firewall rule: chooseAction() receives only PlayerView.snapshot().
 * Exact opponent teams are retained solely on the recorded label side of the
 * dataset so future item/ability/move/Tera auxiliary heads can be supervised.
 */
import {mkdir, writeFile} from 'node:fs/promises';
import path from 'node:path';

import {BattleStreams, Teams} from '@pkmn/sim';
import {TeamGenerators} from '@pkmn/randoms';
import {PlayerView} from '../src/core/view.js';
import {chooseAction, legalActions} from '../src/ai/policy.js';
import {actionIndexFromChoice} from '../src/ai/neural/action-space.js';
import {encodeObservation} from '../src/ai/neural/observation.js';

Teams.setGeneratorFactory(TeamGenerators);

function arg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 && process.argv[index + 1] !== undefined ? process.argv[index + 1] : fallback;
}
const games = Math.max(1, Number(arg('games', '25')) || 25);
const baseSeed = Number(arg('seed', '8675309')) || 8675309;
const difficulty = String(arg('difficulty', 'Very Strong'));
const output = path.resolve(arg('output', `artifacts/neural/privileged-randbats-${games}.jsonl`));

function seedFor(game, offset = 0) {
  let x = (baseSeed + offset + Math.imul(game + 1, 0x9e3779b1)) >>> 0;
  const next = () => {
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    return (x >>> 0) & 0xffff;
  };
  return [next(), next(), next(), next()];
}

function hiddenTeamLabel(team) {
  return team.map(set => ({
    species: String(set.species || set.name || ''),
    item: String(set.item || ''),
    ability: String(set.ability || ''),
    moves: Array.isArray(set.moves) ? set.moves.map(String) : [],
    teraType: String(set.teraType || ''),
    level: Number(set.level) || null,
  }));
}

async function runGame(gameIndex) {
  const gameId = `priv-rb-${baseSeed}-${gameIndex}`;
  const p1team = Teams.generate('gen9randombattle', {seed: seedFor(gameIndex, 0)});
  const p2team = Teams.generate('gen9randombattle', {seed: seedFor(gameIndex, 7919)});
  const hidden = {p1: hiddenTeamLabel(p1team), p2: hiddenTeamLabel(p2team)};
  const views = {p1: new PlayerView('p1', p1team), p2: new PlayerView('p2', p2team)};
  const streams = BattleStreams.getPlayerStreams(new BattleStreams.BattleStream());
  const rows = [];
  let winner = 'tie';
  let sequence = 0;
  let settled = false;

  let resolveFinished, rejectFinished;
  const finished = new Promise((resolve, reject) => { resolveFinished = resolve; rejectFinished = reject; });
  const timeout = setTimeout(() => rejectFinished(new Error(`${gameId} timed out`)), 60_000);

  async function consume(side) {
    try {
      for await (const chunk of streams[side]) {
        const view = views[side];
        const requested = view.receive(chunk);
        const state = view.snapshot();
        for (const line of chunk.split('\n')) {
          if (line.startsWith('|win|')) {
            const name = line.slice(5);
            winner = name === 'Learner A' ? 'p1' : name === 'Learner B' ? 'p2' : 'tie';
            if (!settled) { settled = true; clearTimeout(timeout); resolveFinished(); }
          } else if (line === '|tie|' && !settled) {
            winner = 'tie'; settled = true; clearTimeout(timeout); resolveFinished();
          }
        }
        if (state.error) {
          if (!String(state.error).startsWith('[Unavailable choice]')) throw new Error(`${side}: ${state.error}`);
          delete view.state.error;
        }
        if (!requested || state.ended || state.request?.wait) continue;

        const publicView = {...state, format: 'gen9randombattle'};
        const actions = legalActions(publicView);
        const decision = chooseAction(publicView, {
          difficulty,
          seed: baseSeed + gameIndex * 1009 + (publicView.turn || 0) * 37 + (side === 'p1' ? 1 : 2),
        });
        if (!decision?.choice) throw new Error(`${side} produced no choice`);
        const action = actionIndexFromChoice(decision.choice);
        if (action >= 0 && !publicView.request?.teamPreview) {
          rows.push({
            schema: 2,
            gameId,
            side,
            sequence: sequence++,
            turn: Number(publicView.turn) || 0,
            observation: encodeObservation(publicView, actions),
            action,
            opponentAction: -1,
            outcome: null,
            // PRIVILEGED LABELS ONLY. Never concatenate this object into observation.
            privilegedOpponentTeam: hidden[side === 'p1' ? 'p2' : 'p1'],
          });
        }
        await streams[side].write(decision.choice);
      }
    } catch (error) {
      if (!settled) { settled = true; clearTimeout(timeout); rejectFinished(error); }
    }
  }

  void consume('p1');
  void consume('p2');
  for (const channel of ['omniscient', 'spectator', 'p3', 'p4']) {
    void (async () => { try { for await (const _ of streams[channel]) { /* discard */ } } catch {} })();
  }

  await streams.omniscient.write(
    `>start ${JSON.stringify({formatid: 'gen9randombattle', seed: seedFor(gameIndex, 12345)})}\n` +
    `>player p1 ${JSON.stringify({name: 'Learner A', team: Teams.pack(p1team)})}\n` +
    `>player p2 ${JSON.stringify({name: 'Learner B', team: Teams.pack(p2team)})}`
  );
  await finished;
  await streams.omniscient.writeEnd();

  // Opponent-action labels for ordinary simultaneous turns.
  const byTurn = new Map();
  for (const row of rows) {
    const pair = byTurn.get(row.turn) || {p1: [], p2: []};
    pair[row.side].push(row);
    byTurn.set(row.turn, pair);
  }
  for (const pair of byTurn.values()) {
    const count = Math.min(pair.p1.length, pair.p2.length);
    for (let i = 0; i < count; i++) {
      pair.p1[i].opponentAction = pair.p2[i].action;
      pair.p2[i].opponentAction = pair.p1[i].action;
    }
  }
  for (const row of rows) row.outcome = winner === 'tie' ? 0 : winner === row.side ? 1 : -1;
  return {rows, winner};
}

await mkdir(path.dirname(output), {recursive: true});
const all = [];
for (let game = 0; game < games; game++) {
  const result = await runGame(game);
  all.push(...result.rows);
  if ((game + 1) % 5 === 0 || game + 1 === games) console.log(`games=${game + 1}/${games} rows=${all.length}`);
}
await writeFile(output, all.map(row => JSON.stringify(row)).join('\n') + '\n');
console.log(`saved ${all.length} privileged-label examples to ${output}`);
console.log('WARNING: privilegedOpponentTeam is training-label data only. Never feed it into live inference.');
