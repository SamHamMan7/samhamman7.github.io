// Renderer readiness regression, using public battle protocol fixtures. Full
// simulator/choice legality is covered separately by showdown-browser-test.mjs.
import {chromium} from 'playwright';
import fs from 'node:fs';
const android=process.argv.includes('--android');
const source=fs.readFileSync('src/transport/battle-assets.js','utf8').replace('export function','function');
const browser=android?await chromium.connectOverCDP('http://127.0.0.1:9223',{noDefaults:true}):await chromium.launch({channel:'chrome',headless:true});
const rows=[];
const batches=[
  ['|gen|9','|tier|[Gen 9] OU','|player|p1|You|1','|player|p2|Offline AI|2','|teamsize|p1|3','|teamsize|p2|3','|poke|p1|Primarina, F','|poke|p1|Dragapult, M','|poke|p2|Gholdengo','|poke|p2|Palafin, M','|start','|switch|p1a: Primarina|Primarina, F|100/100','|switch|p2a: Gholdengo|Gholdengo|100/100','|turn|1'],
  ['|move|p2a: Gholdengo|Substitute|p2a: Gholdengo','|-start|p2a: Gholdengo|Substitute','|-damage|p2a: Gholdengo|75/100','|move|p1a: Primarina|Moonblast|p2a: Gholdengo','|-activate|p2a: Gholdengo|Substitute|[damage]','|turn|2'],
  ['|-terastallize|p1a: Primarina|Fairy','|move|p1a: Primarina|Moonblast|p2a: Gholdengo','|-end|p2a: Gholdengo|Substitute','|-status|p1a: Primarina|brn','|turn|3'],
  ['|switch|p1a: Dragapult|Dragapult, M|100/100','|switch|p2a: Palafin|Palafin, M|100/100','|-formechange|p2a: Palafin|Palafin-Hero','|turn|4'],
  ['|move|p1a: Dragapult|Shadow Ball|p2a: Palafin','|-damage|p2a: Palafin|0 fnt','|faint|p2a: Palafin','|win|You'],
];
try {
  for(const gated of android?[true]:[false,true]) {
    const context=android?browser.contexts()[0]:await browser.newContext({viewport:{width:412,height:915},serviceWorkers:'block'});
    const page=android?context.pages()[0]:await context.newPage();
    if(!android)await page.route(/\.(png|gif|jpe?g)(\?|$)/,async route=>{await new Promise(r=>setTimeout(r,350));await route.continue();});
    if(android)await page.reload();else await page.goto('http://127.0.0.1:4173/');
    await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
    await page.evaluate(({source,gated})=>{
      Storage.prefs('noanim',false);Storage.prefs('nogif',false);Storage.prefs('mute',true);BattleSound.setMute(true);
      const decoded=new Set(),first=new Map(),frames=[];
      const key=url=>new URL(url,location.href).pathname;
      const NativeImage=window.Image;
      window.Image=class extends NativeImage {
        async decode(){await super.decode();decoded.add(key(this.src));}
      };
      window.readiness={gated,first,frames};
      window.testAssets=new Function('Dex','Storage',source+';return createBattleAssets({Dex,Storage});')(Dex,Storage);
      const check=(kind,url)=>{if(url&&!first.has(kind+url))first.set(kind+url,{kind,url:key(url),decodedBeforeUse:decoded.has(key(url))});};
      const effect=BattleScene.prototype.showEffect;
      BattleScene.prototype.showEffect=function(e,...args){check('effect',typeof e==='string'?BattleEffects[e]?.url:e?.url);return effect.call(this,e,...args);};
      const background=BattleScene.prototype.backgroundEffect;
      BattleScene.prototype.backgroundEffect=function(css,...args){check('background',/url\(['"]?([^)'" ]+)/.exec(css)?.[1]);return background.call(this,css,...args);};
      const summon=BattleScene.prototype.animSummon;
      BattleScene.prototype.animSummon=function(p,...args){check('sprite',p.sprite.sp.url);return summon.call(this,p,...args);};
      app.receive('>battle-gen9ou-readiness\n|init|battle\n|title|Animation readiness');app.focusRoom('battle-gen9ou-readiness');
      const room=app.rooms['battle-gen9ou-readiness'];
      new MutationObserver(records=>{
        for(const record of records)for(const node of record.addedNodes){
          if(node.nodeType!==1)continue;
          const imgs=node.tagName==='IMG'?[node]:[...node.querySelectorAll('img')];
          for(const img of imgs)if(img.closest('[role=complementary]'))continue;else {
            const firstVisible=()=>{
              if(!img.isConnected)return;
              if(img.getClientRects().length&&Number(getComputedStyle(img).opacity)>0)frames.push({url:key(img.src),ready:img.complete&&img.naturalWidth>0});
              else requestAnimationFrame(firstVisible);
            };
            requestAnimationFrame(firstVisible);
          }
        }
      }).observe(room.battle.scene.$battle[0],{childList:true,subtree:true});
    },{source,gated});
    for(const lines of batches) {
      await page.evaluate(async lines=>{if(readiness.gated)await testAssets.prepare({lines});app.receive('>battle-gen9ou-readiness\n'+lines.join('\n'));},lines);
      await page.waitForFunction(()=>app.rooms['battle-gen9ou-readiness'].battle.atQueueEnd,{},{timeout:45000});
    }
    await page.screenshot({path:`reports/showdown-animation-${android?'android':gated?'decoded':'baseline'}.png`});
    const result=await page.evaluate(()=>({gated:readiness.gated,firstUses:[...readiness.first.values()],spriteFrames:readiness.frames,assets:testAssets.snapshot()}));
    result.undecodedFirstUses=result.firstUses.filter(e=>!e.decodedBeforeUse).length;
    result.unreadySpriteFrames=result.spriteFrames.filter(e=>!e.ready).length;
    rows.push(result);
    if(gated&&(result.undecodedFirstUses||result.unreadySpriteFrames||result.assets.failed.length))throw new Error('First-use readiness failed: '+JSON.stringify(result));
    if(!android)await context.close();
  }
  const report={testedAt:new Date().toISOString(),android,coldImageDelayMs:android?0:350,fixture:'Public renderer protocol: switch, Moonblast background, Substitute, Tera, burn, Palafin formechange, Shadow Ball, faint',rows};
  fs.writeFileSync(`reports/showdown-animation-${android?'android':'browser'}.json`,JSON.stringify(report,null,2));
  console.log(rows.map(r=>({gated:r.gated,firstUses:r.firstUses.length,undecoded:r.undecodedFirstUses,unreadyFrames:r.unreadySpriteFrames,assets:r.assets})));
} finally {await browser.close();}
