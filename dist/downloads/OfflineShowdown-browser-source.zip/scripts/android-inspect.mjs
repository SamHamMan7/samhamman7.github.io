import {chromium} from 'playwright';
const b=await chromium.connectOverCDP('http://127.0.0.1:9223',{noDefaults:true});const p=b.contexts()[0].pages()[0];console.log(await p.evaluate(()=>({url:location.href,text:document.body.innerText.slice(0,800),health:window.offlinePractice?.snapshot(),controlled:!!navigator.serviceWorker?.controller})));await b.close();
