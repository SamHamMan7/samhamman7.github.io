import {chromium} from 'playwright';
const browser=await chromium.launch({channel:'chrome',headless:true});
const context=await browser.newContext({viewport:{width:412,height:915},serviceWorkers:'block'});
const page=await context.newPage();
page.on('pageerror',e=>console.log('PAGEERROR',e.stack));
page.on('console',m=>{if(m.type()==='error')console.log('CONSOLE',m.text())});
page.on('response',r=>{if(r.status()>=400)console.log('HTTP',r.status(),r.url())});
await page.goto('http://127.0.0.1:4173/');
await page.waitForTimeout(3000);
await page.locator('button[name=search]').click(); await page.waitForTimeout(3000); await page.locator('button[name=goToEnd]').first().click(); await page.waitForTimeout(500); console.log(await page.evaluate(()=>({text:document.body.innerText,health:window.offlinePractice?.snapshot()})));
await page.screenshot({path:'reports/showdown-initial.png'});
await browser.close();


