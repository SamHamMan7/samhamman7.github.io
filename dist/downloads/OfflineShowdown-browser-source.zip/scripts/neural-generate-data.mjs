import {mkdir, writeFile} from 'node:fs/promises';
import path from 'node:path';

import {BattleSession} from '../src/core/session.js';
import {chooseAction, legalActions} from '../src/ai/policy.js';
import {actionIndexFromChoice} from '../src/ai/neural/action-space.js';
import {trainingExample} from '../src/ai/neural/dataset.js';

function arg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 && process.argv[index + 1] !== undefined ? process.argv[index + 1] : fallback;
}

const games = Math.max(1, Number(arg('games', '50')) || 50);
const baseSeed = Number(arg('seed', '1729')) || 1729;
const difficulty = String(arg('difficulty', 'Very Strong'));
const output = path.resolve(arg('output', `artifacts/neural/gen9randombattle-${difficulty.toLowerCase().replaceAll(' ', '-')}-${games}.jsonl`));

function seedFor(game) {
  let x = (baseSeed + Math.imul(game + 1, 0x9e3779b1)) >>> 0;
  const next = () => {
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    return (x >>> 0) & 0xffff;
  };
  return [next(), next(), next(), next()];
}

function ordinaryTurn(view) {
  if (view?.request?.teamPreview) return false;
  if (view?.request?.forceSwitch?.some(Boolean)) return false;
  if (view?.request?.active?.some(slot => slot?.reviving)) return false;
  return true;
}

async function runGame(gameIndex) {
  const gameId = `rb-${baseSeed}-${gameIndex}`;
  const decisions = [];
  let winner = 'tie';
  let session;
  let settled = false;

  const finished = new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`Battle ${gameId} exceeded 60 seconds.`)), 60_000);
    const done = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve(result);
    };

    session = new BattleSession({
      onUpdate({view, lines}) {
        for (const line of lines || []) {
          if (line.startsWith('|win|')) {
            const name = line.slice(5);
            winner = name === 'You' ? 'p1' : name === 'Offline AI' ? 'p2' : 'tie';
            done(winner);
          } else if (line === '|tie|') {
            winner = 'tie';
            done(winner);
          }
        }
        if (view?.ended && !settled) {
          // In case a simulator/version omits the normal win line from this
          // player chunk, give the other player stream one event loop to emit it.
          setTimeout(() => done(winner), 0);
        }
      },
      onRequest({side, token, view}) {
        void (async () => {
          const actions = legalActions(view);
          const decisionSeed = baseSeed + gameIndex * 1009 + (view.turn || 0) * 37 + (side === 'p1' ? 1 : 2);
          const result = chooseAction(view, {difficulty, seed: decisionSeed});
          if (!result?.choice) throw new Error(`${gameId} ${side} returned no action on turn ${view.turn}.`);

          const action = actionIndexFromChoice(result.choice);
          if (action >= 0 && !view?.request?.teamPreview) {
            const row = trainingExample({
              view,
              legalActions: actions,
              choice: result.choice,
              opponentChoice: null,
              outcome: null,
              gameId,
            });
            decisions.push({side, turn: Number(view.turn) || 0, ordinary: ordinaryTurn(view), choice: result.choice, row});
          }
          const accepted = await session.choose(side, token, result.choice);
          if (!accepted) throw new Error(`${gameId} rejected a freshly issued token for ${side}.`);
        })().catch(reject);
      },
      onError(error) { reject(error); },
    });
  });

  await session.start({format: 'gen9randombattle', seed: seedFor(gameIndex)});
  await finished;
  await session.close();

  // Label simultaneous ordinary-turn opponent decisions. Forced replacements
  // intentionally do not receive an opponent-action label because they are not
  // simultaneous strategic responses.
  const byTurn = new Map();
  for (const decision of decisions) {
    if (!decision.ordinary) continue;
    const key = `${decision.turn}`;
    const slot = byTurn.get(key) || {};
    slot[decision.side] = decision;
    byTurn.set(key, slot);
  }
  for (const pair of byTurn.values()) {
    if (!pair.p1 || !pair.p2) continue;
    pair.p1.row.opponentAction = actionIndexFromChoice(pair.p2.choice);
    pair.p2.row.opponentAction = actionIndexFromChoice(pair.p1.choice);
  }

  for (const decision of decisions) {
    decision.row.outcome = winner === 'tie' ? 0 : winner === decision.side ? 1 : -1;
  }
  return {rows: decisions.map(d => d.row), winner};
}

await mkdir(path.dirname(output), {recursive: true});
const rows = [];
const wins = {p1: 0, p2: 0, tie: 0};
for (let game = 0; game < games; game++) {
  const result = await runGame(game);
  rows.push(...result.rows);
  wins[result.winner] = (wins[result.winner] || 0) + 1;
  if ((game + 1) % 10 === 0 || game + 1 === games) {
    console.log(`games=${game + 1}/${games} rows=${rows.length} p1=${wins.p1} p2=${wins.p2} ties=${wins.tie}`);
  }
}
await writeFile(output, rows.map(row => JSON.stringify(row)).join('\n') + '\n');
console.log(`saved ${rows.length} examples to ${output}`);
