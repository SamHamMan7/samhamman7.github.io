import {spawn} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
const arg=(name,fallback)=>{const i=process.argv.indexOf('--'+name);return i<0?fallback:process.argv[i+1];};
const games=Number(arg('games',2000)),workers=Number(arg('workers',4)),seed=arg('seed','424242');
const output=path.resolve(arg('output','artifacts/neural/randbats-v2'));
const difficulty=arg('difficulty','Very Strong');
if(!Number.isInteger(games)||games<1||!Number.isInteger(workers)||workers<1||workers>16)throw new Error('Invalid job size');
await mkdir(output,{recursive:true});
const shards=[];
await Promise.all(Array.from({length:Math.min(workers,games)},async(_,worker)=>{
  const start=Math.floor(games*worker/workers),end=Math.floor(games*(worker+1)/workers);
  const file=path.join(output,`part-${worker}.jsonl`);shards.push({file,start,games:end-start});
  const args=['scripts/neural-generate-trajectories.mjs','--games',String(end-start),'--start-game',String(start),'--seed',seed,'--difficulty',difficulty,'--output',file,'--resume'];
  await new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,args,{stdio:'inherit',windowsHide:true});
    child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(new Error(`Shard ${worker} exited ${code}`)));
  });
}));
await writeFile(path.join(output,'dataset.json'),JSON.stringify({schema:2,games,seed:Number(seed),difficulty,shards:shards.sort((a,b)=>a.start-b.start),createdAt:new Date().toISOString()},null,2));
