// Resumable orchestration of real ONNX decisions -> PPO -> checked ONNX export.
// Outputs remain under an explicit training run directory; this never deploys.
import {spawn} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {readFile, writeFile, rename, mkdir, open, unlink, access} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const values = new Map();
for (let index = 2; index < process.argv.length; index++) {
  const key = process.argv[index];
  if (key === '--help') {values.set(key, true); continue;}
  if (!key.startsWith('--') || !process.argv[index + 1] || process.argv[index + 1].startsWith('--')) throw new Error(`Expected --option value: ${key}`);
  values.set(key, process.argv[++index]);
}
if (values.has('--help')) {
  console.log('node scripts/neural-selfplay.mjs --init checkpoint.pt --model manifest.json [--run-dir artifacts/neural/selfplay] [--iterations 2] [--games 20] [--epochs 2] [--batch-size 128] [--lr 0.00001] [--threads 4] [--seed 731] [--python python] [--league league.json]');
  console.log('Re-run the same command to resume interrupted phases; --iterations is the TOTAL desired iteration count. Existing checkpoints are never deployed.');
  process.exit(0);
}
const allowed = new Set(['--init', '--model', '--run-dir', '--iterations', '--games', '--epochs', '--batch-size', '--lr', '--threads', '--seed', '--python', '--league']);
for (const key of values.keys()) if (!allowed.has(key)) throw new Error(`Unknown option: ${key}`);
const argument = (name, fallback) => values.get('--' + name) ?? fallback;
const positive = (name, fallback) => {
  const value = Number(argument(name, fallback));
  if (!Number.isSafeInteger(value) || value < 1) throw new Error(`--${name} must be a positive integer`);
  return value;
};
const runDirectory = path.resolve(ROOT, argument('run-dir', 'artifacts/neural/selfplay'));
if (runDirectory === ROOT || runDirectory.startsWith(path.join(ROOT, 'models') + path.sep) || runDirectory === path.join(ROOT, 'models') || runDirectory.startsWith(path.join(ROOT, 'dist') + path.sep)) {
  throw new Error('Use a dedicated artifacts training directory, not a production model/build directory');
}
const statePath = path.join(runDirectory, 'state.json');
const targetIterations = positive('iterations', 2);
await mkdir(runDirectory, {recursive: true});
const exists = value => access(value).then(() => true, () => false);
const json = async value => JSON.parse(await readFile(value, 'utf8'));
const hash = async value => createHash('sha256').update(await readFile(value)).digest('hex');
async function atomicJson(filename, value) {
  await writeFile(filename + '.tmp', JSON.stringify(value, null, 2));
  await rename(filename + '.tmp', filename);
}

// Stop two trainers from updating the same phase/checkpoints. Recover stale
// locks after a process crash without deleting any datasets or checkpoints.
const lockPath = path.join(runDirectory, 'selfplay.lock');
if (await exists(lockPath)) {
  const lock = await json(lockPath);
  let running = true;
  try {process.kill(lock.pid, 0);} catch (error) {if (error.code === 'ESRCH') running = false; else throw error;}
  if (running) throw new Error(`Self-play run is already owned by process ${lock.pid}`);
  await unlink(lockPath);
}
const lock = await open(lockPath, 'wx');
await lock.writeFile(JSON.stringify({pid: process.pid, startedAt: new Date().toISOString()}));
await lock.close();

let state;
async function run(command, args, logName) {
  const logPath = path.join(runDirectory, logName);
  await mkdir(path.dirname(logPath), {recursive: true});
  console.log(`[selfplay] ${logName}`);
  await new Promise((resolve, reject) => {
    const log = createWriteStream(logPath, {flags: 'a'});
    const child = spawn(command, args, {cwd: ROOT, windowsHide: true, shell: false, env: {...process.env, PYTHONUNBUFFERED: '1'}, stdio: ['ignore', 'pipe', 'pipe']});
    child.stdout.on('data', bytes => {log.write(bytes); process.stdout.write(bytes);});
    child.stderr.on('data', bytes => {log.write(bytes); process.stderr.write(bytes);});
    child.once('error', error => {log.end(); reject(error);});
    child.once('close', code => {log.end(); code === 0 ? resolve() : reject(new Error(`${logName} exited ${code}; resume with the same command after resolving the error`));});
  });
}
const pythonArgs = script => [path.join(ROOT, 'training/jaxlite', script)];
async function leagueCommand(args, logName) {
  await run(state.config.python, [...pythonArgs('league.py'), '--league', state.config.league, ...args], logName);
}
async function currentVerifiedArtifacts() {
  await leagueCommand(['verify'], 'league-verify.log');
  const league = await json(state.config.league);
  const current = league.checkpoints.find(entry => entry.path === state.current.checkpoint && entry.onnxManifest === state.current.manifest);
  if (!current) throw new Error('Current learner checkpoint/ONNX pair is not registered in the verified league');
  return {league, current};
}

try {
  if (await exists(statePath)) {
    state = await json(statePath);
    if (state.schemaVersion !== 1) throw new Error('Unsupported self-play resume state');
    const aliases = {games: 'games', epochs: 'epochs', 'batch-size': 'batchSize', lr: 'lr', threads: 'threads', seed: 'seed'};
    for (const [option, key] of Object.entries(aliases)) {
      if (values.has('--' + option) && Number(argument(option)) !== state.config[key]) throw new Error(`Cannot change --${option} for an existing on-policy run`);
    }
    for (const [option, key] of [['init', 'initialCheckpoint'], ['model', 'initialManifest'], ['league', 'league']]) {
      if (values.has('--' + option) && path.resolve(ROOT, argument(option)) !== state.config[key]) throw new Error(`Cannot change --${option} for an existing run`);
    }
    if (values.has('--python')) state.config.python = argument('python');
  } else {
    if (!argument('init') || !argument('model')) throw new Error('A new run requires --init checkpoint.pt and its matching --model manifest.json');
    const preferredPython = path.join(ROOT, '.tools/neural-python', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
    const config = {initialCheckpoint: path.resolve(ROOT, argument('init')), initialManifest: path.resolve(ROOT, argument('model')),
      league: path.resolve(ROOT, argument('league', path.join(runDirectory, 'league.json'))),
      python: argument('python', await exists(preferredPython) ? preferredPython : 'python'),
      games: positive('games', 20), epochs: positive('epochs', 2), batchSize: positive('batch-size', 128), threads: positive('threads', 4),
      seed: positive('seed', 731), lr: Number(argument('lr', 1e-5))};
    if (!Number.isFinite(config.lr) || config.lr <= 0) throw new Error('--lr must be positive');
    state = {schemaVersion: 1, config, createdAt: new Date().toISOString(), completedIterations: 0,
      current: {checkpoint: config.initialCheckpoint, manifest: config.initialManifest}, phase: 'initialize', history: []};
    await atomicJson(statePath, state);
  }
  if (state.phase === 'initialize') {
    await leagueCommand(['add', state.current.checkpoint, '--onnx-manifest', state.current.manifest, '--tag', 'initial'], 'league-initialize.log');
    state.phase = 'ready'; await atomicJson(statePath, state);
  }
  await currentVerifiedArtifacts();
  while (state.completedIterations < targetIterations) {
    const iteration = state.completedIterations + 1;
    const prefix = `iteration-${String(iteration).padStart(4, '0')}`;
    const directory = path.join(runDirectory, prefix);
    await mkdir(directory, {recursive: true});
    const rollouts = path.join(directory, 'rollouts.jsonl'), checkpoint = path.join(directory, 'checkpoint.pt'), manifest = path.join(directory, 'manifest.json');
    if (state.phase === 'ready') {
      const {league, current} = await currentVerifiedArtifacts();
      // The collector supplies 45% current-policy play itself. Exclude the
      // learner from historical entries to keep the other 55% historical.
      const opponents = league.checkpoints.filter(entry => entry.onnxSha256 !== current.onnxSha256);
      await atomicJson(path.join(directory, 'opponents.json'), {version: 2, checkpoints: opponents});
      state.iteration = {number: iteration, parent: {...state.current}, learnerOnnxSha256: current.onnxSha256,
        seed: state.config.seed + (iteration - 1) * 100003, historicalCheckpoints: opponents.map(entry => entry.onnxSha256)};
      state.phase = 'collect'; await atomicJson(statePath, state);
    }
    if (state.phase === 'collect') {
      await run(process.execPath, [path.join(ROOT, 'scripts/neural-rollouts.mjs'), '--model', state.current.manifest, '--games', String(state.config.games),
        '--seed', String(state.iteration.seed), '--opponent', 'self', '--league', path.join(directory, 'opponents.json'), '--output', rollouts], `${prefix}/collect.log`);
      const report = await json(rollouts + '.report.json');
      if (report.games !== state.config.games || report.rows < 10 || report.model.sha256 !== state.iteration.learnerOnnxSha256) throw new Error('Collector report does not match the current on-policy iteration');
      state.iteration.rolloutSha256 = await hash(rollouts); state.iteration.collection = report;
      state.phase = 'train'; await atomicJson(statePath, state);
    }
    if (state.phase === 'train') {
      if (await hash(rollouts) !== state.iteration.rolloutSha256) throw new Error('Recorded neural rollouts changed before PPO training');
      await run(state.config.python, [...pythonArgs('train_ppo.py'), rollouts, '--init', state.iteration.parent.checkpoint,
        '--epochs', String(state.config.epochs), '--batch-size', String(state.config.batchSize), '--lr', String(state.config.lr),
        '--threads', String(state.config.threads), '--seed', String(state.iteration.seed), '--output', checkpoint], `${prefix}/train.log`);
      state.iteration.checkpointSha256 = await hash(checkpoint);
      state.phase = 'export'; await atomicJson(statePath, state);
    }
    if (state.phase === 'export') {
      if (await hash(checkpoint) !== state.iteration.checkpointSha256) throw new Error('PPO checkpoint changed before ONNX export');
      await run(state.config.python, [...pythonArgs('export_onnx.py'), checkpoint, '--output', path.join(directory, 'checkpoint.onnx')], `${prefix}/export.log`);
      state.phase = 'register'; await atomicJson(statePath, state);
    }
    if (state.phase === 'register') {
      await leagueCommand(['add', checkpoint, '--onnx-manifest', manifest, '--parent', state.iteration.parent.checkpoint, '--tag', prefix], `${prefix}/league.log`);
      state.history.push({...state.iteration, checkpoint, manifest, completedAt: new Date().toISOString()});
      state.current = {checkpoint, manifest}; state.completedIterations = iteration; state.phase = 'ready'; delete state.iteration;
      await atomicJson(statePath, state);
      console.log(`[selfplay] Completed iteration ${iteration}; checkpoint retained for evaluation, not deployed.`);
    }
  }
  await currentVerifiedArtifacts();
  console.log(JSON.stringify({completedIterations: state.completedIterations, current: state.current, league: state.config.league, statePath, deployed: false}, null, 2));
} catch (error) {
  if (state) {state.lastError = {message: error.message, at: new Date().toISOString(), phase: state.phase}; await atomicJson(statePath, state);}
  throw error;
} finally {await unlink(lockPath);}
