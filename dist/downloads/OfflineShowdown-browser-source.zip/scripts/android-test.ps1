[CmdletBinding()]
param([string]$Serial='emulator-5554')
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$adb=Join-Path $root '.tools/android-sdk/platform-tools/adb.exe'
function Adb([string[]]$Arguments) {
    $result=& $adb -s $Serial @Arguments
    if($LASTEXITCODE -ne 0){throw "ADB failed: $Arguments"}
    return $result
}
Adb @('install','-r',(Join-Path $root 'artifacts/OfflineShowdown-debug.apk'))
Adb @('shell','cmd','connectivity','airplane-mode','enable')
Adb @('shell','svc','wifi','disable')
Adb @('shell','svc','data','disable')
$airplane=Adb @('shell','settings','get','global','airplane_mode_on')
if($airplane.Trim() -ne '1'){throw 'Airplane mode was not enabled.'}
$wifi=Adb @('shell','settings','get','global','wifi_on')
if($wifi.Trim() -ne '0'){throw 'Wi-Fi was not disabled.'}
Adb @('shell','am','force-stop','org.offlineshowdown.practice')
Adb @('shell','am','start','-n','org.offlineshowdown.practice/.MainActivity')
$appProcess=''
for($attempt=0;$attempt -lt 30;$attempt++) {
    $appProcess=(& $adb -s $Serial shell pidof org.offlineshowdown.practice | Out-String).Trim()
    if($appProcess){break}
    Start-Sleep -Milliseconds 200
}
if(!$appProcess){throw 'Native app did not start.'}
Adb @('forward','tcp:9223',"localabstract:webview_devtools_remote_$appProcess")
$nativeEvidence=@{testedAt=[DateTime]::UtcNow.ToString('o');serial=$Serial;airplaneMode=$airplane.Trim();wifiOn=$wifi.Trim();apkSha256=(Get-FileHash -LiteralPath (Join-Path $root 'artifacts/OfflineShowdown-debug.apk') -Algorithm SHA256).Hash;model=(Adb @('shell','getprop','ro.product.model')).Trim()}
$nativeEvidence | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'reports/android-environment.json')
& node (Join-Path $root 'scripts/showdown-browser-test.mjs') --android
if($LASTEXITCODE -ne 0){throw 'Android UI test failed.'}
