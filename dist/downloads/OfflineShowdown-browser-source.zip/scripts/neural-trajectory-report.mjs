import {createReadStream} from 'node:fs';
import {readdir,writeFile} from 'node:fs/promises';
import {createInterface} from 'node:readline';
import path from 'node:path';
import {OBSERVATION_VERSION,TOKEN_COUNT,CAT_FEATURES,NUM_FEATURES,ACTION_COUNT} from '../src/ai/neural/contract.js';

const input=process.argv[2];
if(!input)throw new Error('Usage: node scripts/neural-trajectory-report.mjs <file.jsonl|directory> [report.json]');
const files=input.endsWith('.jsonl')?[path.resolve(input)]:(await readdir(input)).filter(f=>f.endsWith('.jsonl')).sort().map(f=>path.resolve(input,f));
const games=new Set(),sides=new Map(),actions=Array(ACTION_COUNT).fill(0);
let rows=0,opponentLabels=0,terminals=0,invalid=0,illegalTargets=0,hiddenNumericFields=0;
for(const file of files){
  const lines=createInterface({input:createReadStream(file),crlfDelay:Infinity});
  for await(const line of lines){
    if(!line.trim())continue;
    const row=JSON.parse(line),obs=row.observation;rows++;
    games.add(row.gameId);const key=row.gameId+':'+row.side;
    sides.set(key,(sides.get(key)||0)+1);
    if(![1,2,3].includes(row.schema)||obs?.version!==OBSERVATION_VERSION||
      obs?.tokenKinds?.length!==TOKEN_COUNT||obs?.legalMask?.length!==ACTION_COUNT||
      obs?.categorical?.length!==TOKEN_COUNT||obs?.numeric?.length!==TOKEN_COUNT||
      obs.categorical.some(r=>r.length!==CAT_FEATURES)||obs.numeric.some(r=>r.length!==NUM_FEATURES))invalid++;
    if(!Number.isInteger(row.action)||!obs?.legalMask?.[row.action])illegalTargets++;
    else actions[row.action]++;
    // Exact opponent stats and private move-slot fields must stay zero in v2.
    if(obs?.numeric?.slice(7,13).some(r=>r.slice(16).some(Boolean))||
      obs?.categorical?.slice(7,13).some(r=>r.slice(8).some(Boolean)))hiddenNumericFields++;
    if(row.opponentAction>=0)opponentLabels++;
    if(row.done)terminals++;
  }
}
const report={testedAt:new Date().toISOString(),files,observationVersion:OBSERVATION_VERSION,rows,games:games.size,
  trajectories:sides.size,averageDecisionsPerSide:rows/Math.max(1,sides.size),actions,
  opponentActionLabels:opponentLabels,opponentLabelRate:opponentLabels/Math.max(1,rows),
  terminalRows:terminals,invalidRows:invalid,illegalTargets,hiddenNumericFields};
console.log(JSON.stringify(report,null,2));
if(process.argv[3])await writeFile(process.argv[3],JSON.stringify(report,null,2));
if(!rows||invalid||illegalTargets||hiddenNumericFields||terminals!==sides.size)process.exitCode=1;
