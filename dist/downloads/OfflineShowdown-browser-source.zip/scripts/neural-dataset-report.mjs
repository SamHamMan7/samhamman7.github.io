import {readFile} from 'node:fs/promises';
import path from 'node:path';

const input = process.argv[2];
if (!input) throw new Error('Usage: node scripts/neural-dataset-report.mjs <dataset.jsonl>');
const text = await readFile(path.resolve(input), 'utf8');
const rows = text.split(/\r?\n/).filter(Boolean).map((line, i) => {
  try { return JSON.parse(line); }
  catch (error) { throw new Error(`Invalid JSON on line ${i + 1}: ${error.message}`); }
});

const report = {
  rows: rows.length,
  games: new Set(),
  actions: Array(14).fill(0),
  outcomes: {'-1': 0, '0': 0, '1': 0, null: 0},
  opponentLabels: 0,
  illegalTargets: 0,
  badSchema: 0,
  meanLegalActions: 0,
};
let legalTotal = 0;
for (const row of rows) {
  if (row.schema !== 1 || row.observation?.version !== 1) report.badSchema++;
  if (row.gameId != null) report.games.add(row.gameId);
  if (Number.isInteger(row.action) && row.action >= 0 && row.action < 14) report.actions[row.action]++;
  const mask = row.observation?.legalMask || [];
  legalTotal += mask.reduce((sum, value) => sum + Number(Boolean(value)), 0);
  if (!mask[row.action]) report.illegalTargets++;
  if (Number.isInteger(row.opponentAction) && row.opponentAction >= 0) report.opponentLabels++;
  const key = row.outcome == null ? 'null' : String(row.outcome);
  report.outcomes[key] = (report.outcomes[key] || 0) + 1;
}
report.meanLegalActions = rows.length ? Math.round(legalTotal / rows.length * 100) / 100 : 0;
report.games = report.games.size;
report.opponentLabelCoverage = rows.length ? Math.round(report.opponentLabels / rows.length * 10000) / 100 : 0;
console.log(JSON.stringify(report, null, 2));
if (report.badSchema || report.illegalTargets) process.exitCode = 1;
