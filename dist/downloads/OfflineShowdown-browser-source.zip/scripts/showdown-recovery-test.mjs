import {chromium} from 'playwright';
import fs from 'node:fs';
const browser=await chromium.launch({channel:'chrome',headless:true});
const page=await browser.newPage({viewport:{width:412,height:915},serviceWorkers:'block'});
await page.addInitScript(()=>{
  const NativeWorker=window.Worker;
  window.testWorkers=[];
  window.Worker=class extends NativeWorker {
    constructor(url,options){super(url,options);this.source=String(url);window.testWorkers.push(this);}
  };
});
const results=[];
try {
  for(const target of ['engine.worker','ai.worker']) {
    await page.goto('http://127.0.0.1:4173/');
    await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
    await page.locator('button[name=search]').click();
    await page.waitForFunction(()=>offlinePractice.snapshot().turn>=1);
    await page.evaluate(target=>{
      const worker=testWorkers.filter(w=>w.source.includes(target)).at(-1);
      worker.dispatchEvent(new ErrorEvent('error',{message:'Injected recovery test'}));
    },target);
    await page.waitForFunction(()=>offlinePractice.snapshot().aborted);
    await page.locator('.ps-popup button[name=close]').click();
    await page.evaluate(()=>app.focusRoom(''));
    await page.locator('button[name=search]').click();
    await page.waitForFunction(()=>offlinePractice.snapshot().turn>=1&&!offlinePractice.snapshot().aborted);
    const state=await page.evaluate(()=>offlinePractice.snapshot());
    if(state.error)throw new Error(state.error);
    results.push({target,restarted:true,turn:state.turn});
  }
  fs.writeFileSync('reports/showdown-recovery.json',JSON.stringify({testedAt:new Date().toISOString(),results},null,2));
  console.log(results);
} finally {await browser.close();}
