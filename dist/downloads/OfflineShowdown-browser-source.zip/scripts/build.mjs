import {build} from 'esbuild';
import {mkdir, cp, readFile, writeFile, readdir, rm, stat} from 'node:fs/promises';
import path from 'node:path';
import {installShowdown} from './showdown-distribution.mjs';
import {validateBeliefManifest} from '../src/ai/neural/belief-model.js';
import {validateOnnxManifest} from '../src/ai/neural/onnx-common.js';
const output=path.resolve('dist');
if(output!==path.join(process.cwd(),'dist')) throw new Error('Unexpected output path');
await rm(output,{recursive:true,force:true});
await mkdir('dist', {recursive:true});
await build({entryPoints:{main:'src/showdown-main.js','engine.worker':'src/engine.worker.js','ai.worker':'src/ai.worker.js'},bundle:true,outdir:'dist',format:'esm',platform:'browser',conditions:['onnxruntime-web-use-extern-wasm'],target:'chrome120',minify:true,sourcemap:false,metafile:true,logLevel:'info',external:['/sprites/*'],define:{global:'globalThis'}}).then(async r => {
  await mkdir('artifacts', {recursive:true});
  await writeFile('artifacts/build-meta.json',JSON.stringify(r.metafile,null,2));
});
await cp('public/THIRD_PARTY_NOTICES.txt','dist/THIRD_PARTY_NOTICES.txt');
await installShowdown('dist');
await mkdir('dist/ort',{recursive:true});
for(const file of ['ort-wasm-simd-threaded.mjs','ort-wasm-simd-threaded.wasm'])await cp('node_modules/onnxruntime-web/dist/'+file,'dist/ort/'+file);
try {
  const manifest=validateOnnxManifest(JSON.parse(await readFile('models/gen9randombattle/manifest.json','utf8')));
  if(!/^[A-Za-z0-9_.-]+\.onnx$/.test(manifest.model)||manifest.trained!==true)throw new Error('Invalid trained model manifest');
  await mkdir('dist/models/gen9randombattle',{recursive:true});
  await cp('models/gen9randombattle/'+manifest.model,'dist/models/gen9randombattle/'+manifest.model);
  await cp('models/gen9randombattle/manifest.json','dist/models/gen9randombattle/manifest.json');
  if(manifest.beliefs){
    const beliefs=validateBeliefManifest(JSON.parse(await readFile('models/gen9randombattle/'+manifest.beliefs,'utf8')));
    await cp('models/gen9randombattle/'+manifest.beliefs,'dist/models/gen9randombattle/'+manifest.beliefs);
    await cp('models/gen9randombattle/'+beliefs.model,'dist/models/gen9randombattle/'+beliefs.model);
  }
}catch(error){if(error.code!=='ENOENT')throw error;}

async function walk(dir) {
  const entries=await readdir(dir,{withFileTypes:true});
  return (await Promise.all(entries.map(e=>e.isDirectory()?walk(path.join(dir,e.name)):path.join(dir,e.name)))).flat();
}

const files=(await walk('dist'))
  .map(p=>'/'+p.replaceAll('\\','/').slice(5))
  .filter(p=>p!='/sw.js');

// This small set covers effects, weather/Tera overlays and common backgrounds.
// Pokémon sprites are selected through the upstream Dex when a team is revealed.
const battleImages=files.filter(file=>/\.(png|jpe?g|gif)$/.test(file)&&(
  /^\/(fx|sprites\/gen6bgs|sprites\/types)\//.test(file)||
  /\/substitute\.(gif|png)$/.test(file)||
  /^\/sprites\/gen5\/tatsugiri(?:-droopy|-stretchy)?\.png$/.test(file)
));
await writeFile('dist/battle-assets.json',JSON.stringify({images:battleImages}));
files.push('/battle-assets.json');

// Keep install fast: do not eagerly cache the huge sprites/audio/fx archives.
// They are already bundled locally and are runtime-cached the first time they are used.
const coreFiles=files.filter(file=>{
  if(file.endsWith('.map')) return false;
  if(['/index.html','/main.js','/engine.worker.js','/ai.worker.js','/battle-assets.json','/favicon.ico','/favicon-256.png','/pokemonshowdownbeta.png','/pokemonshowdownbeta@2x.png','/sprites/pokemonicons-sheet.png','/sprites/itemicons-sheet.png'].includes(file)) return true;
  return /^\/(?:style|config|data|js|fonts)\//.test(file)||file.startsWith('/fx/client-');
});

const version='offline-'+Date.now();
await writeFile('dist/sw.js',`const CACHE=${JSON.stringify(version)};
const CORE=${JSON.stringify(coreFiles)};
async function addBatches(cache,urls) {
  for(let i=0;i<urls.length;i+=24) await cache.addAll(urls.slice(i,i+24));
}
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>addBatches(cache,CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys()
    .then(keys=>Promise.all(keys.filter(key=>key.startsWith('offline-')&&key!==CACHE).map(key=>caches.delete(key))))
    .then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin) {
    event.respondWith(new Response('External network disabled',{status:403}));
    return;
  }
  if(event.request.method!=='GET') return;
  event.respondWith((async()=>{
    const cached=await caches.match(event.request,{ignoreSearch:true});
    if(cached) return cached;
    try {
      const response=await fetch(event.request);
      if(response.ok) {
        const clone=response.clone();
        event.waitUntil(caches.open(CACHE).then(cache=>cache.put(event.request,clone)).catch(()=>{}));
      }
      return response;
    } catch {
      if(event.request.mode==='navigate') {
        const fallback=await caches.match('/index.html');
        if(fallback) return fallback;
      }
      return new Response('Offline asset not cached',{status:504});
    }
  })());
});`);

const pkg=JSON.parse(await readFile('package-lock.json','utf8'));
const versions=Object.fromEntries(['@pkmn/sim','@pkmn/randoms','@smogon/calc'].map(name=>[name,pkg.packages['node_modules/'+name].version]));
await writeFile('dist/build-info.json',JSON.stringify({
  built:new Date().toISOString(),
  versions,
  formats:['gen9ou','gen9randombattle','gen9randomdoublesbattle'],
  cache:{coreFiles:coreFiles.length,coreBytes:(await Promise.all(coreFiles.map(file=>stat('dist'+file)))).reduce((sum,s)=>sum+s.size,0),totalFiles:files.length,strategy:'core-precache + runtime battle assets'},
},null,2));
