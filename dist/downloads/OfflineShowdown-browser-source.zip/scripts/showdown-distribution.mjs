import {cp,readFile,writeFile,readdir,mkdir,access} from 'node:fs/promises';
import path from 'node:path';
const site='vendor/pokemon-showdown-client/play.pokemonshowdown.com';
export async function installShowdown(output) {
  for(const dir of ['js','style','data','fonts']) {
    try { await cp(`${site}/${dir}`,`${output}/${dir}`,{recursive:true}); }
    catch(e) { if(dir!=='fonts'||e.code!=='ENOENT') throw e; }
  }
  for(const name of ['pokemonshowdownbeta.png','pokemonshowdownbeta@2x.png','favicon.ico','favicon-256.png']) await cp(`${site}/${name}`,`${output}/${name}`);
  await cp('vendor/showdown-assets',output,{recursive:true});
  await cp('vendor/LICENSE.pokemon-showdown-client',`${output}/LICENSE`);
  await cp('vendor/LICENSE.fontawesome-font',`${output}/LICENSE.fontawesome-font`);
  await cp('vendor/showdown-client-manifest.json',`${output}/showdown-client-manifest.json`);
  const fallbacks={};
  for(const file of JSON.parse(await readFile('vendor/showdown-unavailable-assets.json','utf8'))) {
    if(file.startsWith('audio/')) {fallbacks['/'+file]='';continue;}
    const staticPath=file.replace('/ani','/gen5').replace(/\.gif$/,'.png');
    if(await access(`${output}/${staticPath}`).then(()=>true,()=>false)) fallbacks['/'+file]='/'+staticPath;
  }
  await writeFile(`${output}/data/offline-resource-fallbacks.js`,'window.OfflineResourceFallbacks='+JSON.stringify(fallbacks)+';');
  await mkdir(`${output}/config`,{recursive:true});
  await writeFile(`${output}/config/colors.json`,'{}');
  await writeFile(`${output}/config/coil.json`,'{}');
  const english=await readFile(`${output}/data/text/en.js`,'utf8');
  await writeFile(`${output}/data/text/en.js`,'(function(exports){\n'+english+'\n})(window);');
  await writeFile(`${output}/config/config.js`,`var Config={testclient:true,version:'offline',bannedHosts:[],whitelist:[],customcolors:{},routes:{client:location.host,dex:'dex.pokemonshowdown.com',replays:'replay.pokemonshowdown.com',users:'pokemonshowdown.com/users'},defaultserver:{id:'offline',host:location.hostname,port:443,registered:false},roomsFirstOpenScript:function(){}}; Config.server=Config.defaultserver;`);
  // Small, reproducible distribution patches. Keep the upstream checkout untouched.
  // Assets in older modules use both literal URLs and Config.routes.client concatenation.
  async function localize(dir) {
    for(const entry of await readdir(dir,{withFileTypes:true})) {
      const file=path.join(dir,entry.name);
      if(entry.isDirectory()) await localize(file);
      else if(/\.(js|css)$/.test(file)) {
        let text=await readFile(file,'utf8');
        text=text.replace(/(?:https?:)?\/\/play\.pokemonshowdown\.com\//g,'/');
        text=text.replace(/https:\/\/\$\{Config\.routes\.client\}\//g,'/');
        text=text.replace(/https:\/\/['"]\s*\+\s*Config\.routes\.client\s*\+\s*['"]\//g,'/');
        text=text.replace(/(['"])https:\/\/\1\s*\+\s*Config\.routes\.client\s*\+\s*(['"])\//g,'$2/');
        text=text.replace(/Net\.defaultRoute\s*=\s*[^;]+;/g,"Net.defaultRoute = '';");
        if(file.endsWith('battle-sound.js')) {
          // Switching rooms can pause an HTMLAudioElement before play resolves.
          // Handle browser cancellation/autoplay rejection, not a battle failure.
          text=text.replace(/(this\.sound|effect)\.play\(\);/g,"$1.play().catch(function(e){if(e.name!=='AbortError'&&e.name!=='NotAllowedError')throw e;});");
        }
        if(file.endsWith(path.join('oldclient','storage.js'))) {
          const needle='return this.initTestClient();';
          if(!text.includes(needle)) throw new Error('Upstream storage integration point changed');
          text=text.replace(needle,'Config.server = Config.server || Config.defaultserver; this.whenPrefsLoaded.load(); this.whenTeamsLoaded.load(); return;');
        }
        await writeFile(file,text);
      }
    }
  }
  await localize(`${output}/js`); await localize(`${output}/style`);
  let html=await readFile(`${site}/index-old.html`,'utf8');
  html=html.replace(/(?:https?:)?\/\/play\.pokemonshowdown\.com\//g,'/');
  html=html.replace(/<script>\s*\/\/ framebust[\s\S]*?<\/script>/,'<script type="module" src="/main.js"></script>');
  html=html.replace(/<script[^>]*clean-cookies[^>]*><\/script>/,'');
  html=html.replace('<script src="/data/graphics.js?"></script>','<script src="/js/battle-animations.js"></script><script src="/js/battle-animations-moves.js"></script>');
  html=html.replace('<script type="module" src="/main.js"></script>','<script src="/data/offline-resource-fallbacks.js"></script><script type="module" src="/main.js"></script>');
  html=html.replace('<title>Showdown!</title>','<title>Pokémon Showdown — Offline Practice</title>');
  html=html.replace('<meta charset="UTF-8" />',`<meta charset="UTF-8" /><meta http-equiv="Content-Security-Policy" content="default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'none'; object-src 'none'" />`);
  html=html.replace('<link rel="manifest" href="/manifest.json" />','');
  html=html.replace('<script src="/js/battledata.js?">','<script src="/data/text/en.js"></script>\n<script src="/js/battledata.js?">');
  await writeFile(`${output}/index.html`,html);
}
