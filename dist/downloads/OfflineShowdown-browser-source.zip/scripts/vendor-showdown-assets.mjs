/** Download official Showdown artwork/audio once; extract the Gen 9 offline subset.
 * No runtime fetching. Requires Node >=20 and this project's pinned @pkmn/sim.
 * Upstream archives have mutable URLs, so exact archive bytes are hash pinned.
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import { inflateRawSync } from 'node:zlib';
import { Dex } from '@pkmn/sim';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'vendor/showdown-assets');
const cache = path.join(root, '.tools/downloads');
const clientRoot = path.join(root, 'vendor/pokemon-showdown-client');
const archives = [
  { name: 'sprites', url: 'https://pokemonshowdown.com/files/resources/sprites.zip',
    sha256: '35caf5f07d890522b68f7fee4ced843f38a734bea275ae93f3c1cdfb68dc7218', bytes: 890019523 },
  { name: 'audio', url: 'https://pokemonshowdown.com/files/resources/audio.zip',
    sha256: '3a9cc4cfd42e48eeeb1d0941c0cbf42ab7e6ba38a5fd66990659966192911e5d', bytes: 240491511 },
];
const spriteDirs = new Set([
  'ani', 'ani-back', 'ani-shiny', 'ani-back-shiny',
  'gen5ani', 'gen5ani-back', 'gen5ani-shiny', 'gen5ani-back-shiny',
  'gen5', 'gen5-back', 'gen5-shiny', 'gen5-back-shiny',
  'dex', 'dex-shiny', 'home-centered', 'home-centered-shiny',
  'categories', 'types', 'typeicons', 'misc', 'trainers', 'substitutes', 'gen6bgs',
]);
// Current Gen 9 mechanics are authoritative for the expensive animation subset.
// Keep every cosmetic forme and gender sprite. Small static sets remain complete
// so the official teambuilder can preview an entry before rejecting an illegal set.
const legalSpecies = Dex.forGen(9).species.all().filter(s => !s.isNonstandard && s.gen <= 9);
const animationNames = new Set(['0', 'substitute', 'egg', 'unknown']);
for (const species of legalSpecies) {
  for (const name of [species.name, ...(species.cosmeticFormes || [])]) {
    const resolved = Dex.species.get(name);
    animationNames.add(resolved.spriteid);
    animationNames.add(resolved.spriteid + '-f');
  }
}
function include(name) {
  if (name.endsWith('/')) return false;
  const [kind, directory, basename, ...extra] = name.split('/');
  if (extra.length) return false;
  if (kind === 'audio') return /\.mp3$/i.test(name) && (!basename || directory === 'cries');
  if (kind !== 'sprites') return false;
  if (!basename) return /\.png$/i.test(directory);
  if (!spriteDirs.has(directory) || !/\.(png|gif|jpg|jpeg|webp)$/i.test(basename)) return false;
  if (/^(ani|gen5ani)(-|$)/.test(directory)) return animationNames.has(basename.replace(/\.[^.]+$/, ''));
  return true;
}
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
async function fileHash(filename) {
  const hash = createHash('sha256');
  for await (const chunk of fs.createReadStream(filename)) hash.update(chunk);
  return hash.digest('hex');
}
async function acquire(archive) {
  const filename = path.join(cache, `showdown-${archive.name}.zip`);
  if (!fs.existsSync(filename)) {
    console.log(`Downloading official ${archive.name} archive (${(archive.bytes / 1048576).toFixed(1)} MiB)...`);
    const response = await fetch(archive.url);
    if (!response.ok) throw new Error(`Download ${archive.url}: HTTP ${response.status}`);
    const partial = filename + '.partial';
    await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(partial));
    await fsp.rename(partial, filename);
  }
  const actualHash = await fileHash(filename);
  if (actualHash !== archive.sha256) throw new Error(
    `${archive.name} archive SHA-256 changed: ${actualHash}. Keep the previous pinned archive or explicitly review and update the source pin; do not silently use new bytes.`);
  return filename;
}
async function readAt(handle, length, position) {
  const data = Buffer.alloc(length);
  const { bytesRead } = await handle.read(data, 0, length, position);
  if (bytesRead !== length) throw new Error('Truncated ZIP archive');
  return data;
}
// ZIP/ZIP64 central directory reader using only Node built-ins. Each selected
// entry is independently decompressed; the full archive never occupies memory.
async function entries(handle, size) {
  const tailLength = Math.min(size, 65557);
  const tail = await readAt(handle, tailLength, size - tailLength);
  let eocd = tail.length - 22;
  while (eocd >= 0 && tail.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('ZIP end record missing');
  let count = tail.readUInt16LE(eocd + 10);
  let cdSize = tail.readUInt32LE(eocd + 12);
  let cdOffset = tail.readUInt32LE(eocd + 16);
  if (count === 65535 || cdSize === 0xffffffff || cdOffset === 0xffffffff) {
    const locator = await readAt(handle, 20, size - tailLength + eocd - 20);
    if (locator.readUInt32LE(0) !== 0x07064b50) throw new Error('ZIP64 locator missing');
    const zip64 = await readAt(handle, 56, Number(locator.readBigUInt64LE(8)));
    count = Number(zip64.readBigUInt64LE(32));
    cdSize = Number(zip64.readBigUInt64LE(40));
    cdOffset = Number(zip64.readBigUInt64LE(48));
  }
  const directory = await readAt(handle, cdSize, cdOffset);
  const result = [];
  let cursor = 0;
  for (let index = 0; index < count; index++) {
    if (directory.readUInt32LE(cursor) !== 0x02014b50) throw new Error('Malformed ZIP central directory');
    const nameLength = directory.readUInt16LE(cursor + 28);
    const extraLength = directory.readUInt16LE(cursor + 30);
    const commentLength = directory.readUInt16LE(cursor + 32);
    const name = directory.toString('utf8', cursor + 46, cursor + 46 + nameLength);
    const compressed = directory.readUInt32LE(cursor + 20);
    const uncompressed = directory.readUInt32LE(cursor + 24);
    const offset = directory.readUInt32LE(cursor + 42);
    if ([compressed, uncompressed, offset].includes(0xffffffff)) throw new Error(`Unsupported >4GB ZIP entry: ${name}`);
    result.push({ name, compressed, uncompressed, offset, method: directory.readUInt16LE(cursor + 10) });
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  return result;
}
const files = [];
async function storeAsset(originalName, bytes, source) {
  // Windows cannot represent ?. Use a stable portable name and expose the mapping.
  const name = originalName === 'sprites/types/???.png' ? 'sprites/types/unknown.png' : originalName;
  const destination = path.resolve(output, name);
  if (!destination.startsWith(output + path.sep) || /[\\]|(^|\/)\.\.?($|\/)/.test(name)) throw new Error(`Unsafe asset path: ${name}`);
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  await fsp.writeFile(destination, bytes);
  files.push({ path: name, ...(name !== originalName ? { upstreamPath: originalName } : {}), bytes: bytes.length, sha256: sha(bytes), source });
}
async function extract(filename, archive) {
  const handle = await fsp.open(filename, 'r');
  try {
    const list = await entries(handle, (await handle.stat()).size);
    const selected = list.filter(entry => include(entry.name));
    console.log(`Extracting ${selected.length} official ${archive.name} files...`);
    let count = 0;
    for (const entry of selected) {
      const localHeader = await readAt(handle, 30, entry.offset);
      if (localHeader.readUInt32LE(0) !== 0x04034b50) throw new Error(`Invalid ZIP local header: ${entry.name}`);
      const dataOffset = entry.offset + 30 + localHeader.readUInt16LE(26) + localHeader.readUInt16LE(28);
      const compressed = await readAt(handle, entry.compressed, dataOffset);
      const bytes = entry.method === 0 ? compressed : entry.method === 8 ? inflateRawSync(compressed) : null;
      if (!bytes || bytes.length !== entry.uncompressed) throw new Error(`Invalid ZIP data: ${entry.name}`);
      await storeAsset(entry.name, bytes, archive.url);
      if (++count % 3000 === 0) console.log(`  ${count}/${selected.length} extracted`);
    }
  } finally { await handle.close(); }
}
async function copyFx(directory, prefix = 'fx') {
  for (const entry of await fsp.readdir(directory, { withFileTypes: true })) {
    if (entry.isDirectory()) await copyFx(path.join(directory, entry.name), `${prefix}/${entry.name}`);
    else if (/\.(png|gif|jpg|jpeg|webp|svg)$/i.test(entry.name)) {
      await storeAsset(`${prefix}/${entry.name}`, await fsp.readFile(path.join(directory, entry.name)), 'pokemon-showdown-client/play.pokemonshowdown.com/fx');
    }
  }
}
await fsp.mkdir(cache, { recursive: true });
await fsp.mkdir(output, { recursive: true });
for (const archive of archives) await extract(await acquire(archive), archive);
await copyFx(path.join(clientRoot, 'play.pokemonshowdown.com/fx'));
files.sort((a, b) => a.path.localeCompare(b.path));
const totalBytes = files.reduce((total, file) => total + file.bytes, 0);
const groups = {};
for (const file of files) {
  const group = file.path.startsWith('sprites/') ? file.path.split('/').slice(0, 2).join('/') : file.path.split('/')[0];
  groups[group] ??= { files: 0, bytes: 0 };
  groups[group].files++;
  groups[group].bytes += file.bytes;
}
const manifest = {
  schemaVersion: 1, generatedAt: new Date().toISOString(), scope: 'Gen9 OU, Random Battle, Random Doubles',
  sourceArchives: archives, legalSpecies: legalSpecies.length, animationNames: animationNames.size,
  totalFiles: files.length, totalBytes, groups,
  pathMappings: { 'sprites/types/%3f%3f%3f.png': 'sprites/types/unknown.png' },
  credits: 'https://pokemonshowdown.com/credits',
  licensing: 'Client code is AGPLv3; battle replay engine has MIT notices. FX have upstream per-file licensing; sprites and audio are not relicensed by the client code license. Preserve upstream attribution.',
  files,
};
await fsp.writeFile(path.join(output, 'asset-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
await fsp.copyFile(path.join(clientRoot, 'LICENSE'), path.join(output, 'SHOWDOWN-CLIENT-LICENSE.txt'));
const animations = await fsp.readFile(path.join(clientRoot, 'play.pokemonshowdown.com/src/battle-animations.ts'), 'utf8');
await fsp.writeFile(path.join(output, 'ASSET-NOTICES.txt'),
  `Official Pokémon Showdown offline resource subset.\nSource: https://pokemonshowdown.com/credits\nSprites: https://play.pokemonshowdown.com/sprites/\nAudio: https://play.pokemonshowdown.com/audio/\n\nThe code license does not license Pokémon sprites or audio. Pokémon and related artwork/audio remain the property of their respective owners. This project is unaffiliated with Nintendo, Game Freak, The Pokémon Company, or Pokémon Showdown.\n\nUpstream battle-animations.ts licensing notices (verbatim):\n${animations.slice(0, animations.indexOf('export class'))}\n`);
console.log(`Official assets ready: ${files.length} files, ${(totalBytes / 1048576).toFixed(1)} MiB at ${output}`);
