import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
const files=JSON.parse(await fs.readFile('vendor/showdown-supplement-requests.json','utf8'));
const records=[];
const old=JSON.parse(await fs.readFile('vendor/showdown-supplements.json','utf8').catch(()=>'[]'));
const unavailable=[];
async function acquire(file){
  const url='https://play.pokemonshowdown.com/'+file, previous=old.find(r=>r.file===file);
  let b=await fs.readFile('vendor/showdown-assets/'+file).catch(()=>null);
  if(!b){const r=await fetch(url);if(r.status===404){unavailable.push(file);return;}if(!r.ok)throw new Error(url+' '+r.status);b=Buffer.from(await r.arrayBuffer());}
  const sha256=crypto.createHash('sha256').update(b).digest('hex');
  if(previous&&previous.sha256!==sha256)throw new Error('Supplement checksum mismatch: '+file);
  await fs.mkdir(path.dirname('vendor/showdown-assets/'+file),{recursive:true});
  await fs.writeFile('vendor/showdown-assets/'+file,b);
  records.push({file,url,sha256,bytes:b.length});
}
for(let i=0;i<files.length;i+=6)await Promise.all(files.slice(i,i+6).map(acquire));
records.sort((a,b)=>a.file.localeCompare(b.file));
await fs.writeFile('vendor/showdown-supplements.json',JSON.stringify(records,null,2));
await fs.writeFile('vendor/showdown-unavailable-assets.json',JSON.stringify(unavailable,null,2));
console.log({supplements:records.length,unavailable});
