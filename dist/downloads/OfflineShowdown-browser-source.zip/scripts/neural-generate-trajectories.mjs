import {mkdir, writeFile, open, rename, readFile} from 'node:fs/promises';
import path from 'node:path';

import {BattleSession} from '../src/core/session.js';
import {chooseAction, legalActions} from '../src/ai/policy.js';
import {actionIndexFromChoice} from '../src/ai/neural/action-space.js';
import {encodeObservation} from '../src/ai/neural/observation.js';

function arg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 && process.argv[index + 1] !== undefined ? process.argv[index + 1] : fallback;
}

const games = Math.max(1, Number(arg('games', '50')) || 50);
const baseSeed = Number(arg('seed', '424242')) || 424242;
const difficulty = String(arg('difficulty', 'Very Strong'));
const startGame = Number(arg('start-game','0'));
const output = path.resolve(arg('output', `artifacts/neural/trajectories-${difficulty.toLowerCase().replaceAll(' ', '-')}-${games}.jsonl`));

function seedFor(game) {
  let x = (baseSeed + Math.imul(game + 1, 0x9e3779b1)) >>> 0;
  const next = () => {
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    return (x >>> 0) & 0xffff;
  };
  return [next(), next(), next(), next()];
}

function ordinaryTurn(view) {
  if (view?.request?.teamPreview) return false;
  if (view?.request?.forceSwitch?.some(Boolean)) return false;
  if (view?.request?.active?.some(slot => slot?.reviving)) return false;
  return true;
}

async function runGame(gameIndex) {
  const gameId = `rb2-${baseSeed}-${gameIndex}`;
  const decisions = [];
  let winner = 'tie';
  let session;
  let settled = false;
  let sequence = 0;
  let timeout;

  const finished = new Promise((resolve, reject) => {
    timeout = setTimeout(() => reject(new Error(`Battle ${gameId} exceeded 60 seconds.`)), 60_000);
    const done = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve(result);
    };

    session = new BattleSession({
      onUpdate({view, lines}) {
        for (const line of lines || []) {
          if (line.startsWith('|win|')) {
            const name = line.slice(5);
            winner = name === 'You' ? 'p1' : name === 'Offline AI' ? 'p2' : 'tie';
            done(winner);
          } else if (line === '|tie|') {
            winner = 'tie';
            done(winner);
          }
        }
        if (view?.ended && !settled) setTimeout(() => done(winner), 0);
      },
      onRequest({side, token, view}) {
        void (async () => {
          const actions = legalActions(view);
          const decisionSeed = baseSeed + gameIndex * 1009 + (view.turn || 0) * 37 + (side === 'p1' ? 1 : 2);
          const result = chooseAction(view, {difficulty, seed: decisionSeed});
          if (!result?.choice) throw new Error(`${gameId} ${side} returned no action on turn ${view.turn}.`);

          const action = actionIndexFromChoice(result.choice);
          if (action >= 0 && !view?.request?.teamPreview) {
            decisions.push({
              schema: 2,
              gameId,
              side,
              sequence: sequence++,
              turn: Number(view.turn) || 0,
              ordinary: ordinaryTurn(view),
              observation: encodeObservation(view, actions),
              action,
              opponentAction: -1,
              reward: 0,
              done: false,
              return: null,
              nextObservation: null,
              teacher: {
                difficulty,
                choice: result.choice,
              },
            });
          }
          const accepted = await session.choose(side, token, result.choice);
          if (!accepted) throw new Error(`${gameId} rejected a freshly issued token for ${side}.`);
        })().catch(reject);
      },
      onError(error) { reject(error); },
    });
  });

  try {
    await session.start({format: 'gen9randombattle', seed: seedFor(gameIndex)});
    await finished;
  } finally {clearTimeout(timeout);await session.close();}

  // Pair simultaneous strategic choices by turn. Forced replacement actions are
  // intentionally excluded from opponent-response labels.
  const ordinaryByTurn = new Map();
  for (const row of decisions) {
    if (!row.ordinary) continue;
    const pair = ordinaryByTurn.get(row.turn) || {p1: [], p2: []};
    pair[row.side].push(row);
    ordinaryByTurn.set(row.turn, pair);
  }
  for (const pair of ordinaryByTurn.values()) {
    const count = Math.min(pair.p1.length, pair.p2.length);
    for (let i = 0; i < count; i++) {
      pair.p1[i].opponentAction = pair.p2[i].action;
      pair.p2[i].opponentAction = pair.p1[i].action;
    }
  }

  for (const side of ['p1', 'p2']) {
    const trajectory = decisions.filter(row => row.side === side).sort((a, b) => a.sequence - b.sequence);
    const outcome = winner === 'tie' ? 0 : winner === side ? 1 : -1;
    for (let i = 0; i < trajectory.length; i++) {
      const row = trajectory[i];
      row.return = outcome;
      row.nextObservation = trajectory[i + 1]?.observation || null;
      row.done = i === trajectory.length - 1;
      row.reward = row.done ? outcome : 0;
    }
  }

  return {rows: decisions.sort((a, b) => a.sequence - b.sequence), winner};
}

await mkdir(path.dirname(output), {recursive: true});
let progress={baseSeed,difficulty,startGame,completed:0,rows:0,bytes:0,wins:{p1:0,p2:0,tie:0}};
if(process.argv.includes('--resume')) {
  try{progress=JSON.parse(await readFile(output+'.progress.json','utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
  if(progress.baseSeed!==baseSeed||progress.startGame!==startGame||progress.difficulty!==difficulty)throw new Error('Resume settings changed');
}
const handle=await open(output,progress.completed?'r+':'w');
try {
  await handle.truncate(progress.bytes);
  for (let game=progress.completed;game<games;game++) {
    const result=await runGame(startGame+game);
    const bytes=Buffer.from(result.rows.map(row=>JSON.stringify(row)).join('\n')+'\n');
    let written=0;
    while(written<bytes.length) {
      const result=await handle.write(bytes,written,bytes.length-written,progress.bytes+written);
      if(!result.bytesWritten)throw new Error('Trajectory write made no progress');
      written+=result.bytesWritten;
    }
    await handle.sync();
    progress.completed++;progress.rows+=result.rows.length;progress.bytes+=bytes.length;
    progress.wins[result.winner]++;
    await writeFile(output+'.progress.tmp',JSON.stringify(progress,null,2));
    await rename(output+'.progress.tmp',output+'.progress.json');
    if((game+1)%10===0||game+1===games)console.log(`games=${game+1}/${games} rows=${progress.rows} wins=${JSON.stringify(progress.wins)}`);
  }
}finally{await handle.close();}
console.log(`saved ${progress.rows} trajectory rows to ${output}`);
