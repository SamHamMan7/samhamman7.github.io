/**
 * Prepare a pinned, unmodified official Pokémon Showdown client plus a hash-locked
 * browser data snapshot. No network is used by the resulting app at battle time.
 *
 * node scripts/vendor-showdown-client.mjs            Verify/use existing assets; fetch missing ones.
 * node scripts/vendor-showdown-client.mjs --verify   Verify snapshot/build outputs without downloading.
 * node scripts/vendor-showdown-client.mjs --verify-source  Verify archived source/data before rebuilding.
 * node scripts/vendor-showdown-client.mjs --refresh  Explicitly update mutable official data snapshot.
 *
 * Artwork/audio are prepared separately by vendor-showdown-assets.mjs.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const VENDOR = path.join(ROOT, 'vendor');
const CHECKOUT = path.join(VENDOR, 'pokemon-showdown-client');
const SITE = path.join(CHECKOUT, 'play.pokemonshowdown.com');
const MANIFEST_PATH = path.join(VENDOR, 'showdown-client-manifest.json');
const SOURCE_MANIFEST_PATH = path.join(VENDOR, 'showdown-source-manifest.json');
const CLIENT_COMMIT = '1e3b209011340e7c149a2e94769183eb4351b2e9';
const SERVER_COMMIT = '524413e8415fe179781e9bbcc7c79a85543b3409';
const CLIENT_REPOSITORY = 'https://github.com/smogon/pokemon-showdown-client.git';
const SERVER_REPOSITORY = 'https://github.com/smogon/pokemon-showdown';
const DATA_FILES = [
  'data/pokedex.js', 'data/moves.js', 'data/items.js', 'data/abilities.js',
  'data/typechart.js', 'data/text/en.js', 'data/search-index.js',
  'data/teambuilder-tables.js', 'data/commands.js', 'data/aliases.js',
  'data/pokedex-mini.js', 'data/pokedex-mini-bw.js',
];
const REQUIRED_BUILD_FILES = [
  'js/battledata.js', 'js/battle.js', 'js/battle-tooltips.js', 'js/battle-sound.js',
  'js/battle-dex-search.js', 'js/battle-animations.js', 'js/battle-animations-moves.js',
  'js/oldclient/storage.js', 'js/oldclient/client.js', 'js/oldclient/client-mainmenu.js',
  'js/oldclient/client-topbar.js', 'js/oldclient/client-teambuilder.js',
  'js/oldclient/client-battle.js', 'js/oldclient/client-chat.js',
  'js/oldclient/client-chat-tournament.js', 'js/oldclient/client-rooms.js',
  'js/oldclient/client-ladder.js', 'js/oldclient/search.js',
  'js/lib/jquery-2.2.4.min.js', 'js/lib/jquery-cookie.js',
  'js/lib/lodash.core.js', 'js/lib/backbone.js', 'js/lib/html-css-sanitizer-minified.js',
  'style/battle.css', 'style/oldclient.css', 'style/sim-types.css',
  'style/utilichart.css', 'style/font-awesome.css',
];

const args = new Set(process.argv.slice(2));
const sourceOnly = args.has('--verify-source');
const verifyOnly = args.has('--verify') || sourceOnly;
const refresh = args.has('--refresh');
if (verifyOnly && refresh) throw new Error('--verify and --refresh are mutually exclusive.');
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const exists = file => fs.access(file).then(() => true, () => false);
function run(command, commandArgs, cwd = ROOT, capture = false) {
  const result = spawnSync(command, commandArgs, {
    cwd, encoding: 'utf8', stdio: capture ? 'pipe' : 'inherit',
    windowsHide: true,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${command} ${commandArgs.join(' ')} failed (${result.status}): ${result.stderr || ''}`);
  return result.stdout?.trim();
}
function npmCi() {
  // npm.cmd is a batch file; use the actual npm JS entry on Windows, avoiding a shell.
  const npmCli = path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
  if (process.platform === 'win32') {
    run(process.execPath, [npmCli, 'ci', '--ignore-scripts', '--no-audit', '--no-fund', '--cache', path.join(ROOT, '.npm-cache')], CHECKOUT);
  } else {
    run('npm', ['ci', '--ignore-scripts', '--no-audit', '--no-fund'], CHECKOUT);
  }
}
async function readCheckoutCommit() {
  // Keep --verify usable in restricted environments that cannot spawn git.
  let gitDirectory = path.join(CHECKOUT, '.git');
  const metadata = await fs.stat(gitDirectory).catch(error => {
    if (error.code === 'ENOENT') return null;
    throw error;
  });
  if (!metadata) {
    // The corresponding-source archive intentionally excludes .git. Its complete
    // tracked-file hash list preserves the pinned source without recloning or
    // discarding the archived mutable-data snapshot.
    const source = JSON.parse(await fs.readFile(SOURCE_MANIFEST_PATH, 'utf8').catch(error => {
      if (error.code === 'ENOENT') throw new Error('Client .git metadata and archived source manifest are both missing. Use the complete corresponding-source archive.');
      throw error;
    }));
    if (source.schemaVersion !== 1 || source.clientCommit !== CLIENT_COMMIT || !Array.isArray(source.files)) {
      throw new Error('Archived client source manifest does not describe the pinned client.');
    }
    const seen = new Set();
    for (const entry of source.files) {
      if (typeof entry.path !== 'string' || entry.path.includes('\\') || path.isAbsolute(entry.path) ||
          entry.path.split('/').some(part => !part || part === '.' || part === '..') || seen.has(entry.path)) {
        throw new Error(`Invalid archived source path: ${entry.path}`);
      }
      seen.add(entry.path);
      const file = path.resolve(CHECKOUT, entry.path);
      if (!file.startsWith(CHECKOUT + path.sep)) throw new Error('Archived source path escaped the client directory.');
      const bytes = await fs.readFile(file);
      if (bytes.length !== entry.bytes || sha256(bytes) !== entry.sha256) {
        throw new Error(`Archived source checksum mismatch: ${entry.path}`);
      }
    }
    for (const required of ['package.json', 'package-lock.json', 'LICENSE', 'build',
      'play.pokemonshowdown.com/index-old.html', 'play.pokemonshowdown.com/src/oldclient/client-battle.js']) {
      if (!seen.has(required)) throw new Error(`Archived source manifest is incomplete: ${required}`);
    }
    console.log(`Verified ${seen.size} archived official source files (no Git checkout required).`);
    return source.clientCommit;
  }
  if (metadata.isFile()) {
    const pointer = (await fs.readFile(gitDirectory, 'utf8')).trim();
    if (!pointer.startsWith('gitdir: ')) throw new Error('Unexpected git metadata.');
    gitDirectory = path.resolve(CHECKOUT, pointer.slice(8));
  }
  const head = (await fs.readFile(path.join(gitDirectory, 'HEAD'), 'utf8')).trim();
  if (!head.startsWith('ref: ')) return head;
  const reference = head.slice(5);
  try { return (await fs.readFile(path.join(gitDirectory, reference), 'utf8')).trim(); } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const refs = await fs.readFile(path.join(gitDirectory, 'packed-refs'), 'utf8');
    return refs.split(/\r?\n/).find(line=>line.endsWith(` ${reference}`))?.split(' ')[0];
  }
}
let previous;
try { previous = JSON.parse(await fs.readFile(MANIFEST_PATH, 'utf8')); } catch (error) {
  if (error.code !== 'ENOENT') throw error;
  if (verifyOnly) throw new Error('Missing snapshot manifest. Run the preparation command first.');
}
await fs.mkdir(VENDOR, {recursive:true});
if (!(await exists(path.join(CHECKOUT, 'package.json')))) {
  if (verifyOnly) throw new Error('Missing vendored client checkout.');
  run('git', ['clone', '--no-checkout', CLIENT_REPOSITORY, CHECKOUT]);
  run('git', ['checkout', '--detach', CLIENT_COMMIT], CHECKOUT);
}
const commit = await readCheckoutCommit();
if (commit !== CLIENT_COMMIT) throw new Error(`Client checkout is ${commit}, expected ${CLIENT_COMMIT}. Restore the pinned checkout explicitly before preparing.`);
const lockBytes = await fs.readFile(path.join(CHECKOUT, 'package-lock.json'));
const licenseBytes = await fs.readFile(path.join(CHECKOUT, 'LICENSE'));
if (previous && previous.dependencyLockSha256 !== sha256(lockBytes)) throw new Error('Official dependency lockfile changed from the recorded snapshot.');

const entries = [
  ...DATA_FILES.map(file => ({file:`play.pokemonshowdown.com/${file}`,url:`https://play.pokemonshowdown.com/${file}`})),
  {file:'caches/pokemon-showdown/server/chat-formatter.ts',url:`${SERVER_REPOSITORY.replace('github.com', 'raw.githubusercontent.com')}/${SERVER_COMMIT}/server/chat-formatter.ts`},
  {file:'caches/pokemon-showdown/LICENSE',url:`${SERVER_REPOSITORY.replace('github.com', 'raw.githubusercontent.com')}/${SERVER_COMMIT}/LICENSE`},
];
const downloads = [];
async function getAsset(entry) {
  const destination = path.join(CHECKOUT, ...entry.file.split('/'));
  const old = previous?.downloads?.find(item => item.file === entry.file);
  let bytes;
  if (!refresh && await exists(destination)) {
    bytes = await fs.readFile(destination);
    if (old && sha256(bytes) !== old.sha256) throw new Error(`Snapshot checksum mismatch: ${entry.file}. Restore the recorded bytes or explicitly --refresh.`);
    if (verifyOnly && !old) throw new Error(`No recorded checksum: ${entry.file}`);
  } else {
    if (verifyOnly) throw new Error(`Missing snapshot asset: ${entry.file}`);
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await fetch(entry.url, {signal:AbortSignal.timeout(60_000)});
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        bytes = Buffer.from(await response.arrayBuffer());
        if (!bytes.length || /^\s*<!doctype html/i.test(bytes.subarray(0,100).toString())) throw new Error('Expected source data, received empty data or HTML.');
        if (old && !refresh && sha256(bytes) !== old.sha256) throw new Error('The official asset changed since this snapshot. Use the saved snapshot or explicitly --refresh to accept a new one.');
        break;
      } catch (error) {
        if (attempt === 2 || /changed since/.test(error.message)) throw new Error(`Could not fetch ${entry.url}: ${error.message}`);
      }
    }
    await fs.mkdir(path.dirname(destination), {recursive:true});
    await fs.writeFile(destination, bytes);
  }
  const checksum = sha256(bytes);
  if (entry.file.endsWith('.js')) new vm.Script(bytes.toString(), {filename:entry.file});
  const timestamp = old?.sha256 === checksum ? old.fetchedAt : new Date().toISOString();
  downloads.push({...entry,sha256:checksum,bytes:bytes.length,fetchedAt:timestamp});
}
for (let offset=0; offset<entries.length; offset+=4) {
  await Promise.all(entries.slice(offset,offset+4).map(getAsset));
}
downloads.sort((a,b)=>a.file.localeCompare(b.file));
if (sourceOnly) {
  console.log(`Verified source and ${downloads.length} retained data assets for client ${CLIENT_COMMIT.slice(0,12)}. Run without --verify-source to compile the client.`);
  process.exit(0);
}
if (!verifyOnly) {
  if (!(await exists(path.join(CHECKOUT, 'node_modules', '@babel', 'core', 'package.json')))) npmCi();
  // Presence of graphics.js makes the official build compile its checked-in animations.
  // Without this sentinel the normal (non-full) build skips animation compilation.
  const graphics = path.join(SITE, 'data', 'graphics.js');
  if (!(await exists(graphics))) await fs.writeFile(graphics, '// Generated by the pinned official client build.\n');
  // A fresh sentinel is newer than the source; reset its time so compileToFile
  // cannot silently mistake the placeholder for an up-to-date renderer.
  if((await fs.stat(graphics)).size<100) await fs.utimes(graphics,new Date(0),new Date(0));
  run(process.execPath, ['build'], CHECKOUT);
  await fs.writeFile(path.join(VENDOR, 'LICENSE.pokemon-showdown-client'), licenseBytes);
  await fs.copyFile(path.join(CHECKOUT, 'caches', 'pokemon-showdown', 'LICENSE'), path.join(VENDOR, 'LICENSE.pokemon-showdown-server'));
}
const outputs = [];
for (const file of REQUIRED_BUILD_FILES) {
  const bytes = await fs.readFile(path.join(SITE, ...file.split('/')));
  if (!bytes.length) throw new Error(`Empty required official output: ${file}`);
  const checksum = sha256(bytes);
  if (file.endsWith('.js')) new vm.Script(bytes.toString(), {filename:file});
  const old = previous?.outputs?.find(item=>item.file===file);
  if (verifyOnly && old && old.sha256 !== checksum) throw new Error(`Built output checksum mismatch: ${file}`);
  outputs.push({file,sha256:checksum,bytes:bytes.length});
}
const manifest = {
  schemaVersion:1,
  client:{repository:CLIENT_REPOSITORY,commit:CLIENT_COMMIT,license:'AGPL-3.0',licenseFile:'LICENSE.pokemon-showdown-client',licenseSha256:sha256(licenseBytes)},
  chatFormatter:{repository:SERVER_REPOSITORY,commit:SERVER_COMMIT,license:'MIT',licenseFile:'LICENSE.pokemon-showdown-server'},
  dependencyLockSha256:sha256(lockBytes),
  runtimeNetworkRequired:false,
  notes:[
    'Official client source is preserved in the pinned git checkout; application adapters are maintained outside that checkout.',
    'Downloaded public client data is a timestamped SHA-256 snapshot. Mutable official URLs are never silently accepted after their contents change.',
    'Commit pins and package-lock provide reproducible source/dependency inputs. Prepared data must be retained with releases because mutable upstream assets can change.',
    'The generated graphics.js and battledata.js are compiled by the official build from pinned client source, the pinned MIT server chat formatter, and the recorded English text snapshot.',
    'Source archive, modifications, build scripts, this manifest, and upstream licenses must accompany redistribution of the AGPL client.',
    'Pokémon artwork/audio preparation and its separate provenance manifest are managed by vendor-showdown-assets.mjs.',
  ],
  downloads,outputs,
};
if (!verifyOnly) await fs.writeFile(MANIFEST_PATH, JSON.stringify(manifest,null,2)+'\n');
console.log(`${verifyOnly?'Verified':'Prepared'} official Showdown client ${CLIENT_COMMIT.slice(0,12)}: ${downloads.length} source/data assets, ${outputs.length} required build outputs.`);
console.log(`Client root: ${SITE}`);
console.log(`Provenance: ${MANIFEST_PATH}`);
