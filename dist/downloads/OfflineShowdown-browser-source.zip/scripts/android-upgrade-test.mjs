// Reproduce an installed app controlled by an obsolete browser service worker,
// then cold-start the native shell and verify cache retirement without team loss.
import {chromium} from 'playwright';
import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const serial=process.env.ANDROID_SERIAL||'emulator-5554';
const executable=path.resolve('.tools/android-sdk/platform-tools/adb.exe');
const adb=(...args)=>execFileSync(executable,['-s',serial,...args],{encoding:'utf8',windowsHide:true}).trim();
const connect=()=>chromium.connectOverCDP('http://127.0.0.1:9223',{noDefaults:true});
let browser=await connect();
try {
  let page=browser.contexts()[0].pages()[0];
  await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
  // A user-edited team may retain an old bundled sample name. Startup must not
  // remove it merely because that name matches the former AI pool.
  await page.evaluate(()=>{
    if(!Storage.teams.length)throw new Error('Upgrade fixture needs an existing team');
    Storage.teams.push({...Storage.teams[0],name:'Parasite by Vert'});
    Storage.saveTeams();
    localStorage.removeItem('offline-showdown-private-ai-pool-v2');
  });
  const before=await page.evaluate(()=>localStorage.getItem('showdown_teams'));
  if(!before)throw new Error('No saved native teams available for upgrade test');
  console.log('Seeding the former service-worker/cache condition on the installed APK...');
  await page.evaluate(()=>navigator.serviceWorker.register('/sw.js'));
  await page.waitForFunction(()=>!!navigator.serviceWorker.controller,{},{timeout:240000});
  const seeded=await page.evaluate(async()=>({controller:!!navigator.serviceWorker.controller,caches:await caches.keys(),registrations:(await navigator.serviceWorker.getRegistrations()).length}));
  if(!seeded.caches.some(k=>k.startsWith('offline-'))||seeded.registrations!==1)throw new Error('Old cache condition was not established');
  await browser.close(); browser=null;
  adb('shell','am','force-stop','org.offlineshowdown.practice');
  adb('shell','am','start','-n','org.offlineshowdown.practice/.MainActivity');
  let processId='';
  for(let attempt=0;attempt<30&&!processId;attempt++) {
    try{processId=adb('shell','pidof','org.offlineshowdown.practice');}catch{}
    if(!processId)await new Promise(r=>setTimeout(r,200));
  }
  if(!processId)throw new Error('Native process did not start');
  adb('forward','tcp:9223',`localabstract:webview_devtools_remote_${processId}`);
  // CDP can become available before the new WebView target has been published.
  for(let attempt=0;attempt<30;attempt++) {
    try {browser=await connect(); if(browser.contexts()[0]?.pages().length)break;await browser.close();browser=null;}catch{}
    await new Promise(r=>setTimeout(r,200));
  }
  if(!browser)throw new Error('Restarted native WebView did not become available');
  page=browser.contexts()[0].pages()[0];
  await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready,{},{timeout:45000});
  const after=await page.evaluate(async()=>({client:offlinePractice.snapshot().client,controller:!!navigator.serviceWorker.controller,caches:await caches.keys(),registrations:(await navigator.serviceWorker.getRegistrations()).length,teams:localStorage.getItem('showdown_teams')}));
  const preserved=after.teams===before;delete after.teams;
  if(after.client!=='smogon/pokemon-showdown-client'||after.controller||after.registrations||after.caches.some(k=>k.startsWith('offline-'))||!preserved)throw new Error(JSON.stringify({after,preserved}));
  const result={testedAt:new Date().toISOString(),serial,seeded,after,teamsPreserved:preserved,airplaneMode:adb('shell','settings','get','global','airplane_mode_on'),wifiOn:adb('shell','settings','get','global','wifi_on')};
  fs.writeFileSync('reports/showdown-android-upgrade.json',JSON.stringify(result,null,2));
  console.log(JSON.stringify(result,null,2));
} finally {if(browser)await browser.close();}
