import {chromium} from 'playwright';
import {Dex as SimDex} from '@pkmn/sim';
import fs from 'node:fs';
const browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({serviceWorkers:'block'});await page.goto('http://127.0.0.1:4173/');await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
const names=SimDex.forGen(9).species.all().filter(s=>!s.isNonstandard&&s.gen<=9).flatMap(s=>[s.name,...s.cosmeticFormes||[]].map(name=>({name,genders:s.gender?[s.gender]:['M','F']})));
const paths=await page.evaluate(names=>{const paths=new Set();for(const {name,genders} of names)for(const front of [true,false])for(const shiny of [true,false])for(const gender of genders){const data=Dex.getSpriteData(name,front,{gen:9,shiny,gender});paths.add(data.url);if(data.cryurl)paths.add(data.cryurl);}return [...paths];},names);
const missing=paths.map(p=>new URL(p,'http://127.0.0.1:4173/').pathname).filter(p=>!fs.existsSync('dist'+p));fs.writeFileSync('reports/showdown-asset-audit.json',JSON.stringify({species:names.length,paths:paths.length,missing},null,2));console.log({species:names.length,paths:paths.length,missing});await browser.close();
