[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$toolRoot = Join-Path $projectRoot '.tools'
$downloadRoot = Join-Path $toolRoot 'downloads'
$sdkRoot = Join-Path $toolRoot 'android-sdk'
New-Item -ItemType Directory -Force -Path $downloadRoot, $sdkRoot | Out-Null

# Official Google archives. SHA1 was cross-checked against repository2-1.xml;
# SHA256 additionally pins these exact downloaded archive bytes.
$packages = @(
    @{ File = 'platform-35_r02.zip'; Hash = '0988CACAD01B38A18A47BAC14A0695F246BC76C1B06C0EEB8EB0DC825AB0C8E0'; Destination = 'platforms'; Check = 'platforms/android-35/android.jar' },
    @{ File = 'build-tools_r35_windows.zip'; Hash = '5753C679A1B90BCF6FBC9945A2CE39DFB9E74F1DF0831A1E1866AE5B594326F0'; Destination = 'build-tools'; Check = 'build-tools/android-15/aapt2.exe' },
    @{ File = 'platform-tools_r37.0.1-win.zip'; Hash = '45F4D63113E895EBDE0C90F194099A4676B6AC653BD28D54314A9E022BBC1A99'; Destination = ''; Check = 'platform-tools/adb.exe' }
)
foreach ($package in $packages) {
    if (Test-Path -LiteralPath (Join-Path $sdkRoot $package.Check)) { continue }
    $archive = Join-Path $downloadRoot $package.File
    if (!(Test-Path -LiteralPath $archive)) {
        Write-Host "Downloading official Android SDK archive $($package.File)..."
        Invoke-WebRequest -Uri ('https://dl.google.com/android/repository/' + $package.File) -OutFile $archive
    }
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $package.Hash) {
        throw "Checksum mismatch for $archive. Delete this archive and retry."
    }
    $destination = Join-Path $sdkRoot $package.Destination
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Expand-Archive -LiteralPath $archive -DestinationPath $destination -Force
}
Write-Host "Android SDK ready at $sdkRoot. Build with scripts/android-build.ps1."
