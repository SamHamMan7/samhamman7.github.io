$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$client=Join-Path $root 'vendor/pokemon-showdown-client'
$output=Join-Path $root 'artifacts/OfflineShowdown-source.zip'
$manifest=Get-Content -LiteralPath (Join-Path $root 'vendor/showdown-client-manifest.json') -Raw | ConvertFrom-Json
$commit=& git -C $client rev-parse HEAD
if($LASTEXITCODE -ne 0 -or $commit -ne $manifest.client.commit) { throw 'The client checkout does not match the pinned source manifest.' }
& git -C $client diff --quiet HEAD -- .
if($LASTEXITCODE -ne 0) { throw 'The pinned upstream source has modifications. Keep application changes in the adapter and build scripts.' }
$tracked=@(& git -C $client ls-files)
if($LASTEXITCODE -ne 0 -or !$tracked.Count) { throw 'Unable to enumerate the pinned official source.' }
$sourceFiles=@(foreach($file in $tracked) {
    $full=Join-Path $client $file
    if(!(Test-Path -LiteralPath $full -PathType Leaf)) { throw "Missing tracked source file: $file" }
    @{path=$file.Replace('\','/'); sha256=(Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant(); bytes=(Get-Item -LiteralPath $full).Length}
})
$sourceManifest=@{schemaVersion=1;clientCommit=$commit;files=$sourceFiles} | ConvertTo-Json -Depth 6
Add-Type -AssemblyName System.IO.Compression.FileSystem
$paths=[Collections.Generic.HashSet[string]]::new()
foreach($dir in @('src','scripts','tests','docs','training','android/app/src')) {
    Get-ChildItem -LiteralPath (Join-Path $root $dir) -File -Recurse | Where-Object { $_.Extension -notin @('.bak','.pyc') -and $_.FullName -notmatch '[\\/]__pycache__[\\/]' } | ForEach-Object { [void]$paths.Add($_.FullName) }
}
foreach($file in @('package.json','package-lock.json','README.md','README_NEURAL_STAGE2.md','ULTRA_HANDOFF_STAGE2.md','PROGRESS.md','LICENSE','.gitignore','public/THIRD_PARTY_NOTICES.txt')) { [void]$paths.Add((Join-Path $root $file)) }
Get-ChildItem -LiteralPath (Join-Path $root 'vendor') -File | Where-Object { $_.Name -ne 'showdown-source-manifest.json' } | ForEach-Object { [void]$paths.Add($_.FullName) }
foreach($file in $tracked) { [void]$paths.Add((Join-Path $client $file)) }
foreach($entry in $manifest.downloads) { [void]$paths.Add((Join-Path $client $entry.file)) }
# Preserve the exact optional deployed graphs and contracts without including
# privileged training labels or workstation-only training checkpoints.
$models=Join-Path $root 'models/gen9randombattle'
if(Test-Path -LiteralPath $models) {
    Get-ChildItem -LiteralPath $models -File | Where-Object { $_.Extension -in @('.json','.onnx') } | ForEach-Object { [void]$paths.Add($_.FullName) }
}
if(Test-Path -LiteralPath $output) { Remove-Item -LiteralPath $output -Force }
$zip=[IO.Compression.ZipFile]::Open($output,[IO.Compression.ZipArchiveMode]::Create)
try {
    $sourceEntry=$zip.CreateEntry('vendor/showdown-source-manifest.json',[IO.Compression.CompressionLevel]::Optimal)
    $writer=[IO.StreamWriter]::new($sourceEntry.Open(),[Text.UTF8Encoding]::new($false))
    try { $writer.Write($sourceManifest) } finally { $writer.Dispose() }
    foreach($file in $paths) {
        $full=[IO.Path]::GetFullPath($file)
        if(!$full.StartsWith($root+[IO.Path]::DirectorySeparatorChar)) { throw "Source path escaped project: $full" }
        if(Test-Path -LiteralPath $full -PathType Leaf) {
            $relative=$full.Substring($root.Length+1).Replace('\','/')
            [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$full,$relative,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
        }
    }
} finally {$zip.Dispose()}
Write-Host "Corresponding source: $output ($([math]::Round((Get-Item $output).Length/1MB,2)) MiB)"
