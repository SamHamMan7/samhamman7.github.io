import {chromium} from 'playwright';
import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const serial=process.env.ANDROID_SERIAL||'emulator-5554';
const adb=(...args)=>execFileSync(path.resolve('.tools/android-sdk/platform-tools/adb.exe'),['-s',serial,...args],{encoding:'utf8',windowsHide:true}).trim();
const rotation=adb('shell','settings','get','system','user_rotation');
const automatic=adb('shell','settings','get','system','accelerometer_rotation');
const browser=await chromium.connectOverCDP('http://127.0.0.1:9223',{noDefaults:true});
try {
  const page=browser.contexts()[0].pages()[0];
  await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
  await page.evaluate(()=>app.focusRoom(''));
  await page.locator('.mainmenu button[name=format]').click();
  const closed=page.locator('.ps-popup details:not([open]) summary');
  if(await closed.count())await closed.first().click();
  await page.locator('.ps-popup button[name=selectFormat][value=gen9randombattle]').click();
  await page.locator('.mainmenu button[name=search]').click();
  await page.waitForFunction(()=>offlinePractice.snapshot().turn>=1&&offlinePractice.snapshot().request&&!offlinePractice.snapshot().ended);
  const before=await page.evaluate(()=>{
    window.lifecycleMarker=crypto.randomUUID();
    return {marker:lifecycleMarker,room:offlinePractice.snapshot().roomid,teams:localStorage.getItem('showdown_teams'),width:innerWidth,height:innerHeight};
  });
  adb('shell','settings','put','system','accelerometer_rotation','0');
  adb('shell','settings','put','system','user_rotation',rotation==='1'?'0':'1');
  await page.waitForFunction(({width,height})=>innerWidth!==width&&innerHeight!==height,before,{timeout:15000});
  const rotated=await page.evaluate(()=>({width:innerWidth,height:innerHeight,marker:lifecycleMarker,room:offlinePractice.snapshot().roomid}));
  adb('shell','input','keyevent','3');
  await new Promise(resolve=>setTimeout(resolve,1500));
  adb('shell','am','start','-n','org.offlineshowdown.practice/.MainActivity');
  await page.waitForFunction(()=>document.visibilityState==='visible');
  const after=await page.evaluate(()=>({marker:lifecycleMarker,room:offlinePractice.snapshot().roomid,error:offlinePractice.snapshot().error,teams:localStorage.getItem('showdown_teams'),turn:offlinePractice.snapshot().turn}));
  if(rotated.marker!==before.marker||after.marker!==before.marker||after.room!==before.room||after.teams!==before.teams||after.error)throw new Error('Rotation/background lost the active battle or saved teams');
  const result={testedAt:new Date().toISOString(),serial,rotationResized:true,documentPreserved:true,battlePreserved:true,teamsPreserved:true,turn:after.turn,
    before:{width:before.width,height:before.height},rotated:{width:rotated.width,height:rotated.height},
    airplaneMode:adb('shell','settings','get','global','airplane_mode_on'),wifiOn:adb('shell','settings','get','global','wifi_on')};
  // End only this test's battle, through the regular local transport.
  await page.evaluate(()=>app.send('/forfeit',offlinePractice.snapshot().roomid));
  await page.waitForFunction(()=>offlinePractice.snapshot().ended);
  fs.writeFileSync('reports/showdown-android-lifecycle.json',JSON.stringify(result,null,2));
  console.log(JSON.stringify(result,null,2));
} finally {
  for(const [name,value] of [['user_rotation',rotation],['accelerometer_rotation',automatic]]) {
    if(value==='null')adb('shell','settings','delete','system',name);
    else adb('shell','settings','put','system',name,value);
  }
  await browser.close();
}
