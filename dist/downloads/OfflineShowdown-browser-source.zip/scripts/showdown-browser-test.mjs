import {chromium} from 'playwright';
import fs from 'node:fs';
import {COMPETITIVE_TEAMS} from '../src/data/competitive-teams.js';
const android=process.argv.includes('--android'), smoke=process.argv.includes('--smoke');
const browser=android?await chromium.connectOverCDP('http://127.0.0.1:9223',{noDefaults:true}):await chromium.launch({channel:'chrome',headless:true,args:['--disable-background-networking']});
const context=android?browser.contexts()[0]:await browser.newContext({viewport:{width:412,height:915},isMobile:true,hasTouch:true,...(smoke?{serviceWorkers:'block'}:{})});
const page=android?context.pages()[0]:await context.newPage();
const errors=[],external=[],missing=[],violations=[];
const prefix=android?'showdown-android':'showdown-browser';
page.on('pageerror',e=>errors.push(e.message));
const expectedOrigin=android?'https://appassets.androidplatform.net':'http://127.0.0.1:4173';
page.on('request',r=>{if(!/^(data:|blob:)/.test(r.url())&&new URL(r.url()).origin!==expectedOrigin)external.push(r.url());});
page.on('response',r=>{if(r.status()>=400)missing.push(r.url());});
page.on('console',m=>{if(m.type()==='error'&&m.text().includes('Content Security Policy'))violations.push(m.text());});
const rows=[];
async function home() { await page.evaluate(()=>app.focusRoom('')); }
async function format(id,area='.mainmenu') {
  await page.locator(`${area} button[name=format]`).click();
  const section=page.locator('.ps-popup details:not([open]) summary');
  if(await section.count()) await section.first().click();
  await page.locator(`.ps-popup button[name=selectFormat][value=${id}]`).click();
}
try {
  if(!android) await page.goto('http://127.0.0.1:4173/');
  await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready&&window.offlinePractice.snapshot().client==='smogon/pokemon-showdown-client',{},{timeout:30000});
  if(!android&&!smoke) {
    console.log('Verifying small core cache and offline shell reload...');
    await page.waitForFunction(()=>!!navigator.serviceWorker.controller,{},{timeout:240000});
    await context.setOffline(true); await page.reload();
    await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready,{},{timeout:30000});
    await context.setOffline(false);
  }
  const identity=await page.evaluate(()=>({client:offlinePractice.snapshot().client,battle:typeof BattleRoom,renderer:typeof BattleScene,teambuilder:typeof TeambuilderRoom,custom:!!document.querySelector('#app')}));
  if(await page.locator('.mainmenu button[name=offlineDifficulty]').getAttribute('value')!=='Very Strong')throw new Error('Stable v1 must default to Very Strong');
  if(identity.client!=='smogon/pokemon-showdown-client'||identity.custom||identity.battle!=='function'||identity.renderer!=='function')throw new Error('Production build is not the native Showdown client');
  await page.screenshot({path:`reports/${prefix}-home.png`});
  await page.locator('.mainmenu button[value=teambuilder]').click();
  await page.locator('button[name=newTop][value=team]').click();
  await page.locator('.teamnameedit').fill('Offline native import test');
  await page.locator('button[name=import]').first().click();
  await page.locator('.teamedit textarea').fill(COMPETITIVE_TEAMS[0].paste);
  await page.locator('button[name=saveImport]').last().click();
  await format('gen9ou','.teamchartbox');
  await page.locator('button[name=validate]').click();
  await page.waitForFunction(()=>document.querySelector('.ps-popup')?.textContent.includes('Your team is valid'));
  await page.locator('.ps-popup button[name=close]').click();
  await page.screenshot({path:`reports/${prefix}-teambuilder.png`});
  // Closing the team editor executes upstream save/unload behavior.
  await page.locator('button[name=back]').first().click();
  const saved=await page.evaluate(()=>Storage.teams.some(t=>t.name==='Offline native import test'&&Storage.unpackTeam(t.team).length===6));
  if(!saved) throw new Error('Native teambuilder import did not persist');
  await home();
  // Browser assets are cached on demand. The APK has the complete local archive.
  // This browser offline battle starts after both OU teams are publicly previewed.
  if(!android)await page.evaluate(()=>{Storage.prefs('mute',true);BattleSound.setMute(true);});
  for(const id of (process.env.TEST_FORMATS||'gen9ou,gen9randombattle,gen9randomdoublesbattle').split(',')) {
    await format(id);
    if(id==='gen9ou') {
      await page.locator('.mainmenu button[name=team]').click();
      await page.locator('.ps-popup button[name=selectTeam]').filter({hasText:'Offline native import test'}).first().click();
    }
    await page.locator('.mainmenu button[name=search]').click();
    const offlineBattle=android||(!smoke&&id==='gen9ou');
    if(!android&&offlineBattle) {
      await page.waitForFunction(()=>!!document.querySelector('button[name=chooseTeamPreview]')||offlinePractice.snapshot().error);
      await context.setOffline(true);
    }
    const began=Date.now(); let clicks=0,frame=false,tera=false,lastProgress=Date.now();
    while(Date.now()-began<180000) {
      const snapshot=await page.evaluate(()=>offlinePractice.snapshot());
      if(Date.now()-lastProgress>10000){console.log(id,'turn',snapshot.turn,'clicks',clicks,await page.evaluate(()=>({choice:app.rooms[offlinePractice.snapshot().roomid]?.choice,tooltip:BattleTooltips.isLocked})));lastProgress=Date.now();}
      if(snapshot.error||errors.length)throw new Error(JSON.stringify({snapshot,errors}));
      if(snapshot.ended) {rows.push({format:id,offline:offlineBattle,turns:snapshot.turn,clicks,tera,lastDecisionMs:snapshot.lastDecisionMs,elapsedMs:Date.now()-began});break;}
      if(snapshot.turn>=1&&!frame) {
        // Allow real animations to run, then use upstream Skip to end for faster coverage.
        await page.waitForTimeout(750);
        await page.screenshot({path:`reports/${prefix}-${id}.png`});frame=true;
      }
      const action=await page.evaluate(()=>{
        BattleTooltips.hideTooltip();
        const room=app.rooms[offlinePractice.snapshot().roomid];
        const controls=room?.$controls?.[0]; if(!controls) return '';
        const visible=button=>button&&!button.disabled&&button.getClientRects().length;
        for(const name of ['chooseTeamPreview','chooseMoveTarget','chooseSwitchTarget','goToEnd']) {
          const button=[...controls.querySelectorAll(`button[name=${name}]`)].find(visible);
          if(button){button.click();return name;}
        }
        const moves=[...controls.querySelectorAll('button[name=chooseMove]')].filter(visible);
        if(moves.length) {
          const tera=controls.querySelector('input[name=terastallize]');
          if(tera&&!tera.checked&&!room.choice?.choices?.some(c=>c.includes('terastallize'))){tera.click();}
          moves.sort((a,b)=>(Dex.moves.get(b.dataset.move).basePower||0)-(Dex.moves.get(a.dataset.move).basePower||0));
          moves[0].click();return tera?'teraMove':'chooseMove';
        }
        const sw=[...controls.querySelectorAll('button[name=chooseSwitch]')].find(visible);
        if(sw){sw.click();return 'chooseSwitch';}
        return '';
      });
      if(action){clicks++;if(action==='teraMove')tera=true;} else await page.waitForTimeout(30);
    }
    if(!rows.some(r=>r.format===id))throw new Error('Battle timed out '+id);
    await page.evaluate(()=>app.rooms[offlinePractice.snapshot().roomid].battle.seekTurn(Infinity));
    await page.screenshot({path:`reports/${prefix}-${id}-complete.png`});
    await home();
    if(!android)await context.setOffline(false);
  }
  await format('gen9randombattle');
  await page.locator('.mainmenu button[name=offlineWatch]').click();
  await page.waitForFunction(()=>offlinePractice.snapshot().ended||offlinePractice.snapshot().error,{},{timeout:120000});
  const watch=await page.evaluate(()=>offlinePractice.snapshot());
  if(watch.error||!watch.ended||watch.turn<1)throw new Error('Watch battle failed: '+JSON.stringify(watch));
  await page.evaluate(()=>app.rooms[offlinePractice.snapshot().roomid].battle.seekTurn(Infinity));
  await page.screenshot({path:`reports/${prefix}-watch-complete.png`});
  await home();
  // Reload proves that native teambuilder storage survives app/page lifetime.
  await page.reload(); await page.waitForFunction(()=>window.offlinePractice?.snapshot().ready);
  const persisted=await page.evaluate(()=>Storage.teams.some(t=>t.name==='Offline native import test'&&Storage.unpackTeam(t.team).length===6));
  if(!persisted)throw new Error('Native team lost after reload');
  if(errors.length||external.length||missing.length||violations.length)throw new Error(JSON.stringify({errors,external,missing,violations}));
  const result={testedAt:new Date().toISOString(),android,offline:android?'APK without INTERNET permission, airplane mode enabled':smoke?false:'Offline core reload and prepared OU battle; random formats use local server for uncached assets',identity,nativeTeamImport:saved,persistedAfterReload:persisted,watch:{turns:watch.turn,ended:watch.ended},rows,errors,external,missing,violations};
  fs.writeFileSync(`reports/${prefix}-${smoke?'smoke':'offline'}.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
} catch(e) {
  await page.screenshot({path:`reports/${prefix}-failure.png`}).catch(()=>{});
  const info=await page.evaluate(()=>({text:document.body.innerText,health:window.offlinePractice?.snapshot()})).catch(()=>null);
  fs.writeFileSync(`reports/${prefix}-failure.json`,JSON.stringify({error:e.stack,info,errors,external,missing,violations,rows},null,2));
  console.error(e);process.exitCode=1;
} finally {await browser.close();}
