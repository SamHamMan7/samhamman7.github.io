import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Dex} from '@pkmn/sim';
const filename=process.argv[2]||'.tools/research/gen9ou-1825.json.gz';
const bytes=fs.readFileSync(filename), source=JSON.parse(gunzipSync(bytes));
if(source.info.metagame!=='gen9ou')throw new Error('Expected a Gen 9 OU dataset');
function top(values,count){const all=Object.entries(values||{}).filter(([,weight])=>weight>0).sort((a,b)=>b[1]-a[1]);const sum=all.reduce((a,[,v])=>a+v,0);return all.slice(0,count).map(([name,w])=>[name,Math.round(w/sum*10000)/10000]);}
const data={};
for(const [name,s] of Object.entries(source.data).sort((a,b)=>b[1].usage-a[1].usage).slice(0,160)) {
  const species=Dex.species.get(name);if(!species.exists)continue;
  data[species.id]={usage:s.usage,moves:top(s.Moves,12),items:top(s.Items,4),abilities:top(s.Abilities,3),spreads:top(s.Spreads,4),teraTypes:top(s['Tera Types'],3),teammates:top(s.Teammates,10)};
}
const metadata={source:'https://www.smogon.com/stats/2026-08/chaos/gen9ou-1825.json.gz',month:'2026-08',format:'gen9ou',cutoff:1825,battles:source.info['number of battles'],sha256:createHash('sha256').update(bytes).digest('hex'),note:'Marginal public usage priors; not correlated complete sets, generated teams, or difficulty Elo.'};
fs.writeFileSync('src/data/ou-statistics.js',`// Public statistics, compiled offline. Refresh with scripts/import-ou-stats.mjs.\nexport const OU_STATISTICS_META=${JSON.stringify(metadata)};\nexport default ${JSON.stringify(data)};\n`);
console.log(`Compiled priors for ${Object.keys(data).length} species`);
