# Handoff to Ultra — improve Stage 2, do not restart it

The regular-chat patch now has a complete public observation/action contract, a
~7.5M transformer, policy/value/opponent-action heads, teacher-data generation,
trajectory generation, BC, advantage-weighted BC, PPO/GAE optimization code,
checkpoint-league scaffolding, a response-risk aggregator, and an optional
response-conditioned search interface.

## First action

Run all existing repository tests plus:

```powershell
node --test tests/neural-scaffold.test.mjs tests/neural-worker-dispatch.test.mjs tests/neural-stage2-risk.test.mjs
python training/jaxlite/test_ppo_core.py
```

Do not weaken the hidden-information firewall.

## Highest-value next work

### 1. Add sanitized short battle history to PlayerView

Observation v1 only has current public state and accumulated revealed moves.
Add a bounded public history (roughly last 4–8 turns/events) to the PlayerView
snapshot, then bump the observation version and add history tokens to both JS
and PyTorch encoders. Never pass omniscient lines.

### 2. Wire privileged auxiliary labels

The training-only privileged collector records exact opponent random teams.
Use those labels to add compact prediction heads for:
- opponent item
- ability
- unrevealed moves
- Tera type

Do not feed the labels into inference. Prediction loss is auxiliary.

### 3. Connect a real desktop neural inference backend

Prefer the shortest reliable route first (likely ONNX Runtime Node for desktop
training/evaluation), then choose ONNX Runtime Web/WASM versus native Android
ONNX for production. `NeuralPolicy` already provides the boundary.

### 4. Build schema-3 neural rollout collection

The PPO trainer is implemented but deliberately refuses heuristic fake
log-probabilities. Run actual neural policies in `@pkmn/sim` and record:
- observation
- legal mask
- sampled action
- old log probability
- old signed value
- reward/done
- next signed value
- opponent action label where simultaneous

Use historical checkpoint league opponents, not only newest-vs-newest.

### 5. Implement response-matrix evaluation

`responseConditionedPolicy()` is already wired to an optional backend method.
Implement `evaluateResponseMatrix()` using a bounded set of likely opponent
responses and post-response value evaluation. Then add hidden-world sampling.

The matrix entries should be resulting **win probabilities**, not hand-tuned
"prediction points." Continue through forced replacements/revenge situations
where practical.

### 6. Improve risk calibration with empirical tests

Current state-dependent CVaR-like coefficients are sensible scaffolding, not
sacred constants. Tune them against paired seeded games/regression positions.
The invariant is:
- ahead: downside matters more
- even: expected value dominates with robust mixing
- behind: tolerate more variance

Do not convert this back into arbitrary aggression bonuses.

## Explicit shortcomings to fix

- AWBC is only a bootstrap bridge and can inherit teacher mistakes.
- PPO optimizer works but online rollout production is missing.
- no real model currently drives the browser/Android worker.
- no human replay ingestion yet.
- no world/set sampler yet.
- no search batching/caching yet.
- no Pixel latency/model-size measurements yet.
- no evidence yet that Neural Preview is stronger than Very Strong.

Preserve Medium/Strong/Very Strong as fallbacks while Neural Preview matures.
