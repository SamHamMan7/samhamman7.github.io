"""Advantage-weighted behavior cloning bridge.

This is intentionally NOT claimed to be PPO. It is a useful intermediate step
between plain imitation of the heuristic teacher and true online self-play:
winning teacher decisions receive more weight, losing teacher decisions receive
less, while the value and opponent-action heads continue learning.

Ultra should replace/supersede this with online PPO once neural rollouts are
available from the real simulator loop.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader, Subset

from dataset import JsonlBattleDataset
from model import JaxLiteModel, parameter_count, OBSERVATION_VERSION


def split_by_game(dataset, val_fraction: float, seed: int):
    groups: dict[str, list[int]] = {}
    for index, game_id in enumerate(dataset.rows.game_ids):
        key = game_id
        groups.setdefault(key, []).append(index)
    keys = list(groups)
    random.Random(seed).shuffle(keys)
    val_games = max(1, int(round(len(keys) * val_fraction))) if len(keys) > 1 else 0
    val_keys = set(keys[:val_games])
    train_indices = [i for key, values in groups.items() if key not in val_keys for i in values]
    val_indices = [i for key, values in groups.items() if key in val_keys for i in values]
    if not val_indices and len(train_indices) > 1:
        val_indices = [train_indices.pop()]
    return Subset(dataset, train_indices), Subset(dataset, val_indices)


def load_model(path: str | None, device):
    if not path:
        config = {"d_model": 256, "nhead": 8, "layers": 4, "dim_feedforward": 1024, "dropout": 0.1}
        return JaxLiteModel(**config).to(device), config
    checkpoint = torch.load(path, map_location=device)
    config = checkpoint.get("model_config") or {"d_model": 256, "nhead": 8, "layers": 4, "dim_feedforward": 1024, "dropout": 0.1}
    model = JaxLiteModel(**config).to(device)
    model.load_state_dict(checkpoint["model"])
    return model, config


def run_epoch(model, loader, optimizer, device, beta: float, max_weight: float):
    training = optimizer is not None
    model.train(training)
    totals = {"loss": 0.0, "policy": 0.0, "opponent": 0.0, "value": 0.0,
              "examples": 0, "mean_weight": 0.0, "policy_correct": 0,
              "opponent_correct": 0, "opponent_examples": 0}
    for batch in loader:
        batch = {key: value.to(device) for key, value in batch.items()}
        out = model(batch["token_kinds"], batch["categorical"], batch["numeric"], batch["token_mask"], batch["legal_mask"])

        signed_value = torch.sigmoid(out["value_logit"]) * 2.0 - 1.0
        outcome_mask = torch.isfinite(batch["outcome"])
        advantage = torch.zeros_like(signed_value)
        advantage[outcome_mask] = batch["outcome"][outcome_mask] - signed_value.detach()[outcome_mask]
        weights = torch.exp(beta * advantage).clamp(min=1.0 / max_weight, max=max_weight)

        per_example_policy = nn.functional.cross_entropy(out["policy_logits"], batch["action"], reduction="none")
        policy_loss = (per_example_policy * weights).mean()

        opp_mask = batch["opponent_action"] >= 0
        opponent_loss = (nn.functional.cross_entropy(out["opponent_policy_logits"][opp_mask], batch["opponent_action"][opp_mask])
                         if opp_mask.any() else torch.zeros((), device=device))

        if outcome_mask.any():
            value_target = (batch["outcome"][outcome_mask] + 1.0) / 2.0
            value_loss = nn.functional.binary_cross_entropy_with_logits(out["value_logit"][outcome_mask], value_target)
        else:
            value_loss = torch.zeros((), device=device)

        loss = policy_loss + 0.35 * opponent_loss + 0.55 * value_loss
        if training:
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        n = batch["action"].shape[0]
        totals["examples"] += n
        totals["mean_weight"] += float(weights.mean().detach()) * n
        totals["policy_correct"] += int((out["policy_logits"].argmax(dim=-1) == batch["action"]).sum())
        if opp_mask.any():
            totals["opponent_correct"] += int((out["opponent_policy_logits"][opp_mask].argmax(dim=-1) == batch["opponent_action"][opp_mask]).sum())
            totals["opponent_examples"] += int(opp_mask.sum())
        for key, value in [("loss", loss), ("policy", policy_loss), ("opponent", opponent_loss), ("value", value_loss)]:
            totals[key] += float(value.detach()) * n

    denom = max(1, totals["examples"])
    return {
        "loss": totals["loss"] / denom,
        "policy_loss": totals["policy"] / denom,
        "opponent_loss": totals["opponent"] / denom,
        "value_loss": totals["value"] / denom,
        "mean_weight": totals["mean_weight"] / denom,
        "policy_accuracy": totals["policy_correct"] / denom,
        "opponent_accuracy": totals["opponent_correct"] / max(1, totals["opponent_examples"]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("data")
    parser.add_argument("--init")
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--beta", type=float, default=1.25)
    parser.add_argument("--max-weight", type=float, default=4.0)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--val-fraction", type=float, default=0.1)
    parser.add_argument("--output", default="models/gen9randombattle/jaxlite-awbc.pt")
    parser.add_argument('--threads', type=int, default=4)
    args = parser.parse_args()
    torch.set_num_threads(args.threads)

    torch.manual_seed(args.seed)
    dataset = JsonlBattleDataset(args.data)
    if len(dataset) < 10:
        raise SystemExit("Need at least 10 examples.")
    train, val = split_by_game(dataset, args.val_fraction, args.seed)
    train_loader = DataLoader(train, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val, batch_size=args.batch_size)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, config = load_model(args.init, device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    print(f"device={device} parameters={parameter_count(model):,} train={len(train)} val={len(val)}")

    history = []
    for epoch in range(1, args.epochs + 1):
        train_metrics = run_epoch(model, train_loader, optimizer, device, args.beta, args.max_weight)
        with torch.no_grad():
            val_metrics = run_epoch(model, val_loader, None, device, args.beta, args.max_weight)
        history.append({"epoch": epoch, "train": train_metrics, "val": val_metrics})
        print(f"epoch={epoch} train={train_metrics} val={val_metrics}")

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model": model.state_dict(),
        "observation_version": OBSERVATION_VERSION,
        "model_config": config,
        "history": history,
        "training": "advantage-weighted-behavior-cloning",
    }, output)
    output.with_suffix(output.suffix + ".json").write_text(json.dumps({
        "parameters": parameter_count(model),
        "training": "advantage-weighted-behavior-cloning",
        "warning": "Bootstrap bridge only; not online PPO.",
        "final": history[-1],
    }, indent=2), encoding="utf-8")
    print(f"saved {output}")


if __name__ == "__main__":
    main()
