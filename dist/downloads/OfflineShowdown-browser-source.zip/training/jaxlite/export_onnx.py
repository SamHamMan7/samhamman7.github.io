from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import torch
from torch import nn

from model import JaxLiteModel, TOKEN_COUNT, CAT_FEATURES, NUM_FEATURES, ACTION_COUNT, HASH_BUCKETS, OBSERVATION_VERSION, parameter_count


class OnnxWrapper(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, token_kinds, categorical, numeric, token_mask, legal_mask):
        out = self.model(token_kinds, categorical, numeric, token_mask, legal_mask)
        return out["policy_logits"], out["value_logit"], out["opponent_policy_logits"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint")
    parser.add_argument("--output", default="models/gen9randombattle/jaxlite-bc.onnx")
    args = parser.parse_args()

    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    if checkpoint.get('observation_version') != OBSERVATION_VERSION:
        raise ValueError('Checkpoint observation version differs from current encoder')
    if not checkpoint.get('history'):
        raise ValueError('Export requires an actually trained checkpoint with training history')
    model = JaxLiteModel(**checkpoint.get("model_config", {}))
    model.load_state_dict(checkpoint["model"])
    model.eval()
    torch.backends.mha.set_fastpath_enabled(False)
    # Keep parent and child in eval mode. Export restores the parent's mode;
    # leaving the wrapper in train mode would re-enable child dropout afterwards.
    wrapped = OnnxWrapper(model).eval()

    batch = 1
    sample = (
        torch.zeros((batch, TOKEN_COUNT), dtype=torch.long),
        torch.zeros((batch, TOKEN_COUNT, CAT_FEATURES), dtype=torch.long),
        torch.zeros((batch, TOKEN_COUNT, NUM_FEATURES), dtype=torch.float32),
        torch.ones((batch, TOKEN_COUNT), dtype=torch.bool),
        torch.ones((batch, ACTION_COUNT), dtype=torch.bool),
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(
        wrapped, sample, output,
        input_names=["token_kinds", "categorical", "numeric", "token_mask", "legal_mask"],
        output_names=["policy_logits", "value_logit", "opponent_policy_logits"],
        dynamic_axes={
            "token_kinds": {0: "batch"}, "categorical": {0: "batch"}, "numeric": {0: "batch"},
            "token_mask": {0: "batch"}, "legal_mask": {0: "batch"},
            "policy_logits": {0: "batch"}, "value_logit": {0: "batch"}, "opponent_policy_logits": {0: "batch"},
        },
        opset_version=17,
        dynamo=False,
    )
    # Check the actual exported graph against PyTorch, including dynamic batch.
    import numpy as np
    import onnxruntime as ort
    session = ort.InferenceSession(str(output), providers=['CPUExecutionProvider'])
    names = ['token_kinds', 'categorical', 'numeric', 'token_mask', 'legal_mask']
    max_error = 0.0
    for count in (1, 3):
        inputs = (torch.ones((count,TOKEN_COUNT),dtype=torch.long),
                  torch.randint(0,HASH_BUCKETS,(count,TOKEN_COUNT,CAT_FEATURES)),
                  torch.rand((count,TOKEN_COUNT,NUM_FEATURES)),
                  torch.ones((count,TOKEN_COUNT),dtype=torch.bool),
                  torch.ones((count,ACTION_COUNT),dtype=torch.bool))
        inputs[3][:,-2:] = False
        with torch.no_grad(): reference = wrapped(*inputs)
        actual = session.run(None,{name: value.numpy() for name,value in zip(names,inputs)})
        for expected,value in zip(reference,actual):
            max_error=max(max_error,float(np.max(np.abs(expected.numpy()-value))))
            np.testing.assert_allclose(expected.numpy(),value,atol=2e-4,rtol=2e-4)
    manifest = {
        'schemaVersion':1, 'trained':True, 'observationVersion':OBSERVATION_VERSION,
        'format':'gen9randombattle', 'actionCount':ACTION_COUNT, 'tokenCount':TOKEN_COUNT,
        'catFeatures':CAT_FEATURES, 'numFeatures':NUM_FEATURES, 'hashBuckets':HASH_BUCKETS,
        'model':output.name, 'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'checkpointSha256':hashlib.sha256(Path(args.checkpoint).read_bytes()).hexdigest(),
        'parameters':parameter_count(model), 'outputs':{'policy':'policy_logits','value':'value_logit','opponentPolicy':'opponent_policy_logits'},
        'onnxParityMaxError':max_error, 'training':checkpoint.get('training','behavior-cloning'),
        'strengthValidated':False,
    }
    output.with_name('manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(f"saved {output}")


if __name__ == "__main__":
    main()
