"""Separate supervised beliefs; privileged records supply targets, NEVER inputs.

The collector stores ORIGINAL generated sets. These heads estimate original sets,
not an item/ability acquired later in battle. Publicly known current facts always
take precedence at inference. No base policy/encoder files or weights are changed.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import re
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset, Subset

from dataset import JsonlRows

OBSERVATION_VERSION, TOKEN_COUNT, CAT_FEATURES, NUM_FEATURES = 2, 29, 12, 22
HASH_BUCKETS, ACTION_COUNT, OPPONENT_START, OPPONENT_SLOTS = 16384, 14, 7, 6
INPUT_NAMES = ['token_kinds', 'categorical', 'numeric', 'token_mask', 'legal_mask']
HEADS = ('item', 'ability', 'tera', 'moves', 'nextMove')
OUTPUT_NAMES = ['item_logits', 'ability_logits', 'tera_logits', 'move_logits', 'next_move_logits']


def to_id(value):
    return re.sub('[^a-z0-9]', '', str(value or '').lower())


def hash_feature(namespace, value):
    value = to_id(value)
    if not value:
        return 0
    result = 0x811c9dc5
    for char in f'{namespace}:{value}':
        result = ((result ^ ord(char)) * 0x01000193) & 0xffffffff
    return result % HASH_BUCKETS + 1


def validate_public_observation(obs):
    if obs.get('version') != OBSERVATION_VERSION or obs.get('meta', {}).get('format') != 'gen9randombattle':
        raise ValueError('Beliefs require Gen9 Random Battle observation version 2')
    for key, count in [('tokenKinds', TOKEN_COUNT), ('tokenMask', TOKEN_COUNT), ('legalMask', ACTION_COUNT)]:
        if len(obs.get(key, [])) != count:
            raise ValueError(f'Invalid observation {key}')
    for key, count in [('categorical', CAT_FEATURES), ('numeric', NUM_FEATURES)]:
        if len(obs.get(key, [])) != TOKEN_COUNT or any(len(row) != count for row in obs[key]):
            raise ValueError(f'Invalid observation {key}')
    for token in range(OPPONENT_START, OPPONENT_START + OPPONENT_SLOTS):
        if obs['tokenMask'][token] and obs['tokenKinds'][token] != 3:
            raise ValueError('Opponent slot has the wrong public token kind')
        if any(obs['categorical'][token][8:]) or any(obs['numeric'][token][16:]) or obs['numeric'][token][14]:
            raise ValueError('Opponent exact moves/stats leaked into public observation')
        if not obs['tokenMask'][token] and (any(obs['categorical'][token]) or any(obs['numeric'][token])):
            raise ValueError('Padded opponent token contains data')


def matched_slots(row, audit=None):
    """Join only revealed slots; skip collisions, disguises and transformed identity."""
    obs = row['observation']
    validate_public_observation(obs)
    team = row.get('privilegedOpponentTeam')
    if not isinstance(team, list):
        raise ValueError('Training row has no privilegedOpponentTeam labels')
    if any(to_id(mon.get('ability')) in ('illusion', 'imposter') or
           'transform' in [to_id(move) for move in mon.get('moves', [])] for mon in team):
        if audit is not None:
            audit['identity_unsafe_rows'] += 1
        return []
    labels = defaultdict(list)
    for mon in team:
        labels[hash_feature('species', mon.get('species'))].append(mon)
    public_hashes = Counter(obs['categorical'][token][0] for token in range(7, 13) if obs['tokenMask'][token])
    result = []
    for slot in range(OPPONENT_SLOTS):
        token = OPPONENT_START + slot
        if not obs['tokenMask'][token]:
            if audit is not None:
                audit['padded_slots_masked'] += 1
            continue
        species_hash = obs['categorical'][token][0]
        candidates = labels.get(species_hash, [])
        if not species_hash or len(candidates) != 1 or public_hashes[species_hash] != 1:
            if audit is not None:
                audit['unmatched_or_ambiguous_slots'] += 1
            continue
        result.append((slot, candidates[0]))
    return result


def observation_tensors(obs):
    # Explicit allowlist: never tensorize row metadata or the privileged team.
    return {
        'token_kinds': torch.tensor(obs['tokenKinds'], dtype=torch.long),
        'categorical': torch.tensor(obs['categorical'], dtype=torch.long),
        'numeric': torch.tensor(obs['numeric'], dtype=torch.float32),
        'token_mask': torch.tensor(obs['tokenMask'], dtype=torch.bool),
        'legal_mask': torch.tensor(obs['legalMask'], dtype=torch.bool),
    }


def ordinary_metadata(row):
    obs = row['observation']
    action = row.get('action', -1)
    if obs['numeric'][0][5] or obs['numeric'][0][6] or obs['numeric'][0][7]:
        return None
    # Keep every ordinary request in grouping, including switches. Multiple
    # ordinary requests per side/turn are ambiguous and must not be paired.
    return {'side': row.get('side'), 'action': action,
            'moveHash': obs['categorical'][13 + action % 4][0] if 0 <= action < 8 else 0}


def semantic_next_move(row, pair_index, move_hashes):
    own = ordinary_metadata(row)
    if own is None:
        return -1
    pair = pair_index.get((row['gameId'], row['turn']), {})
    side, other = row.get('side'), 'p2' if row.get('side') == 'p1' else 'p1'
    if len(pair.get(side, [])) != 1 or len(pair.get(other, [])) != 1:
        return -1
    opponent = pair[other][0]
    # Only ordinary moves; forced replacements and voluntary switches are not
    # encoded as misleading move-slot labels. Tera move slots share move identity.
    return move_hashes.get(opponent['moveHash'], -1) if 0 <= opponent['action'] < 8 else -1


def make_targets(row, vocab, pair_index, move_hashes, audit=None):
    indices = {head: {value: index for index, value in enumerate(vocab[head])} for head in ('item', 'ability', 'tera', 'moves')}
    targets = {head: torch.full((6,), -1, dtype=torch.long) for head in ('item', 'ability', 'tera')}
    targets['moves'] = torch.zeros((6, len(vocab['moves'])), dtype=torch.float32)
    targets['moves_mask'] = torch.zeros_like(targets['moves'], dtype=torch.bool)
    obs = row['observation']
    for slot, label in matched_slots(row, audit):
        token = 7 + slot
        for head, field, cat in [('item', 'item', 1), ('ability', 'ability', 2), ('tera', 'teraType', 5)]:
            if not isinstance(label.get(field), str) or obs['categorical'][token][cat]:
                continue
            target = indices[head].get(to_id(label[field]) or 'none', -1)
            targets[head][slot] = target
            if audit is not None and target < 0:
                audit[f'{head}_out_of_vocabulary'] += 1
        moves = [to_id(move) for move in label.get('moves', [])]
        if not moves or any(move not in indices['moves'] for move in moves):
            if audit is not None:
                audit['moves_out_of_vocabulary_slots'] += 1
            continue
        targets['moves_mask'][slot] = True
        for move in moves:
            targets['moves'][slot, indices['moves'][move]] = 1
        if obs['numeric'][token][2]:
            # Known active opponent moves are public facts, not hidden targets.
            for move_token in range(17, 21):
                if not obs['tokenMask'][move_token]:
                    continue
                move = move_hashes.get(obs['categorical'][move_token][0], -1)
                if move >= 0:
                    targets['moves_mask'][slot, move] = False
    # The paired opponent observation is used ONLY to assign this training label.
    targets['nextMove'] = torch.tensor(semantic_next_move(row, pair_index, move_hashes), dtype=torch.long)
    return targets


class BeliefDataset(Dataset):
    def __init__(self, rows, selected, targets):
        self.rows, self.selected, self.targets = rows, selected, targets

    def __len__(self):
        return len(self.selected)

    def __getitem__(self, index):
        return {**observation_tensors(self.rows[self.selected[index]]['observation']), **self.targets[index]}


class PublicBeliefModel(nn.Module):
    """Small standalone token/pooled-context MLP, with the unchanged ONNX inputs."""
    def __init__(self, vocab_sizes, width=48):
        super().__init__()
        self.category_embedding = nn.Embedding(HASH_BUCKETS + 1, width, padding_idx=0)
        self.kind_embedding = nn.Embedding(8, width, padding_idx=0)
        self.numeric_projection = nn.Linear(NUM_FEATURES, width)
        self.input_norm = nn.LayerNorm(width)
        self.body = nn.Sequential(nn.Linear(width * 4 + 1, width * 2), nn.GELU(), nn.LayerNorm(width * 2))
        self.heads = nn.ModuleDict({head: nn.Linear(width * 2, vocab_sizes[head]) for head in ('item', 'ability', 'tera', 'moves')})
        self.next_move = nn.Linear(width * 2, vocab_sizes['moves'])

    def forward(self, token_kinds, categorical, numeric, token_mask, legal_mask):
        scale = categorical.ne(0).sum(-1, keepdim=True).clamp(min=1).float().sqrt()
        cats = self.category_embedding(categorical).sum(2) / scale
        tokens = self.input_norm(cats + self.kind_embedding(token_kinds) + self.numeric_projection(numeric))
        mask = token_mask.unsqueeze(-1).float()
        context = (tokens * mask).sum(1) / mask.sum(1).clamp(min=1)
        opponent = tokens[:, 7:13]
        global_token = tokens[:, 0]
        moves_mask = mask[:, 17:21]
        public_moves = (tokens[:, 17:21] * moves_mask).sum(1) / moves_mask.sum(1).clamp(min=1)
        repeat = lambda value: value[:, None, :].expand(-1, 6, -1)
        legal_fraction = legal_mask.float().mean(-1, keepdim=True)
        state = self.body(torch.cat([opponent, repeat(context), repeat(global_token), repeat(public_moves), repeat(legal_fraction)], -1))
        active = (numeric[:, 7:13, 2:3] * mask[:, 7:13])
        active_state = (state * active).sum(1) / active.sum(1).clamp(min=1)
        return (*[self.heads[head](state) for head in ('item', 'ability', 'tera', 'moves')], self.next_move(active_state))


def run_epoch(model, loader, optimizer=None):
    model.train(optimizer is not None)
    totals, counts = Counter(), Counter()
    for batch in loader:
        with torch.set_grad_enabled(optimizer is not None):
            outputs = dict(zip(HEADS, model(*[batch[key] for key in INPUT_NAMES])))
            losses = []
            for head in ('item', 'ability', 'tera', 'nextMove'):
                valid = batch[head] >= 0
                if not valid.any():
                    continue
                logits, target = outputs[head][valid], batch[head][valid]
                losses.append(nn.functional.cross_entropy(logits, target))
                totals[head + '_correct'] += int((logits.argmax(-1) == target).sum())
                counts[head] += int(valid.sum())
            mask, target = batch['moves_mask'], batch['moves']
            if mask.any():
                loss = nn.functional.binary_cross_entropy_with_logits(outputs['moves'], target, reduction='none', pos_weight=torch.tensor(8.0))
                losses.append(3 * loss[mask].mean())
                eligible = (target.bool() & mask)
                top4 = outputs['moves'].masked_fill(~mask, -1e9).topk(min(4, outputs['moves'].shape[-1]), dim=-1).indices
                predicted = torch.zeros_like(mask).scatter_(-1, top4, True)
                totals['moves_recovered'] += int((predicted & eligible).sum())
                counts['moves'] += int(eligible.sum())
            if not losses:
                continue
            loss = sum(losses)
            if optimizer is not None:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 2.0)
                optimizer.step()
            totals['loss'] += float(loss.detach())
            counts['batches'] += 1
    return {'loss': totals['loss'] / max(1, counts['batches']),
            **{head + '_accuracy': totals[head + '_correct'] / max(1, counts[head]) for head in ('item', 'ability', 'tera', 'nextMove')},
            'hidden_moves_recall_at_4': totals['moves_recovered'] / max(1, counts['moves']),
            'target_counts': dict(counts)}


def prepare_data(filename, seed, val_fraction, max_per_game):
    rows = JsonlRows(filename)
    groups = defaultdict(list)
    for index, game in enumerate(rows.game_ids):
        groups[game].append(index)
    games = sorted(groups)
    if len(games) < 2:
        raise ValueError('At least two complete games are required for a leakage-safe validation split')
    random.Random(seed).shuffle(games)
    val_games = set(games[:max(1, round(len(games) * val_fraction))])
    selected = sorted(index for indices in groups.values() for index in
                      (indices if len(indices) <= max_per_game else [indices[i] for i in np.linspace(0, len(indices) - 1, max_per_game, dtype=int)]))
    selected_set = set(selected)
    vocab = {head: set() for head in ('item', 'ability', 'tera', 'moves')}
    pairs = defaultdict(lambda: defaultdict(list))
    audit = Counter()
    for index in range(len(rows)):
        row = rows[index]
        audit['rows'] += 1
        audit[f"schema_{row.get('schema')}"] += 1
        validate_public_observation(row['observation'])
        ordinary = ordinary_metadata(row)
        if ordinary is not None:
            pairs[(row['gameId'], row['turn'])][row['side']].append(ordinary)
        if index not in selected_set or row['gameId'] in val_games:
            continue
        for _, label in matched_slots(row):
            for head, field in [('item', 'item'), ('ability', 'ability'), ('tera', 'teraType')]:
                if isinstance(label.get(field), str):
                    vocab[head].add(to_id(label[field]) or 'none')
            vocab['moves'].update(to_id(move) for move in label.get('moves', []) if to_id(move))
    vocab = {head: sorted(values) for head, values in vocab.items()}
    if any(not values for values in vocab.values()):
        raise ValueError('No eligible labels for a required belief head')
    hash_classes = defaultdict(list)
    for index, move in enumerate(vocab['moves']):
        hash_classes[hash_feature('move', move)].append(index)
    move_hashes = {key: indices[0] for key, indices in hash_classes.items() if len(indices) == 1}
    targets = [make_targets(rows[index], vocab, pairs, move_hashes, audit) for index in selected]
    dataset = BeliefDataset(rows, selected, targets)
    train = [i for i, index in enumerate(selected) if rows.game_ids[index] not in val_games]
    val = [i for i, index in enumerate(selected) if rows.game_ids[index] in val_games]
    report = {**dict(audit), 'games': len(games), 'train_games': len(games) - len(val_games), 'val_games': len(val_games),
              'selected_rows': len(selected), 'train_rows': len(train), 'val_rows': len(val),
              'val_game_ids': sorted(val_games), 'move_hash_collisions': sum(len(ids) > 1 for ids in hash_classes.values()),
              'vocabulary_sizes': {key: len(value) for key, value in vocab.items()},
              'input_source': 'Only five observation tensors; no privileged fields or counterpart observations',
              'label_semantics': 'Original generated set; uniquely paired ordinary next-move identity',
              'heldout_vocabulary': 'Training-game matched revealed slots only; heldout unknown labels masked'}
    return dataset, train, val, vocab, report


def export_model(model, checkpoint_path, vocab, report, example):
    import onnxruntime as ort
    output = checkpoint_path.with_suffix('.onnx')
    model.eval()
    sample = tuple(example[key][None] for key in INPUT_NAMES)
    torch.onnx.export(model, sample, output, input_names=INPUT_NAMES, output_names=OUTPUT_NAMES,
                      dynamic_axes={name: {0: 'batch'} for name in INPUT_NAMES + OUTPUT_NAMES}, opset_version=17, dynamo=False)
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    session = ort.InferenceSession(str(output), sess_options=options, providers=['CPUExecutionProvider'])
    if set(item.name for item in session.get_inputs()) != set(INPUT_NAMES):
        raise ValueError('Belief export did not preserve the five-input contract')
    max_error = 0
    for batch_size in (1, 3):
        inputs = tuple(value.expand(batch_size, *value.shape[1:]).contiguous() for value in sample)
        with torch.no_grad():
            expected = model(*inputs)
        actual = session.run(None, {name: value.numpy() for name, value in zip(INPUT_NAMES, inputs)})
        for target, result in zip(expected, actual):
            np.testing.assert_allclose(target.numpy(), result, rtol=2e-4, atol=2e-4)
            max_error = max(max_error, float(np.max(np.abs(target.numpy() - result))))
    manifest = {'schemaVersion': 1, 'kind': 'auxiliary-public-beliefs', 'trained': True,
                'observationVersion': OBSERVATION_VERSION, 'format': 'gen9randombattle',
                'tokenCount': TOKEN_COUNT, 'catFeatures': CAT_FEATURES, 'numFeatures': NUM_FEATURES,
                'hashBuckets': HASH_BUCKETS, 'actionCount': ACTION_COUNT, 'opponentSlots': 6,
                'model': output.name, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'bytes': output.stat().st_size,
                'checkpointSha256': hashlib.sha256(checkpoint_path.read_bytes()).hexdigest(),
                'outputs': dict(zip(HEADS, OUTPUT_NAMES)), 'vocabulary': vocab,
                'targetSemantics': 'initial-generated-set', 'nextMoveSemantics': 'ordinary-counterpart-move-identity',
                'trainedParameters': sum(parameter.numel() for parameter in model.parameters()),
                'basePolicyModified': False, 'strengthValidated': False, 'onnxParityMaxError': max_error,
                'dataAudit': report}
    output.with_name(output.stem + '.manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    return {'onnx': str(output), 'bytes': manifest['bytes'], 'parity_max_error': max_error}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('data')
    parser.add_argument('--output', default='models/gen9randombattle/beliefs-smoke.pt')
    parser.add_argument('--epochs', type=int, default=4)
    parser.add_argument('--batch-size', type=int, default=256)
    parser.add_argument('--max-per-game', type=int, default=48)
    parser.add_argument('--width', type=int, default=48)
    parser.add_argument('--threads', type=int, default=2)
    parser.add_argument('--lr', type=float, default=0.002)
    parser.add_argument('--seed', type=int, default=37)
    parser.add_argument('--val-fraction', type=float, default=0.1)
    args = parser.parse_args()
    if args.epochs < 1 or args.max_per_game < 2 or not 0 < args.val_fraction < 1:
        raise ValueError('Invalid epochs, max-per-game or validation fraction')
    torch.set_num_threads(args.threads)
    torch.manual_seed(args.seed)
    started = time.monotonic()
    dataset, train, val, vocab, audit = prepare_data(args.data, args.seed, args.val_fraction, args.max_per_game)
    print('audit=' + json.dumps({key: value for key, value in audit.items() if key != 'val_game_ids'}), flush=True)
    model = PublicBeliefModel({head: len(values) for head, values in vocab.items()}, args.width)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.001)
    train_loader = DataLoader(Subset(dataset, train), batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(Subset(dataset, val), batch_size=args.batch_size)
    initial = run_epoch(model, val_loader)
    history = []
    for epoch in range(1, args.epochs + 1):
        metrics = {'epoch': epoch, 'train': run_epoch(model, train_loader, optimizer), 'val': run_epoch(model, val_loader)}
        history.append(metrics)
        print('epoch=' + json.dumps(metrics), flush=True)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    checkpoint = {'model': model.state_dict(), 'model_config': {'width': args.width}, 'vocabulary': vocab,
                  'observation_version': OBSERVATION_VERSION, 'training': 'supervised-public-beliefs',
                  'data_audit': audit, 'history': history}
    torch.save(checkpoint, output)
    export = export_model(model, output, vocab, audit, dataset[val[0]])
    result = {'device': 'cpu', 'seed': args.seed, 'initial_validation': initial, 'history': history,
              'audit': audit, 'export': export, 'elapsed_seconds': time.monotonic() - started,
              'scope': 'Bounded heldout-game prediction experiment; no playing-strength or calibration claim'}
    output.with_suffix('.metrics.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('result=' + json.dumps(export), flush=True)


if __name__ == '__main__':
    main()
