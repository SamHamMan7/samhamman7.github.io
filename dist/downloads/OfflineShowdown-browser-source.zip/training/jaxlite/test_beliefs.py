import copy
import unittest

import torch

from train_beliefs import (HASH_BUCKETS, PublicBeliefModel, hash_feature, make_targets,
                          matched_slots, observation_tensors, ordinary_metadata,
                          semantic_next_move)


def row(species='Pikachu'):
    obs = {'version': 2, 'meta': {'format': 'gen9randombattle'},
           'tokenKinds': [1] + [0] * 28, 'tokenMask': [1] + [0] * 28,
           'categorical': [[0] * 12 for _ in range(29)], 'numeric': [[0.] * 22 for _ in range(29)],
           'legalMask': [1] + [0] * 13}
    obs['tokenKinds'][7], obs['tokenMask'][7] = 3, 1
    obs['categorical'][7][0] = hash_feature('species', species)
    obs['numeric'][7][2] = 1
    return {'schema': 2, 'gameId': 'game-a', 'turn': 1, 'side': 'p1', 'action': 0, 'observation': obs,
            'privilegedOpponentTeam': [{'species': species, 'item': 'Light Ball', 'ability': 'Static', 'teraType': 'Electric', 'moves': ['thunderbolt', 'surf']},
                                       {'species': 'Bulbasaur', 'item': 'Eviolite', 'ability': 'Overgrow', 'teraType': 'Grass', 'moves': ['gigadrain']}]}


VOCAB = {'item': ['lightball', 'eviolite'], 'ability': ['static', 'overgrow'],
         'tera': ['electric', 'grass'], 'moves': ['thunderbolt', 'surf', 'gigadrain']}
MOVE_HASHES = {hash_feature('move', move): i for i, move in enumerate(VOCAB['moves'])}


class BeliefFirewallTests(unittest.TestCase):
    def test_exact_targets_never_change_inputs(self):
        original, changed = row(), row()
        changed['privilegedOpponentTeam'][0]['item'] = 'Eviolite'
        for key, value in observation_tensors(original['observation']).items():
            self.assertTrue(torch.equal(value, observation_tensors(changed['observation'])[key]))
        self.assertNotEqual(make_targets(original, VOCAB, {}, MOVE_HASHES)['item'][0], make_targets(changed, VOCAB, {}, MOVE_HASHES)['item'][0])

    def test_unseen_slots_are_never_labelled(self):
        target = make_targets(row(), VOCAB, {}, MOVE_HASHES)
        self.assertEqual(target['item'].tolist(), [0, -1, -1, -1, -1, -1])
        self.assertFalse(target['moves_mask'][1:].any())

    def test_revealed_facts_are_excluded_from_hidden_loss(self):
        record = row()
        record['observation']['categorical'][7][1:3] = [42, 43]
        record['observation']['categorical'][7][5] = 44
        record['observation']['tokenMask'][17] = 1
        record['observation']['categorical'][17][0] = hash_feature('move', 'thunderbolt')
        target = make_targets(record, VOCAB, {}, MOVE_HASHES)
        for head in ('item', 'ability', 'tera'):
            self.assertEqual(target[head][0], -1)
        self.assertFalse(target['moves_mask'][0, 0])
        self.assertTrue(target['moves_mask'][0, 1])

    def test_collision_and_illusion_labels_are_skipped(self):
        seen = {}
        for index in range(HASH_BUCKETS + 1):
            name = f'Species{index}'
            hashed = hash_feature('species', name)
            if hashed in seen:
                record = row(name)
                other = copy.deepcopy(record['privilegedOpponentTeam'][0])
                other['species'] = seen[hashed]
                record['privilegedOpponentTeam'].append(other)
                self.assertEqual(matched_slots(record), [])
                break
            seen[hashed] = name
        record = row()
        record['privilegedOpponentTeam'][1]['ability'] = 'Illusion'
        self.assertEqual(matched_slots(record), [])

    def test_exact_opponent_inputs_rejected(self):
        record = row()
        record['observation']['numeric'][7][17] = .4
        with self.assertRaisesRegex(ValueError, 'leaked'):
            matched_slots(record)

    def test_semantic_next_move_uses_actual_counterpart_move(self):
        record, counterpart = row(), row()
        counterpart['side'], counterpart['action'] = 'p2', 5
        counterpart['observation']['categorical'][14][0] = hash_feature('move', 'surf')
        pair = {('game-a', 1): {'p1': [ordinary_metadata(record)], 'p2': [ordinary_metadata(counterpart)]}}
        self.assertEqual(semantic_next_move(record, pair, MOVE_HASHES), 1)
        pair[('game-a', 1)]['p2'].append(ordinary_metadata(counterpart))
        self.assertEqual(semantic_next_move(record, pair, MOVE_HASHES), -1)
        counterpart['observation']['numeric'][0][5] = 1
        self.assertIsNone(ordinary_metadata(counterpart))

    def test_model_outputs_all_heads_and_masks_do_not_accept_labels(self):
        model = PublicBeliefModel({head: len(values) for head, values in VOCAB.items()}, width=16)
        inputs = observation_tensors(row()['observation'])
        outputs = model(*[value[None] for value in inputs.values()])
        self.assertEqual([list(value.shape) for value in outputs], [[1, 6, 2], [1, 6, 2], [1, 6, 2], [1, 6, 3], [1, 3]])
        self.assertTrue(all(torch.isfinite(value).all() for value in outputs))


if __name__ == '__main__':
    unittest.main()
