from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader, Subset

from dataset import JsonlBattleDataset
from model import JaxLiteModel, parameter_count, OBSERVATION_VERSION


def split_by_game(dataset, val_fraction: float, seed: int):
    groups: dict[str, list[int]] = {}
    for index, game_id in enumerate(dataset.rows.game_ids):
        key = game_id
        groups.setdefault(key, []).append(index)
    keys = list(groups)
    random.Random(seed).shuffle(keys)
    val_games = max(1, int(round(len(keys) * val_fraction))) if len(keys) > 1 else 0
    val_keys = set(keys[:val_games])
    train_indices = [i for key, values in groups.items() if key not in val_keys for i in values]
    val_indices = [i for key, values in groups.items() if key in val_keys for i in values]
    if not val_indices and len(train_indices) > 1:
        val_indices = [train_indices.pop()]
    return Subset(dataset, train_indices), Subset(dataset, val_indices)


def run_epoch(model, loader, optimizer, device):
    training = optimizer is not None
    model.train(training)
    totals = {"loss": 0.0, "policy": 0.0, "opponent": 0.0, "value": 0.0,
              "examples": 0, "policy_correct": 0, "opponent_correct": 0,
              "opponent_examples": 0, "brier_sum": 0.0, "value_examples": 0}
    started = time.monotonic()
    for batch_index, batch in enumerate(loader):
        batch = {key: value.to(device) for key, value in batch.items()}
        out = model(batch["token_kinds"], batch["categorical"], batch["numeric"], batch["token_mask"], batch["legal_mask"])
        policy_loss = nn.functional.cross_entropy(out["policy_logits"], batch["action"])

        opp_mask = batch["opponent_action"] >= 0
        opponent_loss = (nn.functional.cross_entropy(out["opponent_policy_logits"][opp_mask], batch["opponent_action"][opp_mask])
                         if opp_mask.any() else torch.zeros((), device=device))

        value_mask = torch.isfinite(batch["outcome"])
        if value_mask.any():
            target = (batch["outcome"][value_mask] + 1.0) / 2.0
            value_loss = nn.functional.binary_cross_entropy_with_logits(out["value_logit"][value_mask], target)
            probability = torch.sigmoid(out["value_logit"][value_mask])
            totals["brier_sum"] += float(torch.sum((probability - target) ** 2).detach())
            totals["value_examples"] += int(value_mask.sum())
        else:
            value_loss = torch.zeros((), device=device)

        loss = policy_loss + 0.35 * opponent_loss + 0.5 * value_loss
        if training:
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        n = batch["action"].shape[0]
        totals["examples"] += n
        totals["policy_correct"] += int((out["policy_logits"].argmax(dim=-1) == batch["action"]).sum())
        if opp_mask.any():
            totals["opponent_correct"] += int((out["opponent_policy_logits"][opp_mask].argmax(dim=-1) == batch["opponent_action"][opp_mask]).sum())
            totals["opponent_examples"] += int(opp_mask.sum())
        for key, value in [("loss", loss), ("policy", policy_loss), ("opponent", opponent_loss), ("value", value_loss)]:
            totals[key] += float(value.detach()) * n
        if training and (batch_index + 1) % 100 == 0:
            print(f"batches={batch_index + 1}/{len(loader)} examples={totals['examples']} elapsed={time.monotonic() - started:.1f}s", flush=True)

    denom = max(1, totals["examples"])
    return {
        "loss": totals["loss"] / denom,
        "policy_loss": totals["policy"] / denom,
        "opponent_loss": totals["opponent"] / denom,
        "value_loss": totals["value"] / denom,
        "policy_accuracy": totals["policy_correct"] / denom,
        "opponent_accuracy": totals["opponent_correct"] / max(1, totals["opponent_examples"]),
        "opponent_examples": totals["opponent_examples"],
        "value_brier": totals["brier_sum"] / max(1, totals["value_examples"]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("data")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--val-fraction", type=float, default=0.1)
    parser.add_argument("--output", default="models/gen9randombattle/jaxlite-bc.pt")
    parser.add_argument("--resume", help="Continue a saved BC checkpoint; --epochs is the total target epoch count.")
    parser.add_argument('--threads', type=int, default=4)
    args = parser.parse_args()
    torch.set_num_threads(args.threads)

    torch.manual_seed(args.seed)
    dataset = JsonlBattleDataset(args.data)
    if len(dataset) < 10:
        raise SystemExit("Need at least 10 examples for a smoke training run.")
    train, val = split_by_game(dataset, args.val_fraction, args.seed)
    train_loader = DataLoader(train, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val, batch_size=args.batch_size)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_config = {"d_model": 256, "nhead": 8, "layers": 4, "dim_feedforward": 1024, "dropout": 0.1}
    model = JaxLiteModel(**model_config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    print(f"device={device} parameters={parameter_count(model):,} train={len(train)} val={len(val)}")

    history = []
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device)
        if checkpoint.get('observation_version') != OBSERVATION_VERSION or checkpoint.get('model_config') != model_config:
            raise ValueError('Resume checkpoint has incompatible observation/model configuration')
        expected = {'examples': len(dataset), 'seed': args.seed, 'val_fraction': args.val_fraction}
        if checkpoint.get('data_split') != expected:
            raise ValueError('Resume dataset/split changed; preserve the original data, seed and validation fraction')
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        history = checkpoint['history']
        torch.set_rng_state(checkpoint['rng_state'].cpu())
        if device.type == 'cuda' and checkpoint.get('cuda_rng_state') is not None:
            torch.cuda.set_rng_state_all(checkpoint['cuda_rng_state'])
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    for epoch in range(len(history) + 1, args.epochs + 1):
        train_metrics = run_epoch(model, train_loader, optimizer, device)
        with torch.no_grad():
            val_metrics = run_epoch(model, val_loader, None, device)
        history.append({"epoch": epoch, "train": train_metrics, "val": val_metrics})
        print(f"epoch={epoch} train={train_metrics} val={val_metrics}")
        temporary = output.with_suffix(output.suffix + '.tmp')
        torch.save({
            'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
            'observation_version': OBSERVATION_VERSION, 'model_config': model_config,
            'history': history, 'training': 'behavior-cloning',
            'data_split': {'examples': len(dataset), 'seed': args.seed, 'val_fraction': args.val_fraction},
            'rng_state': torch.get_rng_state(),
            'cuda_rng_state': torch.cuda.get_rng_state_all() if device.type == 'cuda' else None,
        }, temporary)
        temporary.replace(output)
        print(f'checkpoint={output} epoch={epoch}', flush=True)

    metadata = output.with_suffix(output.suffix + ".json")
    metadata.write_text(json.dumps({
        "observation_version": OBSERVATION_VERSION,
        "parameters": parameter_count(model),
        "model_config": model_config,
        "examples": len(dataset),
        "train_examples": len(train),
        "val_examples": len(val),
        "final": history[-1],
    }, indent=2), encoding="utf-8")
    print(f"saved {output}")
    print(f"saved {metadata}")


if __name__ == "__main__":
    main()
