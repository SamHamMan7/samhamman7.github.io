from __future__ import annotations

import torch

from ppo_core import compute_gae, ppo_loss


def main():
    rewards = torch.tensor([0.0, 0.0, 1.0])
    values = torch.tensor([0.1, 0.2, 0.3])
    next_values = torch.tensor([0.2, 0.3, 0.0])
    dones = torch.tensor([0.0, 0.0, 1.0])
    advantages, returns = compute_gae(rewards, values, next_values, dones)
    assert advantages.shape == rewards.shape
    assert abs(float(returns[-1]) - 1.0) < 1e-5

    logits = torch.tensor([[2.0, 0.0], [0.0, 2.0], [1.0, 1.0]], requires_grad=True)
    actions = torch.tensor([0, 1, 0])
    old = torch.distributions.Categorical(logits=logits.detach()).log_prob(actions)
    value_logit = torch.zeros(3, requires_grad=True)
    loss = ppo_loss(logits, value_logit, actions, old, advantages, returns)
    assert torch.isfinite(loss["loss"])
    assert float(loss['approx_kl']) >= 0
    loss["loss"].backward()
    # The critic predicts signed [-1,1] values while export returns [0,1] win
    # probability. A terminal win/loss must train in the corresponding direction.
    for terminal in (-1.0, 1.0):
        _, target = compute_gae([0.0, terminal], [0.0, 0.0], [0.0, 0.0], [0.0, 1.0], lam=1.0)
        assert torch.allclose(target, torch.tensor([terminal, terminal]))
        critic = torch.zeros(2, requires_grad=True)
        result = ppo_loss(torch.zeros((2,2)), critic, torch.zeros(2,dtype=torch.long),
                          torch.full((2,), -torch.log(torch.tensor(2.0))), torch.ones(2), target)
        result['value_loss'].backward()
        assert bool((critic.grad * terminal < 0).all())
    print("ppo_core smoke test passed")


if __name__ == "__main__":
    main()
