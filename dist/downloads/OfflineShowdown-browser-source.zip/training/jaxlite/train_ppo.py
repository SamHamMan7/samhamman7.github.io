"""PPO trainer for pre-collected neural self-play rollouts (schema 3).

scripts/neural-rollouts.mjs supplies actual ONNX samples, old log probabilities
and signed values from @pkmn/sim games. scripts/neural-selfplay.mjs manages the
historical checkpoint league. Heuristic decisions cannot supply PPO ratios.
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import torch
from torch import nn

from model import JaxLiteModel, parameter_count, OBSERVATION_VERSION
from ppo_core import compute_gae, ppo_loss


def tensorize_observation(obs):
    return {
        "token_kinds": torch.tensor(obs["tokenKinds"], dtype=torch.long),
        "categorical": torch.tensor(obs["categorical"], dtype=torch.long),
        "numeric": torch.tensor(obs["numeric"], dtype=torch.float32),
        "token_mask": torch.tensor(obs["tokenMask"], dtype=torch.bool),
        "legal_mask": torch.tensor(obs["legalMask"], dtype=torch.bool),
    }


def load_rollouts(path: str | Path, gamma: float, lam: float):
    rows = []
    for line_number, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        row = json.loads(line)
        if row.get("schema") != 3:
            raise ValueError(f"line {line_number}: PPO requires schema 3")
        for field in ("oldLogProb", "oldValue", "nextValue", "reward", "done", "action", "observation"):
            if field not in row:
                raise ValueError(f"line {line_number}: missing {field}")
        rows.append(row)

    groups: dict[tuple[str, str], list[dict]] = {}
    for row in rows:
        key = (str(row.get("gameId")), str(row.get("side")))
        groups.setdefault(key, []).append(row)
    prepared = []
    for trajectory in groups.values():
        trajectory.sort(key=lambda r: int(r.get("sequence", 0)))
        rewards = torch.tensor([float(r["reward"]) for r in trajectory])
        values = torch.tensor([float(r["oldValue"]) for r in trajectory])
        next_values = torch.tensor([float(r["nextValue"]) for r in trajectory])
        dones = torch.tensor([float(bool(r["done"])) for r in trajectory])
        advantages, returns = compute_gae(rewards, values, next_values, dones, gamma=gamma, lam=lam)
        for row, advantage, ret in zip(trajectory, advantages, returns):
            prepared.append({**row, "advantage": float(advantage), "ppoReturn": float(ret)})
    return prepared


def load_model(path: str, device):
    checkpoint = torch.load(path, map_location=device)
    config = checkpoint.get("model_config") or {"d_model":256,"nhead":8,"layers":4,"dim_feedforward":1024,"dropout":0.1}
    model = JaxLiteModel(**config).to(device)
    model.load_state_dict(checkpoint["model"])
    return model, config


def batch_rows(rows, indices, device):
    obs = [tensorize_observation(rows[i]["observation"]) for i in indices]
    stack = lambda key: torch.stack([o[key] for o in obs]).to(device)
    return {
        "token_kinds": stack("token_kinds"),
        "categorical": stack("categorical"),
        "numeric": stack("numeric"),
        "token_mask": stack("token_mask"),
        "legal_mask": stack("legal_mask"),
        "action": torch.tensor([rows[i]["action"] for i in indices], dtype=torch.long, device=device),
        "opponent_action": torch.tensor([rows[i].get("opponentAction", -1) for i in indices], dtype=torch.long, device=device),
        "old_log_prob": torch.tensor([rows[i]["oldLogProb"] for i in indices], dtype=torch.float32, device=device),
        "advantage": torch.tensor([rows[i]["advantage"] for i in indices], dtype=torch.float32, device=device),
        "return": torch.tensor([rows[i]["ppoReturn"] for i in indices], dtype=torch.float32, device=device),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("rollouts")
    parser.add_argument("--init", required=True)
    parser.add_argument("--epochs", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--gamma", type=float, default=1.0)
    parser.add_argument("--lam", type=float, default=0.95)
    parser.add_argument("--clip", type=float, default=0.2)
    parser.add_argument("--entropy", type=float, default=0.01)
    parser.add_argument("--value-coef", type=float, default=0.5)
    parser.add_argument("--opponent-coef", type=float, default=0.15)
    parser.add_argument("--target-kl", type=float, default=0.015,
                        help="Stop updates when sampled policy KL exceeds this bound (0 disables).")
    parser.add_argument("--seed", type=int, default=11)
    parser.add_argument("--output", default="models/gen9randombattle/jaxlite-ppo.pt")
    parser.add_argument('--threads', type=int, default=4)
    args = parser.parse_args()
    torch.set_num_threads(args.threads)

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    rows = load_rollouts(args.rollouts, args.gamma, args.lam)
    if len(rows) < 10:
        raise SystemExit("Need at least 10 neural rollout rows.")
    model, config = load_model(args.init, device)
    model.eval()
    # Reject off-policy/mismatched rollouts instead of quietly manufacturing PPO.
    probe = batch_rows(rows, list(range(min(32,len(rows)))), device)
    with torch.no_grad():
        logits = model(probe['token_kinds'],probe['categorical'],probe['numeric'],probe['token_mask'],probe['legal_mask'])['policy_logits']
        log_probs = torch.distributions.Categorical(logits=logits).log_prob(probe['action'])
        max_logprob_error = float((log_probs-probe['old_log_prob']).abs().max())
    if max_logprob_error > 1e-3:
        raise ValueError(f'Rollouts do not match the initial policy: max logprob error {max_logprob_error}')
    print(f'initial_policy_logprob_max_error={max_logprob_error}')
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    print(f"device={device} parameters={parameter_count(model):,} rollouts={len(rows)}")

    history = []
    stopped_for_kl = False
    for epoch in range(1, args.epochs + 1):
        indices = list(range(len(rows)))
        random.shuffle(indices)
        metrics = {"loss":0.0,"policy":0.0,"value":0.0,"entropy":0.0,"opponent":0.0,"kl":0.0,"clip":0.0,"batches":0}
        # Rollouts use eval-mode ONNX. Keep dropout off while retaining autograd,
        # otherwise the PPO probability ratio changes before any parameter update.
        model.eval()
        for start in range(0, len(indices), args.batch_size):
            batch = batch_rows(rows, indices[start:start + args.batch_size], device)
            out = model(batch["token_kinds"], batch["categorical"], batch["numeric"], batch["token_mask"], batch["legal_mask"])
            core = ppo_loss(
                out["policy_logits"], out["value_logit"], batch["action"], batch["old_log_prob"],
                batch["advantage"], batch["return"], batch["legal_mask"], clip_ratio=args.clip,
                value_coef=args.value_coef, entropy_coef=args.entropy,
            )
            if args.target_kl > 0 and float(core['approx_kl']) > args.target_kl:
                print(f"early_stop=policy_kl epoch={epoch} kl={float(core['approx_kl'])}")
                stopped_for_kl = True
                break
            opp_mask = batch["opponent_action"] >= 0
            opponent_loss = (nn.functional.cross_entropy(out["opponent_policy_logits"][opp_mask], batch["opponent_action"][opp_mask])
                             if opp_mask.any() else torch.zeros((), device=device))
            loss = core["loss"] + args.opponent_coef * opponent_loss
            if not torch.isfinite(loss):
                raise ValueError('Nonfinite PPO loss; checkpoint was not updated')
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            metrics["loss"] += float(loss.detach()); metrics["policy"] += float(core["policy_loss"].detach())
            metrics["value"] += float(core["value_loss"].detach()); metrics["entropy"] += float(core["entropy"].detach())
            metrics["opponent"] += float(opponent_loss.detach()); metrics["kl"] += float(core["approx_kl"])
            metrics["clip"] += float(core["clip_fraction"]); metrics["batches"] += 1
        denom = max(1, metrics.pop("batches"))
        averaged = {key: value / denom for key, value in metrics.items()}
        history.append({"epoch": epoch, **averaged})
        print(f"epoch={epoch} {averaged}")
        if stopped_for_kl:
            break

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model": model.state_dict(), "model_config": config, "observation_version": OBSERVATION_VERSION,
        "training": "ppo", "history": history, "training_config": vars(args),
    }, output)
    output.with_suffix(output.suffix + ".json").write_text(json.dumps({
        "training":"ppo", "rollout_rows":len(rows), "parameters":parameter_count(model), "history":history,
        "training_config":vars(args), "stopped_for_kl":stopped_for_kl,
    }, indent=2), encoding="utf-8")
    print(f"saved {output}")


if __name__ == "__main__":
    main()
