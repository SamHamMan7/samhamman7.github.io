"""Reusable PPO/GAE core for the eventual online self-play loop.

This module is deliberately environment-agnostic so Ultra can connect it to a
batched Showdown rollout collector without rewriting the optimization math.
"""
from __future__ import annotations

import torch
from torch import nn


def compute_gae(rewards, values, next_values, dones, gamma: float = 1.0, lam: float = 0.95):
    rewards = torch.as_tensor(rewards, dtype=torch.float32)
    values = torch.as_tensor(values, dtype=torch.float32)
    next_values = torch.as_tensor(next_values, dtype=torch.float32)
    dones = torch.as_tensor(dones, dtype=torch.float32)
    if not (rewards.shape == values.shape == next_values.shape == dones.shape):
        raise ValueError("GAE tensors must have identical shapes")
    advantages = torch.zeros_like(rewards)
    gae = torch.zeros((), dtype=rewards.dtype, device=rewards.device)
    for t in range(rewards.numel() - 1, -1, -1):
        nonterminal = 1.0 - dones[t]
        delta = rewards[t] + gamma * next_values[t] * nonterminal - values[t]
        gae = delta + gamma * lam * nonterminal * gae
        advantages[t] = gae
    returns = advantages + values
    return advantages, returns


def ppo_loss(
    policy_logits,
    value_logit,
    actions,
    old_log_probs,
    advantages,
    returns,
    legal_mask=None,
    clip_ratio: float = 0.2,
    value_coef: float = 0.5,
    entropy_coef: float = 0.01,
):
    if legal_mask is not None:
        policy_logits = policy_logits.masked_fill(~legal_mask.bool(), -1e9)
    dist = torch.distributions.Categorical(logits=policy_logits)
    new_log_probs = dist.log_prob(actions.long())
    normalized_adv = (advantages - advantages.mean()) / (advantages.std(unbiased=False) + 1e-8)
    ratio = torch.exp(new_log_probs - old_log_probs)
    unclipped = ratio * normalized_adv
    clipped = torch.clamp(ratio, 1.0 - clip_ratio, 1.0 + clip_ratio) * normalized_adv
    policy_loss = -torch.minimum(unclipped, clipped).mean()

    signed_value = torch.sigmoid(value_logit) * 2.0 - 1.0
    value_loss = nn.functional.mse_loss(signed_value, returns)
    entropy = dist.entropy().mean()
    total = policy_loss + value_coef * value_loss - entropy_coef * entropy
    # Nonnegative estimator under the sampled old policy. The former sampled
    # log-ratio mean could be negative and conceal excessive shared-encoder
    # changes caused by value fitting.
    log_ratio = new_log_probs - old_log_probs
    approx_kl = ((ratio - 1.0) - log_ratio).mean().detach().clamp_min(0)
    clip_fraction = ((ratio - 1.0).abs() > clip_ratio).float().mean().detach()
    return {
        "loss": total,
        "policy_loss": policy_loss,
        "value_loss": value_loss,
        "entropy": entropy,
        "approx_kl": approx_kl,
        "clip_fraction": clip_fraction,
        "new_log_probs": new_log_probs,
    }
