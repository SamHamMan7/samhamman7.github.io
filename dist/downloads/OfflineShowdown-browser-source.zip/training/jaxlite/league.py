"""Verified local checkpoint league for real neural self-play.

An entry links a training checkpoint to the exact trained ONNX graph loaded by
the collector. Hash checks run on registration and sampling; a stale or edited
model is an explicit failure, never silently substituted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import re
import time
from pathlib import Path


def load(path: Path):
    if not path.exists():
        return {"version": 2, "checkpoints": []}
    league = json.loads(path.read_text(encoding="utf-8"))
    if league.get("version") not in (1, 2) or not isinstance(league.get("checkpoints"), list):
        raise ValueError("Unsupported checkpoint league manifest")
    return league


def save(path: Path, league):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(league, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def sha256(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_artifacts(checkpoint: str, onnx_manifest: str):
    checkpoint_path = Path(checkpoint).resolve(strict=True)
    manifest_path = Path(onnx_manifest).resolve(strict=True)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schemaVersion") != 1 or manifest.get("trained") is not True or manifest.get("format") != "gen9randombattle":
        raise ValueError("League requires a trained Random Battle ONNX manifest")
    if not isinstance(manifest.get("observationVersion"), int) or manifest["observationVersion"] < 1:
        raise ValueError("ONNX manifest has no observation version")
    if manifest.get("actionCount") != 14:
        raise ValueError("League checkpoint does not use the 14-action singles contract")
    name = manifest.get("model", "")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*\.onnx", name) or ".." in name:
        raise ValueError("League ONNX model must be a local filename")
    model_path = (manifest_path.parent / name).resolve(strict=True)
    if model_path.parent != manifest_path.parent:
        raise ValueError("ONNX model escaped its manifest directory")
    model_hash, checkpoint_hash = sha256(model_path), sha256(checkpoint_path)
    if model_hash != manifest.get("sha256"):
        raise ValueError("League ONNX model SHA-256 mismatch")
    if checkpoint_hash != manifest.get("checkpointSha256", manifest.get("checkpointHash")):
        raise ValueError("ONNX manifest does not match the training checkpoint SHA-256")
    return {"path": str(checkpoint_path), "onnxManifest": str(manifest_path),
            "checkpointSha256": checkpoint_hash, "onnxSha256": model_hash,
            "onnxManifestSha256": sha256(manifest_path), "observationVersion": manifest["observationVersion"]}


def verify_entry(entry):
    if not entry.get("onnxManifest"):
        raise ValueError(f"Checkpoint has no verified ONNX manifest: {entry.get('path')}")
    verified = verify_artifacts(entry["path"], entry["onnxManifest"])
    for field in ("checkpointSha256", "onnxSha256", "onnxManifestSha256", "observationVersion"):
        if entry.get(field) != verified[field]:
            raise ValueError(f"Registered league checkpoint changed: {field}")
    return entry


def verify(path: Path):
    league = load(path)
    for entry in league["checkpoints"]:
        verify_entry(entry)
    return {"verified": len(league["checkpoints"]), "checkpoints": league["checkpoints"]}


def add(path: Path, checkpoint: str, tag: str, parent: str | None, onnx_manifest: str):
    league = load(path)
    artifacts = verify_artifacts(checkpoint, onnx_manifest)
    previous = next((entry for entry in league["checkpoints"] if entry.get("path") == artifacts["path"]), None)
    if previous:
        verify_entry(previous)
        if previous["onnxSha256"] != artifacts["onnxSha256"]:
            raise ValueError("Cannot replace an already registered checkpoint with different weights")
        return previous
    if league["checkpoints"] and any(entry.get("observationVersion") != artifacts["observationVersion"] for entry in league["checkpoints"]):
        raise ValueError("A league cannot mix observation versions; create a new league")
    parent_path = str(Path(parent).resolve()) if parent else None
    if parent_path and not any(entry.get("path") == parent_path for entry in league["checkpoints"]):
        raise ValueError("Parent checkpoint is not registered in this league")
    entry = {**artifacts, "tag": tag, "parent": parent_path, "created": int(time.time())}
    league["version"] = 2
    league["checkpoints"].append(entry)
    save(path, league)
    return entry


def sample(path: Path, seed: int, newest_weight: float = 0.45):
    checkpoints = verify(path)["checkpoints"]
    if not checkpoints:
        raise SystemExit("league is empty")
    if len(checkpoints) == 1:
        return checkpoints[0]
    if not 0 <= newest_weight <= 1:
        raise ValueError("newest_weight must be between 0 and 1")
    rng = random.Random(seed)
    newest = checkpoints[-1]
    if rng.random() < newest_weight:
        return newest
    # No unmeasured Elo/PFSP weights: retain a simple reproducible historical mix.
    return rng.choice(checkpoints[:-1])


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--league", default="models/gen9randombattle/league.json")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add"); a.add_argument("checkpoint"); a.add_argument("--tag", default="checkpoint"); a.add_argument("--parent"); a.add_argument("--onnx-manifest", required=True)
    s = sub.add_parser("sample"); s.add_argument("--seed", type=int, default=1); s.add_argument("--newest-weight", type=float, default=0.45)
    sub.add_parser("list")
    sub.add_parser("verify")
    args = p.parse_args()
    path = Path(args.league)
    if args.cmd == "add": print(json.dumps(add(path, args.checkpoint, args.tag, args.parent, args.onnx_manifest), indent=2))
    elif args.cmd == "sample": print(json.dumps(sample(path, args.seed, args.newest_weight), indent=2))
    elif args.cmd == "verify": print(json.dumps(verify(path), indent=2))
    else: print(json.dumps(load(path), indent=2))


if __name__ == "__main__":
    main()
