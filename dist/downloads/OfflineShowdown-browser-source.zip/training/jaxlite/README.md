# JaxLite Stage 2 training bootstrap

This folder now supports three progressively less-teacher-dependent stages.
It is still **not** a finished Jaxcalibur clone.

## 1. Behavior-cloning warm start

```powershell
node scripts/neural-generate-data.mjs --games 500 --difficulty "Very Strong" --output artifacts/neural/rb-vstrong-500.jsonl
node scripts/neural-dataset-report.mjs artifacts/neural/rb-vstrong-500.jsonl
python -m pip install -r training/jaxlite/requirements.txt
python training/jaxlite/train_bc.py artifacts/neural/rb-vstrong-500.jsonl --epochs 8
```

The model has about 7.5M parameters and learns three heads immediately:
our action policy, win probability, and opponent next action.

## 2. Trajectory / advantage-weighted bridge

Generate sequential trajectories:

```powershell
node scripts/neural-generate-trajectories.mjs --games 500 --difficulty "Very Strong" --output artifacts/neural/rb-trajectories-500.jsonl
node scripts/neural-trajectory-report.mjs artifacts/neural/rb-trajectories-500.jsonl
```

Then initialize from BC and advantage-weight the teacher decisions:

```powershell
python training/jaxlite/train_awbc.py artifacts/neural/rb-trajectories-500.jsonl --init models/gen9randombattle/jaxlite-bc.pt --epochs 6
```

This is only a bridge. It preferentially imitates decisions from winning
trajectories; it is **not PPO** and cannot by itself surpass a weak teacher
reliably.

## 3. PPO core for real neural self-play

`ppo_core.py` and `train_ppo.py` implement GAE and clipped PPO optimization.
The trainer expects **schema 3 neural rollouts** containing the policy's actual
`oldLogProb`, `oldValue`, `nextValue`, rewards, and done flags.

Do not fabricate these from heuristic data.

Ultra needs to connect a neural rollout collector to `@pkmn/sim`, then:

```powershell
python training/jaxlite/train_ppo.py artifacts/neural/neural-rollouts.jsonl --init models/gen9randombattle/jaxlite-awbc.pt
```

The `league.py` helper maintains a small historical checkpoint pool so self-play
is not only newest-vs-newest.

## Training-only privileged labels

```powershell
node scripts/neural-generate-privileged-data.mjs --games 100 --output artifacts/neural/rb-privileged.jsonl
```

This collector gives `chooseAction()` only the sanitized PlayerView, but records
the exact opposing random team under `privilegedOpponentTeam` **afterward as a
training label**. It is intended for future item/ability/move/Tera prediction
heads. Never concatenate privileged labels into the live observation.

## Export

```powershell
python training/jaxlite/export_onnx.py models/gen9randombattle/jaxlite-awbc.pt
```

The project still needs a production ONNX/native inference backend before the
weights can drive the Android AI.
