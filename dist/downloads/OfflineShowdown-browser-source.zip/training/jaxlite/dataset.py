from __future__ import annotations

import json
from pathlib import Path

import torch
from torch.utils.data import Dataset
from model import OBSERVATION_VERSION


class JsonlRows:
    """Indexed disk rows: thousands of full games need not fit in Python RAM."""
    def __init__(self, source):
        source = Path(source)
        paths = sorted(source.glob('*.jsonl')) if source.is_dir() else [source]
        self.index = []
        self.game_ids = []
        self.handles = []
        for path in paths:
            handle = path.open('rb')
            file_index = len(self.handles)
            self.handles.append(handle)
            while True:
                offset = handle.tell()
                line = handle.readline()
                if not line:
                    break
                if not line.strip():
                    continue
                row = json.loads(line)
                if row.get('schema') not in (1, 2, 3) or row.get('observation', {}).get('version') != OBSERVATION_VERSION:
                    raise ValueError(f'Unsupported observation/schema: {path} byte {offset}')
                self.index.append((file_index, offset))
                self.game_ids.append(str(row.get('gameId') or f'{path.name}-{offset}'))

    def __len__(self):
        return len(self.index)

    def __getitem__(self, index):
        file_index, offset = self.index[index]
        handle = self.handles[file_index]
        handle.seek(offset)
        return json.loads(handle.readline())


class JsonlBattleDataset(Dataset):
    """Loads Stage-1 BC rows and Stage-2 trajectory rows.

    Schema 1 uses `outcome`; schemas 2/3 use `return`. Observation version must
    match the model; old v1 files cannot silently enter a v2 training run.
    """

    def __init__(self, path: str | Path):
        self.rows = JsonlRows(path)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        obs = row["observation"]
        outcome = row.get("outcome", row.get("return"))
        return {
            "token_kinds": torch.tensor(obs["tokenKinds"], dtype=torch.long),
            "categorical": torch.tensor(obs["categorical"], dtype=torch.long),
            "numeric": torch.tensor(obs["numeric"], dtype=torch.float32),
            "token_mask": torch.tensor(obs["tokenMask"], dtype=torch.bool),
            "legal_mask": torch.tensor(obs["legalMask"], dtype=torch.bool),
            "action": torch.tensor(row["action"], dtype=torch.long),
            "opponent_action": torch.tensor(row.get("opponentAction", -1), dtype=torch.long),
            "outcome": torch.tensor(float("nan") if outcome is None else float(outcome), dtype=torch.float32),
            "reward": torch.tensor(float(row.get("reward", 0.0)), dtype=torch.float32),
            "done": torch.tensor(bool(row.get("done", False)), dtype=torch.bool),
        }
