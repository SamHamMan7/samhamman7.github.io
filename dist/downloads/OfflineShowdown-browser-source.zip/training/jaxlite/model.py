"""Compact Jaxcalibur-inspired policy/value/opponent-policy model.

This is intentionally only the Milestone-A model scaffold. It consumes the fixed
public observation contract emitted by src/ai/neural/observation.js.
"""
from __future__ import annotations

import torch
from torch import nn

OBSERVATION_VERSION = 2
ACTION_COUNT = 14
HISTORY_TOKEN_START = 21
HISTORY_TOKEN_COUNT = 8
TOKEN_COUNT = HISTORY_TOKEN_START + HISTORY_TOKEN_COUNT
CAT_FEATURES = 12
NUM_FEATURES = 22
HASH_BUCKETS = 16384
TOKEN_KIND_COUNT = 8


class JaxLiteModel(nn.Module):
    def __init__(
        self,
        d_model: int = 256,
        nhead: int = 8,
        layers: int = 4,
        dim_feedforward: int = 1024,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.category_embedding = nn.Embedding(HASH_BUCKETS + 1, d_model, padding_idx=0)
        self.kind_embedding = nn.Embedding(TOKEN_KIND_COUNT, d_model, padding_idx=0)
        self.position_embedding = nn.Embedding(TOKEN_COUNT, d_model)
        self.numeric_projection = nn.Linear(NUM_FEATURES, d_model)
        self.input_norm = nn.LayerNorm(d_model)

        layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=layers, norm=nn.LayerNorm(d_model))
        self.policy_head = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, ACTION_COUNT))
        self.value_head = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.GELU(), nn.Linear(d_model // 2, 1))
        self.opponent_policy_head = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, ACTION_COUNT))

    def forward(self, token_kinds, categorical, numeric, token_mask=None, legal_mask=None):
        # categorical: [B, T, C]. Sum hashed categorical embeddings within each token.
        cat = self.category_embedding(categorical.long()).sum(dim=2)
        kinds = self.kind_embedding(token_kinds.long())
        positions = self.position_embedding(torch.arange(token_kinds.shape[1], device=token_kinds.device))[None, :, :]
        nums = self.numeric_projection(numeric.float())
        x = self.input_norm(cat + kinds + positions + nums)

        padding_mask = None if token_mask is None else ~token_mask.bool()
        x = self.encoder(x, src_key_padding_mask=padding_mask)
        state = x[:, 0]  # global token

        policy = self.policy_head(state)
        if legal_mask is not None:
            policy = policy.masked_fill(~legal_mask.bool(), -1e9)
        return {
            "policy_logits": policy,
            "value_logit": self.value_head(state).squeeze(-1),
            "opponent_policy_logits": self.opponent_policy_head(state),
        }


def parameter_count(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


if __name__ == "__main__":
    model = JaxLiteModel()
    print(f"parameters={parameter_count(model):,}")
