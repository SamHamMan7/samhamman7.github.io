# Offline Showdown practice

The actual Pokémon Showdown client with a local BattleStream transport and offline AI. It bundles Showdown's battle room, renderer, teambuilder, animations, controls, tooltips and artwork. No account, cloud inference or manually started server is required on the phone.

## Try it

Install `artifacts/OfflineShowdown-v1.apk` on your Android phone. See [Android installation and build instructions](docs/android.md). Current formats: Gen 9 OU, Random Battle and Random Doubles. Choose a format and press **Offline Battle**. Very Strong is the default and strongest validated local option. For OU, import or create your team in Showdown's **Teambuilder**, validate it and select it for battle. **Watch AI Battle** runs two local AIs. A specific-opponent matchup selector is not included in v1.

**Neural Preview** is experimental and uses a real bundled offline model for Random Battle singles, with Very Strong fallback on loading/inference failures or unsupported formats. It is currently much weaker than Very Strong. Training and checkpoint promotion remain separate from the stable app. See [neural training commands and limits](docs/neural-training.md).

The app has completed offline games in Chrome and an Android 15 emulator. Physical Pixel 9a performance has not yet been verified. AI strength is tested against local baselines; no ladder Elo is claimed. The project remains under active development; [PROGRESS.md](PROGRESS.md) records current evidence, limits and the next task.

## Develop

```powershell
npm ci
npm run prepare:client
npm run prepare:assets
npm test
npm run build
npm start
```

Open `http://127.0.0.1:4173` for desktop development. Node is a development dependency only. The browser test uses locally installed Chrome:

```powershell
node scripts/showdown-browser-test.mjs
node scripts/ai-benchmark.mjs 100 gen9randombattle Strong greedy
```

See [migration notes](docs/showdown-migration.md) and [engineering notes](docs/engineering.md). Versions, asset hashes, environments and team sources are recorded in the repository. Initial preparation downloads official resources; ordinary builds and all battles use local files. Preserve the prepared assets and data snapshot for reproducible releases because upstream URLs can change.

Code is supplied under AGPL-3.0 with preserved third-party notices. `scripts/source-package.ps1` creates `artifacts/OfflineShowdown-source.zip` with the application, pinned upstream source and data, modifications, and build scripts. Distribute this corresponding source alongside the APK. Artwork/audio retain their separate ownership and notices.
