# AI risk-calibration patch

This patch is aimed specifically at the playtest complaint that Very Strong plays too recklessly, overuses offensive Tera, and repeats overly deterministic lines.

## Main changes

- Replaces the old `mean + absolute-worst-case` blend with a weighted lower-tail (CVaR-like) evaluation plus variance penalty.
- Makes risk tolerance state-dependent: when a good line / material edge exists, Strong and Very Strong prefer robust lines; when behind, the downside penalty relaxes so the AI can accept more variance.
- Adds a team-resource opportunity cost for Terastallization based on remaining teammates.
- Defensive Tera can earn back that cost when it actually improves expected HP/survival; marginal offensive Tera must justify consuming the one-use resource.
- Adds extra penalty for spending Tera on a mon still likely to be removed immediately.
- Values losing a healthy Pokemon more heavily than losing an already-damaged one.
- Penalizes execution variance from inaccurate moves, and scales targeted status utility by accuracy.
- Improves opponent switch modeling: revealed switch-ins are ranked by switch-in damage, counter-pressure, and hazards instead of receiving the same generic rank.
- Continuation search now allows opponent switch responses instead of move-only responses.
- Adds seeded mixed play only among near-equal robust actions, so Very Strong is less exploitable without randomly choosing bad moves.
- Applies similar Tera reservation / accuracy logic to doubles, with small near-equal mixing on Very Strong.

## What this is not

This is still a heuristic/search policy, not a trained Jaxcalibur-style policy/value/opponent-action neural model. It moves the current engine toward Jaxcalibur-like behavior (response distributions, robust mixed play, resource preservation), but a learned policy prior / opponent-action head would be a later architectural step.

## Verification performed here

`node --check` passes for all six files in the supplied `ai/` folder.

The full runtime battle suite could not be executed from the uploaded folder alone because the rest of the project and its `@pkmn/sim` / `@smogon/calc` dependencies were not included in this zip.

## Recommended integration test

After replacing `src/ai` with this folder in the real project:

```powershell
npm.cmd test
node scripts/ai-benchmark.mjs 20 gen9randombattle "Very Strong" greedy
```

More importantly, add fixed regression positions for:

1. offensive Tera that gains one KO but leaves the user easily revenge-killed;
2. a safe switch vs. a high-upside prediction while ahead;
3. defensive Tera that is actually necessary to preserve a win condition;
4. low-accuracy nuke vs. a reliable winning line;
5. same ambiguous position under many seeds: multiple good moves may appear, but obviously inferior lines should not.
