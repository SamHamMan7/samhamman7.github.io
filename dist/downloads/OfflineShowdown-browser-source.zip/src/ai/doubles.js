import {Dex} from '@pkmn/sim';
import {fromRequest, damageEstimate, effectiveSpeed, hazardCost, toID} from './damage.js';
import {opponentHypotheses, possibleMoves} from './priors.js';

const living = mon => mon && !mon.fainted && !String(mon.condition).includes('fnt') && (mon.hpFraction ?? 1) > 0;
const PROTECT_MOVES = new Set(['protect','detect','spikyshield','banefulbunker','silktrap','burningbulwark','kingsshield','obstruct','endure','maxguard']);
const protect = move => PROTECT_MOVES.has(toID(move));
const protectSuccessChance = mon => protect(mon?.lastMove) ? 1 / 3 : 1;
const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, value));

function volatileIDs(mon) {
  const value=mon?.volatiles,ids=new Set();
  const add=item=>{if(!item)return;if(typeof item==='string')ids.add(toID(item));else if(typeof item==='object'&&(item.id||item.name))ids.add(toID(item.id||item.name));};
  if(!value)return ids;
  if(Array.isArray(value)||value instanceof Set)for(const item of value)add(item);
  else if(typeof value==='object')for(const [key,item] of Object.entries(value)){ids.add(toID(key));add(item);}
  else add(value);
  return ids;
}
const hasVolatile=(mon,id)=>volatileIDs(mon).has(toID(id));
const recoveryMove=id=>['recover','roost','slackoff','softboiled','milkdrink','shoreup','strengthsap','synthesis','morningsun','moonlight','rest','wish'].includes(toID(id));
function seededRandom(seed) {
  let value=(Number(seed)||1)>>>0;
  return ()=>{value+=0x6D2B79F5;let t=value;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};
}

/** Joint action evaluation from a player view. Damage resolution remains in Showdown. */
export function chooseDoubles(view, {difficulty='Strong',seed=1} = {}) {
  const started=performance.now(), request=view.request;
  if (!request || request.wait) return {choice:null};
  const publicOwn=view.own?.active || [], publicFoes=view.opponent?.active || [];
  const roster=request.side.pokemon.map(mon=>fromRequest(mon, publicOwn.find(p=>p && p.ident?.slice(4) === mon.ident?.slice(3)) || {}));
  const active=roster.filter(mon=>mon.active);
  const field={...view.field,gameType:'Doubles'};
  const foes=publicFoes.map(mon=>mon && opponentHypotheses(mon,view.format,difficulty==='Medium'?1:2)[0]);
  const cache=new Map(); let calculations=0, calcFailures=0;
  const damage=(attacker,defender,move,reverse=false)=>{
    const key=JSON.stringify([attacker,defender,move,reverse]);
    if(cache.has(key))return cache.get(key);
    let result;
    try {result=damageEstimate(attacker,defender,move,field,reverse).mean;}
    catch {calcFailures++;result=0;}
    calculations++;cache.set(key,result);return result;
  };
  const threat=(mon)=>foes.filter(living).reduce((total,foe)=>total+Math.max(0,...possibleMoves(foe,5,view.format).map(move=>damage(foe,mon,move,true)))*.58,0);
  const width=difficulty==='Medium'?5:difficulty==='Very Strong'?12:8;
  const count=request.active?.length || request.forceSwitch?.length || active.length;
  const bench=roster.map((mon,i)=>({mon,slot:i+1})).filter(x=>!x.mon.active&&living(x.mon));
  const livingCount=roster.filter(living).length;
  const forcedCount=request.forceSwitch?.filter(Boolean).length || 0;
  const candidates=Array.from({length:count},(_,slot)=>{
    const mon=active[slot], req=request.active?.[slot], forced=request.forceSwitch?.[slot];
    if(mon?.reviving) return roster.flatMap((fainted,i)=>living(fainted)?[]:[{choice:`switch ${i+1}`,kind:'revive',switchSlot:i+1,slot,damage:[0,0],score:Math.max(Dex.species.get(fainted.species).baseStats.atk,Dex.species.get(fainted.species).baseStats.spa)}]);
    if(request.forceSwitch && !forced || !request.forceSwitch && (!req || !living(mon) || mon.commanding)) return [{choice:'pass',score:0,slot,damage:[0,0]}];
    const options=[];
    if(forced || !req?.trapped) for(const {mon:replacement,slot:switchSlot} of bench) {
      const offense=Math.max(0,...foes.filter(living).flatMap(foe=>replacement.moves.map(move=>damage(replacement,foe,move))));
      const danger=threat(replacement), cost=hazardCost(replacement,field.sideConditions);
      options.push({choice:`switch ${switchSlot}`,kind:'switch',switchSlot,slot,damage:[0,0],
        score:offense*27-danger*(forced?18:52)-cost*110+(replacement.hpFraction||1)*8-(forced?0:17)});
    }
    if(forced) {
      // If two faint but only one reserve remains, Showdown permits one explicit pass.
      if(forcedCount>bench.length)options.push({choice:'pass',slot,score:-100,damage:[0,0]});
      return options;
    }
    const incoming=threat(mon);
    for(const [moveIndex,moveReq] of (req.moves||[]).entries()) {
      if(moveReq.disabled || moveReq.pp===0)continue;
      const move=Dex.moves.get(moveReq.id||moveReq.move), target=moveReq.target;
      const targets=['normal','any','adjacentFoe'].includes(target) ? foes.map((f,i)=>living(f)?i+1:null).filter(Boolean)
        : ['adjacentAlly','adjacentAllyOrSelf'].includes(target) ? active.map((a,i)=>living(a)&&(i!==slot||target==='adjacentAllyOrSelf')?-(i+1):null).filter(Boolean) : [0];
      for(const teraType of [null,...(req.canTerastallize?[req.canTerastallize]:[])]) for(const location of targets) {
        const actor=teraType?{...mon,terastallized:true,teraType}:mon;
        const dealt=foes.map((foe,i)=>living(foe)&&(location===i+1||['allAdjacent','allAdjacentFoes','all','randomNormal'].includes(target))?damage(actor,foe,move.name):0);
        let score=0;
        if(move.category!=='Status') {
          score=dealt.reduce((total,d,i)=>total+Math.min(d,foes[i]?.hpFraction||0)*92+(d >= (foes[i]?.hpFraction||1)?22:0),0);
          if(target==='allAdjacent')for(const [allyIndex,ally] of active.entries())if(allyIndex!==slot&&living(ally))score-=damage(actor,ally,move.name)*115;
          if(move.drain)score+=Math.min(1-actor.hpFraction,dealt.reduce((a,b)=>a+b,0)*move.drain[0]/move.drain[1])*35;
          if(move.recoil)score-=dealt.reduce((a,b)=>a+b,0)*move.recoil[0]/move.recoil[1]*25;
          if(move.id==='fakeout')score+=(mon.activeTurns||0)===0&&!mon.lastMove?16:-60;
        } else {
          if(protect(move.id)) {
            const successChance=protectSuccessChance(actor);
            const blockValue=incoming*42+(actor.hpFraction<.4?8:0);
            // A double Protect is not a guaranteed free turn: only the success
            // branch blocks damage, while the failure branch still eats the hit.
            score=blockValue*successChance-incoming*(1-successChance)*30-(successChance<1?12:8);
          }
          else if(move.heal) {
            const heal=Math.min(1-actor.hpFraction,move.heal[0]/move.heal[1]);
            const endHP=clamp(actor.hpFraction+heal-incoming);
            const netGain=Math.max(0,endHP-actor.hpFraction);
            const withoutHeal=clamp(actor.hpFraction-incoming);
            const survivalGain=Math.max(0,endHP-withoutHeal);
            score=netGain*92+Math.min(.35,survivalGain)*24;
            if(toID(actor.lastMove)===move.id&&netGain<.08)score-=24;
            if(incoming>=heal*.85&&netGain<.04)score-=12;
          }
          else if(move.id==='tailwind')score=(field.sideConditions||[]).some(c=>toID(c)==='tailwind')?-25:38;
          else if(move.id==='trickroom')score=foes.filter(living).every(f=>effectiveSpeed(actor,field)<effectiveSpeed(f,field,true))&&!field.trickRoom?30:-12;
          else if(move.id==='helpinghand')score=8;
          else if(['followme','ragepowder'].includes(move.id))score=actor.hpFraction>.6?12:-8;
          else if(move.id==='leechseed'&&location>0) {
            const foe=foes[location-1],types=Dex.species.get(foe.species).types;
            score=(types.includes('Grass')||hasVolatile(foe,'leechseed'))?-85:22;
            if(toID(actor.lastMove)==='leechseed'&&hasVolatile(foe,'leechseed'))score-=35;
          }
          else if(move.boosts)score=Object.values(move.boosts).reduce((a,b)=>a+b,0)*9-incoming*30;
          else if(move.status&&location>0) {
            const foe=foes[location-1],types=Dex.species.get(foe.species).types;
            const immune=foe.status||(move.status==='brn'&&types.includes('Fire'))||(move.status==='par'&&types.includes('Electric'))||(['psn','tox'].includes(move.status)&&types.some(t=>['Poison','Steel'].includes(t)));
            score=immune?-55:move.status==='slp'?35:22;
          } else score=-8;
        }
        const danger=teraType?threat(actor):incoming;
        const fastKO=dealt.some((d,i)=>d>=(foes[i]?.hpFraction||1)&&(move.priority>0||effectiveSpeed(actor,field)>effectiveSpeed(foes[i],field,true)));
        score-=Math.min(actor.hpFraction,danger)*(fastKO?8:23);
        const accuracy=move.accuracy===true?1:clamp(Number(move.accuracy||100)/100);
        if(move.target!=='self')score-=(1-accuracy)*(difficulty==='Very Strong'?8:4);
        let teraCost=0;
        if(teraType) {
          const reserveScale=difficulty==='Very Strong'?1.15:difficulty==='Strong'?1:0.8;
          const defensiveGain=Math.max(0,incoming-danger);
          teraCost=Math.max(2,(5+Math.max(0,livingCount-1)*2)*reserveScale-defensiveGain*30);
          if(actor.hpFraction<.28&&defensiveGain<.08)teraCost+=4;
          score-=teraCost;
        }
        options.push({kind:'move',choice:`move ${moveIndex+1}${location?' '+location:''}${teraType?' terastallize':''}`,slot,move:move.id,tera:!!teraType,teraCost,damage:dealt,score,actor,protect:protect(move.id),protectChance:protect(move.id)?protectSuccessChance(actor):0});
      }
    }
    // Keep coverage/Protect alternatives while bounding joint combinations.
    return options.sort((a,b)=>b.score-a.score).slice(0,width);
  });
  const joint=[];
  for(const a of candidates[0]||[]) for(const b of candidates[1]||[{choice:'pass',score:0,damage:[0,0]}]) {
    if(a.switchSlot&&a.switchSlot===b.switchSlot || a.tera&&b.tera)continue;
    const revivalCount=active.filter(m=>m.reviving).length;
    if(request.forceSwitch && [a,b].filter(x=>x.kind==='switch').length!==Math.min(forcedCount-revivalCount,bench.length))continue;
    let score=a.score+b.score;
    foes.forEach((foe,i)=>{if(!living(foe))return;const d=(a.damage[i]||0)+(b.damage[i]||0);score-=Math.max(0,d-foe.hpFraction)*50;if(d>=foe.hpFraction&&(a.damage[i]||0)<foe.hpFraction&&(b.damage[i]||0)<foe.hpFraction)score+=24;});
    for(const [support,partner] of [[a,b],[b,a]]) {
      if(support.move==='helpinghand'&&partner.kind==='move')score+=partner.damage.reduce((x,y)=>x+y,0)*35;
      if(support.protect&&partner.move&&Dex.moves.get(partner.move).target==='allAdjacent')score+=damage(partner.actor,support.actor,partner.move)*115*(support.protectChance||0);
    }
    joint.push({choice:[a.choice,b.choice].slice(0,count).join(', '),score,teraCost:(a.teraCost||0)+(b.teraCost||0)});
  }
  if(!joint.length) throw new Error('No joint doubles command satisfies the request');
  joint.sort((a,b)=>b.score-a.score);
  let best=joint[0],selectedRank=1;
  if(difficulty==='Very Strong') {
    const pool=joint.filter(candidate=>candidate.score>=joint[0].score-3.5).slice(0,5);
    if(pool.length>1) {
      const weights=pool.map(candidate=>Math.exp((candidate.score-pool[0].score)/1.8));
      const total=weights.reduce((a,b)=>a+b,0),random=seededRandom((Number(seed)||1)^Math.imul((view.turn||0)+1,0x9e3779b1));
      let pick=random()*total;
      for(let i=0;i<pool.length;i++){pick-=weights[i];if(pick<=0){best=pool[i];break;}}
      selectedRank=joint.indexOf(best)+1;
    }
  }
  return {...best,reason:`Joint target, survival, spread damage and support evaluation${selectedRank>1?' with a near-equal mixed line':''}.`,diagnostics:{policy:'risk-calibrated-joint-doubles-v2',selectedRank,calculations,calcFailures,ms:performance.now()-started}};
}
