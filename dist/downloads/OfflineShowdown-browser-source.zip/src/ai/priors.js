import {Dex} from '@pkmn/sim';
import randomSets from './random-priors.js';
import ouStats from '../data/ou-statistics.js';

const id = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');

// These are public move priors, never the opponent's generated team or private set.
// They are filtered through the species' Showdown learnset before use.
const CANDIDATES = [
  'Earthquake', 'Earth Power', 'Headlong Rush', 'Close Combat', 'Body Press', 'Aura Sphere',
  'Drain Punch', 'Superpower', 'Focus Blast', 'Flamethrower', 'Fire Blast', 'Flare Blitz',
  'Lava Plume', 'Magma Storm', 'Hydro Pump', 'Surf', 'Scald', 'Liquidation', 'Wave Crash',
  'Waterfall', 'Thunderbolt', 'Thunder', 'Volt Switch', 'Wild Charge', 'Ice Beam',
  'Freeze-Dry', 'Ice Spinner', 'Icicle Crash', 'Blizzard', 'Giga Drain', 'Leaf Storm',
  'Energy Ball', 'Wood Hammer', 'Power Whip', 'Leaf Blade', 'Flower Trick',
  'Moonblast', 'Play Rough', 'Dazzling Gleam', 'Psychic', 'Psyshock', 'Expanding Force',
  'Shadow Ball', 'Shadow Claw', 'Poltergeist', 'Hex', 'Rage Fist', 'Last Respects',
  'Knock Off', 'Dark Pulse', 'Crunch', 'Sucker Punch', 'Kowtow Cleave',
  'Iron Head', 'Flash Cannon', 'Make It Rain', 'Bullet Punch', 'Meteor Mash',
  'Draco Meteor', 'Dragon Pulse', 'Dragon Darts', 'Outrage', 'Dragon Claw',
  'Brave Bird', 'Hurricane', 'Air Slash', 'Acrobatics', 'Stone Edge', 'Rock Slide',
  'Power Gem', 'Salt Cure', 'Sludge Bomb', 'Sludge Wave', 'Gunk Shot', 'Poison Jab',
  'U-turn', 'Bug Buzz', 'First Impression', 'Megahorn', 'Extreme Speed',
  'Body Slam', 'Double-Edge', 'Boomburst', 'Hyper Voice', 'Facade', 'Tera Blast',
  'Mach Punch', 'Ice Shard', 'Aqua Jet', 'Vacuum Wave', 'Quick Attack',
];

function learnsetFor(speciesName) {
  const learned = new Set();
  let species = Dex.species.get(speciesName);
  for (let depth = 0; species?.exists && depth < 4; depth++) {
    try {
      const data = Dex.species.getLearnsetData(species.id);
      for (const move of Object.keys(data?.learnset || {})) learned.add(move);
    } catch { /* Public metadata can be absent for battle-only forms. */ }
    const previous = species.prevo || (species.baseSpecies !== species.name ? species.baseSpecies : '');
    if (!previous) break;
    species = Dex.species.get(previous);
  }
  return learned;
}

/** Moves are possible species moves, not assertions about what an opponent has. */
export function possibleMoves(mon, limit = 8, format = '') {
  // A revealed/current hypothesized Choice item constrains responses until switching.
  if(['choiceband','choicespecs','choicescarf'].includes(id(mon.item))&&mon.lastMove&&Dex.moves.get(mon.lastMove).exists) return [mon.lastMove];
  const observed = [...new Set((mon.movesSeen || mon.moves || []).map(m => typeof m === 'string' ? m : m.move || m.id))]
    .filter(m => Dex.moves.get(m).exists);
  if (observed.length >= 4) return observed;
  const species = Dex.species.get(mon.species);
  if(format==='gen9ou' && ouStats[species.id]) {
    const moves=ouStats[species.id].moves.filter(([,p])=>p>.005).map(([name])=>Dex.moves.get(name).name);
    return [...observed,...moves.filter(m=>!observed.some(o=>id(o)===id(m)))].slice(0,Math.max(limit,observed.length));
  }
  if (format.includes('random') && !format.includes('doubles')) {
    const source = randomSets[species.id] || randomSets[id(species.baseSpecies)];
    if (source) {
      // Condition the candidate set family on all already revealed moves.
      const matching = source.sets.filter(set => observed.every(move => set.movepool.some(m => id(m) === id(move))));
      const pool = [...new Set((matching.length ? matching : source.sets).flatMap(set => set.movepool))];
      return [...observed, ...pool.filter(m => !observed.some(o => id(o) === id(m)))].slice(0, Math.max(limit, 12));
    }
  }
  const learned = learnsetFor(mon.species);
  const physical = (species.baseStats?.atk || 80) >= (species.baseStats?.spa || 80);
  const options = CANDIDATES.filter(m => learned.has(id(m)) && !observed.some(s => id(s) === id(m)))
    .map(name => {
      const move = Dex.moves.get(name);
      const stab = species.types?.includes(move.type) ? 1.65 : 1;
      const role = (move.category === 'Physical') === physical ? 1.2 : 0.7;
      const accuracy = move.accuracy === true ? 1 : Number(move.accuracy || 100) / 100;
      return {name, type: move.type, rank: (move.basePower || 75) * stab * role * accuracy};
    }).sort((a, b) => b.rank - a.rank);
  const selected = [...observed];
  const types = new Set(observed.map(m => Dex.moves.get(m).type));
  // Cover plausible attacking types rather than filling every slot with one STAB type.
  for (const candidate of options) {
    if (!types.has(candidate.type)) {
      selected.push(candidate.name);
      types.add(candidate.type);
    }
    if (selected.length >= limit) break;
  }
  for (const candidate of options) {
    if (selected.length >= limit) break;
    if (!selected.includes(candidate.name)) selected.push(candidate.name);
  }
  return selected.length ? selected : ['Struggle'];
}

/** Explicit uncertainty over hidden spreads/abilities. No battle instance enters here. */
export function opponentHypotheses(mon, format = 'gen9ou', count = 3) {
  const species = Dex.species.get(mon.species);
  const stats=format==='gen9ou' && ouStats[species.id];
  if(stats && stats.spreads.length) {
    return Array.from({length:Math.min(count,stats.spreads.length)},(_,i)=>{
      const [spread,spreadWeight]=stats.spreads[i];
      const [nature,values]=spread.split(':');
      const evs=Object.fromEntries(['hp','atk','def','spa','spd','spe'].map((name,index)=>[name,Number(values.split('/')[index])||0]));
      const item=Object.hasOwn(mon,'item')?mon.item:Dex.items.get(stats.items[i%stats.items.length]?.[0]||'').name;
      const ability=mon.ability||Dex.abilities.get(stats.abilities[i%stats.abilities.length]?.[0]||'').name;
      return {...mon,nature,evs,item,ability,inferred:true,weight:Math.max(.05,spreadWeight),priorSource:'Smogon 2026-08 OU 1825 marginal statistics'};
    });
  }
  const physical = (species.baseStats?.atk || 80) >= (species.baseStats?.spa || 80);
  const abilities = Object.values(species.abilities || {});
  const ability = mon.ability || abilities[0] || '';
  const attack = physical ? 'atk' : 'spa';
  const random = format.includes('random');
  const publicSetData = randomSets[species.id] || randomSets[id(species.baseSpecies)];
  const possibleSetFamilies = random && publicSetData ? publicSetData.sets.filter(set =>
    (mon.movesSeen || []).every(move => set.movepool.some(m => id(m) === id(move)))) : [];
  const randomAbilities = [...new Set(possibleSetFamilies.flatMap(set => set.abilities))];
  const spreads = random ? [
    {evs: {hp: 84, atk: 84, def: 84, spa: 84, spd: 84, spe: 84}, nature: 'Serious'},
  ] : [
    {evs: {[attack]: 252, spe: 252, hp: 4}, nature: physical ? 'Jolly' : 'Timid'},
    {evs: {hp: 252, [attack]: 252, spd: 4}, nature: physical ? 'Adamant' : 'Modest'},
    {evs: {hp: 252, def: 252, spd: 4}, nature: 'Bold'},
  ];
  return spreads.slice(0, count).map((spread, index) => ({
    ...mon, ...spread, ability: mon.ability || (randomAbilities.length ? randomAbilities : abilities)[index % Math.max(1, randomAbilities.length || abilities.length)] || ability,
    item: mon.item || '', inferred: true, weight: index === 0 ? 0.5 : 0.25,
  }));
}
