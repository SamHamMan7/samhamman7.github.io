import {readFile, stat, realpath} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {validateOnnxManifest, verifyModelBytes, onnxSessionBackend, MAX_MODEL_BYTES} from './onnx-common.js';
import {createBeliefBackend, validateBeliefManifest} from './belief-model.js';
import {withBeliefs} from './with-beliefs.js';

/** Load a trained, hash-checked local checkpoint into the native CPU runtime. */
export async function createNodeOnnxBackend({manifestPath = 'models/gen9randombattle/manifest.json', ort, sessionOptions = {}} = {}) {
  if (typeof manifestPath !== 'string' || /^([a-z]+:\/\/|\\\\|\/\/)/i.test(manifestPath)) throw new Error('ONNX Node manifest must be a local filesystem path');
  const manifestFile = path.resolve(manifestPath);
  const info = await stat(manifestFile);
  if (info.size > 256 * 1024) throw new Error('ONNX manifest is too large');
  const manifest = validateOnnxManifest(JSON.parse(await readFile(manifestFile, 'utf8')));
  const directory = await realpath(path.dirname(manifestFile));
  const modelFile = await realpath(path.join(directory, manifest.model));
  if (path.dirname(modelFile) !== directory) throw new Error('ONNX model must stay within its manifest directory');
  const modelInfo = await stat(modelFile);
  if (modelInfo.size > MAX_MODEL_BYTES) throw new Error('ONNX model is too large');
  const bytes = await readFile(modelFile);
  await verifyModelBytes(bytes, manifest, value => createHash('sha256').update(value).digest('hex'));
  const runtime = ort || await import('onnxruntime-node');
  const session = await runtime.InferenceSession.create(bytes, {graphOptimizationLevel: 'all',
    intraOpNumThreads: 1, interOpNumThreads: 1, ...sessionOptions, executionProviders: ['cpu']});
  try {
    const policy = onnxSessionBackend({ort: runtime, session, manifest, runtime: 'onnxruntime-node-cpu'});
    if (!manifest.beliefs) return policy;
    try {
      const beliefFile = await realpath(path.join(directory, manifest.beliefs));
      if(path.dirname(beliefFile)!==directory || (await stat(beliefFile)).size>256*1024)throw new Error('Invalid local belief manifest path/size');
      const beliefManifest=validateBeliefManifest(JSON.parse(await readFile(beliefFile,'utf8')));
      const beliefModel=await realpath(path.join(directory,beliefManifest.model));
      if(path.dirname(beliefModel)!==directory || (await stat(beliefModel)).size>32*1024*1024)throw new Error('Invalid local belief model path/size');
      const beliefs=await createBeliefBackend({ort:runtime,manifest:beliefManifest,bytes:await readFile(beliefModel),
        digest:value=>createHash('sha256').update(value).digest('hex'),runtime:'onnxruntime-node-cpu',
        sessionOptions:{intraOpNumThreads:1,interOpNumThreads:1,executionProviders:['cpu']}});
      return withBeliefs(policy,beliefs);
    } catch(error) {return withBeliefs(policy,null,String(error.message||error));}
  }
  catch (error) {await session.release?.(); throw error;}
}
