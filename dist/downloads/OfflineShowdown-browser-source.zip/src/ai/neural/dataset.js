import {actionIndexFromChoice} from './action-space.js';
import {encodeObservation} from './observation.js';

export function trainingExample({
  view,
  legalActions = [],
  choice,
  opponentChoice = null,
  outcome = null,
  gameId = null,
} = {}) {
  const action = actionIndexFromChoice(choice);
  if (action < 0) throw new Error(`Choice is outside the RandBats neural action space: ${choice}`);
  const opponentAction = opponentChoice == null ? -1 : actionIndexFromChoice(opponentChoice);
  if (opponentChoice != null && opponentAction < 0) throw new Error(`Opponent choice is outside the neural action space: ${opponentChoice}`);
  if (outcome != null && ![-1, 0, 1].includes(outcome)) throw new Error('Outcome must be -1, 0, 1, or null.');
  return {
    schema: 1,
    gameId,
    observation: encodeObservation(view, legalActions),
    action,
    opponentAction,
    outcome,
  };
}

/** In-memory JSONL buffer suitable for workers/browser; persistence can be added outside the AI. */
export class JsonlDatasetBuffer {
  #rows = [];
  append(example) { this.#rows.push(example); }
  get length() { return this.#rows.length; }
  toJSONL() { return this.#rows.map(row => JSON.stringify(row)).join('\n') + (this.#rows.length ? '\n' : ''); }
  clear() { this.#rows.length = 0; }
  drainJSONL() { const text = this.toJSONL(); this.clear(); return text; }
}
