import {softmax, scoreResponseMatrix, mixNearBest} from './risk.js';

function topIndices(probabilities, count) {
  return probabilities
    .map((probability, index) => ({index, probability}))
    .filter(entry => entry.probability > 0)
    .sort((a, b) => b.probability - a.probability)
    .slice(0, Math.max(1, count));
}

/**
 * Backend extension contract for later hidden-world/simulator search:
 *
 *   await backend.evaluateResponseMatrix({
 *     observation,
 *     ownActionIndices,
 *     opponentActionIndices,
 *   }) -> number[own][opponent]
 *
 * Every returned number is a post-response win probability in [0,1].
 * The current Stage-1 backend does not implement this yet, so Neural Preview
 * remains on its normal policy path until Ultra connects a real evaluator.
 */
export async function responseConditionedPolicy({
  backend,
  observation,
  prediction,
  ownLegalMask,
  opponentLegalMask = null,
  ownTopK = 6,
  opponentTopK = 6,
  resourceCosts = null,
  flexibilityBonuses = null,
} = {}) {
  if (!backend?.evaluateResponseMatrix || !prediction?.policyLogits || !prediction?.opponentPolicyLogits) return null;

  const ownProbabilities = softmax(prediction.policyLogits, ownLegalMask, 1);
  const opponentProbabilitiesFull = softmax(prediction.opponentPolicyLogits, opponentLegalMask, 1);
  const own = topIndices(ownProbabilities, ownTopK);
  const opponent = topIndices(opponentProbabilitiesFull, opponentTopK);
  if (!own.length || !opponent.length) return null;

  const matrix = await backend.evaluateResponseMatrix({
    observation,
    ownActionIndices: own.map(entry => entry.index),
    opponentActionIndices: opponent.map(entry => entry.index),
  });
  if (!Array.isArray(matrix) || matrix.length !== own.length || matrix.some(row => !Array.isArray(row) || row.length !== opponent.length)) return null;

  const currentWinProbability = Number.isFinite(Number(prediction.value)) ? Number(prediction.value) : 0.5;
  const responseProbabilities = opponent.map(entry => entry.probability);
  const localCosts = own.map(entry => resourceCosts?.[entry.index] || 0);
  const localFlex = own.map(entry => flexibilityBonuses?.[entry.index] || 0);
  const scored = scoreResponseMatrix({
    outcomeMatrix: matrix,
    opponentProbabilities: responseProbabilities,
    currentWinProbability,
    resourceCosts: localCosts,
    flexibilityBonuses: localFlex,
  }).map((entry, index) => ({...entry, actionIndex: own[index].index}));

  return {
    currentWinProbability,
    opponentResponses: opponent,
    scored,
    mixed: mixNearBest(scored, {currentWinProbability}),
  };
}
