export const OBSERVATION_VERSION = 2;
export const ACTION_COUNT = 14;
export const HISTORY_TOKEN_START = 21;
export const HISTORY_TOKEN_COUNT = 8;
export const TOKEN_COUNT = HISTORY_TOKEN_START + HISTORY_TOKEN_COUNT;
export const CAT_FEATURES = 12;
export const NUM_FEATURES = 22;
export const HASH_BUCKETS = 16384;

export const TOKEN_KIND = Object.freeze({
  PAD: 0,
  GLOBAL: 1,
  OWN_POKEMON: 2,
  OPPONENT_POKEMON: 3,
  OWN_MOVE: 4,
  OPPONENT_MOVE: 5,
  HISTORY: 6,
});

// Only structured public events from PlayerView are eligible for history tokens.
export const HISTORY_EVENT_TYPES = Object.freeze([
  'switch', 'drag', 'replace', 'move', 'damage', 'heal', 'sethp', 'faint',
  'status', 'curestatus', 'boost', 'unboost', 'setboost', 'terastallize',
  'ability', 'item', 'enditem', 'start', 'end', 'singleturn', 'singlemove',
  'activate', 'formechange', 'transform', 'fail', 'immune', 'miss', 'crit',
  'supereffective', 'resisted', 'clearboost', 'weather', 'fieldstart',
  'fieldend', 'sidestart', 'sideend',
]);

export const ACTION_LAYOUT = Object.freeze({
  MOVE_START: 0,
  TERA_MOVE_START: 4,
  SWITCH_START: 8,
  MOVE_COUNT: 4,
  SWITCH_COUNT: 6,
});
