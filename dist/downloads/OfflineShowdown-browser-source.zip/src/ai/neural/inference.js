import {legalMask, legalActionForIndex, maskedArgmax} from './action-space.js';
import {encodeObservation} from './observation.js';
import {responseConditionedPolicy} from './response-search.js';

function finiteArray(value, length) {
  return Array.isArray(value) && value.length === length && value.every(item => Number.isFinite(Number(item)));
}

function seededUnit(seed) {
  let x = (Number(seed) || 1) >>> 0;
  x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
  return (x >>> 0) / 0x100000000;
}

function sampleMixed(mixed, seed) {
  if (!mixed?.length) return null;
  let r = seededUnit(seed);
  for (const entry of mixed) {
    r -= Number(entry.probability) || 0;
    if (r <= 0) return entry;
  }
  return mixed[mixed.length - 1];
}

/**
 * Backend contract:
 *   await backend.predict(observation) -> {
 *     policyLogits: number[14],
 *     value?: number,                    // calibrated win probability [0,1]
 *     opponentPolicyLogits?: number[14]
 *   }
 *
 * Optional Stage-2 search contract:
 *   await backend.evaluateResponseMatrix({observation, ownActionIndices,
 *     opponentActionIndices}) -> number[own][opponent]
 *
 * The optional matrix contains post-response win probabilities. If supplied,
 * NeuralPolicy uses state-dependent downside-aware response aggregation rather
 * than blindly taking the largest policy logit.
 */
export class NeuralPolicy {
  constructor({backend = null, fallback = null} = {}) {
    this.backend = backend;
    this.fallback = fallback;
  }

  async choose(view, actions, options = {}) {
    const mask = legalMask(actions);
    if (!mask.some(Boolean) || !this.backend?.predict) return this.#fallback(view, actions, options, 'unsupported-request');
    try {
      const observation = encodeObservation(view, actions);
      const result = await this.backend.predict(observation);
      if (!finiteArray(result?.policyLogits, mask.length)) return this.#fallback(view, actions, options, 'invalid-model-output');

      let index = -1;
      let responseSearch = null;
      if (finiteArray(result?.opponentPolicyLogits, mask.length) && this.backend?.evaluateResponseMatrix) {
        responseSearch = await responseConditionedPolicy({
          backend: this.backend,
          observation,
          prediction: result,
          ownLegalMask: mask,
          ownTopK: options.ownTopK || 6,
          opponentTopK: options.opponentTopK || 6,
        });
        const sampled = sampleMixed(responseSearch?.mixed, options.seed);
        if (sampled) index = sampled.actionIndex;
      }

      if (index < 0) index = maskedArgmax(result.policyLogits.map(Number), mask);
      const action = legalActionForIndex(index, actions);
      if (!action) return this.#fallback(view, actions, options, 'model-selected-illegal-action');
      return {
        choice: action.choice,
        reason: responseSearch ? 'Neural response-conditioned selection.' : 'Neural policy selection.',
        diagnostics: {
          policy: 'jaxlite-stage2',
          actionIndex: index,
          value: Number.isFinite(Number(result.value)) ? Number(result.value) : null,
          opponentPolicy: finiteArray(result?.opponentPolicyLogits, mask.length) ? result.opponentPolicyLogits.map(Number) : null,
          learnedBeliefs: result.beliefs || null,
          beliefError: result.beliefError || null,
          responseSearch: responseSearch ? {
            opponentResponses: responseSearch.opponentResponses,
            scored: responseSearch.scored,
            mixed: responseSearch.mixed,
          } : null,
          usedFallback: false,
        },
      };
    } catch (error) {
      return this.#fallback(view, actions, options, `inference-error:${error?.message || error}`);
    }
  }

  #fallback(view, actions, options, reason) {
    if (typeof this.fallback === 'function') {
      const result = this.fallback(view, options);
      return {...result, diagnostics: {...result?.diagnostics, usedFallback:true, neuralFallback: reason}};
    }
    return {choice: actions?.[0]?.choice || null, reason: 'Neural scaffold fallback.', diagnostics: {usedFallback:true,neuralFallback: reason}};
  }
}
