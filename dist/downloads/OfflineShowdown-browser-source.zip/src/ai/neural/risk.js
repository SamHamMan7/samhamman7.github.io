/**
 * Generic response-distribution risk utilities for the learned/search path.
 *
 * This deliberately does not know about Pokemon-specific concepts such as
 * Protect or Tera. Search should supply long-run win-probability outcomes for
 * each own-action/opponent-response pair; this layer only decides how much to
 * care about mean value versus downside from the current game state.
 */

function clamp01(value) {
  return Math.max(0, Math.min(1, Number(value) || 0));
}

export function normalizeProbabilities(probabilities = []) {
  const clean = probabilities.map(value => Math.max(0, Number(value) || 0));
  const sum = clean.reduce((a, b) => a + b, 0);
  if (sum <= 0) return clean.map(() => clean.length ? 1 / clean.length : 0);
  return clean.map(value => value / sum);
}

/** Numerically stable softmax with an optional 0/1 legality mask. */
export function softmax(logits = [], mask = null, temperature = 1) {
  const t = Math.max(1e-4, Number(temperature) || 1);
  const legal = logits.map((_, index) => !mask || Boolean(mask[index]));
  const values = logits.map((value, index) => legal[index] ? Number(value) / t : -Infinity);
  const finite = values.filter(Number.isFinite);
  if (!finite.length) return logits.map(() => 0);
  const max = Math.max(...finite);
  const exps = values.map(value => Number.isFinite(value) ? Math.exp(value - max) : 0);
  return normalizeProbabilities(exps);
}

/** Lower-tail expectation (CVaR-style) for a discrete response distribution. */
export function lowerTailMean(outcomes, probabilities, quantile = 0.25) {
  if (!Array.isArray(outcomes) || outcomes.length !== probabilities?.length || !outcomes.length) return 0;
  const q = Math.max(1e-6, Math.min(1, Number(quantile) || 0.25));
  const probs = normalizeProbabilities(probabilities);
  const pairs = outcomes.map((value, index) => ({value: clamp01(value), p: probs[index]})).sort((a, b) => a.value - b.value);
  let mass = 0;
  let total = 0;
  for (const pair of pairs) {
    if (mass >= q) break;
    const take = Math.min(pair.p, q - mass);
    total += pair.value * take;
    mass += take;
  }
  return mass > 0 ? total / mass : 0;
}

/**
 * State-dependent downside aversion. `winProbability` is the model's current
 * estimate BEFORE committing to the candidate action.
 *
 * Ahead: strongly protect the lower tail.
 * Even: care about downside, but expected value still dominates.
 * Behind: mostly chase expected comeback value rather than preserving a loss.
 */
export function riskProfile(winProbability) {
  const value = clamp01(winProbability);
  if (value >= 0.70) {
    const t = (value - 0.70) / 0.30;
    return {tailWeight: 0.48 + 0.27 * t, tailQuantile: 0.30, mixGap: 0.025};
  }
  if (value <= 0.30) {
    const t = value / 0.30;
    return {tailWeight: 0.06 + 0.10 * t, tailQuantile: 0.16, mixGap: 0.055};
  }
  const t = (value - 0.30) / 0.40;
  return {tailWeight: 0.16 + 0.32 * t, tailQuantile: 0.20 + 0.10 * t, mixGap: 0.04};
}

export function responseScore({
  outcomes,
  probabilities,
  currentWinProbability = 0.5,
  resourceCost = 0,
  flexibilityBonus = 0,
} = {}) {
  if (!Array.isArray(outcomes) || !outcomes.length || outcomes.length !== probabilities?.length) {
    return {score: -Infinity, expected: 0, tail: 0, variance: 0};
  }
  const probs = normalizeProbabilities(probabilities);
  const values = outcomes.map(clamp01);
  const expected = values.reduce((sum, value, index) => sum + value * probs[index], 0);
  const variance = values.reduce((sum, value, index) => sum + probs[index] * (value - expected) ** 2, 0);
  const profile = riskProfile(currentWinProbability);
  const tail = lowerTailMean(values, probs, profile.tailQuantile);
  const robust = (1 - profile.tailWeight) * expected + profile.tailWeight * tail;
  const score = robust - Math.max(0, Number(resourceCost) || 0) + (Number(flexibilityBonus) || 0);
  return {score, expected, tail, variance, profile};
}

/** Score an own-action x opponent-response matrix of resulting win probabilities. */
export function scoreResponseMatrix({
  outcomeMatrix,
  opponentProbabilities,
  currentWinProbability = 0.5,
  resourceCosts = [],
  flexibilityBonuses = [],
} = {}) {
  if (!Array.isArray(outcomeMatrix)) return [];
  return outcomeMatrix.map((outcomes, index) => ({
    actionIndex: index,
    ...responseScore({
      outcomes,
      probabilities: opponentProbabilities,
      currentWinProbability,
      resourceCost: resourceCosts[index] || 0,
      flexibilityBonus: flexibilityBonuses[index] || 0,
    }),
  }));
}

/**
 * Turn robust action scores into a mixed policy. Materially inferior actions are
 * excluded; remaining near-equal lines are softmaxed. This prevents "mixed
 * strategy" from meaning random aggression.
 */
export function mixNearBest(scores = [], {currentWinProbability = 0.5, temperature = 0.025} = {}) {
  const finite = scores.filter(entry => Number.isFinite(entry?.score));
  if (!finite.length) return [];
  const best = Math.max(...finite.map(entry => entry.score));
  const gap = riskProfile(currentWinProbability).mixGap;
  const eligible = finite.filter(entry => entry.score >= best - gap);
  const probs = softmax(eligible.map(entry => entry.score), null, temperature);
  return eligible.map((entry, index) => ({...entry, probability: probs[index]}));
}
