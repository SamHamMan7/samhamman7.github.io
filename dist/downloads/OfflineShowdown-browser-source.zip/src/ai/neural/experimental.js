import {NeuralPolicy} from './inference.js';
import {encodeObservation} from './observation.js';

let previewBackend = null;
let bundledLoad;
let backendError='';

export async function initializeBundledNeuralPreview() {
  return bundledLoad ||= (async()=>{
    try {
      const {createBrowserOnnxBackend}=await import('./onnx-browser.js');
      previewBackend=await createBrowserOnnxBackend();
      return true;
    } catch(error) {backendError=String(error.message||error);return false;}
  })();
}

export function setNeuralPreviewBackend(backend) {
  previewBackend = backend || null;
}

export function neuralPreviewStatus() {
  return {installed: Boolean(previewBackend?.predict)};
}

function supportedRandBatsRequest(view) {
  const format = String(view?.format || '').toLowerCase();
  if (format !== 'gen9randombattle') return false;
  const active = view?.request?.active || [];
  const forced = view?.request?.forceSwitch || [];
  // The first learned model is deliberately singles-only. Team preview and
  // Revival Blessing/special replacement requests stay on the trusted teacher.
  if (view?.request?.teamPreview) return false;
  return Math.max(active.length, forced.length) <= 1;
}

/**
 * Experimental learned-agent boundary.
 *
 * Today this is safe to expose in the UI because, until a trained backend is
 * installed, it runs the current Very Strong policy as a teacher/fallback while
 * still exercising the public observation/action contract. Once Ultra supplies
 * an ONNX/native backend, setNeuralPreviewBackend() can activate it without
 * changing Showdown transport or legality handling.
 */
export async function chooseNeuralPreview(view, {
  seed = 1,
  chooseAction,
  legalActions,
} = {}) {
  if (typeof chooseAction !== 'function' || typeof legalActions !== 'function') {
    throw new Error('Neural Preview requires the existing policy and legal-action boundary.');
  }

  let teacher;
  const fallback=()=>teacher ||= chooseAction(view, {difficulty: 'Very Strong', seed});
  const actions = legalActions(view);

  if (!supportedRandBatsRequest(view)) {
    return {
      ...fallback(),
      diagnostics: {
        ...teacher?.diagnostics,
        policy: 'jaxlite-neural-preview-v1',
        neuralBackend: false,
        neuralFallback: 'randbats-singles-only',
      },
    };
  }

  // Encode even in bootstrap mode. This makes the live UI exercise exactly the
  // same sanitized representation that the trained model will consume later.
  const observation = encodeObservation(view, actions);

  if (!previewBackend?.predict) {
    return {
      ...fallback(),
      diagnostics: {
        ...teacher?.diagnostics,
        policy: 'jaxlite-neural-preview-v1',
        neuralBackend: false,
        neuralFallback: 'no-trained-model-installed',
        backendError: backendError||null,
        observationVersion: observation.version,
        legalActionCount: observation.legalMask.reduce((a, b) => a + Number(Boolean(b)), 0),
        teacherChoice: teacher?.choice || null,
      },
    };
  }

  const policy = new NeuralPolicy({
    backend: previewBackend,
    fallback,
  });
  const result = await policy.choose(view, actions, {seed});
  return {
    ...result,
    diagnostics: {
      ...result?.diagnostics,
      policy: 'jaxlite-neural-preview-v1',
      neuralBackend: !result?.diagnostics?.usedFallback,
      teacherChoice: teacher?.choice || null,
      observationVersion: observation.version,
    },
  };
}
