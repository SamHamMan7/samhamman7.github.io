/** Optional separate learned belief model. It never alters the base policy.
 * The only inference input is the fixed public observation. Privileged generated
 * teams belong to the training dataset and are never accepted by this API.
 */
import {OBSERVATION_VERSION, TOKEN_COUNT, CAT_FEATURES, NUM_FEATURES, HASH_BUCKETS, ACTION_COUNT} from './contract.js';
import {observationFeeds, verifyModelBytes} from './onnx-common.js';

const INPUTS = ['token_kinds', 'categorical', 'numeric', 'token_mask', 'legal_mask'];
const OUTPUTS = {item: 'item_logits', ability: 'ability_logits', tera: 'tera_logits', moves: 'move_logits', nextMove: 'next_move_logits'};
const VOCABULARIES = ['item', 'ability', 'tera', 'moves'];
const arrayLike = value => Array.isArray(value) || (ArrayBuffer.isView(value) && !(value instanceof DataView));

export function validateBeliefManifest(manifest) {
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) throw new Error('Belief manifest must be an object');
  const expected = {schemaVersion: 1, kind: 'auxiliary-public-beliefs', trained: true,
    observationVersion: OBSERVATION_VERSION, format: 'gen9randombattle',
    tokenCount: TOKEN_COUNT, catFeatures: CAT_FEATURES, numFeatures: NUM_FEATURES,
    hashBuckets: HASH_BUCKETS, actionCount: ACTION_COUNT, opponentSlots: 6,
    targetSemantics: 'initial-generated-set', nextMoveSemantics: 'ordinary-counterpart-move-identity', basePolicyModified: false};
  for (const [name, value] of Object.entries(expected)) if (manifest[name] !== value) throw new Error(`Belief manifest ${name} mismatch`);
  if (typeof manifest.model !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]*\.onnx$/.test(manifest.model) || manifest.model.includes('..')) throw new Error('Belief model must be a local ONNX filename');
  if (!/^[a-f0-9]{64}$/i.test(manifest.sha256 || '')) throw new Error('Belief manifest requires a SHA-256 hash');
  if (!Number.isSafeInteger(manifest.bytes) || manifest.bytes < 1 || manifest.bytes > 32 * 1024 * 1024) throw new Error('Invalid compact belief model size');
  if (!manifest.outputs || Object.keys(manifest.outputs).length !== Object.keys(OUTPUTS).length) throw new Error('Invalid belief output contract');
  for (const [key, value] of Object.entries(OUTPUTS)) if (manifest.outputs[key] !== value) throw new Error(`Belief output ${key} mismatch`);
  if (!manifest.vocabulary || Object.keys(manifest.vocabulary).some(key => !VOCABULARIES.includes(key))) throw new Error('Invalid belief vocabulary');
  for (const key of VOCABULARIES) {
    const values = manifest.vocabulary[key];
    if (!Array.isArray(values) || !values.length || values.length > 2048 || new Set(values).size !== values.length || values.some(value => typeof value !== 'string' || !/^[a-z0-9]{1,60}$/.test(value))) throw new Error(`Invalid belief ${key} vocabulary`);
  }
  return manifest;
}

function assertPublicSlots(observation) {
  if (observation?.version !== OBSERVATION_VERSION || observation.meta?.format !== 'gen9randombattle') throw new Error('Beliefs require the Gen9 Random Battle public observation');
  for (const key of ['tokenKinds', 'tokenMask', 'categorical', 'numeric']) if (!Array.isArray(observation[key]) || observation[key].length !== TOKEN_COUNT) throw new Error(`Invalid belief observation ${key}`);
  for (let token = 7; token < 13; token++) {
    const cats = observation.categorical[token], nums = observation.numeric[token];
    if (!Array.isArray(cats) || cats.length !== CAT_FEATURES || !Array.isArray(nums) || nums.length !== NUM_FEATURES) throw new Error('Invalid opponent token shape');
    if (observation.tokenMask[token] && observation.tokenKinds[token] !== 3) throw new Error('Invalid public opponent token kind');
    if (cats.slice(8).some(Boolean) || nums.slice(16).some(Boolean) || nums[14]) throw new Error('Opponent exact moves/stats cannot enter belief inference');
    if (!observation.tokenMask[token] && (cats.some(Boolean) || nums.some(Boolean))) throw new Error('Padded opponent token contains data');
  }
}

function tensorValues(tensor, name, dims) {
  if (!tensor || !['float32', 'float64'].includes(tensor.type) || !arrayLike(tensor.data) || !Array.isArray(tensor.dims) || tensor.dims.length !== dims.length || tensor.dims.some((size, index) => size !== dims[index])) throw new Error(`Invalid ${name} tensor shape/type`);
  const values = Array.from(tensor.data);
  if (values.length !== dims.reduce((a, b) => a * b, 1) || values.some(value => !Number.isFinite(value))) throw new Error(`Invalid ${name} logits`);
  return values;
}

function probabilities(logits, marginal = false) {
  if (marginal) return logits.map(value => value >= 0 ? 1 / (1 + Math.exp(-value)) : Math.exp(value) / (1 + Math.exp(value)));
  const max = Math.max(...logits), weights = logits.map(value => Math.exp(value - max));
  const total = weights.reduce((a, b) => a + b, 0);
  return weights.map(value => value / total);
}

function rank(vocabulary, values, limit) {
  return vocabulary.map((id, index) => ({id, probability: values[index]}))
    .sort((a, b) => b.probability - a.probability || a.id.localeCompare(b.id)).slice(0, limit);
}

/** Numeric probabilities are uncalibrated model estimates, not revealed facts. */
export function decodeBeliefOutputs(outputs, manifest, observation, {topK = 6} = {}) {
  validateBeliefManifest(manifest);
  assertPublicSlots(observation);
  if (!Number.isInteger(topK) || topK < 1 || topK > 32) throw new Error('Belief topK must be between 1 and 32');
  const values = {};
  for (const head of VOCABULARIES) values[head] = tensorValues(outputs[OUTPUTS[head]], OUTPUTS[head], [1, 6, manifest.vocabulary[head].length]);
  const nextValues = tensorValues(outputs[OUTPUTS.nextMove], OUTPUTS.nextMove, [1, manifest.vocabulary.moves.length]);
  const opponents = [];
  for (let slot = 0; slot < 6; slot++) {
    const token = 7 + slot;
    if (!observation.tokenMask[token] || !observation.categorical[token][0]) continue;
    const cats = observation.categorical[token];
    const result = {publicSlot: slot, speciesHash: cats[0], active: Boolean(observation.numeric[token][2])};
    for (const [head, category] of [['item', 1], ['ability', 2], ['tera', 5]]) {
      if (cats[category]) {
        // The target was the initial set. Never overwrite a current public item,
        // ability, or Tera with a learned hypothesis about the original loadout.
        result[head] = {source: 'public', knownHash: cats[category]};
      } else {
        const size = manifest.vocabulary[head].length;
        result[head] = {source: 'learned', target: 'initial-generated-set', candidates: rank(manifest.vocabulary[head], probabilities(values[head].slice(slot * size, (slot + 1) * size)), topK)};
      }
    }
    const size = manifest.vocabulary.moves.length;
    result.moves = {source: 'learned', target: 'initial-generated-set', probabilitySemantics: 'independent-move-membership',
      candidates: rank(manifest.vocabulary.moves, probabilities(values.moves.slice(slot * size, (slot + 1) * size), true), Math.max(4, topK)),
      publicMoveHashes: result.active ? observation.categorical.slice(17, 21).flatMap((row, i) => observation.tokenMask[17 + i] && row[0] ? [row[0]] : []) : []};
    opponents.push(result);
  }
  return {kind: 'learned-public-beliefs', observationVersion: OBSERVATION_VERSION, calibrated: false,
    targetSemantics: 'initial-generated-set', opponents,
    nextMove: opponents.some(mon => mon.active) ? {
      candidates: rank(manifest.vocabulary.moves, probabilities(nextValues), topK),
      conditionalOnOrdinaryMove: true, predictsChosenMove: true,
      includesSwitchProbability: false, includesTeraProbability: false,
    } : null};
}

export function beliefSessionBackend({ort, session, manifest, runtime = 'onnx'}) {
  validateBeliefManifest(manifest);
  if (!ort?.Tensor || !session?.run) throw new Error('Belief inference requires an ONNX Runtime session');
  if (!Array.isArray(session.inputNames) || session.inputNames.length !== INPUTS.length || INPUTS.some(name => !session.inputNames.includes(name))) throw new Error('Belief input names mismatch');
  if (!Array.isArray(session.outputNames) || session.outputNames.length !== Object.values(OUTPUTS).length || Object.values(OUTPUTS).some(name => !session.outputNames.includes(name))) throw new Error('Belief output names mismatch');
  let disposed = false;
  return {
    metadata: Object.freeze({kind: 'auxiliary-public-beliefs', runtime, model: manifest.model, sha256: manifest.sha256, basePolicyModified: false}),
    async predict(observation, options) {
      if (disposed) throw new Error('Belief backend has been disposed');
      assertPublicSlots(observation);
      const feeds = observationFeeds(ort, observation);
      let outputs;
      try {
        outputs = await session.run(feeds);
        return decodeBeliefOutputs(outputs, manifest, observation, options);
      } finally {
        for (const tensor of Object.values(feeds)) tensor.dispose?.();
        if (outputs) for (const tensor of Object.values(outputs)) tensor.dispose?.();
      }
    },
    async dispose() { if (!disposed) { disposed = true; await session.release?.(); } },
  };
}

/** Caller supplies existing Node or browser/WASM ORT; no base runtime changes. */
export async function createBeliefBackend({ort, manifest, bytes, digest, sessionOptions, runtime}) {
  validateBeliefManifest(manifest);
  await verifyModelBytes(bytes, manifest, digest);
  const session = await ort.InferenceSession.create(bytes, sessionOptions);
  try { return beliefSessionBackend({ort, session, manifest, runtime}); }
  catch (error) { await session.release?.(); throw error; }
}
