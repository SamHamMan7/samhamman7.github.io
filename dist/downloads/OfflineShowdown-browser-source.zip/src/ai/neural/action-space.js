import {ACTION_COUNT, ACTION_LAYOUT} from './contract.js';

function parseChoice(choice) {
  const text = String(choice || '').trim().toLowerCase();
  let match = text.match(/^move\s+(\d+)(?:\s+.*)?$/);
  if (match) {
    const slot = Number(match[1]);
    if (slot < 1 || slot > ACTION_LAYOUT.MOVE_COUNT) return null;
    const tera = /\bterastallize\b/.test(text);
    return {kind: 'move', slot, tera};
  }
  match = text.match(/^switch\s+(\d+)$/);
  if (match) {
    const slot = Number(match[1]);
    if (slot < 1 || slot > ACTION_LAYOUT.SWITCH_COUNT) return null;
    return {kind: 'switch', slot};
  }
  return null;
}

export function actionIndexFromChoice(choice) {
  const parsed = parseChoice(choice);
  if (!parsed) return -1;
  if (parsed.kind === 'switch') return ACTION_LAYOUT.SWITCH_START + parsed.slot - 1;
  return (parsed.tera ? ACTION_LAYOUT.TERA_MOVE_START : ACTION_LAYOUT.MOVE_START) + parsed.slot - 1;
}

export function actionIndex(action) {
  if (!action) return -1;
  if (typeof action.choice === 'string') return actionIndexFromChoice(action.choice);
  if (action.kind === 'switch' && Number.isInteger(action.slot)) {
    const slot = action.slot;
    return slot >= 1 && slot <= ACTION_LAYOUT.SWITCH_COUNT ? ACTION_LAYOUT.SWITCH_START + slot - 1 : -1;
  }
  if (action.kind === 'move' && Number.isInteger(action.slot)) {
    const slot = action.slot;
    if (slot < 1 || slot > ACTION_LAYOUT.MOVE_COUNT) return -1;
    return (action.tera ? ACTION_LAYOUT.TERA_MOVE_START : ACTION_LAYOUT.MOVE_START) + slot - 1;
  }
  return -1;
}

/** Build the model legality mask from the already-authoritative legal action list. */
export function legalMask(actions = []) {
  const mask = Array(ACTION_COUNT).fill(0);
  for (const action of actions) {
    const index = actionIndex(action);
    if (index >= 0) mask[index] = 1;
  }
  return mask;
}

/** Resolve a model action back to the exact Showdown command already deemed legal. */
export function legalActionForIndex(index, actions = []) {
  if (!Number.isInteger(index) || index < 0 || index >= ACTION_COUNT) return null;
  return actions.find(action => actionIndex(action) === index) || null;
}

export function maskedArgmax(logits, mask) {
  if (!Array.isArray(logits) || logits.length !== ACTION_COUNT) return -1;
  let best = -1;
  let bestValue = -Infinity;
  for (let i = 0; i < ACTION_COUNT; i++) {
    if (!mask?.[i]) continue;
    const value = Number(logits[i]);
    if (!Number.isFinite(value)) continue;
    if (value > bestValue) {
      best = i;
      bestValue = value;
    }
  }
  return best;
}
