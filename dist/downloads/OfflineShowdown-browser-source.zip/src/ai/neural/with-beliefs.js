/** Auxiliary estimates remain separate from policy logits and public facts.
 * No response search is implied by returning these trained predictions.
 */
export function withBeliefs(policy, beliefs, loadError = null) {
  return {
    metadata: Object.freeze({...policy.metadata, beliefModelSha256: beliefs?.metadata.sha256 || null}),
    async predict(observation) {
      const prediction = await policy.predict(observation);
      if (!beliefs) return {...prediction, beliefError: loadError};
      try { return {...prediction, beliefs: await beliefs.predict(observation)}; }
      catch (error) { return {...prediction, beliefError: String(error.message || error)}; }
    },
    async dispose() { try { await beliefs?.dispose(); } finally { await policy.dispose(); } },
  };
}
