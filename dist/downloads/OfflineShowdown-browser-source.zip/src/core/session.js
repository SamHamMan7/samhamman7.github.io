import {BattleStreams, Teams} from '@pkmn/sim';
import {TeamGenerators} from '@pkmn/randoms';
import {PlayerView} from './view.js';
import {validateTeam, FORMATS, assessTeam} from './teams.js';
import {TEAM_POOL} from '../data/teams.js';
import {COMPETITIVE_TEAMS} from '../data/competitive-teams.js';

Teams.setGeneratorFactory(TeamGenerators);

/** The only engine owner. Public methods provide player channels, never battle internals. */
export class BattleSession {
  #streams; #views; #tokens = {p1: 0, p2: 0}; #pending = {}; #closed = false;
  constructor({onUpdate = () => {}, onRequest = () => {}, onError = () => {}} = {}) {
    this.onUpdate = onUpdate; this.onRequest = onRequest; this.onError = onError;
  }
  async start({format = 'gen9ou', teamPaste, opponentPaste, seed = [1,2,3,4]} = {}) {
    if (!FORMATS.includes(format)) throw new Error('Unsupported format');
    this.format = format;
    const random = format.includes('random');
    const own = random ? Teams.generate(format, {seed}) : validateTeam(teamPaste, format);
    const anchor = COMPETITIVE_TEAMS[seed[0] % COMPETITIVE_TEAMS.length] || TEAM_POOL[0];
    const opponent = random ? Teams.generate(format, {seed: seed.map(x => (x + 7919) % 65536)}) : validateTeam(opponentPaste || anchor.paste, format);
    if (!random && (own.errors.length || opponent.errors.length)) throw new Error([...own.errors, ...opponent.errors.map(x => `Opponent: ${x}`)].join('\n'));
    const p1team = random ? own : own.team, p2team = random ? opponent : opponent.team;
    if (!random && assessTeam(p2team).score < 50) throw new Error('Opponent failed the team coherence filter.');
    this.#views = {p1: new PlayerView('p1', p1team), p2: new PlayerView('p2', p2team)};
    this.#streams = BattleStreams.getPlayerStreams(new BattleStreams.BattleStream());
    for (const side of ['p1', 'p2']) void this.#consume(side);
    // Drain unused channels without retaining omniscient logs or exposing them to any policy.
    for (const channel of ['omniscient', 'spectator', 'p3', 'p4']) void (async () => {try {for await (const _ of this.#streams[channel]) { /* discard */ }} catch {}})();
    await this.#streams.omniscient.write(`>start ${JSON.stringify({formatid: format, seed})}\n>player p1 ${JSON.stringify({name: 'You', team: Teams.pack(p1team)})}\n>player p2 ${JSON.stringify({name: 'Offline AI', team: Teams.pack(p2team)})}`);
  }
  async #consume(side) {
    try {
      for await (const chunk of this.#streams[side]) {
        if (this.#closed) break;
        const view = this.#views[side];
        const requested = view.receive(chunk);
        const state = view.snapshot();
        this.onUpdate({side, view: state, lines: chunk.split('\n').filter(l => !l.startsWith('|request|'))});
        if (state.error) {
          // Unavailable choices legitimately reveal traps/disabled moves. Showdown sends
          // an updated player request immediately after this error; wait for that request.
          if (!state.error.startsWith('[Unavailable choice]')) this.onError(new Error(state.error), side);
          delete view.state.error;
        }
        if (requested && !state.ended) {
          const token = ++this.#tokens[side];
          this.#pending[side] = token;
          this.onRequest({side, token, view: {...state, format: this.format}});
        }
      }
    } catch (error) { if (!this.#closed) this.onError(error, side); }
  }
  async choose(side, token, choice) {
    if (this.#closed || !this.#streams) return false;
    if (this.#pending[side] !== token) return false;
    if (typeof choice !== 'string' || choice.length > 200 || /[\r\n|>]/.test(choice)) throw new Error('Invalid battle command');
    delete this.#pending[side];
    // The official simulator is the final legality authority.
    await this.#streams[side].write(choice);
    return true;
  }
  retry(side) {
    const view = this.#views[side].snapshot();
    const token = ++this.#tokens[side]; this.#pending[side] = token;
    // Preserve the format on retry just like normal requests do.
    this.onRequest({side, token, view: {...view, format: this.format}});
  }
  async forfeit(side = 'p1') { if (this.#streams) await this.#streams.omniscient.write(`>forcewin ${side === 'p1' ? 'p2' : 'p1'}`); }
  async close() { this.#closed = true; if (this.#streams) await this.#streams.omniscient.writeEnd(); }
}
