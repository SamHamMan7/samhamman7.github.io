import {Dex} from '@pkmn/sim';

export const id = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const clone = value => JSON.parse(JSON.stringify(value));
export const PUBLIC_HISTORY_LIMIT = 8;
const publicID = value => id(value).slice(0, 80);
const publicStatus = value => ['brn', 'par', 'psn', 'tox', 'slp', 'frz', 'fnt'].includes(value) ? value : '';
// Match Showdown's Gen 9 public HP display, including the non-full 99% cap.
// Never retain exact HP, max HP, nicknames, raw protocol, or request fields here.
function publicHP(fraction) {
  if (!Number.isFinite(fraction)) return undefined;
  const hp = Math.max(0, Math.min(1, fraction));
  return hp === 1 ? 1 : Math.min(99, Math.ceil(hp * 100 - 1e-10)) / 100;
}
function publicCondition(condition = '') {
  const match = condition.match(/^(\d+)\/(\d+)(?:\s|$)/);
  const fainted = /\bfnt\b/.test(condition);
  return {
    hp: fainted ? 0 : match && Number(match[2]) > 0 ? publicHP(Number(match[1]) / Number(match[2])) : undefined,
    status: publicStatus(condition.split(' ')[1]),
  };
}
export function health(condition = '') {
  const [amount, status = ''] = condition.split(' ');
  const [hp, max] = amount.split('/').map(Number);
  return {hpFraction: condition.includes('fnt') ? 0 : (max ? hp / max : hp ? 1 : 0), status, fainted: condition.includes('fnt')};
}
function speciesInfo(details = '') {
  const species = details.split(',')[0];
  const dex = Dex.species.get(species);
  const level = Number(details.match(/, L(\d+)/)?.[1] || 100);
  return {species, details, level, num: dex.num, types: [...dex.types], spriteId: dex.id};
}

/** Consumes ONE official Showdown player channel. Never consumes engine state. */
export class PlayerView {
  constructor(side, ownSets = []) {
    this.side = side;
    this.ownSets = ownSets;
    this.state = {side, turn: 0, request: null, history: [], own: {active: [], revealed: []}, opponent: {active: [], revealed: []}, field: {weather: '', terrain: '', sideConditions: [], opponentSideConditions: []}};
    this.log = [];
  }
  party(side) { return side === this.side ? this.state.own : this.state.opponent; }
  mon(ident) {
    const party = this.party(ident.slice(0, 2));
    const slot = Math.max(0, ident.charCodeAt(2) - 97);
    return party.active[slot];
  }
  publicParticipant(ident = '') {
    const match = ident.match(/^(p[12])([a-c])?:/);
    if (!match) return null;
    const slot = match[2] ? match[2].charCodeAt(0) - 97 : -1;
    const mon = slot >= 0 ? this.party(match[1]).active[slot] : null;
    return {side: match[1] === this.side ? 'own' : 'opponent', slot, species: publicID(mon?.species)};
  }
  recordPublicEvent(type, args) {
    let kind = type.replace(/^-/, '');
    const actor = this.publicParticipant(args[0]);
    const event = {turn: this.state.turn, type: kind};
    if (actor) Object.assign(event, {actor: actor.side, slot: actor.slot, species: actor.species});
    const target = ident => {
      const participant = this.publicParticipant(ident);
      if (participant) Object.assign(event, {target: participant.side, targetSlot: participant.slot, targetSpecies: participant.species});
    };
    const hp = condition => {
      const conditionData = publicCondition(condition);
      if (conditionData.hp !== undefined) event.hp = conditionData.hp;
      event.status = conditionData.status;
      const before = actor?.slot >= 0 ? publicHP(this.mon(args[0])?.hpFraction) : undefined;
      if (before !== undefined) event.hpBefore = before;
    };
    if (['switch', 'drag', 'replace'].includes(type)) {
      if (!actor) return;
      event.species = publicID(args[1]?.split(',')[0]);
      hp(args[2]);
      delete event.hpBefore; // the outgoing slot's health belongs to a different Pokémon
    } else if (type === 'move') {
      if (!actor) return;
      event.move = publicID(args[1]); target(args[2]);
    } else if (['-damage', '-heal', '-sethp'].includes(type)) {
      if (!actor) return;
      hp(args[1]);
    } else if (type === 'faint') {
      if (!actor) return;
      hp('0 fnt');
    } else if (['-status', '-curestatus'].includes(type)) {
      if (!actor) return;
      event.effect = publicStatus(args[1]);
      event.status = type === '-status' ? event.effect : '';
    } else if (['-boost', '-unboost', '-setboost'].includes(type)) {
      if (!actor || !['atk', 'def', 'spa', 'spd', 'spe', 'accuracy', 'evasion'].includes(args[1])) return;
      event.effect = args[1];
      event.amount = Math.max(-6, Math.min(6, Number(args[2]) || 0)) * (type === '-unboost' ? -1 : 1);
    } else if (['-terastallize', '-ability', '-item', '-enditem', '-start', '-end', '-singleturn', '-singlemove', '-activate'].includes(type)) {
      if (!actor) return;
      event.effect = publicID(args[1]?.replace(/^(move|ability|item): /, ''));
    } else if (['detailschange', '-formechange'].includes(type)) {
      if (!actor) return;
      event.type = 'formechange'; event.species = publicID(args[1]?.split(',')[0]);
    } else if (type === '-transform') {
      if (!actor) return;
      target(args[1]);
    } else if (['-fail', '-immune', '-miss', '-crit', '-supereffective', '-resisted', '-clearboost'].includes(type)) {
      if (!actor) return;
      if (type === '-miss') target(args[1]);
    } else if (['-weather', '-fieldstart', '-fieldend'].includes(type)) {
      event.effect = publicID(args[0]?.replace(/^move: /, ''));
    } else if (['-sidestart', '-sideend'].includes(type)) {
      if (!actor) return;
      event.effect = publicID(args[1]?.replace(/^move: /, ''));
    } else {
      return; // Includes request, private hints, team preview, chat, names, and unknown future lines.
    }
    this.state.history.push(event);
    if (this.state.history.length > PUBLIC_HISTORY_LIMIT) this.state.history.shift();
  }
  receive(chunk) {
    let requested = false;
    const lines = chunk.split('\n');
    // Reject an entire wrong-channel chunk before it can add any state or history.
    for (const line of lines) {
      if (line.startsWith('|split|')) throw new Error('Information firewall: unsplit protocol supplied');
      if (line.startsWith('|request|')) {
        const request = JSON.parse(line.slice(9));
        if (request && request.side?.id !== this.side) throw new Error('Information firewall: wrong player request');
      }
    }
    for (const line of lines) {
      if (!line.startsWith('|')) continue;
      const [, type, ...args] = line.split('|');
      if (type === 'request') {
        const request = JSON.parse(args.join('|'));
        if (request) {
          if (request.side?.id !== this.side) throw new Error('Information firewall: wrong player request');
          for (const mon of request.side?.pokemon || []) {
            Object.assign(mon, speciesInfo(mon.details), health(mon.condition));
            const name = mon.ident.split(': ').slice(1).join(': ');
            const set = this.ownSets.find(s => (s.name || s.species) === name);
            if (set) mon.ownSet = clone(set);
          }
          for (const active of request.active || []) {
            for (const move of active.moves || []) move.type = Dex.moves.get(move.id || move.move).type;
          }
          this.state.request = request;
          requested = !request.wait;
        }
        continue;
      }
      if (type === 'split') throw new Error('Information firewall: unsplit protocol supplied');
      if (type === 'error') { this.state.error = args.join('|'); continue; }
      this.recordPublicEvent(type, args);
      this.log.push(line);
      if (type === 'turn') {
        this.state.turn = Number(args[0]);
        this.state.history = this.state.history.filter(event => this.state.turn - event.turn <= PUBLIC_HISTORY_LIMIT);
      }
      if (type === 'win' || type === 'tie') {
        this.state.ended = true; this.state.winner = args[0] || 'Tie'; this.state.request = null;
      }
      if (type === 'poke') {
        const party = this.party(args[0]);
        party.revealed.push({...speciesInfo(args[1]), hpFraction: 1, status: '', boosts: {}, movesSeen: [], preview: true});
      }
      if (['switch', 'drag', 'replace'].includes(type)) {
        const [ident, details, condition] = args;
        const party = this.party(ident.slice(0, 2));
        const info = speciesInfo(details);
        let mon = party.revealed.find(m => m.ident?.slice(4) === ident.slice(4));
        mon ||= party.revealed.find(m => m.preview && m.species === info.species);
        if (!mon) { mon = {}; party.revealed.push(mon); }
        Object.assign(mon, info, health(condition), {ident, preview: false, boosts: {}, movesSeen: mon.movesSeen || [], volatiles: [],lastMove:null,boostedStat:null,transformed:false});
        party.active[Math.max(0, ident.charCodeAt(2) - 97)] = mon;
      }
      const mon = this.mon(args[0] || '');
      if (mon) {
        if (['-damage', '-heal', '-sethp'].includes(type)) Object.assign(mon, health(args[1]));
        if (type === 'faint') Object.assign(mon, {hpFraction: 0, fainted: true, status: 'fnt'});
        if (type === 'move') { if (!mon.movesSeen.includes(args[1])) mon.movesSeen.push(args[1]); mon.lastMove = args[1]; }
        if (type === '-status') mon.status = args[1];
        if (type === '-curestatus') mon.status = '';
        if (type === '-boost') mon.boosts[args[1]] = Math.min(6, (mon.boosts[args[1]] || 0) + Number(args[2]));
        if (type === '-unboost') mon.boosts[args[1]] = Math.max(-6, (mon.boosts[args[1]] || 0) - Number(args[2]));
        if (type === '-setboost') mon.boosts[args[1]] = Number(args[2]);
        if (type === '-clearboost') mon.boosts = {};
        if (type === '-invertboost') for(const key in mon.boosts) mon.boosts[key]*=-1;
        if (type === '-clearpositiveboost') for(const key in mon.boosts) if(mon.boosts[key]>0)mon.boosts[key]=0;
        if (type === '-clearnegativeboost') for(const key in mon.boosts) if(mon.boosts[key]<0)mon.boosts[key]=0;
        if (type === '-copyboost') mon.boosts={...this.mon(args[1])?.boosts};
        if (type === '-transform') {
          const target=this.mon(args[1]);
          if(target)Object.assign(mon,{species:target.species,types:[...target.types],boosts:{...target.boosts},transformed:true});
        }
        if (type === '-ability') mon.ability = args[1];
        if (type === '-item') mon.item = args[1];
        if (type === '-enditem') mon.item = '';
        if (type === '-terastallize') { mon.terastallized = true; mon.teraType = args[1]; }
        if (type === 'detailschange' || type === '-formechange') Object.assign(mon, speciesInfo(args[1]));
        if (type === '-start') mon.volatiles = [...new Set([...(mon.volatiles || []), args[1]])];
        if (type === '-start' && /^(protosynthesis|quarkdrive)(atk|def|spa|spd|spe)$/.test(args[1])) mon.boostedStat=args[1].slice(-3);
        if (type === '-end') mon.volatiles = (mon.volatiles || []).filter(v => v !== args[1]);
        for (const extra of args) {
          if (extra.startsWith('[from] ability: ') && !args.some(a => a.startsWith('[of]'))) mon.ability = extra.slice(16);
          if (extra.startsWith('[from] item: ')) mon.item = extra.slice(13);
        }
      }
      if (type === '-clearallboost') for (const p of [this.state.own, this.state.opponent]) for (const m of p.active) if(m) m.boosts = {};
      if (type === '-weather') this.state.field.weather = args[0] === 'none' ? '' : args[0];
      if (type === 'gametype') this.state.field.gameType = args[0] === 'doubles' ? 'Doubles' : 'Singles';
      if (type === '-fieldstart' && args[0].includes('Terrain')) this.state.field.terrain = args[0].replace('move: ', '');
      if (type === '-fieldend' && args[0].includes('Terrain')) this.state.field.terrain = '';
      if (type === '-fieldstart' && args[0].includes('Trick Room')) this.state.field.trickRoom = true;
      if (type === '-fieldend' && args[0].includes('Trick Room')) this.state.field.trickRoom = false;
      if (type === '-sidestart' || type === '-sideend') {
        const key = args[0].startsWith(this.side) ? 'sideConditions' : 'opponentSideConditions';
        const effect = args[1].replace('move: ', '');
        if (type === '-sidestart') this.state.field[key].push(effect);
        else this.state.field[key] = this.state.field[key].filter(x => x !== effect);
      }
    }
    return requested;
  }
  snapshot() { return clone(this.state); }
}
