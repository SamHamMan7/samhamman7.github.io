import {Dex, Teams, TeamValidator} from '@pkmn/sim';
export const FORMATS = ['gen9ou', 'gen9randombattle', 'gen9randomdoublesbattle'];

/** Coherence is a transparent junk filter, never a claim of competitive strength. */
export function assessTeam(team) {
  const notes = [], roles = new Set();
  let score = 100;
  const types = new Set();
  for (const set of team) {
    const species = Dex.species.get(set.species);
    species.types.forEach(t => types.add(t));
    const moves = set.moves.map(m => Dex.moves.get(m));
    if (!set.item) { score -= 4; notes.push(`${set.species}: no held item.`); }
    if (!Object.values(set.evs || {}).some(x => x > 0)) { score -= 10; notes.push(`${set.species}: no EV investment.`); }
    if (moves.filter(m => m.category !== 'Status').length === 0) { score -= 8; notes.push(`${set.species}: no direct attack; check its role.`); }
    if (set.item?.startsWith('Choice') && moves.filter(m => m.category === 'Status' && m.id !== 'trick' && m.id !== 'switcheroo').length > 1) { score -= 10; notes.push(`${set.species}: multiple status moves with a Choice item.`); }
    if (set.item === 'Assault Vest' && moves.some(m => m.category === 'Status')) { score -= 30; notes.push(`${set.species}: Assault Vest prevents its status moves.`); }
    if (moves.some(m => ['stealthrock','spikes','toxicspikes','stoneaxe','ceaselessedge'].includes(m.id))) roles.add('hazards');
    if (moves.some(m => ['rapidspin','defog','mortalspin','tidyup'].includes(m.id))) roles.add('removal');
    if (species.baseStats.spe >= 110 || moves.some(m => m.priority > 0) || set.item === 'Choice Scarf') roles.add('speed');
    if (moves.some(m => m.category === 'Physical')) roles.add('physical');
    if (moves.some(m => m.category === 'Special')) roles.add('special');
    if (moves.some(m => ['uturn','voltswitch','flipturn','teleport','chillyreception'].includes(m.id))) roles.add('pivot');
  }
  for (const role of ['hazards','removal','speed','physical','special']) if (!roles.has(role)) { score -= 7; notes.push(`No ${role} role detected.`); }
  if (types.size < 5) { score -= 12; notes.push('Limited type diversity.'); }
  return {score: Math.max(0, score), roles: [...roles], notes};
}
export function validateTeam(paste, format = 'gen9ou') {
  if (!FORMATS.includes(format)) return {errors: ['Unsupported bundled format.'], notes: [], team: null};
  if (format.includes('random')) return {errors: [], notes: ['Uses the bundled official Showdown Random Battle generator.'], team: null};
  try {
    if (typeof paste !== 'string' || paste.length > 50000) throw new Error('Team paste is empty or too large.');
    const team = Teams.import(paste);
    if (!team?.length) return {errors: ['Paste a Pokémon Showdown team before starting.'], notes: [], team: null};
    const errors = new TeamValidator(format).validateTeam(team) || [];
    if (team.length !== 6) errors.push('This practice mode requires a full team of six Pokémon.');
    const quality = assessTeam(team);
    return {errors, notes: quality.notes, quality, team: errors.length ? null : team};
  } catch (error) { return {errors: [error.message], notes: [], team: null}; }
}
