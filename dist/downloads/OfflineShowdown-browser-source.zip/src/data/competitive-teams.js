// Source metadata travels with every bundled team.
export const COMPETITIVE_TEAMS = [
  {
    "id": "efd0a22207f6e5f9",
    "name": "Parasite by Vert",
    "paste": "Dragapult @ Heavy-Duty Boots  \r\nAbility: Infiltrator  \r\nTera Type: Fairy  \r\nEVs: 16 Atk / 240 SpA / 252 Spe  \r\nNaive Nature  \r\n- Dragon Darts  \r\n- Hex  \r\n- U-turn  \r\n- Will-O-Wisp  \r\n\r\nGliscor @ Toxic Orb  \r\nAbility: Poison Heal  \r\nTera Type: Fairy  \r\nEVs: 244 HP / 168 SpD / 96 Spe  \r\nCareful Nature  \r\n- Earthquake  \r\n- Protect  \r\n- Toxic Spikes  \r\n- Toxic  \r\n\r\nOgerpon-Wellspring (F) @ Wellspring Mask  \r\nAbility: Water Absorb  \r\nTera Type: Water  \r\nEVs: 244 Atk / 12 Def / 252 Spe  \r\nJolly Nature  \r\n- Ivy Cudgel  \r\n- Knock Off  \r\n- U-turn  \r\n- Taunt  \r\n\r\nIron Crown @ Booster Energy  \r\nAbility: Quark Drive  \r\nTera Type: Fighting  \r\nEVs: 80 HP / 4 Def / 172 SpA / 252 Spe  \r\nTimid Nature  \r\nIVs: 20 Atk  \r\n- Tachyon Cutter  \r\n- Psychic  \r\n- Focus Blast  \r\n- Calm Mind  \r\n\r\nTing-Lu @ Rocky Helmet  \r\nAbility: Vessel of Ruin  \r\nTera Type: Water  \r\nEVs: 24 HP / 4 Atk / 252 SpD / 228 Spe  \r\nJolly Nature  \r\n- Heavy Slam  \r\n- Taunt  \r\n- Stealth Rock  \r\n- Ruination  \r\n\r\nKingambit @ Air Balloon  \r\nAbility: Supreme Overlord  \r\nTera Type: Dark  \r\nEVs: 252 Atk / 4 Def / 252 Spe  \r\nJolly Nature  \r\n- Kowtow Cleave  \r\n- Low Kick  \r\n- Sucker Punch  \r\n- Swords Dance  \r\n",
    "provenance": {
      "source": "https://www.smogon.com/forums/threads/sv-ou-sample-teams-new-samples-added-post-spl-and-tera-blast-ban.3712513/",
      "pasteUrl": "https://pokepast.es/efd0a22207f6e5f9",
      "author": "Vert",
      "confidence": "high",
      "retrieved": "2026-09-10",
      "evidence": "Listed by OU room and forum staff as a sample team; no individual tournament placement claimed."
    }
  },
  {
    "id": "54d94a017c0f67ee",
    "name": "AV Torn + Specs Kyurem by Heileone",
    "paste": "Hatterene @ Rocky Helmet  \r\nAbility: Magic Bounce  \r\nTera Type: Flying  \r\nEVs: 248 HP / 204 Def / 56 Spe  \r\nBold Nature  \r\n- Psychic Noise  \r\n- Draining Kiss  \r\n- Pain Split  \r\n- Nuzzle  \r\n\r\nGreat Tusk @ Rocky Helmet  \r\nAbility: Protosynthesis  \r\nTera Type: Steel  \r\nEVs: 252 Atk / 4 SpD / 252 Spe  \r\nJolly Nature  \r\n- Rapid Spin  \r\n- Ice Spinner  \r\n- Headlong Rush  \r\n- Stealth Rock  \r\n\r\nTornadus-Therian @ Assault Vest  \r\nAbility: Regenerator  \r\nTera Type: Normal  \r\nEVs: 176 HP / 92 SpD / 240 Spe  \r\nTimid Nature  \r\n- Bleakwind Storm  \r\n- Heat Wave  \r\n- Knock Off  \r\n- U-turn  \r\n\r\nKyurem @ Choice Specs  \r\nAbility: Pressure  \r\nTera Type: Ice  \r\nEVs: 4 Def / 252 SpA / 252 Spe  \r\nTimid Nature  \r\nIVs: 0 Atk  \r\n- Blizzard  \r\n- Ice Beam  \r\n- Freeze-Dry  \r\n- Earth Power  \r\n\r\nSlowking-Galar @ Black Sludge  \r\nAbility: Regenerator  \r\nTera Type: Grass  \r\nEVs: 248 HP / 252 Def / 8 SpD  \r\nRelaxed Nature  \r\nIVs: 0 Atk / 0 Spe  \r\n- Sludge Bomb  \r\n- Future Sight  \r\n- Chilly Reception  \r\n- Trick  \r\n\r\nKingambit @ Leftovers  \r\nAbility: Supreme Overlord  \r\nTera Type: Ghost  \r\nEVs: 244 HP / 252 Atk / 12 Spe  \r\nAdamant Nature  \r\n- Kowtow Cleave  \r\n- Sucker Punch  \r\n- Iron Head  \r\n- Swords Dance  \r\n\r\n",
    "provenance": {
      "source": "https://www.smogon.com/forums/threads/sv-ou-sample-teams-new-samples-added-post-spl-and-tera-blast-ban.3712513/",
      "pasteUrl": "https://pokepast.es/54d94a017c0f67ee",
      "author": "Heileone",
      "confidence": "high",
      "retrieved": "2026-09-10",
      "evidence": "Listed by OU room and forum staff as a sample team; no individual tournament placement claimed."
    }
  },
  {
    "id": "f3a8f53d6e1fd2bb",
    "name": "Nasty Plot 3 Attacks Gholdengo by kDCA",
    "paste": "Kyurem @ Assault Vest  \r\nAbility: Pressure  \r\nTera Type: Poison  \r\nEVs: 252 Def / 144 SpA / 112 Spe  \r\nModest Nature  \r\nIVs: 0 Atk  \r\n- Earth Power  \r\n- Ice Beam  \r\n- Freeze-Dry  \r\n- Body Press  \r\n\r\nHatterene @ Rocky Helmet  \r\nAbility: Magic Bounce  \r\nTera Type: Flying  \r\nEVs: 248 HP / 204 Def / 56 Spe  \r\nBold Nature  \r\nIVs: 0 Atk  \r\n- Psychic Noise  \r\n- Draining Kiss  \r\n- Pain Split  \r\n- Nuzzle  \r\n\r\nDarkrai @ Choice Scarf  \r\nAbility: Bad Dreams  \r\nEVs: 252 SpA / 4 SpD / 252 Spe  \r\nTimid Nature  \r\nIVs: 0 Atk  \r\n- Dark Pulse  \r\n- Ice Beam  \r\n- Will-O-Wisp  \r\n- Trick  \r\n\r\nGreat Tusk @ Leftovers  \r\nAbility: Protosynthesis  \r\nTera Type: Poison  \r\nEVs: 232 HP / 88 Def / 188 Spe  \r\nImpish Nature  \r\n- Headlong Rush  \r\n- Ice Spinner  \r\n- Stealth Rock  \r\n- Rapid Spin  \r\n\r\nDragonite (F) @ Heavy-Duty Boots  \r\nAbility: Multiscale  \r\nTera Type: Normal  \r\nEVs: 248 HP / 108 Atk / 152 Spe  \r\nAdamant Nature  \r\n- Dragon Dance  \r\n- Extreme Speed  \r\n- Earthquake  \r\n- Roost  \r\n\r\nGholdengo @ Shuca Berry  \r\nAbility: Good as Gold  \r\nTera Type: Flying  \r\nEVs: 120 HP / 192 SpA / 196 Spe  \r\nModest Nature  \r\nIVs: 0 Atk  \r\n- Nasty Plot  \r\n- Make It Rain  \r\n- Thunderbolt  \r\n- Psyshock  \r\n\r\n",
    "provenance": {
      "source": "https://www.smogon.com/forums/threads/sv-ou-sample-teams-new-samples-added-post-spl-and-tera-blast-ban.3712513/",
      "pasteUrl": "https://pokepast.es/f3a8f53d6e1fd2bb",
      "author": "kDCA",
      "confidence": "high",
      "retrieved": "2026-09-10",
      "evidence": "Listed by OU room and forum staff as a sample team; no individual tournament placement claimed."
    }
  }
];
