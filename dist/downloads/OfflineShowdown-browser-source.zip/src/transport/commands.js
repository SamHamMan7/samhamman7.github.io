/** Existing Showdown client wire commands, including joint choices and request ids. */
export function parseLocalCommand(message) {
  const pipe=message.indexOf('|'), room=pipe<0?'':message.slice(0,pipe);
  const body=pipe<0?message:message.slice(pipe+1), space=body.indexOf(' ');
  const command=space<0?body:body.slice(0,space), arg=space<0?'':body.slice(space+1);
  if(command==='/utm') return {type:'team',team:arg};
  if(command==='/search') return {type:'start',format:arg};
  if(command==='/vtm') return {type:'validate',format:arg};
  if(['/choose','/team','/move','/switch'].includes(command)) {
    const end=arg.lastIndexOf('|'), rqid=end<0?null:Number(arg.slice(end+1));
    const choiceArg=end<0?arg:arg.slice(0,end);
    return {type:'choice',room,rqid,choice:command==='/choose'?choiceArg:command.slice(1)+' '+choiceArg};
  }
  if(command==='/forfeit') return {type:'forfeit',room};
  if(command==='/cmd'&&arg==='rooms') return {type:'rooms'};
  if(['/autojoin','/join','/leave','/cancelsearch','/noreply','/blockchallenges','/unblockchallenges','/blockpms','/unblockpms'].includes(command)) return {type:'ignore'};
  return {type:'unsupported',room,command};
}
