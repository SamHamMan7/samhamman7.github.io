// A delivery barrier around the protocol, not a replacement animation engine.
// Only p1 requests and public reveal lines reach this asset planner.
export function createBattleAssets({Dex, Storage}) {
  const images=new Map(), audio=new Map();
  const metrics={decoded:0,failed:[],batches:0,maxWaitMs:0,lastWaitMs:0};
  let common;
  function local(url) {
    if(!url)return '';
    const u=new URL(url,location.href);
    if(u.origin!==location.origin)throw new Error('Nonlocal battle asset: '+url);
    return u.pathname+u.search;
  }
  function image(url) {
    const key=local(url);if(!key)return Promise.resolve();
    if(images.has(key))return images.get(key).ready;
    const element=new Image();element.decoding='async';
    const entry={element,ready:null};
    entry.ready=new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(new Error('Image decode timed out: '+key)),12000);
      element.onerror=()=>{clearTimeout(timer);reject(new Error('Image load failed: '+key));};
      element.onload=async()=>{
        try {
          if(element.decode)await element.decode();
          if(!element.naturalWidth)throw new Error('Empty image: '+key);
          metrics.decoded++;clearTimeout(timer);resolve();
        }catch(e){clearTimeout(timer);reject(e);}
      };
      element.src=key;
    }).catch(e=>{metrics.failed.push(key);throw e;});
    images.set(key,entry);
    return entry.ready;
  }
  // Eight concurrent decodes prevent a team-preview burst from monopolizing memory.
  async function warm(urls) {
    const queue=[...new Set(urls)].filter(Boolean);
    await Promise.all(Array.from({length:Math.min(8,queue.length)},async()=>{
      while(queue.length)await image(queue.shift());
    }));
  }
  function sound(url) {
    const key=local(url);if(!key)return Promise.resolve();
    if(!audio.has(key))audio.set(key,fetch(key).then(r=>{if(!r.ok)throw new Error('Audio asset failed: '+key);return r.arrayBuffer();}).then(()=>{}));
    return audio.get(key);
  }
  function sprites(details, urls, sounds, {shiny=false,gender=''}={}) {
    const parts=String(details).split(',').map(s=>s.trim());
    const species=Dex.species.get(parts[0]);if(!species.exists)return;
    const options={gen:9,shiny:shiny||parts.includes('shiny'),gender:parts.find(s=>s==='M'||s==='F')||gender};
    const names=[species.name];
    const base=Dex.species.get(species.baseSpecies);
    for(const name of base.otherFormes||[]) {
      const form=Dex.species.get(name);
      if(form.battleOnly&&form.gen<=9&&!form.isNonstandard)names.push(name);
    }
    for(const name of new Set(names))for(const front of [false,true]) {
      const data=Dex.getSpriteData(name,front,options);
      urls.push(data.url);if(data.cryurl)sounds.push(data.cryurl);
    }
  }
  async function core() {
    if(!common)common=fetch('/battle-assets.json').then(r=>{if(!r.ok)throw new Error('Battle asset manifest missing');return r.json();}).then(m=>warm([...m.images,...[false,true].map(front=>Dex.getSpriteData('substitute',front,{gen:9}).url)]));
    return common;
  }
  async function prepare({lines=[],request=null,packed=''}={}) {
    const started=performance.now(),urls=[],sounds=[];
    for(const set of packed?Storage.unpackTeam(packed):[])sprites(set.species||set.name,urls,sounds,set);
    for(const pokemon of request?.side?.pokemon||[])sprites(pokemon.details||pokemon.speciesForme,urls,sounds);
    for(const line of lines) {
      const p=line.split('|');
      if(['poke','switch','drag','replace','detailschange','-formechange'].includes(p[1]))sprites(p[3],urls,sounds);
      if(p[1]==='player'&&p[4])urls.push(Dex.resolveAvatar(p[4]));
      // Transform can copy a previously revealed opponent; both facings are warm.
    }
    await Promise.all([core(),warm(urls),...[...new Set(sounds)].map(url=>sound(url))]);
    metrics.batches++;metrics.lastWaitMs=performance.now()-started;
    metrics.maxWaitMs=Math.max(metrics.maxWaitMs,metrics.lastWaitMs);
  }
  return {
    prepare,
    // Release previous battle sprite references; the browser can evict their decoded
    // frames. Core effects remain warm. Requests never inspect the opponent worker.
    reset(){for(const key of images.keys())if(/\/sprites\/(ani|gen5)/.test(key)&&!key.includes('substitute'))images.delete(key);audio.clear();},
    snapshot:()=>({...metrics,failed:[...metrics.failed],retainedImages:images.size}),
  };
}
