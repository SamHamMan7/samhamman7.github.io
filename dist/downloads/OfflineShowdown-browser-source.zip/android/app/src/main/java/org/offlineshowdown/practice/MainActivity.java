package org.offlineshowdown.practice;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.ConsoleMessage;
import android.webkit.MimeTypeMap;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** A local HTTPS asset origin, without a socket server, network permission, or JavaScript bridge. */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/index.html";
    private static final int CHOOSE_FILE = 10;
    private WebView webView;
    private int startupStage;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createWebView();
    }

    @SuppressWarnings("deprecation")
    private void createWebView() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(21, 34, 56));
        webView = new WebView(this);
        startupStage = 0;
        webView.setVisibility(View.INVISIBLE);
        frame.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Android 15 edge-to-edge: keep controls below the camera/status bar and above navigation/IME.
        frame.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        setContentView(frame);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        // Interception handles local HTTPS before fallback. Anything unmatched also gets a local error.
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return localResponse(request.getUrl(), request.getMethod());
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (startupStage == 1 && "about:blank".equals(request.getUrl().toString())) return false;
                return !isLocal(request.getUrl());
            }

            private void retireLegacyCache(WebView view) {
                if (startupStage == 0) {
                    startupStage = 1;
                    // Do not finish loading thousands of old cached resources first.
                    // The committed real document already has a valid storage origin.
                    view.stopLoading();
                    view.evaluateJavascript("(async()=>{"
                            + "if('serviceWorker' in navigator)for(const r of await navigator.serviceWorker.getRegistrations())await r.unregister();"
                            + "if('caches' in window)for(const k of await caches.keys())if(k.startsWith('offline-'))await caches.delete(k);"
                            + "location.replace('about:blank');"
                            + "})().catch(e=>{document.body.textContent='Unable to start: '+e.message;});", null);
                    view.setVisibility(View.VISIBLE);
                }
            }

            @Override public void onPageCommitVisible(WebView view, String url) {
                retireLegacyCache(view);
            }

            @Override public void onPageFinished(WebView view, String url) {
                retireLegacyCache(view);
                if (startupStage == 1 && "about:blank".equals(url)) {
                    // Unregistering does not release the current document's controller.
                    // Destroy that document before navigating to the bundled client.
                    startupStage = 2;
                    view.loadUrl(START_URL);
                }
            }

            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                ((ViewGroup) view.getParent()).removeView(view);
                view.destroy();
                webView = null;
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Battle view stopped")
                        .setMessage("Android closed the web renderer. Your saved teams remain on this device, but the active battle must restart.")
                        .setPositiveButton("Reopen", (dialog, which) -> createWebView())
                        .setCancelable(false).show();
                return true;
            }
        });
        // This also covers a service worker if the web application adds one later.
        ServiceWorkerController controller = ServiceWorkerController.getInstance();
        controller.getServiceWorkerWebSettings().setAllowContentAccess(false);
        controller.getServiceWorkerWebSettings().setAllowFileAccess(false);
        controller.setServiceWorkerClient(new ServiceWorkerClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                return localResponse(request.getUrl(), request.getMethod());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                Log.d("OfflineShowdown", message.messageLevel() + " " + message.message()
                        + " @" + message.sourceId() + ":" + message.lineNumber());
                return true;
            }

            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                                        FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(intent, CHOOSE_FILE); }
                catch (ActivityNotFoundException exception) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    new AlertDialog.Builder(MainActivity.this).setMessage("No file picker is available. Paste your team text in the team editor.")
                            .setPositiveButton("OK", null).show();
                }
                return true;
            }
        });
        WebView.setWebContentsDebuggingEnabled(true); // Sideload development build only.
        // A real same-origin document can retire old registrations; loadDataWithBaseURL
        // cannot call getRegistrations in WebView. An old worker may serve its cached
        // shell here; onPageFinished still performs the same cleanup and blank hop.
        // localStorage (including saved teams) is deliberately preserved.
        webView.loadUrl("https://" + HOST + "/__offline_start__");
    }

    private static boolean isLocal(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
                && (uri.getPort() == -1 || uri.getPort() == 443);
    }

    private WebResourceResponse localResponse(Uri uri, String method) {
        if (!isLocal(uri) || !("GET".equals(method) || "HEAD".equals(method))) {
            return errorResponse(403, "Offline app: external requests are disabled.");
        }
        String path = uri.getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        if (path.equals("/__offline_start__")) {
            return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(
                    "<!doctype html><meta name='viewport' content='width=device-width'><p>Loading Pokémon Showdown…</p>".getBytes(StandardCharsets.UTF_8)));
        }
        if (path.indexOf('\\') >= 0 || path.indexOf('\0') >= 0) return errorResponse(400, "Invalid asset path.");
        for (String segment : path.split("/")) {
            if (segment.equals("..") || segment.equals(".")) return errorResponse(400, "Invalid asset path.");
        }
        try {
            InputStream content = getAssets().open("web" + path);
            Map<String, String> headers = new HashMap<>();
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Cache-Control", "no-cache");
            headers.put("Cross-Origin-Resource-Policy", "same-origin");
            if ("HEAD".equals(method)) { content.close(); content = new ByteArrayInputStream(new byte[0]); }
            return new WebResourceResponse(mimeType(path), "UTF-8", 200, "OK", headers, content);
        } catch (IOException exception) {
            Log.w("OfflineShowdown", "Missing bundled asset: " + path);
            return errorResponse(404, "Bundled asset not found.");
        }
    }

    private static String mimeType(String path) {
        String extension = path.substring(path.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
        if (extension.equals("js") || extension.equals("mjs")) return "text/javascript";
        if (extension.equals("json") || extension.equals("map")) return "application/json";
        if (extension.equals("wasm")) return "application/wasm";
        if (extension.equals("svg")) return "image/svg+xml";
        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        return type == null ? "application/octet-stream" : type;
    }

    private static WebResourceResponse errorResponse(int status, String message) {
        return new WebResourceResponse("text/plain", "UTF-8", status,
                status == 404 ? "Not Found" : status == 403 ? "Forbidden" : "Bad Request",
                new HashMap<>(), new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8)));
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == CHOOSE_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        new AlertDialog.Builder(this).setTitle("Close Offline Showdown?")
                .setMessage("Saved teams stay on this device. An unfinished battle will be lost.")
                .setNegativeButton("Keep playing", null)
                .setPositiveButton("Close", (dialog, which) -> finish()).show();
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
