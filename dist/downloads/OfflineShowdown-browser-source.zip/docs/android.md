# Android offline app

The APK packages the web application, real Showdown simulator, AI workers, rules data, and artwork into one installable Android application. It does not launch a server or need Node.js on the phone. Runtime network access is disabled: the manifest does not request `android.permission.INTERNET`.

## Install on the Pixel 9a

1. Copy `artifacts/OfflineShowdown-v1.apk` to the phone using USB or another file transfer method.
2. Open the APK in Files. Android may ask you to allow that file manager to install unknown apps; enable it for this installation.
3. Launch **Offline Showdown**. Saved teams live in the app's local WebView storage.
4. Turn on airplane mode, with Wi-Fi and Bluetooth off. Launch a battle, finish it, then start another battle without reconnecting.

Alternatively, after enabling USB debugging and accepting the computer's debugging prompt on the phone:

```powershell
& .\.tools\android-sdk\platform-tools\adb.exe install -r .\artifacts\OfflineShowdown-v1.apk
& .\.tools\android-sdk\platform-tools\adb.exe shell am start -n org.offlineshowdown.practice/.MainActivity
```

The APK is a development build signed with a local development key. Keep `.tools/offline-showdown-debug.keystore` if you want subsequent builds to install as updates without uninstalling and losing saved teams. Uninstalling or clearing application storage deletes locally saved data.

Android v1 uses versionName `1.0.0` / versionCode `2`, package
`org.offlineshowdown.practice`. Very Strong is the default; Neural Preview is
experimental. No automatic training or model replacement happens on the phone.
Preserve existing app storage when installing with `-r`.

For this already-prepared repository, the exact tested Windows build commands are:

```powershell
npm.cmd test
npm.cmd run build
& .\scripts\android-build.ps1 -JavaHome 'C:\Users\wjxia\AppData\Local\Programs\BurpSuiteCommunity\jre' -VersionCode 2 -VersionName '1.0.0'
Copy-Item .\artifacts\OfflineShowdown-debug.apk .\artifacts\OfflineShowdown-v1.apk
& .\scripts\source-package.ps1
```

The JDK path above is specific to this workstation; substitute your JDK path
elsewhere. The generated debug APK and its v1 copy contain identical bytes.
Verify the copy with `Get-FileHash .\artifacts\OfflineShowdown-v1.apk -Algorithm SHA256`.

## Build on Windows

Prerequisites: Node.js/npm for the web build, PowerShell, and a JDK with `java`, `javac`, and `keytool` (JDK 17 or newer). No Android Studio or Gradle is required.

```powershell
npm ci
npm run prepare:client
npm run prepare:assets
npm run build
pwsh -File .\scripts\android-setup.ps1
pwsh -File .\scripts\android-build.ps1 -JavaHome 'C:\path\to\your\jdk'
```

`-JavaHome` is optional when `JAVA_HOME` or a `javac` executable is available on `PATH`. `-SdkRoot` can point at an existing SDK containing `platforms/android-35` and `build-tools/35.0.0`. Google’s standalone build-tools archive calls its top directory `android-15`; the script handles both layouts.

Setup downloads pinned official Google archives, verifies SHA-256, and extracts them only into `.tools/android-sdk`. Build dependencies require an initial online download; subsequent APK builds and all installed battles can run offline. Android SDK use is covered by [Google's SDK license](https://developer.android.com/studio/terms).

The build script compiles resources with AAPT2, compiles Java, converts bytecode with D8, bundles the complete `dist` directory, aligns and signs the APK, verifies its signature/alignment, and fails if the resulting manifest requests Internet permission. Outputs:

- `artifacts/OfflineShowdown-debug.apk`
- `artifacts/OfflineShowdown-debug.apk.sha256`
- `artifacts/OfflineShowdown-source.zip` (run `scripts/source-package.ps1` and supply alongside the APK)

The official client's full offline sprite, animation, cry and music bundle makes the APK about 537 MiB including experimental neural models. Asset preparation is an initial download; no resource download is needed on the phone. The source package includes pinned client/application source, browser data and build scripts. Preserve the resource archives and their hash manifests for later builds.

The scripts use only Android's standard public SDK tools; Android documents this [manual packaging and signing path](https://developer.android.com/build/building-cmdline).

## Runtime design

`MainActivity` serves APK assets directly from `AssetManager` at `https://appassets.androidplatform.net/`. This is an intercepted local HTTPS origin, not a DNS request or a listening socket. The mechanism follows Android's [recommended local HTTPS content approach](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content), implemented using framework classes to avoid an additional AndroidX dependency.

The origin supports the same-origin behavior needed for JavaScript module workers, storage, and local fetches. Both normal WebView and service-worker requests are intercepted. External requests return a local 403 response, missing assets return a local 404, file access is disabled, mixed content is disabled, and external navigation is rejected. There is no JavaScript-to-native bridge or network permission. APK resources do not need a service worker; caches left by the previous frontend are retired at startup without deleting localStorage teams.

The shell targets Android API 35, with minimum API 26. It contains no native `.so` libraries, so the APK works across Android CPU architectures and does not introduce a native-library 16 KB page-size compatibility requirement. The device supplies Android System WebView. Rotation preserves the WebView and workers; the native window applies status bar, navigation bar, display cutout, and keyboard insets.

## Verification and practical limits

The v1 acceptance commands on the prepared workstation are:

```powershell
node scripts/serve.mjs
# In another terminal, with the existing Android emulator running:
node scripts/showdown-browser-test.mjs
node scripts/showdown-animation-test.mjs
node scripts/showdown-recovery-test.mjs
& .\scripts\android-test.ps1 -Serial emulator-5554
node scripts/android-upgrade-test.mjs
node scripts/android-lifecycle-test.mjs
node scripts/neural-browser-probe.mjs models/gen9randombattle --installed --android
node scripts/showdown-animation-test.mjs --android
```

The Android test installs the debug-named build as an update, enables airplane
mode and disables Wi-Fi/mobile data. It verifies Very Strong is the default.
Upgrade coverage includes an edited team retaining an old bundled name;
rotation and brief background/resume are tested separately. Animation fixtures
measure decoded first uses, not exhaustive visual correctness of every move.

APK signature, ZIP alignment, packaged asset presence, and absence of Internet permission are machine-checkable. Browser offline tests verify the JavaScript battle path, but do not by themselves prove physical Pixel performance. Record Android/emulator and physical-device results separately in the project verification report.

For a physical acceptance test, cold-launch the installed app in airplane mode; import/save a team; finish a singles battle including switches and forced replacements; finish a Random Battle; rotate during a battle; return to the app after a brief background pause; and confirm your saved team remains after relaunch. Measure AI turn latency on the actual Pixel before claiming a phone-specific performance result.

Android can reclaim a background renderer or terminate the app. Saved teams survive normal restarts, but active battle recovery depends on the web application saving its battle state. The native shell displays a recovery dialog if its renderer is reclaimed. Do not assume a long-backgrounded battle remains active. Build updates must retain the signing key to preserve install/update continuity.

For troubleshooting with USB debugging enabled:

```powershell
& .\.tools\android-sdk\platform-tools\adb.exe logcat -s OfflineShowdown chromium AndroidRuntime
```

The development APK permits local WebView debugging through Chrome's `chrome://inspect` while connected by USB. This is a development convenience; it is not a runtime Internet dependency.
