# Local neural training and evaluation

## Android v1 review (2026-09-14)

Very Strong remains the stable default. No training run promotes itself into
the application. Neural Preview retains the previously installed first-epoch
BC graph (`c7be6af0...`) and is explicitly experimental.

| Checkpoint | Very Strong matchup | Evidence |
| --- | --- | --- |
| BC epoch 1, 2,000 teacher games | 7 wins / 100 | `bc-2000/epoch-1/vs-very-strong.jsonl.report.json` |
| BC epoch 4 | 7 / 100 | `bc-2000/final/vs-very-strong.jsonl.report.json` |
| Earlier two-iteration PPO | 2 / 100 | `ppo-bc-epoch1/iteration-0002/vs-very-strong.jsonl.report.json` |
| Latest conservative PPO | 11 / 100 | `manual-ppo1/vs-very-strong.jsonl.report.json` |

Evidence paths above are relative to `artifacts/neural`. All use paired seeds
918311, so they are exploratory comparisons, not independent proof of a
significant strength gain. The 2/100 checkpoint was not deployed. The 11/100
checkpoint is retained for evaluation rather than replacing the stable AI.
The two-iteration self-play loop trained on 7,093 true neural decisions across
200 games with historical opponents. The later conservative update used 5,351
sampled neural decisions across 200 games against Very Strong. Teacher actions
were not substituted for the learner's sampled log probabilities.

The critic is overfitting: epoch 4 training Brier is 0.0073 versus 0.3653 on
held-out games (0.25 for a constant 50/50 prediction). Signed PPO values and
exported win probabilities use consistent units; terminal win/loss gradient
regressions verify this. PPO now uses a nonnegative KL estimate and a
`--target-kl 0.015` update guard to limit shared-encoder policy drift from value
fitting. A low-threshold real-rollout smoke run verified the guard stops updates.
This protects future training; it does not repair or revalidate existing models.

The separate 0.9M-parameter auxiliary model is trained and executes in the
browser/Android worker. Its semantic next-move accuracy was 46.55% versus a
43.59% species prior on held-out ordinary turns. Its hidden set heads performed
worse than species priors; none currently changes selected actions. Original
set predictions are not current facts after Trick/consumption/Transform. In v2,
an empty public item and an unrevealed item share a zero feature; public-view
evidence must resolve that before using a belief to construct a world.

Public damage features are a suitable next experiment using the existing
`@smogon/calc`, without importing another UI or replacing `@pkmn/sim`. Proposed
features: damage ranges and KO probability across public set hypotheses, speed
order uncertainty, hazards, and own-Tera-adjusted matchups. Inputs must come
from the player's request and public reveals only; unknown opponent items,
spreads, moves and Tera stay distributions. This requires a versioned encoder
and equal-budget benchmarks and is deliberately deferred from Android v1.

Do not reapply the original bootstrap over the integrated code. The live input
contract is observation v2 (29 tokens, 12 categorical and 22 numeric features).
Only Gen 9 Random Battle singles is supported by the learned policy.

Use the workspace Python environment `.tools/neural-python/Scripts/python.exe`
or install `training/jaxlite/requirements.txt` on a training workstation. GPU
training is selected automatically when CUDA is available; this workspace is
currently using CPU. Training runs on the workstation, never on the phone.

## Current teacher data and BC

The completed `artifacts/neural/randbats-v2` directory contains 2,000 games and
127,430 decisions. Its report verifies 4,000 terminal trajectories, zero invalid
rows, illegal targets, or opponent private-stat fields. No more teacher data is
needed for the current experiment. The separately supplied 500-game teacher
file is retained. Whole games are held out from BC validation.

```powershell
node scripts/neural-trajectory-report.mjs artifacts/neural/randbats-v2 artifacts/neural/randbats-v2/report.json
& .\.tools\neural-python\Scripts\python.exe -u training/jaxlite/train_bc.py artifacts/neural/randbats-v2 --epochs 4 --batch-size 256 --threads 4 --output artifacts/neural/bc-2000/jaxlite-bc.pt
```

Each completed epoch is saved atomically with optimizer and RNG state. If the
process actually stops, resume with the same data and split options:

```powershell
& .\.tools\neural-python\Scripts\python.exe -u training/jaxlite/train_bc.py artifacts/neural/randbats-v2 --resume artifacts/neural/bc-2000/jaxlite-bc.pt --epochs 4 --batch-size 256 --threads 4 --output artifacts/neural/bc-2000/jaxlite-bc.pt
```

Optional AWBC is an imitation experiment, not PPO:

```powershell
& .\.tools\neural-python\Scripts\python.exe -u training/jaxlite/train_awbc.py artifacts/neural/randbats-v2 --init artifacts/neural/bc-2000/jaxlite-bc.pt --epochs 2 --batch-size 256 --threads 4 --output artifacts/neural/awbc-2000/jaxlite-awbc.pt
```

## Export, deploy and compare

Export a stable checkpoint, not a file being replaced by an active trainer.
The exporter checks Torch/ONNX parity and writes a hash-checked manifest.

```powershell
& .\.tools\neural-python\Scripts\python.exe -u training/jaxlite/export_onnx.py artifacts/neural/bc-2000/jaxlite-bc.pt --output artifacts/neural/bc-2000/jaxlite-bc.onnx
node scripts/neural-rollouts.mjs --games 100 --seed 918311 --model artifacts/neural/bc-2000/manifest.json --opponent "Very Strong" --evaluate --output artifacts/neural/bc-2000/vs-very-strong.jsonl
```

Evaluation alternates the learner between both sides of each generated team
pair. The native runtime is constrained to one inference thread. The report
records actual wins/losses, model hash, and latency. It does not establish
physical Pixel performance. Use fresh seeds for a final held-out strength
comparison after choosing an architecture on exploratory benchmarks.

To deploy the chosen experimental checkpoint in Neural Preview:

```powershell
New-Item -ItemType Directory -Force models/gen9randombattle | Out-Null
Copy-Item artifacts/neural/bc-2000/jaxlite-bc.onnx models/gen9randombattle/
Copy-Item artifacts/neural/bc-2000/manifest.json models/gen9randombattle/
npm.cmd run build
node scripts/neural-browser-probe.mjs models/gen9randombattle --installed
```

The installed probe uses the real production worker and model URLs without
intercepting them. Neural Preview falls back to Very Strong for a missing,
incompatible, failed, or unsupported model. Model execution does not imply the
checkpoint is stronger than Very Strong. Android packaging must be rebuilt
separately to include any newly deployed weights.

## True neural PPO and historical checkpoints

```powershell
node scripts/neural-selfplay.mjs --init artifacts/neural/bc-2000/jaxlite-bc.pt --model artifacts/neural/bc-2000/manifest.json --run-dir artifacts/neural/ppo-2000 --iterations 4 --games 100 --epochs 2 --batch-size 128 --threads 4 --seed 773121
```

Run the same command to resume. `--iterations` is the total iteration target.
Each iteration collects real sampled ONNX actions/log-probabilities/values from
`@pkmn/sim`, trains clipped PPO with GAE and undiscounted terminal win reward,
exports and checks ONNX, and registers a hashed historical checkpoint. The
learner plays 45% against its current policy and 55% against historical policies
when history exists. Historical opponent rows do not enter the learner's PPO
updates. No checkpoint is promoted automatically. Evaluate the resulting
`iteration-0004/manifest.json` using the same benchmark command.

## Privacy and current limitations

`rb-privileged-500.jsonl` contains auxiliary training targets. It must never be
bundled in the app or passed as model inputs. Only sanitized `observation`
tensors enter ONNX. Revealed opponent properties are legal inputs; original
generated item/ability/move/Tera labels are not always current after public
changes such as Trick, Transform, or consumption.

The original 14-slot opponent head predicts hidden request slot indices, which
alone cannot identify semantic opponent moves. Semantic response prediction and
hidden-set auxiliary learning are a separate experiment. A response-matrix
interface and state-dependent risk aggregator exist, but no live simulator
response search has yet been validated. See PROGRESS.md for actual measured
checkpoint results; do not infer strength from smoke tests or self-play balance.
