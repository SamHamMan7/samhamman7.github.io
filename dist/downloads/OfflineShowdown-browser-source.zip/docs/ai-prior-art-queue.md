# Next strength milestone (after native client/APK verification)

User-provided research is queued, not claimed as studied or implemented:

- Jaxcalibur: https://jaxcalibur.github.io/ and https://www.smogon.com/forums/threads/jaxcalibur-a-gen-9-randbats-bot-that-reached-1-on-the-ladder.3787537/
  Study the reportedly compact 8.5M Transformer, recent history, policy/value,
  opponent-next-action and hidden set/item/ability/Tera heads, world sampling,
  simultaneous-action pUCT/regret matching. Verify reported ladder results from
  sources. Keep actual Showdown mechanics; do not port mechanics to JAX or copy
  its GPU rollout budget. Experiment with the same ideas for OU too.
- Metamon: https://github.com/UT-Austin-RPL/metamon and https://arxiv.org/html/2504.04395v1
  Study Gen 9 OU policies, human replay trajectories, full-history sequence models,
  imitation/RL, opponent adaptation, arbitrary-team generalization, pretrained
  policies and human-like action distributions.
- VGC-Bench: https://github.com/cameronangliss/vgc-bench
  Study code/datasets, human behavior cloning, multi-agent RL, Team Preview,
  open team sheets, diverse-team generalization and matchup-specific training.
  Doubles must model joint actions/targets, Protect, switches, redirection,
  spread moves, speed control and ally interactions, not a reused singles policy.

Observed weaknesses to target: too few meaningful opponent predictions, myopic
offensive Terastallization and excessive immediate damage/KO valuation compared
with long-term win probability. Very Strong is also too risk-seeking. A mixed
strategy must mix strong alternatives, never reward a prediction or aggression
for its own sake. When ahead, favor robust low-variance lines and simplification;
when even, mix genuinely strong choices; when behind, accept calculated variance.
Evaluate likely opponent-response distributions and downside when a read fails.
Preserve Tera, healthy defensive checks, win conditions and future flexibility.
Add named regression positions for unnecessary offensive Tera, overprediction,
risky double-switches, sacrificing a healthy check for immediate damage, and
failing to simplify when ahead. A flashy Tera/KO must lose to a safer line when
long-run win probability is worse or common responses punish it severely.

Benchmark learned/hybrid policies against the
current policy with identical legal information, seeds/team pairs and Pixel-like
compute budgets. Use meaningful agents and tactical positions, not only greedy
baselines. Keep the stronger measured architecture; no unmeasured Elo claims.

Training and deployment are separate. Workstation/GPU training or public datasets
and model weights may feed distillation/quantization. The phone runs efficient
offline inference/search only; do not attempt large-scale phone training.

Previously read: Agarwal's Pokémon Arena engineering history, ps-ppo, foul-play,
and taylorhansen/pokemonshowdown-ai. Preserve lessons in `engineering.md` and the
existing authoritative BattleStream/player-stream boundary.
