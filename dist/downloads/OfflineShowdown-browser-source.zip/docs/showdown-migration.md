# Official client integration

The production build uses the actual `smogon/pokemon-showdown-client` at commit
`1e3b209011340e7c149a2e94769183eb4351b2e9`. Its mature client is maintained upstream
under `play.pokemonshowdown.com/src/oldclient`. The previous custom frontend was
removed; it remains recoverable in Git commit `ee606ef`.

`scripts/build.mjs` compiles `src/showdown-main.js` as `dist/main.js` and copies the
official scripts, styles, data and assets. `scripts/showdown-distribution.mjs`
derives the entry HTML from upstream `index-old.html`, redirects asset URLs to
the local origin, initializes local storage without a cross-domain login iframe,
and loads the separately compiled official animation modules. Upstream's checkout
is unchanged. Distribution changes are explicit and reproducible in that script.

`App.connect` installs a local socket. `App.send` and the original battle controls
remain intact. `src/transport/commands.js` accepts packed teams, validation,
search/start, preview, move, switch, joint choices, rqid and forfeit commands.
The adapter starts the existing engine worker, which owns the actual BattleStream.
Each p1 protocol chunk goes to `app.receive('>battle-id\n' + chunk)`. Requests
are delivered separately because the mature battle room recognizes them only at
the beginning of a message. A one-use worker token supplies the server rqid.

The original Showdown battle room, animations, tooltips, log, targeting, team
preview, move/switch controls, teambuilder and mobile CSS are used directly.
Offline entry points use existing menu classes and native format/team selectors.
The team builder writes native `showdown_teams` storage; old saved teams migrate
once. Online login, remote team loading and Smogon resource requests are disabled.
Only the three engine-supported formats are advertised.

The engine's per-player stream split and sanitized AI interface are preserved.
The p2 AI receives its own request and publicly revealed opponent information;
it receives neither the human's choice nor the simulator seed or hidden team.
Watch mode uses independently sanitized requests for both policies.

No Android runtime blocker was found. The WebView reads the same static files and
workers from APK assets under `appassets.androidplatform.net`. No Node server,
socket server, internet permission or JS/native bridge is required on the device.
The concrete costs are installation size and asset preparation: the official
normal/shiny/front/back animations, static sprites, cries, music and effects total
roughly 550 MiB uncompressed. The downloaded archive is older than the pinned
client data; renderer-discovered supplemental assets are URL/hash recorded.
For a few URLs absent upstream too, the renderer uses the official static image
of the same form. A missing Bloodmoon Ursaluna cry is skipped.

Client code is AGPL-3.0, with MIT notices on the simulator and certain shared
modules. The application's source is supplied under AGPL-3.0 in `LICENSE`.
Pokémon artwork/audio retain their separate ownership; code licensing does not
grant rights to those assets. Preserve all notices. The preparation manifests,
scripts, source checkout and downloaded data snapshot accompany this work.

The corresponding-source ZIP does not require Git metadata. Packaging records all
965 tracked upstream files in `vendor/showdown-source-manifest.json`; preparation
verifies their bytes against that manifest and the pinned commit when `.git` is
absent. From an extracted ZIP, run
`node scripts/vendor-showdown-client.mjs --verify-source` to check source and the
retained data snapshot without downloading or compiling, then follow the README's
normal preparation/build commands. Altered or missing upstream source is rejected
explicitly; the preparation step never replaces the archived source by recloning.
The separate artwork/audio preparation still needs its pinned resource archives
or the already prepared local assets.

Tests distinguish actual browser offline reload from online smoke checks and
native Android airplane mode. Physical Pixel 9a performance remains a separate
acceptance requirement; emulator results do not establish phone performance.
