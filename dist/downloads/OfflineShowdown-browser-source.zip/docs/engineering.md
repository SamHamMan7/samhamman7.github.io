# Engineering decisions and evidence

The local simulator and Android package are working; see `PROGRESS.md` and the reports for current test coverage. Physical Pixel acceptance and experienced-player strength remain unproven.

## Prior art applied

[Lakshya Agarwal's Pokémon Arena](https://lakshyaag.com/blogs/building-a-pokemon-arena) describes a failed modular/websocket integration followed by a reliable local Showdown server and poke-env bridge. The lesson applied here is to keep one authoritative simulator and consume its player protocol. We first tested complete battles, then browser and Android offline battles. Android embeds the browser-compatible Showdown extraction because Python/server orchestration would complicate a self-contained phone install. There are no reimplemented battle-resolution rules, sockets or cloud inference.

[@pkmn/sim](https://github.com/pkmn/ps/tree/main/sim) is an automatically maintained extraction of Showdown's simulator/validator for browser use. Its documented random-generator extension is `@pkmn/randoms`. Both versions are locked together. `getPlayerStreams` performs the official split-message filtering. A private `BattleSession` owns the engine; the AI worker receives only a structured-cloned p2 view, its own request and public data. It never receives the simulator, battle RNG seed, human command or unrevealed human set. Learned priors are hypotheses, never substituted into the actual battle engine.

[ps-ppo](https://github.com/Nebraskinator/ps-ppo) demonstrates entity-based representations, imitation bootstrapping and PPO self-play for Gen 9 Random Battle. Its author reports strong ladder/baseline results, but those results do not transfer to this app. The repository is archival and its inference/training stack requires model checkpoints and Python frameworks. We use separate Random Battle beliefs and benchmarks now; a measured mobile model export remains a possible future improvement.

[Foul Play's search implementation](https://github.com/pmariglia/foul-play/blob/main/fp/search/main.py) samples uncertain battle states, searches them with poke-engine MCTS, and aggregates weighted policies. We apply the uncertainty-weighted response idea in a bounded local evaluator. Importing its Python/Rust stack and GPL code was not necessary for the first working APK. Our current two-turn forecast is approximate, not Foul Play's MCTS or a claim of equal strength.

[Taylor Hansen's Pokémon Showdown AI](https://github.com/taylorhansen/pokemonshowdown-ai) separates protocol tracking, bot transport and neural training, and currently documents Gen 4 Random Battle support. This reinforces the need to test the protocol boundary separately and calibrate each format. Its Gen 4 trained policy is not a compatible Gen 9 drop-in.

## Current policy

Singles ranks legal request actions using the Smogon generation-nine damage calculator, speed/priority reasoning, uncertain opponent responses, switches, hazards, healing, setup, Tera cost and bounded next-turn continuation. Known private own stats are allowed inputs. Hidden enemy spreads/items/abilities come from explicit public priors. OU uses a compact August 2026 Smogon snapshot; Random Singles uses Showdown's public set families. Statistical marginals are not claimed to be correlated sets and are never used to independently generate a team.

Doubles evaluates paired commands, legal targets, concentrated damage/overkill, spread damage and ally costs, support, Protect, switching and forced passes. Only one Tera and one use of each reserve slot are allowed. This policy is less mature than singles and needs stronger tactical and adversarial evaluation.

Difficulty currently controls search width, response count and budget. Medium/Strong/Very Strong are product settings, not tested ladder Elo equivalents. The OU statistics cutoff (1825) describes the data source only. No rating threshold is applied to Random Battle difficulty.

The current official Random Battle top-500 listing was inspected separately; `reports/random-ladder-snapshot.json` records retrieval time and aggregate rating range. It is a selected leaderboard, not a population distribution, and cannot convert local baseline win rates into ladder ratings. Current paired tests also compare difficulty settings directly by format.

## Offline proof and its limits

The JavaScript test harness disables fetch for full simulator games. The browser test goes further: it caches all assets, sets Chrome's network state to offline, reloads, and completes games by clicking the same mobile controls. The native test installs the actual APK, checks airplane mode and Wi-Fi state, and plays the app's real WebView. Android also denies network capability at the manifest level, and intercepts external requests with a local error. Local ADB debugging is test control, not a runtime server dependency.

Reports are evidence only for their stated environment and seeds. Desktop/emulator latency is not Pixel latency. Baseline wins do not establish strength against an experienced human. The remaining device test must use a physical Pixel 9a with airplane mode, Wi-Fi/Bluetooth off, cold launch, team import/save, full games, rotation and background/resume.
